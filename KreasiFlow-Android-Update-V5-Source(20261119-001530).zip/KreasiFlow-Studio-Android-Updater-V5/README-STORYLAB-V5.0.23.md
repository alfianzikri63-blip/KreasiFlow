# KreasiFlow 5.0.23 — ASAQ & ZAYN StoryLab (ZIP tunggal)

Source: KreasiFlow v5.0.22 dari arsip pengguna; fitur lama tidak diganti.
Tambahan:
- Modul `app/src/main/assets/storylab/` (ide/judul, narasi, storyboard, paket produksi)
- Tombol navigasi native **KreasiFlow** / **StoryLab** di toolbar atas aplikasi.
- Tidak mengubah pengaturan API, paket Android, kunci signing, updater, workflow, atau fitur lama.

## CARA UPDATE LEWAT HP TANPA EKSTRAK
1. Upload **arsip ZIP ini sebagai satu file** ke **root** repository `alfianzikri63-blip/KreasiFlow` di GitHub, dengan nama *persis* `KreasiFlow-Android-Update-V5-Source.zip`.
2. **Ganti** file ZIP yang sudah ada di repository (bukan upload berkas bernama `(2).zip`). Commit perubahan.
3. Actions -> **Test KreasiFlow APK Build from ZIP** -> Run workflow (atau tunggu otomatis setelah commit). Skrip GitHub Actions di repo akan unzip saat proses build.
4. Bila sukses, unduh artifact `Test-Debug-APK-Not-Updateable`, lalu unzip file artifact untuk mendapatkan `app-debug.apk`.
5. Debug adalah APK terpisah dari versi rilis. Gunakan untuk uji, bukan pengganti APK release resmi; jangan uninstall versi lama sebelum backup data.
6. Bila semuanya lulus, gunakan workflow **Publish Signed KreasiFlow APK from ZIP** dengan versi `5.0.23` dan keystore signing yang sama dengan APK rilis lama.

## BATASAN
- Belum menjalankan Android/Gradle build yang berhasil; integrasi dicek secara statis.
- Video MP4 dari HeyGen/Flow tidak dibuat otomatis oleh tombol lokal bila koneksi API/server video belum disetel.
- Google Flow dan AI Studio tetap membuka browser eksternal untuk login yang aman.
- Jika GitHub Actions gagal pada SDK sebelum kompilasi, perbaiki workflow SDK terlebih dahulu; itu masalah berbeda dari kebutuhan ekstrak ZIP.
- File ZIP ini sengaja memakai struktur satu folder `KreasiFlow-Studio-Android-Updater-V5/` supaya workflow build repo lama mengenalinya.
