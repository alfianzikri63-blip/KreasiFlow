# KreasiFlow V6.8.1

Basis kumulatif KF680. Versi `6.8.1`, version code `6008001`, package `id.kreasiflow.studio`.

- Beranda baru dengan cover penuh, pengelolaan proyek, dan akses studio serta galeri. Midnight Pro mendapat pilihan bertema dan pengaturan tema pindah ke Settings. Tema lama tetap tersedia.
- Story Studio memakai alur terpisah. Ide, naskah, dan dialog memanggil provider teks yang dikonfigurasi. Respons divalidasi sebelum ditampilkan atau dipakai.
- Galeri global menyimpan profil, referensi, dan hasil visual di IndexedDB. Formulir melayani teks, foto, naskah, serta manual. Permintaan Gemini yang menyertakan foto meminta persetujuan sebelum transfer.
- Multi VO membuat kartu dari pembicara, menyimpan rekaman per pembicara, membaca timestamp kata atau segmen, dan membentuk audio serta subtitle berdasarkan urutan dialog.
- Pengaturan produksi menyediakan lima rasio, 720p, 1080p, 2160p dengan pengecekan encoder, serta batas scene 4, 6, 8, atau 10 detik. Render Go otomatis tetap utama. Render Cepat V2 memakai engine fast decode lama.
- Audio Trimmer membaca waveform audio asli dan menyimpan potongan tanpa mengubah file sumber. Timeline Editor Pro opsional memuat footage dan trek audio serta subtitle.
- Hasil publikasi, konfigurasi OAuth, package ID, signing, dan workflow lama dipertahankan. Updater menyimpan versi yang telah dinotifikasi.

Cakupan implementasi dan batas pengujian dijelaskan dalam `IMPLEMENTATION_REPORT.md` dan `TEST_REPORT.txt`.
