# KreasiFlow V6.8.2

Paket kumulatif melanjutkan source KF682 awal yang berasal dari KF681. Versi aplikasi tetap `6.8.2`. Version code Android naik dari `6008002` ke `6008003`. ID rilis tetap `id.kreasiflow.studio`.

## Story Studio

- Template Instan menjadi pilihan awal. Galeri dua kolom memuat 20 kategori bergambar dengan 200 ide offline. Setiap ide mencakup judul, sinopsis, konflik, rekomendasi lokasi, genre, peran karakter, dan rekomendasi pengembangan. Peran mengikuti karakter pilihan pengguna.
- Pengguna dapat mencari ide, memilih kategori, mengacak hasil, memakai dan mengedit template, lalu mengembangkan ide menjadi naskah. Mode Standalone, Series, dan semua sudut pandang tetap tersedia.
- Generate Ide AI memakai satu panggilan ringkas, batas 1.050 token dan batas tunggu antarmuka 26 detik. Gemini memakai Flash-Lite. Provider lain memakai konfigurasi model yang tersedia untuk provider tersebut. Pengguna dapat membatalkan, mencoba lagi, dan memilih Template Instan.
- Hasil dari pengaturan tema sebelumnya ditandai sebagai ide lama. Validasi memeriksa lima ide unik, bentuk judul cerita, dan relevansi berdasarkan kata kunci dan alias. Tema Mancing Wader mengharuskan tiap ide membahas aktivitas memancing serta menyebut wader dalam sinopsis atau konflik.

## Durasi dan audio

- Pembagian scene mengikuti transkrip VO secara default. Pilihan sekitar 4, 6, 8, dan 10 detik mengarahkan pengelompokan scene. Durasi dapat melampaui target saat ucapan atau jeda perlu dipertahankan.
- Single VO mempertahankan panjang rekaman. Batch Character VO menyusun potongan dialog sesuai urutan scene dan timestamp. Pemrosesan mempertahankan jeda dalam rangkaian rekaman yang sama dan memakai transisi singkat saat berganti pembicara. Subtitle menyimpan identitas dialog jika tersedia.
- Timeline Editor Pro, Render Go, dan Render Cepat V2 memakai daftar batas waktu yang sama. File footage pendek menahan frame akhir di scene biasa. Pengambilan keputusan khusus proyek Smart Loop lama tetap tersedia.
- Audio Trimmer memakai waveform dari file asli. Handle dapat digeser di waveform atau lewat slider. Pilihan potongan bisa diputar dan digeser sambil mendengarkan. Fade, volume, loop, Auto Trim, dan reset memakai parameter nondestruktif.

## Aurora Pro

- Tema baru tersedia di Settings. Satu latar aurora memadukan ungu, biru, dan magenta dengan permukaan matte tanpa efek kaca.
- Pengguna dapat menyimpan preferensi animasi, intensitas gradasi, transparansi card, blur latar, dan mode hemat performa. Animasi berhenti selama playback dan render. Preferensi pengurangan gerakan sistem juga dihormati.
- Beranda menampilkan cover proyek dengan overlay judul, akses Smart Story Template Library, serta enam tab yang tetap terpisah. Midnight Pro, Aurora premium, Dark premium, dan AMOLED tetap ada.

## Kompatibilitas

- Skema penyimpanan dan data proyek lama dipertahankan. Timeline manual lama yang masih sesuai dengan durasi dan isi proyek dapat dibuka dengan trim yang tersimpan.
- Konfigurasi signing dan dua workflow yang disertakan dalam source dasar tetap identik. Gradle menetapkan version code minimum 6008003 untuk versi 6.8.2, termasuk saat workflow memasok kode semver sebelumnya.
- Updater memeriksa tag rilis dengan nomor versi lebih tinggi. Pemasangan APK pembaruan, verifikasi sertifikat perangkat, dan eksekusi GitHub Actions perlu diuji pada lingkungan rilis.
