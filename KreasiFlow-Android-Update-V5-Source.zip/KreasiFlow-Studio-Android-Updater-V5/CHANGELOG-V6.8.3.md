# KreasiFlow V6.8.3

Update kumulatif dari KF682 terakhir. Package aplikasi rilis tetap `id.kreasiflow.studio`. `versionCode` minimum naik ke `6008004` dan version name menjadi `6.8.3`.

## AI dan alur produksi

- Generate Ide Short dan Story Studio memakai permintaan yang terpisah dari naskah dengan target lima hasil dan penanda ide dari tema lama.
- Jalur utama Generate Naskah dan Dialog menggabungkan naskah Story 60 detik menjadi satu request pada Balanced dan Quality. Naskah lebih panjang tetap dapat dibagi agar output lengkap. Standalone tidak mengirim riwayat episode. Series mengirim bagian terbaru dari memori.
- Fast, Balanced, dan Quality mengatur batas tunggu, panjang referensi, ukuran batch, dan ruang output. Provider aktif tetap dipilih pengguna. Model Gemini dan OpenRouter dapat dipilih di Settings.
- Permintaan teks terkelola memiliki batas waktu HTTP dan WebView, satu pekerjaan aktif, maksimal dua retry sementara per pekerjaan, serta pembatalan koneksi jika provider masih memproses. Error autentikasi, rate limit, model, timeout, jaringan, dan respons tidak lengkap dibedakan.
- OpenRouter memakai streaming untuk naskah narasi polos pada jalur terkelola. Naskah diterapkan setelah aliran lengkap dan lolos validasi.
- Panel status utama menampilkan waktu aktual, provider, model, tahapan, percobaan ulang, dan jumlah scene yang tersimpan. Settings memiliki tes koneksi, salin log bebas data sensitif, dan refresh cache.
- Pembagian storyboard tetap lokal. Gemini dan NVIDIA dapat memproses hingga dua batch sekaligus. Batch lain tetap berurutan. Cache per scene menyimpan hasil yang sudah valid dan mempertahankan hasil sukses saat ada batch gagal.
- Audio dan Scene tetap dapat dibuka. Aksi produksi memeriksa naskah atau dialog terlebih dahulu dan membedakan naskah hilang, gagal, diproses, berdialog, atau visual tanpa ucapan.

## Produksi, audio, dan tampilan

- Perbaiki Loop Otomatis mengusulkan pasangan kalimat akhir dan awal lewat AI. Pengguna melihat preview dan mengonfirmasi sebelum naskah diubah. Isi tengah tetap dipertahankan. VO lama disimpan dan perlu disinkronkan ulang bila naskah berubah.
- Batch Character VO tetap menyusun potongan per pembicara, dengan konfirmasi internal saat memakai hasil sinkronisasi. Opsi salin intonasi mengenali emosi dialog dan mode teks polos untuk model tanpa audio tags.
- Scene otomatis memakai transkrip dan mengurangi potongan yang terlalu singkat karena tanda baca. Preferensi 4, 6, 8 dan 10 detik tetap lentur. Render Go, Render Cepat V2, Timeline Editor Pro, dan Audio Trimmer memakai durasi VO.
- Panel naskah Short menggabungkan edit dan impor teks ke satu naskah utama. Tombol draf lokal duplikat, suara browser, dan override tambahan dikeluarkan dari formulir utama. Naskah tempel dan draf lokal utama tetap tersedia.
- Konfirmasi utama yang disentuh memakai dialog HTML sesuai tema. Dialog WebView lama memakai judul KreasiFlow tanpa menampilkan domain host.
- Aurora Pro matte, enam tab, galeri visual offline, Music Library, dan 200 template offline dipertahankan. Panel status AI mengikuti aksen tema.
