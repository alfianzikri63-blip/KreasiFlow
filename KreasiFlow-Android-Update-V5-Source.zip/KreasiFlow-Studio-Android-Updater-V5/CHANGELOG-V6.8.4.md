# KreasiFlow V6.8.4

Smart Voice & Audio Synchronization Update. Paket kumulatif dari KF683 terakhir. Package ID rilis tetap `id.kreasiflow.studio`. Version name `6.8.4` dan version code minimum `6008005`.

## Audio dan subtitle

- Batch Character VO memakai pencocokan lokal berdasarkan urutan, timestamp dan tingkat kecocokan teks. Variasi seperti ngetok dan mengetuk, nengok dan menengok, enggak dan nggak, serta udah dan sudah dinormalisasi. Negasi dan angka mendapat perlakuan lebih ketat.
- Dialog atau cue tambahan yang perlu diperiksa ditandai satu per satu. Hasil transkripsi yang berhasil tetap tersimpan.
- Panel koreksi menampilkan dialog, hasil transkrip, waktu, tingkat kecocokan dan status. Pengguna dapat mendengarkan rentang, memakai teks dialog asli, mengoreksi teks dan waktu, menggabungkan atau memisahkan cue, dan menyimpan perubahan. Audio sumber tetap utuh.
- Penyusunan ulang VO memakai satu rekaman per pembicara. PCM dalam rentang jeda dan nonverbal ikut dipertahankan. Subtitle hanya memakai teks dan batas ucapan. Timestamp hasil verifikasi dipakai pada timeline dan payload render tanpa batas 10 detik per scene.
- Render cerita berdialog meminta VO dan subtitle bertimestamp yang siap. Cerita visual tanpa dialog tetap dapat diproses.

## Ekspresi dan proses transkripsi

- Smart VO Director memakai emosi dialog, situasi, ekspresi, dan dialog di sekitarnya. Perubahan emosi dapat terjadi di kalimat berikutnya. Koreksi per dialog tersedia secara opsional.
- Model Eleven v4 dan v3 memakai arahan tag saat teks disalin. Opsi model lain menyalin teks bersih. KreasiFlow tidak mengubah audio hasil ElevenLabs. Uji dalam paket ini menilai teks yang disalin.
- Emosi yang sama dipakai untuk konteks VO dan arahan ekspresi di prompt visual serta storyboard. Respons naskah terstruktur dapat mengisi intensitas, atmosfer, dan perubahan emosi tanpa panggilan AI tambahan.
- Transkripsi Single VO, per karakter, semua karakter, dan transkripsi ulang memakai panel proses terpusat. Panel menampilkan nama pembicara, model, durasi, waktu proses, status, dan jumlah karakter selesai. Status menunggu provider bersifat indeterminate jika persentase tidak tersedia.
- Pembatalan terhubung ke koneksi Android yang dikelola. Retry sementara dibatasi. Karakter yang sudah sukses tidak dikirim ulang saat melanjutkan batch yang gagal.
- Panel Audio memperkecil thumbnail dan tetap menyediakan tampilan referensi lengkap. Aurora Pro, Midnight Pro, dan tema lama dipertahankan.
