# KreasiFlow V6.8.5

- Render Go dan Render Cepat V2 menggunakan konversi warna H.264 yang lebih efisien dengan keluaran YUV bit-identik pada fixture. Pemilihan encoder memprioritaskan hardware yang melaporkan dukungan resolusi, FPS, dan input YUV.
- Render menggunakan kembali aset temporer yang masih valid untuk sumber dan transformasi yang sama. Mixing menggunakan PCM bertahap tanpa salinan rata dan dapat menggunakan ulang PCM footage berulang dalam batas cache.
- Status render menampilkan tahap aktual, waktu berjalan, frame yang tertulis, scene, nama encoder, akselerasi, dan kecepatan aktual. Estimasi hanya muncul untuk sisa tahap video saat data pengukuran mencukupi.
- Pembatalan tersedia pada status aplikasi dan notifikasi Android. Penyimpanan MP4 memeriksa pembatalan sebelum membuka hasil kepada aplikasi lain.
- Warna progress berasal dari tema aktif. Aurora Pro memakai track #252A3D dan aksen #8B5CF6/#A78BFA. Animasi aurora dijeda selama ekspor.
- Render memakai nama engine aktual. Pesan Smart Loop berulang dibersihkan dari halaman Render, dan logika loop tetap tersedia.
- Fallback ekspor browser mengikuti timestamp subtitle. Status ekspor browser memakai indikator tahapan tanpa persentase sintetis.
- Versi 6.8.5 memakai versionCode minimum 6008006, application ID `id.kreasiflow.studio`, serta signing dan workflow yang dipertahankan dari V6.8.4.
