# KreasiFlow V6.8.6 · Render Engine Performance Recovery

- Render Go dan Render Cepat V2 mencoba jalur MediaCodec → SurfaceTexture → OpenGL ES → encoder AVC hardware untuk footage atau still yang kompatibel. Jalur bitmap KF685 masih tersedia untuk kombinasi yang memerlukan kompatibilitas.
- Decoder membaca frame maju melalui satu sesi per klip. Seek awal hanya digunakan ketika trim meminta bagian yang jauh dari awal klip. Frame sumber yang dilewati tidak perlu dikirim ke tekstur. Still yang kompatibel diunggah sekali per scene.
- Crop/Fit, zoom/slide, fade, flash/dip, subtitle dan watermark dapat dikomposisikan ke encoder surface. Tekstur subtitle hanya diperbarui saat tampilan cue berubah. Frame Blend, dissolve, outro, dan jenis lain yang memerlukan jalur bitmap tetap berjalan melalui fallback.
- Render memeriksa jumlah frame hasil encoding serta ukuran dan durasi trek video sebelum menyimpan MP4. Jika jalur surface gagal, hasil sementara dibersihkan sebelum encoding kompatibilitas dimulai.
- Statistik memuat jalur yang dipakai, decoder, waktu decoding, waktu tunggu surface, pengiriman perintah GL, upload subtitle, waktu encoder, mux, finalisasi, dan statistik GC proses saat tersedia.
- Perbaikan progress/tema V6.8.5, jalur remux, sinkronisasi VO, konfigurasi signing dan workflow tetap tersedia. Versi 6.8.6 memakai versionCode minimum 6008007.
