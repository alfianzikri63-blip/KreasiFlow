# V6.8.7 – Baseline render recovery candidate
- Actual supplied APK manifest: 5.1.27, versionCode 5001027, package id.kreasiflow.studio. Its embedded index.html defaults to 540p, 30 FPS, fastRender true; KF686 defaults to 1080p, 30 FPS, fastRender true.
- Render Go previously unconditionally set fastRender=false, disabling the existing bounded batch decoder on bitmap fallback. It now respects the saved optimization option; Render Cepat V2 enables it. Surface renderer remains unchanged.
- Explicit resolution/FPS controls on Render, including 540p baseline; existing project resolution is not automatically changed. Advanced selector now includes 1080p and 2160p.
- Render engine label is separate from the decode optimization flag. Native statistics include actual output dimensions and FPS.
- Version 6.8.7 / 6008008. Signing, application ID, workflow unchanged.
- Tests: 380 Node tests passed (including three new source-contract tests; ten version assertions updated). No Android build, device benchmark or native performance validation performed. Exact 5.1.27 Java source and DEX decompiler unavailable locally; no claim of native legacy pipeline restoration. 5.1.28 source is not treated as exact baseline.
- 540p has one quarter of 1080p pixels for same aspect ratio; actual old project settings remain unknown. Test both APKs with same footage, output dimensions, FPS, effects and audio. Test Render Go and Render Cepat V2 separately. Copy statistics after completion. Verify full duration and visual/audio/subtitle quality. Six-minute target remains unverified.
