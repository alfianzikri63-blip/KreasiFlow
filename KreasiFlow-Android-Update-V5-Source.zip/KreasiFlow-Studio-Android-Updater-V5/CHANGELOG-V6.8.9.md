# KreasiFlow V6.8.9 — Smart Content Director

- Short Studio memakai satu dropdown Jenis Konten dengan 14 pilihan. Otomatis sesuai judul menjadi pilihan awal. Struktur konten lama dipetakan untuk proyek yang sudah menyimpannya.
- Deteksi lokal mengenali daftar, ranking, mekanisme, sains, dokumenter, reka ulang, recap, analisis karakter, What If, perbandingan, misteri, dan storytelling. Respons AI dapat memperjelas judul dengan konteks lokal yang belum cukup.
- Tambah pengaturan kontekstual, pilihan kesetiaan sumber, pemilih versi adegan, referensi tambahan, pengarahan VO otomatis dan panel kualitas naskah.
- Daftar dan reka ulang menyimpan identitas objek, bagian narasi dan konteks yang relevan untuk storyboard. Alur generate menggunakan satu permintaan pada respons valid dan membatasi koreksi struktur.
- Gemini dapat mencoba mengakses URL publik dari Referensi Tambahan. Status akses dicatat dari metadata provider.
- Render engine, pipeline media dan konfigurasi rilis tetap sesuai KF688. Release 6.8.9 / 6008010.
