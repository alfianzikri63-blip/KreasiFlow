# KreasiFlow v5.0.29 — Progress Bar Auto Produksi AI

## Perubahan

- Progress bar untuk tombol **Generate judul sampai gambar** (juga dipakai alur **Uji otomatis sampai 1 klip AI** saat tahap judul-gambar).
- Tahap produksi yang ditampilkan:
  1. Permintaan judul (0% → 20% setelah berhasil)
  2. Naskah & narasi (20% → 45% setelah berhasil)
  3. Storyboard + prompt gambar & gerak (45% → 80% berdasarkan batch prompt yang selesai)
  4. Gambar AI (80% → 100% menurut jumlah gambar yang berhasil dari target)
- Saat memilih `0 gambar` sebagai mode hemat, progres 100% berarti **judul, narasi, storyboard, dan prompt saja** selesai, bukan gambar/video sudah dibuat.
- Panel progres tersedia di bawah tombol Auto Produksi dan sebagai indikator di atas konten; tetap terlihat saat aplikasi pindah ke tab Scene.
- Menampilkan jumlah gambar berhasil dan gagal. Proses parsial berhenti dengan status berbeda dari sukses penuh.
- Timeout/gagal menampilkan tahap yang terhenti, menyimpan hasil yang sudah dibuat, dan tidak memaksakan progres menjadi 100%.
- Tombol Generate ditahan selama pekerjaan berlangsung agar pengguna tidak menggandakan permintaan.
- Hapus konfirmasi ganda untuk batch gambar yang dijalankan oleh Auto Produksi, tetapi pertahankan konfirmasi saat pengguna menjalankan pembuatan gambar manual.

## Catatan keakuratan

Persentase adalah **checkpoint hasil yang telah berhasil diselesaikan** — bukan perhitungan sisa waktu. Selama menunggu permintaan AI, persentase bisa diam beberapa saat. Stage prompt naik hanya setelah batch prompt yang sesuai berhasil disimpan. Pembuatan suara melalui AI Studio dan rendering MP4 tidak termasuk persentase bar judul→gambar.

## Verifikasi

- Pemeriksaan sintaks JavaScript utama (`node --check`) lulus.
- `tests/auto-progress.test.cjs` lulus, memeriksa status, monotonic progress, hitung gagal, proteksi klik ganda dan tanpa konfirmasi batch kedua.
- Tes scene planner dan continuity yang tersedia sebelumnya lulus.
- Tidak ada build APK dan tes panggilan provider AI nyata di Android dalam lingkungan ini; wajib uji setelah menjalankan GitHub Actions.

## Update via GitHub

Upload ZIP bagian dalam dengan nama **KreasiFlow-Android-Update-V5-Source.zip** di root repo lama `alfianzikri63-blip/KreasiFlow`, lalu jalankan workflow `Test KreasiFlow APK Build from ZIP`. Jangan upload ZIP luar ke workflow tersebut.
