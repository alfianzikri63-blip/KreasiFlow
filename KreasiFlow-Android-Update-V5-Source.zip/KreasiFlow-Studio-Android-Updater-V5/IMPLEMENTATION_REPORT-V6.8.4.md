# Audit dan implementasi KreasiFlow V6.8.4

## Akar masalah yang terverifikasi pada KF683

1. Batch VO memakai perbandingan teks persis setelah mengubah kapitalisasi dan tanda baca. Mesin menganggap variasi percakapan seperti ngetok dan mengetuk berbeda, lalu melempar error sebelum menyimpan cue pembicara tersebut. Jalur penggabungan mengulang validasi ketat yang sama.
2. Arah VO otomatis terutama memakai preset karakter, label emosi, atau tanda baca. Tanda seru dapat memicu arahan berenergi saat adegan seharusnya takut. Konteks visual dan dialog di sekitar kalimat belum menjadi satu sumber arahan.
3. Tombol transkripsi karakter memakai pesan status lokal dan belum terhubung ke indikator pekerjaan generasi. Native tracker HTTP hanya mencatat permintaan teks. Transkripsi multi-pembicara dapat terhenti saat pembicara pertama gagal.
4. Penyusunan PCM lama mengekstrak hanya batas ucapan yang cocok. Suara sebelum atau sesudah kata, terutama ketika pembicara berbeda, dapat tertinggal. Subtitle dan potongan PCM kini memiliki batas terpisah.

## Implementasi

| Bagian | Perubahan |
| --- | --- |
| Pencocokan | Kandidat berurutan dengan skor token dan ejaan ringan, alias percakapan, perlindungan negasi dan angka. Cue tidak dipecah secara otomatis jika batas antar-dialog tidak tersedia. |
| Koreksi | Edit teks, timestamp, play, gabung/pisah cue, rematch, gunakan teks naskah, dan verifikasi eksplisit. Hasil disimpan dengan aset pembicara di IndexedDB. |
| Audio | Partisi per pembicara mempertahankan seluruh sampel pada file asli dalam susunan baru. Jeda antarucapan dari pembicara yang sama ikut pada ujung dialog sebelumnya. Subtitle bersih memakai batas ucapan. |
| Pekerjaan transkripsi | Panel terpusat, hitungan karakter selesai, kontrol batal dan ulang. Timeout dikirim ke native bridge. Gagal transkripsi tidak menimpa cue yang sudah ada. |
| Model suara | Tag untuk Eleven v4/v3, teks bersih untuk pilihan model lain. Teks dan arahan ekspresi dibuat tanpa request TTS. Identitas suara mengikuti satu rekaman setiap pembicara. |
| Konteks | Naskah terstruktur dapat menyimpan emosi, intensitas, cara bicara, ekspresi visual dan atmosfer dalam satu respons. Untuk sumber lama, arahan bisa dihitung ulang secara lokal berdasarkan scene. |
| Kompatibilitas | Package ID, konfigurasi signing, workflow, aset visual dan musik bawaan, Content Store, serta akses proyek yang disalin dari KF683 dipertahankan. |

## Batas implementasi dan pengujian

- Cue segment-only Gemini untuk Batch VO diperlakukan sebagai perkiraan sampai diverifikasi. Segment tunggal yang berisi lebih dari satu dialog membutuhkan batas waktu dari pengguna atau transkrip word-level. Persentase kecocokan merupakan skor heuristik, bukan jaminan makna atau ketepatan timing.
- Ucapan tambahan dapat disetujui setelah didengar dan dipertahankan di audio tanpa caption, atau diperbaiki melalui rentang dialog. Efek nonverbal tidak dicetak pada subtitle.
- Pembatalan request menghentikan penantian dan memanggil disconnect pada bridge Android. Layanan eksternal dapat tetap memproses request yang sudah diterima. Batch mempertahankan hasil lintas tab. Pemulihan pekerjaan aktif setelah force-stop belum diverifikasi.
- Pengujian render memeriksa timeline, audio dan subtitle di Chromium serta payload native. APK, sertifikat, action publish, Android WebView dan encoding native belum bisa dijalankan dalam lingkungan ini.
- Hasil laporan pengguna tentang 8 detik pada Gemini KF683 digunakan sebagai catatan perangkat, tanpa pengukuran live pembanding pada KF684.

## Referensi kompatibilitas

- Perilaku audio tags Eleven v3 dan v4. https://elevenlabs.io/docs/help-center/product/core-capabilities/text-to-speech/how-do-audio-tags-work-with-eleven-v3-and-v4
- Model transkripsi dan timestamp Scribe. https://elevenlabs.io/docs/overview/models
