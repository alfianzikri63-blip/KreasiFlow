# Audit regresi render KreasiFlow V6.8.5

## Baseline

Baseline utama adalah KF670.zip (V6.7.0, code 6007000), arsip source yang mendahului rangkaian V6.8.0 hingga V6.8.5 di percakapan ini. Arsip source resmi V6.6.0 pada commit `9bb2309806ca35529210103786041d3c1e9f21ab` memiliki lima file inti render yang identik dengan V6.7.0. Pemeriksaan V6.8.3 hanya digunakan untuk melokalisasi perubahan. Lima file inti tersebut identik antara V6.8.3 dan V6.8.4, sehingga perubahan di luar file inti masih dapat memengaruhi waktu aktual.

| File | V6.7.0 / V6.6.0 SHA-256 (awalan) | V6.8.4 SHA-256 (awalan) |
| --- | --- | --- |
| NativeVideoRenderer.java | c210ee5f7e55 | da4a67cfd159 |
| NativeAudioMixer.java | cba6f25ab100 | e87716f2e1fb |
| RenderForegroundService.java | a06e69efc52e | c520bc87488d |
| FastFrameReader.java | 77c202bc5909 | 77c202bc5909 |
| SmartRemux.java | dfd4bd0de7f7 | dfd4bd0de7f7 |

## Temuan source dan keputusan

| Area | Perubahan atau biaya yang ditemukan | Implementasi V6.8.5 |
| --- | --- | --- |
| Pemilihan encoder | V6.7.0 dan V6.8.4 keduanya meminta encoder default untuk AVC. Perubahan encoder yang terpilih di perangkat belum terbukti. V6.8.4 juga menambah pemeriksaan kemampuan resolusi/FPS sebelum inisialisasi encoder. | Satu seleksi codec per render. Calon encoder H.264 yang kompatibel diprioritaskan berdasarkan akselerasi hardware. Jika inisialisasi calon gagal, seleksi mencoba calon berikutnya. Resolusi, FPS, interval keyframe, dan rumus bitrate dipertahankan. |
| Decoding footage | FastFrameReader dan SmartRemux identik. Jalur Go dan Cepat V2 tetap menggunakan pilihan pembacaan frame masing-masing. Kedua versi lama bisa membuka bitmap still untuk scene yang akhirnya memakai footage. | Bitmap still hanya dibuka saat scene memerlukannya. Metadata FPS disimpan per sumber dalam satu render. Batch reader, fallback pembacaan frame, dan aturan kelayakan remux tetap berlaku. |
| VO dan mixing | V6.7.0 memiliki transcode bertahap untuk VO slideshow tanpa mixing. V6.8.4 membawa jalur itu ke mixer PCM untuk menerapkan gain. Agregasi buffer dan salinan PCM meningkatkan kebutuhan heap pada audio panjang. Perubahan voicing V6.8.4 juga dapat menjaga lebih banyak jeda sehingga beberapa proyek memiliki durasi aktual lebih panjang. | PCM disimpan dalam blok tanpa salinan ke array rata. PCM footage berulang disimpan sementara hingga pemakaian terakhir dengan batas 12 MiB. Mixing, gain, subtitle, dan jeda VO tetap dipertahankan. Jalur streaming lama belum dipulihkan karena kesetaraan gain, resampling, dan durasi output belum terbukti. |
| Encoding dan komposisi | Konversi Java membaca komponen warna beberapa kali. Pencarian scene, subtitle, layout teks, dan gradien juga dapat berulang setiap frame. | Luma dan chroma dihitung bersama per blok 2×2 dengan matriks dan pembulatan yang sama. Pencarian scene memakai batas terurut. Pemindaian subtitle bergerak maju dan layout teks serta gradien dipakai ulang saat sama. |
| Persiapan dan penyimpanan | ID VO, musik, dan sebagian still dibuat ulang saat render berikutnya. Batas 12.000 karakter pada konfigurasi moving render dapat menolak proyek dengan banyak scene/cue. | Cache aset immutable per proyek dan parameter transformasi, validasi file native, batas 128 MiB dan 110 item serta pembersihan file sementara. Snapshot antrian menyertakan aset yang dipakai dan menerima konfigurasi yang lebih besar dalam batas ukuran dan validasi payload. |
| Operasional | Perkiraan persentase tahap sebelumnya kurang informatif. Animasi tema tetap menjadi biaya antarmuka. | Status mengukur frame yang sudah masuk muxer. Status membedakan persiapan, encoding, mixing, mux, penyimpanan, lambat atau belum ada kemajuan. Aturan timeout codec lama dan wake lock foreground tetap tersedia. Pembatalan bergantung pada codec atau I/O kembali ke loop yang dapat mengamati sinyal. |

Kenaikan biaya dari buffer audio dan transfer ulang dapat dijelaskan dari source. Besar dampaknya pada total render pengguna belum terukur. Kecepatan decode atau encode hardware tidak dapat diturunkan dari benchmark Java maupun ekspor Chromium.

## Pengukuran Android yang masih dibutuhkan

Gunakan `python tests/android-render-fixture-685.py prepare /tmp/fixture` untuk menghasilkan 15 footage AVC, satu WAV, satu SRT, dan SHA-256 setiap file. Durasi 30 detik, masing-masing scene 2 detik. Atur ketiga versi ke 540 × 960, 30 FPS, 9:16, Crop, tanpa frame blend, transisi, outro, musik, loop atau audio footage, dengan VO 100% dan subtitle klasik. Target bitrate AVC dari rumus source adalah 2.221.714 bps. Periksa bitrate dan durasi output aktual.

Lakukan tiga ulangan per engine, per versi, pada perangkat yang sama dengan kondisi suhu, daya, layar dan ruang kosong yang sebanding. Gunakan salinan proyek uji yang bisa dipulihkan untuk berpindah versi. Uji ekspor pertama dan ekspor ulang secara terpisah karena cache hanya berlaku untuk media yang sudah ditransfer dan masih valid. Catat waktu proses sejak tekan tombol hingga file tampil, decoder/encoder yang dipilih, waktu tiap tahap dari log, puncak PSS dari sampel `adb shell dumpsys meminfo id.kreasiflow.studio`, ukuran file, dan playback. V6.8.5 menyediakan tombol Salin statistik yang menyertakan sampel heap Java, output bytes, serta waktu internal. Ukur versi lama dengan pencatat eksternal, atau build uji tambahan yang hanya memberi pencatat waktu.

Jalankan `python tests/android-render-fixture-685.py inspect /path/video.mp4` untuk memeriksa metadata dan awal sinyal audio pada setiap scene. Bandingkan kualitas antaroutput pada timestamp yang sama dengan SSIM dan pemeriksaan visual. Ukur kapan subtitle muncul dan hilang di sekitar timestamp SRT. Lakukan uji layar terkunci secara terpisah untuk kedua engine dan verifikasi playback setelah file tersimpan.
