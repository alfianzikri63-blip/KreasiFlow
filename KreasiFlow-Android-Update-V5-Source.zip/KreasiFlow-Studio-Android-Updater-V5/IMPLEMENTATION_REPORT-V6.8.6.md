# Audit regresi dan pemulihan pipeline render

## Baseline dan bukti perangkat

KF670.zip (V6.7.0, versionCode 6007000) adalah baseline source sebelum rangkaian V6.8.x di percakapan ini. Tidak ada MP4 atau log dari percobaan enam menit yang mengonfirmasi versi APK, panjang proyek, pengaturan render, codec, atau kondisi perangkat. Waktu enam menit dicatat sebagai observasi pengguna. Nilai V6.8.5 pada perangkat pengguna: 15 scene, 2.618 frame, throughput 3,3 FPS dan encoder hardware `c2.mtk.avc.encoder`. Estimasi 2.618/3,3 detik adalah sekitar 13 menit 13 detik untuk tahap video pada laju tersebut. Estimasi ini bukan waktu ekspor yang selesai. Untuk 2.618 frame dalam enam menit, tahap video saja perlu sekitar 7,27 FPS dan tahap lainnya masih memerlukan waktu.

## Perbandingan source langsung

| Komponen | KF670 → KF684 → KF685 | Dampak yang dapat ditetapkan dari source |
| --- | --- | --- |
| Pembacaan frame Render Go | Ketiganya memakai `MediaMetadataRetriever.getScaledFrameAtTime(..., OPTION_CLOSEST)` ketika frame sumber berubah. | Encoder yang terakselerasi tidak menghilangkan seek/extraction frame dan salinan frame. Jalur ini sudah ada pada baseline. Bukti yang tersedia belum menunjukkan kenaikan waktu komponen ini di perangkat pengguna. |
| Pembacaan frame Render Cepat V2 | `FastFrameReader.java` identik ketiganya (SHA-256 diawali 77c202bc5909). Batch dibatasi delapan gambar dan 24 MiB. Jika metadata/frekuensi frame tidak sesuai atau batch gagal, pemanggil kembali ke ekstraksi timestamp. | Preset cepat tetap dapat jatuh ke jalur bitmap. Belum ada jumlah batch yang berhasil dari percobaan pengguna. |
| Ukuran output dan timeline | Batas native V6.7.0 adalah 1.280 px per sisi. V6.8.4 membuka dimensi hingga 5.040 px dengan pemeriksaan codec. Dynamic duration, trim, dan perubahan penempatan VO dapat menaikkan jumlah frame. Pemetaan scene lebih panjang dari footage juga berubah sejak baseline. | Resolusi, jumlah frame, atau durasi proyek bisa memperbesar beban. Pengaturan proyek lama belum tersedia sehingga dampaknya belum terbukti. |
| Komposisi dan encoder | Ketiganya menggambar bitmap dengan Canvas lalu `getPixels → ARGB/YUV → MediaCodec ByteBuffer/Image`. V6.8.5 mengoptimalkan packing dan memilih hardware yang melaporkan dukungan. | GPU encoder dapat menunggu jalur produksi frame berbasis CPU. V6.8.5 tidak menghapus alur baca ulang piksel. Perubahan codec default ke pilihan hardware eksplisit bisa memengaruhi laju, namun encoder V6.7.0 belum diketahui. |
| Audio dan penyimpanan | V6.7.0 memiliki jalur transcode streaming VO untuk slideshow. V6.8.4 memakai mixer agar gain, SFX dan penyesuaian timeline efektif. KF685 mengurangi salinan PCM dan transfer ulang aset. | Menambah biaya audio dan heap pada kasus yang relevan. Proses audio yang terjadi setelah encoding tidak menjelaskan throughput video 3,3 FPS dengan sendirinya. |
| Remux | `SmartRemux.java` identik (SHA-256 diawali dfd4bd0de7f7). Remux hanya berlaku ketika pengaturan dan trek kompatibel, misalnya tanpa subtitle dan tanpa perubahan frame. | Belum ada bukti bahwa proyek enam menit berjalan melalui remux. V6.8.6 mempertahankan pemeriksaan kelayakan dan menguji durasi trek yang dirakit. |

Kesimpulan yang didukung: ekstraksi per frame dan komposisi bitmap tetap merupakan pekerjaan pada jalur kritis yang tidak dipercepat oleh encoder hardware. Benchmark host mengisolasi biaya seek berulang. Akar penyebab selisih enam dan tiga belas menit untuk proyek Android pengguna belum terisolasi karena tidak ada pengukuran berpasangan pada perangkat.

## Pemilihan jalur render di KF686

1. Remux ketika opsi Smart Render aktif dan seluruh pemeriksaan yang ada lulus.
2. Surface saat codec AVC hardware dapat menerima input surface dan media/efek kompatibel. MediaExtractor memberi sampel maju ke decoder hardware. SurfaceTexture meneruskan frame pilihan sebagai tekstur OES. EGL memberi timestamp yang sama dengan kalkulasi output bitmap. Untuk still, bitmap satu scene diunggah sekali ke tekstur dan kemudian dilepas. Subtitle diraster ke area transparan yang dipakai ulang dan dipertahankan di GPU selama cue teksnya sama. Gaya subtitle termasuk karaoke tetap memakai timestamp cue yang sama.
3. Bitmap KF685 ketika pipeline surface gagal atau proyek memerlukan warna/rotasi yang di luar jalur surface, perpindahan sumber di dalam scene, outro, dissolve, Frame Blend, atau seam loop berbasis still. Proyek dengan file still valid dapat memakai jalur surface. Jalur fallback memulai encoding dari awal jika percobaan surface sempat mulai. Waktu percobaan yang dibuang disimpan sebagai `abandonedSurfaceMs`.

Kedua encoder berbagi dimensi, FPS, rumus target bitrate, dan interval keyframe. Seluruh jalur video menggunakan versi mixer dan mux yang sama sehingga Single VO, Batch Character VO, musik dan SFX tetap memakai timeline produksi. Smart Direct Loop semua-motion memakai pemetaan endpoint yang sama. Proyek yang meminta efek yang belum ditangani GPU memilih renderer kompatibilitas. Warna GPU pada driver vendor dan visual native tetap perlu diperiksa dengan footage pengguna.

## Arti statistik

- `uiPrepareMs` untuk persiapan media sebelum handoff, `prepareMs` dan `videoSetupMs` untuk persiapan layanan/encoder, `frameSetupMs` untuk pembukaan decoder atau pembuatan aset scene.
- `decodeMs` untuk waktu panggilan ekstraksi atau decoding/antrean frame, dengan `textureLatchMs` sebagai bagian dari waktu ini. `retrieverCalls` menghitung permintaan fallback timestamp, `decodedFrames` dan `latchedFrames` tersedia untuk surface.
- `canvasCompositionMs` meliputi scaling, Crop/Fit, efek dan gambar subtitle pada bitmap. `bitmapAllocationMs` mengukur alokasi bitmap utama, `bitmapReadbackMs` dan `colorPackMs` mengukur salinan/pengemasan jalur CPU. Alokasi internal Android saat decode berada dalam waktu operasi pemanggilnya.
- `subtitleMs`, `subtitleUploads` dan `stillUploadMs` mengukur pekerjaan subtitle/transfer tekstur yang bisa diamati thread render. `glSubmitMs` meliputi pengiriman komposisi GPU selain subtitle. `surfaceSwapMs` juga bisa meliputi antrean encoder. Durasi GPU-eksekusi, scaling/cropping GPU dan transfer internal codec tidak diukur secara eksklusif. Kolom yang tumpang tindih tidak boleh dijumlahkan untuk menghitung total.
- `encoderInputMs`, `encoderOutputMs`, `muxWriteMs`, `audioMs`, `muxMs`, `videoFinalizeMs`, `validationMs` dan `publishMs` membedakan langkah yang diobservasi. Sampel heap Java dan GC adalah metrik proses, bukan puncak PSS per tahap. Catat PSS dan eksekusi GPU dengan alat perangkat jika diperlukan.

Dokumentasi API yang dipakai: https://developer.android.com/reference/android/graphics/SurfaceTexture.html
