# Implementasi Smart Content Accuracy & Title Alignment

Baseline tunggal adalah KF687.zip yang dilampirkan, SHA-256 `4f58d206a0d815a89e13efdc6c134fbe3501a407d6ab06299a993b16e5e53dcb`. Source diekstrak langsung dari ZIP dalam. Tidak ada penggabungan KF686 revisi lama, pemulihan dari APK V5.1.27 atau perubahan mekanisme render.

## Alur naskah

- Modul `content-accuracy-688.js` mengenali bentuk daftar, peringkat, fakta, cara kerja, proses ilmiah, sejarah, perbandingan, biografi, misteri, edukasi, atau storytelling dari judul. Aturan struktur berbeda menurut jenis. Model memperoleh judul terpilih dan preferensi gaya tutur yang diberi batas peran. Tema acak tidak ikut menjadi instruksi generasi naskah.
- Judul daftar meminta pembuka, array objek bernama dan uraian, penutup, serta klaim yang perlu diperiksa. Semuanya berasal dari satu request saat jawaban valid. VO dibuat dari urutan yang sama dan memasukkan nama objek yang belum disebut dalam uraian.
- Validasi lokal memeriksa jumlah, bentuk dan duplikasi nama, panjang dan pengulangan uraian, objek kategori utama, urutan, relevansi mekanisme, indikasi rujukan yang tidak didukung dan pengulangan pembuka/penutup. Validasi jumlah kata memberi catatan toleransi agar naskah faktual tidak dipenuhi pengulangan. Kegagalan syarat inti memicu paling banyak satu request koreksi semantik. Kebijakan retry transport baseline tetap berlaku untuk permintaan awal.
- Catatan klaim yang perlu diperiksa muncul di bagian naskah. Kutipan faktual yang ditempel pengguna dapat dijadikan konteks. Integrasi provider pada KF687 belum menyediakan hasil web grounding dan metadata sumber yang bisa divalidasi. Update ini tidak menambahkan pencarian eksternal otomatis; pemeriksaan lokal tidak dapat memastikan kebenaran fakta atau peringkat dunia.
- Nama objek dan snapshot judul/naskah disimpan bersama proyek. Jika judul berubah saat naskah lama masih aktif, Generate Scene meminta regenerasi naskah. Prompt scene yang baru memakai pemetaan lokal nama ke potongan narasi atau transkrip. Batch yang menukar objek ditolak sebelum cache atau scene lama diganti. Prompt visual eksternal tetap perlu diperiksa pada hasil gambar/video.
- Jalur pembuatan naskah Short Studio dan produksi otomatis menggunakan pemeriksa yang sama. Naskah manual dan proyek lama masih bisa dibuka. Kunci daftar otomatis berlaku pada naskah baru yang menyimpan struktur daftar. Data render, scene timer, mesin sinkronisasi serta mixer memakai implementasi KF687.

## Penguncian render

`tests/check-render-lock-688.py` membuktikan seluruh 33 source Java, dua workflow GitHub Actions dan empat area JavaScript render identik byte demi byte. Area JavaScript yang dibandingkan mencakup pengaturan render/mixer, Canvas/preview, cache/progress/layanan kedua engine, serta aksi pemilihan engine. Berkas stylesheet progress, aset dan modul pendukung saat ini identik dengan baseline. Blok signing dan application ID tetap. Perubahan pada `app/build.gradle` hanya angka versi.

## Referensi fixture

Contoh berbasis proses ditinjau dengan NASA Science untuk pembentukan black hole bermassa bintang, dan MedlinePlus untuk penjelasan umum tahapan luka kulit. Fixture gedung menggunakan daftar bangunan **selesai dibangun** dari CTBUH/The Skyscraper Center. Fixture stadion adalah pilihan editorial. Fixture hewan menguji struktur daftar dengan contoh berbagai jenis gerak, tanpa klaim peringkat universal atau angka kecepatan. Referensi ini dipakai saat menyusun fixture, bukan sebagai hasil verifikasi otomatis aplikasi.

- https://science.nasa.gov/universe/black-holes/types/
- https://medlineplus.gov/ency/patientinstructions/000741.htm
- https://www.skyscrapercenter.com/buildings?lang=en&list=tallest100-completed
