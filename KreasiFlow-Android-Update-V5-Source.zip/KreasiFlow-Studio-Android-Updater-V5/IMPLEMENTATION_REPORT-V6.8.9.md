# Audit dan implementasi Smart Content Director

## Baseline

Satu-satunya baseline adalah KF688.zip, SHA-256 `1c4868d0fafd4fbf2eeca6cc04439e2bc9a0e76b761f1f3d945942c13ed51de9`. Struktur ZIP asli diperiksa sebelum ekstraksi. KF688 sudah memiliki Title Intent Lock, validator daftar, pengecekan sumber lokal dan kunci subjek scene. V6.8.9 memperluas modul `content-accuracy-688.js`; tidak memperkenalkan validator paralel.

## Perubahan source

- Halaman Naskah Short Studio menyediakan satu selector jenis konten, hasil deteksi bercap lokal atau konteks AI yang memang dikembalikan provider, pengaturan per jenis, sumber opsional dan gaya VO melalui profil yang sudah ada. Kontrol produksi masih memakai panel asli. Jenis manual yang bertentangan dengan judul diblokir sebelum request dan menawarkan jenis otomatis atau edit judul.
- Reka ulang, recap, analisis karakter dan What If memakai respons berbagian dengan konteks karya, karakter, lokasi dan aksi. Reka ulang memeriksa urutan setup, conflict, climax dan outcome. Mode asli dapat meminta pengguna memilih edisi/cakupan. Adaptasi dan versi alternatif ditandai di pembuka. Ini pemeriksaan isi dan struktur respons, bukan pemeriksaan otomatis terhadap kanon karya.
- Validasi lokal menentukan cocok judul dan jumlah objek, menolak pengulangan/rujukan palsu yang terdeteksi, memberi catatan target kata, serta menahan hasil salah agar tidak menimpa naskah sebelumnya. Judul ambigu bisa meminta respons yang menyertakan klasifikasi dan narasi dalam satu panggilan. Koreksi semantik otomatis paling banyak satu kali. Batas timeout, pembatalan, retry transport dan cache dari baseline tetap berlaku.
- Referensi pengguna dicatat terpisah dari VO. Untuk Gemini, URL publik pada kolom referensi dikirim ke URL Context dalam permintaan naskah yang sama. Status diambil dari `urlContextMetadata` ketika provider mengembalikannya. URL tidak terjangkau, tanpa metadata, atau provider lain tidak dianggap sudah dibaca. URL yang berhasil diperiksa tetap tidak membuktikan semua klaim. Update ini tidak menambah pencarian Google Search otomatis dan tidak menggolongkan seluruh sumber user sebagai tepercaya.
- Objek daftar menggunakan kunci nama stabil. Metadata per bagian dan perkiraan posisi pada teks ditambahkan ke konteks scene yang relevan. Prompt gambar/aksi/video mewarisi identitas, lokasi, dan tahap yang sedang dibahas serta saran SFX sesuai aksi. Timestamp dan pembagian VO tetap milik jalur lama. Untuk narasi mekanisme/sains nonterstruktur, konteks utama berasal dari topik dan potongan narasi, tanpa mengklaim pemetaan tahapan kanon yang tidak tersedia. Referensi visual tetap mengikuti dukungan alur generator yang ada.
- Data baru bersifat opsional dan disimpan dalam snapshot proyek. Perubahan judul atau jenis memunculkan peringatan untuk media lama. Generate Naskah meminta konfirmasi jika media/scene sudah ada; menerima naskah baru tidak menghapus file audio, footage, atau scene. Arahan VO menggunakan profil sesuai judul bila otomatis dan tetap menghormati pilihan manual dan opsi teks polos.
- Story Studio tidak mendapat selector ini; naskah dan dialognya memakai alur yang sudah ada.

## Render lock

`tests/check-render-lock-689.py` membandingkan checksum, diff, paket aplikasi, workflow, dan enam bagian JavaScript. Semua implementasi render, timeline, subtitle payload, cache, progress dan audio mixer identik dengan KF688. Satu perubahan Java terbatas pada metode `GeminiApi.fastText` untuk URL Context. Seluruh 32 file Java lain identik. Package id.kreasiflow.studio, signing serta workflow GitHub Actions tetap sama.

Dokumentasi provider: https://ai.google.dev/gemini-api/docs/url-context
