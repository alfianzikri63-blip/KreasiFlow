# KreasiFlow Studio v5.0.12 — Perbaikan Video AI Bergerak (Debug)

Patch ini menggunakan source v5.0.12 Fix503, bukan source Rebuild. Seluruh tab, desain, generator judul, gambar, suara, serta render lama dipertahankan.

## Perubahan
- Gemini video memakai model stabil `gemini-omni-1.1-flash` (bukan model 1.2 yang tidak cocok dengan dokumentasi).
- Parser video menerima `steps[].content` maupun `output_video.data` (respons Gemini Interactions API).
- ID pekerjaan video Gemini dan Replicate disimpan di penyimpanan lokal **tanpa menyimpan API key**. Bila polling gagal, tombol **Cek hasil video sebelumnya** digunakan agar tidak membuat pekerjaan/tagihan baru.
- Request POST generate video berbayar **tidak diulang otomatis**. Hanya pemeriksaan status (GET) boleh dicoba ulang singkat bila error 503/koneksi.
- Uji satu klip dulu, tidak perlu langsung batch 5.

## Syarat
- Gemini Omni Flash memerlukan **paid tier** Gemini Developer API dan kuota video. Google AI Studio gratis tidak otomatis memberi akses API video berbayar.
- Periksa akses model lewat Google AI Studio dan billing, jangan mengirim API key ke siapa pun.
- Belum diuji memakai API key pengguna dan belum diuji APK Android di HP.

## Instal lewat GitHub
1. Gunakan file `KreasiFlow-Android-Update-V5-Source.zip` dari paket update ini (bukan ZIP kit luar).
2. Ganti file dengan nama sama pada root repo `alfianzikri63-blip/KreasiFlow` di branch `main`.
3. Jalankan Actions → **Test KreasiFlow APK Build from ZIP**.
4. Dari run yang sukses, unduh artifact `Test-Debug-APK-Not-Updateable` (bukan Publish Signed).
5. APK debug memakai ID terpisah `.videotest`, sehingga bisa dipasang berdampingan dengan KreasiFlow lama. API key perlu dimasukkan lagi di aplikasi uji; jangan membagikan kunci. Tidak perlu menghapus aplikasi utama.
6. Buka scene yang memiliki gambar → pilih Gemini → Generate 1 klip video.
7. Jika lama/gagal jaringan, klik **Cek hasil video sebelumnya** sebelum membuat klip baru.

## Batasan
- Video 360p diterima sebagai MP4 inline atau, ketika Google mengembalikan URI resmi, diunduh melalui Google Files API dengan batas ukuran 55 MB dan pemeriksaan host HTTPS. Hasil yang melebihi batas ukuran akan ditolak.
- Klip MP4 hanya tersimpan di cache aplikasi sesi itu; render MP4 final dan simpan ke Downloads sebelum keluar.
- Auto-retry tidak dilakukan untuk pembuatan video karena mungkin ditagih lebih dari sekali.
- Tidak ada perubahan pada keystore/API key pribadi ataupun signed production release. APK debug untuk pengujian memakai suffix `.videotest`.
