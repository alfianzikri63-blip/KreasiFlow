# KreasiFlow v5.0.15 — OpenRouter timeout fix

Patch dari v5.0.14; tampilan hijau dan seluruh alur tetap sama.

## Perbaikan
- Perbaikan mismatch batas tunggu: WebView sebelumnya menyerah di 160 detik sementara koneksi native bisa menunggu 180 detik (ditambah koneksi awal). Permintaan teks sekarang diberi batas 225 detik di WebView.
- Pesan timeout OpenRouter kini membedakan timeout aplikasi dengan timeout jaringan.
- Membuat prompt video per kelompok 3 scene, bukan 5; setiap prompt 40–75 kata, dan batas output 1250 token per kelompok. Scene yang berhasil disimpan sebelum kelompok gagal tidak hilang.
- Prompt gambar dibuat per kelompok maksimal 6 scene, bukan semua scene sekaligus; tiap kelompok disimpan agar proses yang selesai tidak hilang.
- Tidak melakukan retry otomatis untuk pembuatan teks; model gratis memiliki kuota, dan percobaan gagal dapat memakan jatah.
- Tidak mengganti model ke opsi berbayar secara diam-diam. `openrouter/free` tetap default.
- Tidak mengubah fitur Gemini, ElevenLabs, Cloudflare, Google Flow, render MP4, dan penyimpanan API key.

## Jika masih terjadi timeout
1. ⚙ Pengaturan AI → AI Judul & Naskah → ganti ke Gemini jika API Gemini tersedia. Ini tidak mengubah provider lain.
2. Jika ingin OpenRouter, uji API key, kemudian pilih model `:free` tertentu yang sedang tersedia melalui https://openrouter.ai/collections/free-models alih-alih `openrouter/free`.
3. Coba 1–3 scene terlebih dahulu, sambil mengecek koneksi dan batas penggunaan OpenRouter.
4. Simpan proyek. Jangan tekan Generate berulang kali ketika pekerjaan belum selesai.

## Instal lewat repo yang sama
Upload `KreasiFlow-Android-Update-V5-Source.zip` ke root repo `alfianzikri63-blip/KreasiFlow` sebagai pengganti ZIP sebelumnya. Jalankan GitHub Actions workflow `Test KreasiFlow APK Build from ZIP`.

APK debug bukan APK rilis signed. Jika tanda tangan debug berbeda, instalasi update dapat ditolak. Cadangkan JSON proyek sebelum menghapus APK debug. Untuk update pengguna produksi, build APK release menggunakan signing key asli lewat workflow signed release.

## Status uji
Source Android dan JS diperiksa secara statis. Tidak ada API key pengguna; belum diuji request OpenRouter nyata atau build Android Gradle lengkap.
