# KreasiFlow v5.0.18 — Mode Animasi 3D Edukasi Pastel

## Tujuan

Fitur ini **tambahan** pada KreasiFlow Studio v5.0.17, tidak menghapus judul, naskah, storyboard, OpenRouter/Gemini, ElevenLabs, Cloudflare, gambar per-scene maupun render lama.

Rujukan visual: video AC 3D yang pengguna unggah (sekitar 81 detik, 720×1280, H.264+AAC). Gaya: kartun 3D low-poly/pastel, karakter biru pastel bertopi krem, ruangan krem, kipas, unit split AC, potongan rumah, aliran panas dan refrigeran.

## Cara mencoba dalam APK

1. **Cadangkan proyek lama** dengan tombol `↓ JSON` sebelum mengubah naskah/scene, terutama jika sudah memiliki banyak scene.
2. Pilih tab **3 Scene & Gambar**, aktifkan **Mode Animasi 3D Edukasi Pastel** (mode lama default tetap nonaktif untuk proyek yang sudah ada).
3. Cek pengaturan: **Kunci karakter**, **Simulasi mekanisme**, **Narasi Google Flow** dan **Subtitle per kata** aktif. Durasi awal 8 detik per klip.
4. Tekan **Muat Contoh 3D Cara Kerja AC**. Ini **mengganti naskah dan scene proyek aktif** setelah konfirmasi. Muncul 10 adegan (estimasi ±80 detik). Untuk proyek lain, tulis naskah sendiri dan tekan **Buat storyboard edukasi dari naskah**.
5. Periksa/edit Character Bible, Style Bible, Object Bible, Location Bible. Tambah maksimal tiga gambar referensi (karakter, objek, lokasi) opsional. Foto master ditaruh di IndexedDB aplikasi, tidak dikirim ke server otomatis dan **tidak ikut ekspor JSON**. Ekspor Ingredients ke Downloads sebelum ke Flow.
6. Per adegan, ubah **Gerakan/simulasi scene**. Untuk prompt lengkap, tekan **Salin prompt lengkap**. Tombol **Siapkan klip di Google Flow** menyiapkan foto yang diunggah ke Downloads, menyalin prompt dan membuka Chrome. Di Google Flow, pilih mode Video → Ingredients, tambahkan gambar referensi yang sama, pilih opsi narasi/suara yang tersedia, tempel prompt, lalu tekan **Generate secara manual**.
7. Unduh MP4 video tiap scene dari Flow dan impor dengan **Impor MP4 + audio Flow** sesuai nomor scene. **Tidak ada otomasi web** atau pengambilan hasil otomatis dari akun Google.
8. Tab Render → **Gabungkan klip MP4 + suara asli Flow**. Android akan mencoba gabung MP4 H.264 + AAC tanpa re-encode dan mempertahankan suara Flow jika codec/resolusi/sample rate/channel kompatibel. Jangan masukkan voice-over ElevenLabs lagi ketika opsi narasi Flow aktif.
9. **Subtitle per kata → Ekspor SRT**. SRT adalah **perkiraan waktu berdasarkan urutan kata dan durasi 8 detik/scene**, bukan transkripsi audio dan belum masuk ke MP4 otomatis. Setelah menggabungkan klip, sinkronkan subtitle ke audio dan pasang di editor video (misalnya CapCut atau editor lain).

## Contoh 10 adegan: memahami cara kerja AC

| Scene | Estimasi | Visual |
|---|---|---|
| 1 | 0–8 dtk | Kamar panas, kipas angin, karakter berkeringat |
| 2 | 8–16 | Karakter memperkenalkan perbedaan AC dan kipas |
| 3 | 16–24 | Evaporator menyerap panas, panah oranye masuk/biru keluar |
| 4 | 24–32 | Udara yang lebih sejuk kembali ke kamar |
| 5 | 32–40 | Refrigeran membawa panas menuju kompresor luar |
| 6 | 40–48 | Potongan kompresor menaikkan tekanan dan suhu |
| 7 | 48–56 | Kondensor dan kipas membuang panas ke luar |
| 8 | 56–64 | Katup ekspansi menurunkan tekanan refrigeran |
| 9 | 64–72 | Siklus pendinginan yang berulang pada rumah potongan |
| 10 | 72–80 | Kesimpulan dan perawatan filter |

Deskripsi dalam video referensi dijadikan inspirasi visual, bukan transkrip utuh atau bukti bahwa mekanisme detail hasil generatif pasti akurat. Untuk konten pendidikan teknik, periksa kembali diagram pipa, arah refrigeran, dan klaim sains.

## Batasan / hal yang perlu diuji

- Tidak mengontrol situs Google Flow, kredensial, cookie, `Generate`, atau download otomatis. Referensi di Flow dipilih manual. Ketersediaan Ingredients, Voice Reference, orientasi video dan durasi mengikuti akun/model/negara Google.
- Narasi Flow dapat berbeda dari naskah karena video generatif tidak menjamin ucapan persis atau durasi 8 detik. Gunakan reference voice yang sama bila tersedia, lalu periksa secara manual.
- **Native clip concat** mempertahankan AAC dari Flow hanya untuk file dengan video H.264, audio AAC, resolusi sama dan sample rate/channel sama. Jika inkompatibel, hasil ditolak dengan pesan, bukan menghilangkan suara. Pemisahan codec/pengkodean ulang belum tersedia.
- Subtitle SRT **belum sinkron otomatis** dengan audio MP4 dan **belum burn-in**. Untuk subtitle presisi dibutuhkan ASR/word-level alignment dan overlay di editor/renderer re-encode.
- Foto Ingredients tersimpan lokal dengan IndexedDB dan bisa hilang bila data aplikasi dibersihkan; proyek JSON memuat teks saja. MP4 impor disimpan di cache sesi; simpan MP4 asli ke Downloads.
- Build Gradle Android penuh, uji Google Flow langsung, uji hasil MP4 gabungan di HP belum dilakukan. Hasil uji sintaks/browser dan kompilasi Java dengan stub tidak menggantikan uji perangkat.
- Model AI teks untuk penyempurnaan prompt dapat memakai kuota API, tetapi pemuatan 10-scene contoh dan prompt template lokal tidak menggunakan API berbayar.

## GitHub yang sudah ada

Repo: `https://github.com/alfianzikri63-blip/KreasiFlow`.

Upload/ganti file root repo bernama **`KreasiFlow-Android-Update-V5-Source.zip`**; ZIP berisi top-level `KreasiFlow-Studio-Android-Updater-V5` sesuai workflow `Test KreasiFlow APK Build from ZIP`. Jalankan Actions dari branch `main`. APK debug `id.kreasiflow.studio.videotest` bukan installer update untuk release resmi. Untuk release gunakan signing key yang sama setelah pengujian; jangan bagikan keystore/password/API key di GitHub.
