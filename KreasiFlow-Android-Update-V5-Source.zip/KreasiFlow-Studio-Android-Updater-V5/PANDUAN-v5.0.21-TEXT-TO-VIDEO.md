# KreasiFlow Studio v5.0.21 — Storyboard & Text-to-Video dari Naskah

## Yang diperbaiki

- Tombol utama **Buat Storyboard + Prompt Text-to-Video** sekarang langsung terlihat di tab **Scene & Video**.
- Storyboard dibuat dari **naskah proyek aktif**, bukan episode demo ASAQ–ZAYN.
- Prompt Text-to-Video Google Flow langsung dibuat **tanpa perlu gambar per scene**.
- Mode 2D Chibi (ASAQ–ZAYN), mode 3D Edukasi, gambar AI, Google AI Studio VO, dan impor MP4 lama tetap tersedia sebagai opsi.
- Episode **Misi Biskuit Terakhir** dipindah ke submenu demo opsional di mode 2D Chibi, bukan alur utama.
- Jika naskah tidak menyebut ASAQ atau ZAYN, generator prompt Text-to-Video tidak memasukkan karakter tersebut secara otomatis.
- Detail per scene dapat diedit: aksi/kamera, dialog, dan karakter referensi opsional.
- AI Gemini/OpenRouter opsional untuk memperjelas gerakan per **dua scene** (manual, bukan auto-retry). Jika respons AI gagal, prompt lokal tetap dapat digunakan.
- Tab Render memiliki tombol untuk menggabungkan MP4 Flow dengan audio asli klip saat fitur ini dipilih.

## Cara menggunakan (tanpa generate gambar)

1. Buka **Upload**: ketik judul dan buat/tempel **naskah**. Bila memakai naskah dengan catatan produksi, pastikan narasi tersusun di bagian *Voice Over*.
2. Di bagian bawah Upload tekan **Langsung Storyboard → Text-to-Video**, atau buka tab **Scene & Video**.
3. Tekan **Buat Storyboard + Prompt Text-to-Video**. Bila proyek sudah memiliki scene, ekspor JSON dahulu sebelum mengonfirmasi pembuatan ulang.
4. Tinjau potongan cerita, aksi visual/kamera, dan style per scene. Tidak ada gambar wajib.
5. Bila ingin, tekan **Perjelas gerakan scene dengan Gemini/OpenRouter**; fitur ini memerlukan API key teks dan dapat memakai kuota.
6. Pada tiap scene, tekan **Text-to-Video Google Flow**. Prompt otomatis disalin dan Chrome membuka Flow.
7. Di Google Flow pilih mode **Text to Video**, tempel prompt, pilih durasi/model yang tersedia, lalu tekan **Generate** sendiri. Bang perlu login, mengatur kredit dan mengunduh hasil di situs Flow secara manual. Aplikasi tidak mengendalikan browser Flow.
8. Impor video MP4 ke scene sesuai urutan. Di tab **Render**, tekan **Gabungkan MP4 + audio asli Flow** bila semua klip sudah tersedia.

## Jika memakai karakter tetap

- Pilih **Mode Karakter Tetap 2D Chibi** bila memang ingin membuat episode ASAQ–ZAYN.
- Perpustakaan karakter tidak dihapus, dan contoh Misi Biskuit hanya dapat dimuat secara sengaja dari menu demo.
- Dalam mode Text-to-Video dari Naskah, karakter tidak dipaksakan. Pilih mereka pada pengaturan referensi per scene jika perlu, lalu unggah gambar referensi di Flow secara manual.

## Batasan penting

- Banyaknya scene mengikuti **naskah dan target durasi**. Kalimat tidak diulang untuk mengejar jumlah scene.
- Generasi Text-to-Video tetap melalui situs Google Flow, yang tidak dikendalikan langsung oleh KreasiFlow. Audio/narasi Flow tidak selalu persis dengan teks; periksa suara dan identitas karakter pada setiap hasil.
- Subtitle otomatis yang benar-benar sinkron memerlukan pemeriksaan/editing; fitur ini **tidak** mengklaim subtitle kata-per-kata dibakar ke MP4 dari Flow.
- Penggabungan native mengharuskan klip MP4 dan codec audio/video kompatibel. **Belum diuji pada perangkat nyata**.
- Belum dilakukan build APK Android penuh di lingkungan ini karena Android SDK/Gradle tidak tersedia. HTML/JS dan alur UI sudah diuji secara lokal.
- API keys tidak disimpan di dalam paket source. Jangan masukkan API key ke repository GitHub.

## GitHub Actions — repo tetap

Repository: `alfianzikri63-blip/KreasiFlow`

1. Unggah **hanya file bernama** `KreasiFlow-Android-Update-V5-Source.zip` dari paket ini ke **root** repository, menggantikan ZIP lama dengan nama yang sama.
2. Jalankan workflow **Test KreasiFlow APK Build from ZIP** pada branch `main`.
3. Jika build berhasil, ambil APK debug dari Artifacts.
4. **Ekspor proyek JSON terlebih dahulu** sebelum instal ulang, karena perubahan APK atau sertifikat debug dapat menyebabkan perlu mencopot versi debug lama.
5. APK debug **bukan** update produksi. Untuk update aplikasi rilis gunakan signing key rilis yang sama.

*Per 18 November 2026, koneksi GitHub dalam sesi ini dapat membaca repo tetapi penulisan sebelumnya ditolak HTTP 403. File di repo tidak diubah otomatis.*
