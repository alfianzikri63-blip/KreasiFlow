# KreasiFlow Studio v5.0.22 — ASAQ & ZAYN: Text-to-Image → Image-to-Video

## Yang dipertahankan

Mode utama Text-to-Video dari Naskah (v5.0.21), mode 3D edukasi, fitur naskah, Gemini/OpenRouter, Google AI Studio VO, perpustakaan karakter, impor klip MP4, render, dan penyimpanan proyek tetap ada. Contoh “Misi Biskuit Terakhir” tetap opsional, tidak dimuat sendiri.

## Implementasi baru

- **Mode ASAQ & ZAYN** di tab Scene & Video; tekan **ASAQ & ZAYN: Storyboard → Gambar → Video**, atau centang opsi di Pilih mode video.
- Membuat storyboard dari naskah tanpa mengulang kalimat demi memenuhi target durasi; jika storyboard sudah tersedia, gunakan **Pakai storyboard aktif** agar teks asli tidak terganti.
- Memakai dua foto referensi asli yang sudah ada di source: `app/src/main/assets/characters/asaq-reference.jpg` dan `zayn-reference.jpg`.
- Karakter default **ASAQ (adik, ±70 cm, topi beruang biru tua)** dan **ZAYN (kakak, ±89 cm, rambut cokelat tanpa topi)**. Keduanya memakai kaus garis cokelat/putih, celana cokelat, dan sepatu terang, sesuai referensi yang dikirim.
- **Character Lock** aktif secara default. Pada tiap scene, pemeran dapat dipilih; deskripsi karakter yang tidak tampil tidak dimasukkan ke daftar visual. Identitas wajah/kostum dan style 2D chibi ditambahkan dalam prompt global.
- **Dua prompt terpisah** per scene: (1) Text-to-Image untuk frame awal yang konsisten; (2) Image-to-Video untuk gerakan frame tersebut di Flow. Keduanya bisa diedit dan hasilnya disimpan dalam JSON proyek.
- Tombol **Buat gambar via Google Flow**, **Salin prompt gambar**, **Impor gambar awal**, **Simpan gambar awal**, **Siapkan Frame → Google Flow**, **Salin prompt gerak**, **Impor MP4 Flow**.
- Tombol opsional memperjelas aksi gambar dan video melalui Gemini/OpenRouter; **bukan** otomatis dijalankan. Batas kuota/biaya model mengikuti akun masing-masing. Kegagalan API tidak menghapus draft lokal.
- Prompt manual tidak ditimpa saat menekan perbarui seluruh scene; untuk mengganti prompt scene tertentu, tekan tombol perbarui di scene itu.

## Cara memakai di HP Android

1. Sebelum memutakhirkan APK, **Ekspor proyek JSON** untuk cadangan. APK debug di GitHub Actions bisa ditandatangani sertifikat berbeda sehingga mungkin perlu instal bersih (data lama dapat hilang). Jangan menghapus aplikasi lama sebelum file cadangan aman.
2. Masukkan judul dan naskah di **Upload**. Contoh: ASAQ dan ZAYN bermain layang-layang di taman.
3. Buka **Scene & Video**, tekan **ASAQ & ZAYN: Storyboard → Gambar → Video**.
4. Jika naskah belum dijadikan scene, tekan **Naskah → Storyboard ASAQ & ZAYN**. Jika storyboard sudah ada dari mode Text-to-Video, tekan **Pakai storyboard aktif**; narasi yang sama tetap digunakan.
5. Periksa opsi **Text-to-Image → Image-to-Video**, aktifkan **Kunci gaya**. Atur judul episode dan Style Bible/Setting Bible bila perlu.
6. Per scene, centang pemeran yang benar (ASAQ, ZAYN, atau keduanya). Tinjau aksi dan prompt gambar.
7. Tekan **Buat gambar via Google Flow**. KreasiFlow menyalin prompt gambar, menyimpan file referensi ASAQ/ZAYN ke Downloads (jika belum), dan membuka Flow melalui Chrome.
8. **Di Google Flow secara manual**: pilih Image; gunakan referensi karakter yang relevan (Ingredients/referensi bila didukung), tempel prompt gambar, lalu Generate. Unduh hasil gambar.
9. Kembali ke KreasiFlow, tekan **Impor gambar awal dari Flow / galeri** pada scene yang benar.
10. Tekan **Siapkan Frame → Google Flow**. KreasiFlow menyimpan gambar awal scene ke Downloads, menyalin prompt animasi, lalu membuka Chrome.
11. **Di Google Flow secara manual**: pilih **Video → Frames**, unggah gambar awal sebagai Start frame; bila model mendukung, tambahkan referensi karakter yang sama sebagai Ingredients; tempel prompt gerak; pilih durasi/rasio dan Generate. Unduh MP4.
12. Kembali ke KreasiFlow: **Impor MP4 Flow** per scene. Setelah semua klip yang dibutuhkan tersedia, masuk ke tab Render dan jalankan penggabungan MP4 + suara asli Flow.

### Catatan keamanan dan batasan

- KreasiFlow **tidak** menekan tombol Generate, tidak mengakses login/cookie Google, tidak mengunggah berkas otomatis ke Flow, dan tidak dapat mengunduh hasil Flow otomatis. Langkah tersebut dilakukan pengguna di browser.
- Prompt gambar dari aplikasi tidak otomatis mengirim gambar referensi ke API gambar Gemini/Cloudflare. **Untuk karakter paling konsisten, gunakan referensi visual secara manual di Google Flow saat membuat frame awal.**
- Pemilihan mode Frames dan Ingredients serta durasi yang tersedia bergantung pada model dan akses akun Google Flow. Tidak semua kombinasi fitur tersedia di setiap mode atau wilayah.
- Referensi karakter dapat disimpan melalui perpustakaan karakter lokal. Namun **foto frame scene baru belum tersimpan permanen antarrestart** (sebagaimana pada source sebelumnya). Simpan gambar hasil Flow ke galeri/Downloads dan impor lagi jika perlu. JSON menyimpan teks prompt, bukan file foto atau MP4.
- Subtitle kata demi kata, kestabilan suara lintas klip, dan penggabungan audio codec berbeda tidak dijamin oleh patch ini; renderer tetap memerlukan uji di HP nyata.
- Diperlukan internet dan kemungkinan kredit Google Flow atau API teks untuk langkah terkait. Tidak ada API key rahasia tertanam pada ZIP source ini.

## Upload ke repository lama (tetap sama)

`https://github.com/alfianzikri63-blip/KreasiFlow`

- Ambil file ZIP bernama **`KreasiFlow-Android-Update-V5-Source.zip`**, bukan ZIP paket luarnya.
- Ganti file dengan nama sama di **root** repo pada branch `main`.
- Jalankan **Actions → Test KreasiFlow APK Build from ZIP → Run workflow**.
- Jika berhasil, unduh artifact **`Test-Debug-APK-Not-Updateable`**, ekstrak APK, instal, dan uji satu scene dahulu.
- Untuk update APK produksi gunakan keystore dan sertifikat rilis lama yang **sama**, bukan APK debug.
- Koneksi GitHub yang tersedia dalam percakapan sebelumnya menolak penulisan (403). Paket ini belum otomatis dipasang ke repository.

## Status uji

- Browser mobile Chromium: tampil Mode ASAQ–ZAYN, 6 scene dari naskah, prompt gambar + prompt gerak per scene, referensi dua karakter, mode Text-to-Video biasa tetap tersedia, pemeran hanya ASAQ, dan mempertahankan prompt edit. **Lulus uji simulasi antarmuka.**
- JavaScript `node --check`: **lulus**.
- Pemeriksaan XML, integritas ZIP, struktur Gradle/workflow: **lulus pemeriksaan statis**.
- **Belum** dilakukan build Gradle Android penuh atau pengujian live Google Flow/hasil MP4 di HP. Jangan dianggap APK terbit atau integrasi Flow otomatis.
