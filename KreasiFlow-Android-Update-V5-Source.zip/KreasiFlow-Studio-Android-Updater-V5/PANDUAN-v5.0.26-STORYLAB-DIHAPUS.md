# KreasiFlow v5.0.26 — Perawatan: StoryLab ASAQ & ZAYN dihapus

## Yang DIHAPUS
- Navigasi `📚 StoryLab` dari toolbar native Android.
- Halaman, Service Worker, manifest, dan ikon StoryLab pada `app/src/main/assets/storylab/`.
- Tiga README StoryLab terdahulu.
- Referensi ke URL halaman StoryLab dari callback Android (sekarang hanya halaman utama KreasiFlow).

## Yang DIPERTAHANKAN
- Alur utama KreasiFlow: judul, AI text, naskah, suara Google AI Studio, storyboard, prompt image/video Google Flow, upload gambar/klip, pratinjau, render media lokal, subtitle, musik, watermark, simpan proyek, login, API key, cadangan dan update.
- Mode karakter/aset asli KreasiFlow (termasuk library dan referensi ASAQ/ZAYN yang sudah ada sebelum StoryLab).
- Application ID `id.kreasiflow.studio` dan konfigurasi signing rilis.
- Workflow ZIP GitHub yang sudah digunakan sebelumnya.

Hanya modul **StoryLab khusus ASAQ & ZAYN** yang dihapus. Mode karakter asli di KreasiFlow belum dihapus karena merupakan bagian tersendiri dari aplikasi lama.

## Review video referensi `265307.mp4` (durasi sekitar 08:24)
Video tutorial `Tuyul Konten` memperlihatkan tahapan ide/judul, gaya/durasi, penulisan naskah, TTS melalui Google AI Studio, upload audio, pemotongan jeda dan scene, prompt/gambar lewat Google Flow, efek, musik, watermark dan render.

Perbandingan source KreasiFlow v5.0.25:
- **Sudah ada:** judul/naskah Gemini atau OpenRouter, template, export naskah untuk AI Studio, import WAV/MP3, storyboard/prompt, Flow via Chrome, upload gambar/video, preview, render lokal, subtitle perkiraan, musik lokal, watermark teks.
- **Belum ada/setara:** deteksi jeda audio dan pembagian scene presisi hasil transkripsi; `renderProcess` secara eksplisit menyatakan potong otomatis belum ada. Scene di `buildScenes` dibuat dari pecahan kalimat dan estimasi durasi, bukan transkripsi bertimestamp.
- **Masih manual/bergantung layanan:** TTS AI Studio dan produksi gambar/klip Google Flow perlu dibuka dan dipakai terpisah, autentikasi di Chrome; tidak ada API resmi video Flow yang diintegrasikan.
- **Editor lebih sederhana:** efek `Smooth zoom`, `Slide pelan`, `Tanpa efek`, fade, teks watermark tanpa penentuan posisi/opacity seperti di video tutorial; preview bergerak di mobile belum setara video referensi.
- **Tidak terbukti:** kualitas ekspor MP4 dan pengalaman runtime Android pada perangkat Bang. Pemeriksaan kode saja tidak membuktikan berhasil.

## Verifikasi
Source, keberadaan path, dan sintaks JS dicek secara statis. APK sesungguhnya belum dikompilasi/diuji di Android. Debug build memiliki suffix application ID `.videotest` sehingga tidak mengganti aplikasi rilis lama.
