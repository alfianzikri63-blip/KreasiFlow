# KreasiFlow v5.0.27 — Perbaikan alur judul, narasi dan scene

Perbaikan terfokus berdasarkan perbandingan aplikasi referensi dengan KreasiFlow. Tetap berasal dari source KreasiFlow v5.0.26 tanpa modul StoryLab ASAQ & ZAYN terpisah.

## Perubahan nyata
1. Pemilihan **Format konten** di panel naskah (sejarah penemuan, bagaimana jika, kisah tokoh, fakta aneh, misteri, ranking, cara kerja, perbandingan, drama viral, dll.). Format ikut dikirim dalam prompt pembuatan judul dan naskah Gemini/OpenRouter.
2. **Target kata vs jumlah kata aktual** terlihat sebelum menulis naskah. Perkiraan 145 kata/menit; bukan jaminan panjang tepat. Tombol draf lokal disebut secara jujur sebagai template, berbeda dari naskah AI.
3. Pembagian scene biasa sekarang menggunakan `scene-planner.js` yang dapat dites terpisah: teks narasi tidak diulang atau dibuat-buat hanya untuk memenuhi durasi; kalimat pendek tidak diulang menjadi banyak scene; scene memiliki estimasi startSec/endSec; maksimum 100 scene. Perkiraan waktu **belum** sama dengan sinkronisasi suara asli.
4. Ketika storyboard dibuat ulang, gambar dan klip lama hanya dipertahankan apabila teks narasi scene pada indeks tersebut tetap sama; jangan menggunakan gambar lama untuk isi adegan baru. Prompt gambar yang telah diedit secara manual dipertahankan selama voice scene sama.
5. Antrean gambar AI normal: hanya memproses scene yang belum memiliki gambar, menandai processing/success/failed, menampilkan error per scene, dan menyediakan tombol ulang gambar gagal. Saat gagal kuota, batch berhenti; error lain dicatat dan batch dapat dilanjutkan ke scene berikutnya. **Tidak melakukan retry otomatis** pada permintaan berbayar. Satu batch aktif pada satu waktu. Konfirmasi penggunaan kuota dilakukan sebelum batch; tidak ada lagi dialog ganda.
6. SRT estimasi memakai rentang scene dari planner bila tersedia. Tetap perlu dicocokkan dengan ucapan asli.

## Batasan jelas
- Google Flow masih dioperasikan manual melalui Chrome. Tidak ada automation login / tombol Generate massal tersembunyi.
- Gemini, OpenRouter, gambar via Gemini/Cloudflare perlu kunci/kuota masing-masing dan harus dites dari perangkat pengguna.
- Render Android MP4, audio yang mengikuti jeda napas, transkripsi otomatis, sinkronisasi gambar dengan audio, serta API gambar cloud belum diuji end-to-end pada HP.
- **Scene planner membagi teks**, bukan memotong gelombang suara menjadi file terpisah.
- Media impor/blob bisa hilang ketika aplikasi ditutup; simpan salinan asal.
- APK debug memakai applicationIdSuffix sendiri dan penyimpanan kunci terpisah dari aplikasi rilis.

## Uji yang sudah dilakukan
- `node --check` pada JavaScript utama dan scene planner.
- `node --test tests/scene-planner.test.cjs`: 5 tes unit, semuanya lulus (kasus kosong, sangat pendek, 750 kata 5 menit, batas 100, verifikasi duplikasi).
- Browser Chromium headless: input judul + format, draf template, proses scene pendek, tampilan scene (tanpa error JavaScript).
- Browser Chromium headless: 750 kata / 5 menit = 60 scene dan teks gabungan tetap sama; tanpa error JavaScript.
- Belum dilakukan build APK Android / tes Google Flow / tes provider AI sungguhan.

## Upload memakai satu ZIP bagian dalam
1. Ekstrak ZIP **luar** di Android sekali.
2. Ambil `KreasiFlow-Android-Update-V5-Source.zip` di dalamnya. **Jangan diekstrak**.
3. Upload berkas tersebut untuk mengganti `KreasiFlow-Android-Update-V5-Source.zip` di root repo `alfianzikri63-blip/KreasiFlow`.
4. Di GitHub buka Actions > `Test KreasiFlow APK Build from ZIP`. Jika berhasil, ambil APK debug di Artifacts.
5. Sebelum menimpa data aplikasi utama, backup proyek dan API keys, cek keberhasilan build & uji fungsi di APK debug.

## Catatan
Paket ini bukan APK. Tidak ada perubahan langsung ke repo GitHub, karena koneksi penulisan repo sebelumnya ditolak 403.
