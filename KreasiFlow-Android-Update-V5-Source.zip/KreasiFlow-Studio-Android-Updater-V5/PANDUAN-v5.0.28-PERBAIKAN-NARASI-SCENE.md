# KreasiFlow 5.0.28 — Prompt narasi dan scene lebih terarah

Perbaikan setelah pemeriksaan dua klip pengguna (orang memasak di dapur tradisional, dengan kostum & komposisi berbeda).

- **Narasi tunggal:** teks VO di tab Upload merupakan sumber storyboard dan audio AI Studio. Arahan teknis jangan disuarakan.
- **Pembagian scene:** satu rangkaian kalimat masuk tepat satu scene, durasi Flow 6 atau 8 detik per klip, dan estimasi durasi visual ditampilkan dibanding target video.
- **Visual Bible:** identitas tokoh, pakaian, lokasi dan properti dapat ditulis sekali dan diulang di semua prompt. Tombol AI dapat menyiapkan Visual Bible dan memperjelas aksi jika Gemini/OpenRouter tersedia.
- **Pemisahan suara:** default video Google Flow memakai ambience/SFX tanpa membaca ulang naskah VO. Jika opsi dialog aktif, hanya dialog karakter singkat yang diminta, tidak membaca narasi panjang di setiap klip.
- **Scene action:** setiap prompt memuat aksi utama scene, konteks narasi, dan tindakan scene sebelum/sesudah untuk menghindari lompatan maupun adegan berulang.
- **Peringatan:** bila narasi diubah setelah storyboard, perbarui storyboard sebelum mengirim ke Flow. Jika Visual Bible kosong, pengguna diminta konfirmasi risiko karakter berubah.
- **StoryLab ASAQ & ZAYN tidak ditambahkan kembali.** Tombol khusus ASAQ & ZAYN pada tab scene umum disembunyikan; pengaturan proyek lama tidak otomatis dihapus.

## Batas kemampuan
Google Flow tidak menyediakan kendali otomatis melalui aplikasi ini. Karakter tetap bisa drift tanpa gambar referensi yang sama. Timing narasi masih estimasi kata, belum sinkron otomatis dengan waveform audio MP3/WAV. Tidak ada bukti render MP4 di perangkat hanya dari lulus tes JavaScript.

## Alur uji
1. Isi judul dan buat naskah AI; periksa teks narasi khusus AI Studio.
2. Buat narasi suara dan unggah audio bila perlu.
3. Pada Scene & Video pilih Text-to-Video dari Narasi, atur durasi klip.
4. Isi Visual Bible (misalnya pakaian juru masak, dapur bambu, wajan, lampu minyak) atau generate dengan AI. Periksa aksi tiap scene.
5. Kirim satu prompt scene ke Google Flow dan bandingkan dengan scene berikutnya sebelum produksi massal.
6. Impor klip MP4 dari Flow ke scene dan uji render.
