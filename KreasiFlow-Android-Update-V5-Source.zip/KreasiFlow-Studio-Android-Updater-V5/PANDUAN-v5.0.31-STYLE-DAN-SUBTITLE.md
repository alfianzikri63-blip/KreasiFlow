# KreasiFlow v5.0.31 — Gaya visual & subtitle bertimestamp

## Perubahan
- Panel `6a · Pilih mode video` (Text-to-Video dan Edukasi 3D) dihilangkan. Mode lama nonaktif pada sesi baru; data proyek dan mode gambar/Flow biasa tetap dipertahankan.
- Style visual ditambah lebih dari 30 pilihan dan bisa dipilih pada tab **Proses** atau **Scene & Video**.
- Tab **Proses** kini memiliki editor subtitle: buat cue perkiraan dari teks narasi, impor SRT/VTT, edit start/end hingga milidetik, atur offset global, dengarkan VO sambil melihat teks cue, dan ekspor SRT.
- **Render MP4 dari gambar statis** (renderer Android NativeVideoRenderer) sekarang menggambar subtitle sesuai cue start/end yang disimpan, bukan membagi otomatis berdasarkan jumlah scene.
- **Render MP4 dari klip Google Flow** belum mendukung burn-in subtitle; ekspor SRT dengan timestamp sudah tersedia untuk editor video. Jangan klaim subtitle sudah menempel pada MP4 Flow. Memperbaiki pipeline klip bergerak memerlukan implementasi transcode video dan pencampuran audio yang berbeda, belum termasuk pembaruan ini.
- Transkripsi speech-to-text otomatis **belum** tersedia. Tombol “Buat subtitle dari narasi” menggunakan teks naskah dan membagi durasi **secara estimasi**, lalu perlu penyelarasan manual atau impor SRT bertimestamp dari luar.

## Uji di APK
1. Buka tab Proses; pilih style visual baru.
2. Upload MP3/WAV VO, pastikan durasi terbaca, lengkapi teks narasi, tekan **Buat subtitle dari narasi**.
3. Putar VO, periksa subtitle pada panel pratinjau; edit timestamp (contoh `00:00:04.250`) dan cek tidak bertumpuk.
4. Jika punya SRT yang sudah ditranskripsi benar, unggah SRT untuk mengganti hasil perkiraan.
5. Aktifkan subtitle di tab Render dan render **dari gambar statis**; subtitle akan ditanam per timestamp ke frame video. Untuk video Google Flow, gunakan **Ekspor SRT** dan editor video yang mendukung subtitle.

## Jujur tentang status
Unit test Node untuk timeline SRT dilakukan. APK dan encoder di perangkat masih perlu tes melalui GitHub Actions dan HP. Jangan menganggap keberhasilan pengujian sintaks sebagai keberhasilan render MP4 Android.
