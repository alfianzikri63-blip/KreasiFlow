# KreasiFlow v5.0.32 — AI Transkrip Voice Over Gemini

## Perubahan

- Tab **Proses → 6 · Transkrip & Subtitle Bertimestamp → 🎙 AI Transkrip dari VO**.
- Upload VO MP3, WAV, M4A, AAC, OGG atau FLAC (hingga 12 MB), durasi hingga 30 menit.
- APK mengirim audio secara native memakai API key Gemini yang tersimpan terenkripsi. API key tidak ditulis ke HTML, SRT, ZIP maupun GitHub.
- Gemini Interactions API model `gemini-3.6-flash` diminta menulis transkrip + `start/end` segmen (detik).
- Respons dicek: wajib ada teks, waktu numerik positif, urut, tidak overlap dan tidak melampaui durasi audio. Jika invalid, subtitle lama tidak ditimpa.
- Editor, ekspor SRT, manual offset dan preview bersama audio tetap berfungsi.

## Penggunaan

1. Di KreasiFlow **Pengaturan** pastikan Gemini API Key benar-benar tersimpan (terpisah antara debug dan release).
2. Di tab **Upload** impor VO MP3/WAV dari Google AI Studio.
3. Di tab **Proses** ketuk **🎙 AI Transkrip dari VO** lalu setujui penggunaan kuota API.
4. Tunggu hasil dan baca status. Putar VO di editor dan periksa tiap baris subtitle; koreksi bila model kurang tepat.
5. **Render gambar statis** akan menanam subtitle ini ke MP4. **Untuk video bergerak MP4 dari Flow, subtitle masih diekspor SRT terpisah** karena renderer native moving video belum mendukung overlay teks, mix SFX+VO, dan alignment otomatis antar klip. Jangan mengandalkan render Flow untuk subtitle sampai engine video diperbaiki.

## Batasan

Akurasi timestamp AI tidak setara forced alignment. Gemini API dapat mengalami 403/404/429 bila model/kuota tidak tersedia dan dapat memotong respons jika file terlalu panjang. Tidak ada kredensial pengguna di source. Tidak ada pengujian API berkey nyata atau APK runtime dalam paket ini.

## Upload ke GitHub

Ekstrak ZIP luar; upload ZIP dalam bernama **KreasiFlow-Android-Update-V5-Source.zip** ke root repo lama. GitHub Actions build dari ZIP yang sama.
