# KreasiFlow v5.0.33 — Sinkronisasi Google Flow MP4 + Voice Over + Subtitle + SFX

## Masalah yang diperbaiki
- v5.0.32: jalur klip bergerak mengulang seluruh urutan MP4 bila VO lebih panjang; subtitle hanya tertanam dalam slideshow gambar, dan audio Google Flow tidak bisa di-mix dengan VO.
- v5.0.33: jalur baru `MainActivity.runNativeMovingRender` → `NativeVideoRenderer` menyusun scene berdasarkan batas waktu VO. Tidak memanggil `NativeClipRenderer.concatenate` berulang.
- Klip bergerak diekstrak frame-nya kemudian di-encode ulang bersama overlay subtitle/watermark. Durasi per scene dipertahankan sesuai cue/transkrip VO; klip yang terlalu pendek dapat menahan frame terakhir, **tidak mengulang scene awal**.
- `NativeAudioMixer` mengonversi VO dan, bila diaktifkan, audio Flow ke PCM 44.1 kHz mono, meletakkan tiap SFX di awal scene sesuai timestamp, mencampur dengan volume terpisah, lalu menghasilkan AAC. Musik latar terpisah masih **tidak** ikut di jalur Android native.

## Cara menggunakan
1. Upload VO MP3/M4A/WAV dengan metadata durasi yang dapat terbaca.
2. Tab **Proses** → **AI Transkrip dari VO** (Gemini) atau **Impor SRT**. Dengarkan dan periksa timestamp; hasil AI tidak dijamin sempurna.
3. Buat storyboard berdasarkan naskah, lalu impor MP4 Google Flow ke nomor scene yang benar (jangan menggeser nomor scene jika suatu klip belum tersedia).
4. Buka tab **Render** → **Sinkronisasi Klip Google Flow + VO**.
5. Lihat tabel batas mulai/akhir tiap scene. Otomatis mencari kecocokan kata transkrip ke naskah; jika teks berbeda, jatuh ke proporsi kata. Edit batas mulai scene secara manual bila diperlukan.
6. Pilih audio Flow: **Otomatis (VO+SFX)**, **Mix SFX + VO**, **Audio asli Flow**, atau **Mute audio Flow**. Default level SFX 18% agar VO dominan.
7. Aktifkan **Tempel subtitle bertimestamp** jika ingin subtitle tertanam, lalu tekan **Render MP4 Flow + VO + Subtitle Sinkron**.
8. MP4 disimpan ke `Download/KreasiFlow`. Uji awal pada video pendek dengan 2–3 scene sebelum ekspor panjang.

## Keterbatasan yang perlu diketahui
- **Tidak ada penghapus suara AI narator dalam klip Flow**. Jika MP4 Flow sudah berisi bahasa Inggris, mode Mix SFX akan turut mencampur suara Inggris itu. Regenerate Flow hanya dengan sound effects tanpa dialog, atau pilih Mute audio Flow.
- AI transkripsi adalah perkiraan timestamp dan perlu dikoreksi manual; sinkronisasi scene berbasis kecocokan kata masih bisa membutuhkan koreksi.
- Jika klip video pendek sementara VO scene panjang, frame terakhir ditahan. Alur video tidak akan diulang otomatis; untuk gerakan terus-menerus, generate klip yang lebih panjang.
- Jalur render video bergerak memakai decode frame + encoding ulang per-frame untuk memungkinkan overlay; lebih berat daripada passtrough, dan perilaku codec/MediaMetadataRetriever bisa berbeda antar HP.
- Track video dalam Flow tidak di-trim/di-reorder secara otomatis berdasarkan isi gambar; kesesuaian visual adegan tetap tanggung jawab penyusun storyboard.
- Hanya hingga 36 scene dan 10 menit, sesuai batas renderer Android.
- Jalur TTS, login/backup Supabase, mode ASAQ/ZAYN, dan workflow GitHub lama dipertahankan.
- **APK belum dibuild di lingkungan ini** karena Android SDK/Gradle tidak tersedia. Perubahan native baru bisa dikonfirmasi melalui build Actions dan tes di HP sungguhan.

## Pemeriksaan source
- `node tests/scene-sync.test.cjs`: lulus
- `node tests/ai-transcription.test.cjs`: lulus
- `node tests/auto-progress.test.cjs`: lulus
- `node tests/subtitle-timeline.test.cjs`: lulus
- `node tests/scene-planner.test.cjs`: lulus (ekspektasi dua tes lama diperbarui agar sesuai perilaku pemotongan per-kalimat yang telah ada di source v5.0.32)
- `node tests/test-story-continuity.js`: lulus
- Syntax JavaScript utama `index.html`: diperiksa
- Build Gradle dan uji codec native: belum tersedia secara lokal.

## Cara build GitHub
Ekstrak ZIP luar lalu upload hanya file **`KreasiFlow-Android-Update-V5-Source.zip`** ke root repository yang sama. Ganti versi lama dengan nama file yang sama. Jalankan workflow debug terlebih dahulu. Untuk release gunakan workflow signed yang sudah ada dan masukkan versi `5.0.33`. Jangan unggah API key, keystore, atau backup rahasia ke repo.
