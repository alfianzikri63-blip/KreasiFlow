# KreasiFlow Studio v5.0.34 — Prompt Google Flow + MP4 Per Scene

Basis: v5.0.33 sinkron render VO / subtitle / SFX. Perbaikan v5.0.34 sengaja hanya mengubah alur per scene dan perhitungan jumlah scene, tanpa mengganti native renderer.

## Scene & Video
- Setiap scene yang dibuat tampil dengan satu editor **Prompt Google Flow (bisa diedit)**, tombol **Salin prompt & buka Google Flow**, dan tombol **Impor MP4 hasil Flow**.
- Tombol generate gambar AI, gerakan AI, video API berbayar, upload/hapus gambar dan pratinjau gambar statis tidak lagi ditampilkan di **setiap kartu scene**. Implementasi lama tetap di source untuk kompatibilitas proyek lama; tidak dieksekusi melalui kartu baru.
- Google Flow dapat dipakai Text-to-Video tanpa harus membuat atau mengunggah gambar di aplikasi. Bila ingin memakai gambar referensi/karakter, tambahkan secara manual di Flow.
- Editor prompt khusus disimpan dalam proyek/JSON dan disalin ke Flow saat tombol scene dipilih. Prompt bawaan meminta SFX/ambience saja, tanpa narasi dalam bahasa apa pun.
- File MP4 masih diimpor manual per scene. Render native dari v5.0.33 tetap dipakai.

## Angka scene antar-tab
- Perkiraan pada tab Proses dan storyboard pada tab Scene memakai kalkulasi bersama: jumlah = ceil(durasi / target detik per scene), dibatasi 100 scene dan jumlah kata agar tidak dibuat scene kosong.
- Pembuatan storyboard melakukan split seimbang berdasarkan kalimat, tanda baca dan frasa, sehingga untuk narasi 60 detik @ 6 detik, hasilnya 10 scene bila naskah cukup panjang.
- Semua kata narasi hanya dipakai satu kali; tidak dipalsukan atau diulang untuk mengisi jumlah scene.
- Jika memuat proyek lama yang memiliki 8 scene namun targetnya 10, UI memperlihatkan kedua angka dengan jujur dan menyediakan tombol **Sinkronkan jumlah scene**. Sinkronisasi bisa mengubah pasangan MP4; aplikasi meminta konfirmasi jika MP4 telah diimpor.
- Timing setiap scene masih **estimasi berbasis kata** jika belum ada timestamp transkrip audio. Untuk presisi gunakan AI transkrip dan penyesuaian manual waktu di tab Render.

## Cara uji
1. Tab Proses: unggah VO, pilih 6 detik/scene, isi narasi, lalu **Buat / sinkronkan seluruh scene & prompt Flow**.
2. Tab Scene & Video: pastikan jumlah kartu sama dengan jumlah storyboard pada tab Proses, tiap kartu punya editor prompt dan impor MP4.
3. Periksa bahwa prompt teredit tetap ada setelah pindah tab, dan tekan tombol Google Flow agar prompt yang disalin sesuai editor.
4. Impor MP4 urut scene, buat AI transkrip atau impor SRT, lalu render dengan tombol **Render MP4 Flow + VO + Subtitle Sinkron**.

## QA
- Semua pengujian JS Node lulus, termasuk skenario 60 detik / 6 detik = 10 scene dan narasi tetap utuh.
- Smoke test antarmuka headless berhasil: 10 kartu scene, tidak ada tombol generate gambar/video AI di setiap kartu, dan perubahan prompt bertahan setelah pindah tab.
- **Build Android dan render fisik di perangkat belum dijalankan**. Verifikasi final tetap harus memakai APK debug v5.0.34 terlebih dahulu sebelum rilis signed, karena dukungan codec/perangkat dapat berbeda.
- Jangan mengunggah API key atau signing ke GitHub. Workflow ZIP dan konfigurasi signing sebelumnya dipertahankan.
