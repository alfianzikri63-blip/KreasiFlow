# KreasiFlow Studio v5.0.35 — Prompt Google Flow unik setiap scene

## Perbaikan

Sumber v5.0.34 memberi narasi tiap scene pada template prompt yang hampir sama, sehingga hasil Flow dapat mengulang pose, objek dan framing. Pada v5.0.35 setiap scene sekarang memiliki:

1. Aksi fisik berdasarkan kalimat narasi yang utuh. Jika satu kalimat terbagi ke beberapa scene karena target durasi, sistem menyusun tahap awal → gerakan utama → hasil; tidak menyalin tindakan identik ke semua scene.
2. Komposisi kamera khusus per scene (wide, medium tracking, detail insert, over shoulder, low angle, high angle, dan lain-lain).
3. Identitas dan gaya visual tetap (bukan outfit/karakter baru). Tidak ada narasi/dialog dari Flow; hanya SFX dan ambience.
4. Tombol **Bedakan aksi seluruh scene dengan AI** (AI teks Gemini/OpenRouter, memerlukan API key yang disimpan pengguna; bukan generate gambar/video) untuk menyusun shot khusus di seluruh cerita berdasarkan semua scene. Hasil disimpan di proyek dan ikut saat export/import JSON.
5. Tombol **Perbarui prompt lama** untuk pengguna yang telanjur mengedit prompt secara manual di versi lama. Meminta konfirmasi, tidak menghapus MP4 hasil impor. Simpan JSON sebelum reset jika ingin menyimpan teks lama.
6. Perbaikan mode Text-to-Video dan prompt master: kedua jalur memasukkan aksi/angle berbeda, bukan hanya nomor scene.

## Alur penggunaan

1. Masuk tab **Proses**, pastikan narasi VO dan jumlah scene sesuai, lalu masuk **Scene & Video**.
2. Ketuk **Buat / sinkronkan prompt semua scene** untuk membuat scene dari narasi. Jika narasi tidak berubah, sistem mempertahankan MP4 lama.
3. Jika prompt lama tidak berubah setelah update, ketuk **Perbarui prompt lama** (muncul hanya bila pernah diedit/dikunci). Simpan backup proyek JSON sebelum reset.
4. Gunakan **Bedakan aksi seluruh scene dengan AI** (opsional, lebih cocok untuk narasi abstrak atau gerakan berulang). Ini memakai token/kuota model teks pengguna, tidak memproduksi MP4.
5. Periksa `UNIQUE VISIBLE EVENT IN THIS SCENE` dan `SHOT COMPOSITION AND CAMERA` pada setiap kartu sebelum menyalin. Bila dua adegan serupa, edit prompt spesifik dengan aksi yang benar-benar berbeda.
6. Di Flow pilih generasi Text-to-Video **baru** untuk setiap scene, bukan memperpanjang video/variasi frame sebelumnya jika ingin gerakan berbeda; jangan mengandalkan prompt yang ditumpuk ke satu generasi untuk menghasilkan banyak file secara otomatis.
7. Download MP4 setiap scene dan impor ke nomor scene masing-masing. Render dengan VO dan subtitle seperti sebelumnya.

## Batasan dan pengujian

- Generator lokal tidak memanggil AI dan tidak dapat menjamin hasil Google Flow berbeda, karena sampling provider tidak dikendalikan aplikasi. Gunakan tombol AI untuk memperjelas visual beat, atau edit manual jika diperlukan.
- Identitas karakter tetap konsisten tanpa mengubah proporsi wajah atau style, tetapi konsistensi paling akurat memerlukan reference di Google Flow jika tersedia.
- Tests JavaScript, pemeriksaan browser antarmuka, dan struktur ZIP dijalankan secara lokal. **Build APK dan uji generate Google Flow langsung belum dilakukan.**
- Tidak ada API key atau keystore tertanam di ZIP source.
