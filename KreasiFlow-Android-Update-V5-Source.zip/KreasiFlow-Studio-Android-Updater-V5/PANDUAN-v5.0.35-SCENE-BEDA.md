# KreasiFlow v5.0.35 — Google Flow Scene Diversity

## Penyebab dari source v5.0.34
Prompt standar pada setiap scene menggunakan teks generik “Show the event represented by this narration”, membuat hasil video berulang walau narasinya berbeda. Split scene 60s ke 10 bagian bisa membelah satu kalimat sehingga scene kehilangan konteks; scene hasil video mengulang tokoh, komposisi, dan adegan.

## Perbaikan
1. `flow-shot-planner.js`: setiap scene menyusun inti **peristiwa fisik + komposisi kamera sendiri**. Subjek/wardrobe/style boleh tetap sama tanpa memaksa pose/kamera identik.
2. Potongan narasi yang berhenti di tengah kalimat dianalisis dengan kalimat lengkap. Bila kalimat sama dipakai beberapa scene, scene diminta menampilkan tahapan awal -> gerakan -> hasil secara berurutan, bukan mengulang momen yang sama.
3. Prompt baru punya satu aksi utama yang terlihat, perbedaan framing/camera dari scene tetangga, dan aturan audio SFX saja tanpa VO Inggris, musik, atau subtitle dari Flow.
4. Tombol `✨ Bedakan aksi seluruh scene dengan AI` di tab Scene & Video menyusun aksi dan kamera tiap scene dengan Gemini/OpenRouter teks. Output disimpan per scene; tombol ini tidak memanggil video/gambar AI berbayar.
5. Prompt edit manual disimpan dan tidak ditimpa otomatis. `↻ Perbarui prompt lama` hanya muncul bila ada override, dengan konfirmasi sebelum menghapus teks edit manual. Klip MP4 impor tidak dihapus.
6. Existing renderer VO + SFX + subtitle, AI transkrip, Supabase, dan style visual tetap ada di source.

## Penggunaan
1. Update APK dan pastikan header `V5.0.35`.
2. Untuk proyek lama: tab `Scene & Video` -> cek prompt tiap scene; jika masih prompt edit manual lama, simpan JSON lalu pilih `↻ Perbarui prompt lama`.
3. Bila tersedia API teks Gemini/OpenRouter: pilih `✨ Bedakan aksi seluruh scene dengan AI`. Tanpa API ini, perbedaan dasar otomatis dibuat dari kata kerja yang ada di narasi dan bagian cerita.
4. Baca prompt scene 1–N lalu pilih `Salin prompt & buka Google Flow` untuk setiap scene. Buat video baru karena klip lama tidak berubah oleh update prompt.
5. Impor setiap MP4 hasil Flow ke kartu scene yang tepat; render dengan VO/SFX/subtitle sesuai pengaturan pada tab Proses/Render.

## Batasan jujur
- Model Google Flow eksternal tidak menjamin hasil setiap shot benar-benar berbeda; variasi sudah diperjelas lewat instruksi, tetapi tetap perlu dicek secara visual.
- Narasi yang sangat abstrak atau tidak memiliki peristiwa nyata memerlukan penyuntingan cerita atau tombol AI untuk menulis visual beat yang lebih spesifik.
- Jumlah scene tidak dapat menciptakan kejadian fisik baru dari naskah yang sangat singkat; tahapan aksi dipakai bila satu kalimat menjangkau beberapa scene.
- Tes source JS dan UI browser dilakukan. Build Android dan render on-device belum dilakukan dalam lingkungan ini.
