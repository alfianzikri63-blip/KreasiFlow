# KreasiFlow Studio v5.0.36 — Storyboard AI-first + pemeriksa perbedaan

## Perubahan utama

- Tombol **✨ Buat storyboard dengan AI** di bagian **★ Mulai dari Naskah** dan tombol sinkronisasi storyboard biasa kini memanggil Gemini/OpenRouter, **bukan** membuat storyboard visual dari template lokal secara diam-diam.
- Pembagian NASKAH menjadi unit suara/timing tetap menggunakan alat pengelompokan lama agar urutan VO, timestamps, dan durasi tidak berubah. **Desain footage / aksi / camera / setting / prompt gambar / prompt video dibuat oleh AI**, bukan oleh pemecah lokal.
- Semua scene punya peristiwa aksi, komposisi kamera, setting, image prompt (first frame) dan video motion prompt masing-masing. Tokoh berulang dan art style terkunci.
- Auto-check memeriksa **seluruh pasangan scene** berdasarkan teks aksi, camera, setting dan image prompt; hingga **dua putaran revisi AI** dicoba jika ada duplikasi tinggi. Jika masih mirip, tampilkan peringatan (jangan menyatakan semua unik secara palsu).
- Panel **🔎 Pemeriksa perbedaan setiap scene** menunjukkan risiko kemiripan dan scene pembanding. Tombol revisi AI tersedia untuk scene yang tidak dikunci manual.
- Tambahan **🎞 Periksa visual MP4 impor** setelah sedikitnya dua klip punya URL preview: ambil dua frame tiap klip dengan browser dan bandingkan perceptual fingerprint. Ini **indikasi kemiripan frame**, bukan deteksi aksi/adegan berbasis AI. Klip yang tak terbaca dilaporkan sebagai "belum dicek", tidak dianggap berbeda.
- Naskah dan klip yang sama tidak dihapus saat regenerasi. Prompt yang diedit manual tetap terjaga jika potongan narasinya sama. Klip dengan narasi berubah bisa kehilangan pasangan; pengguna mendapat konfirmasi terlebih dahulu bila ada MP4 yang telah dipasang.
- Jika API key AI tidak tersedia / request gagal, storyboard lama tetap ada; tidak ada fallback diam-diam ke template visual lokal.
- VO, SFX, subtitle, Google Flow bridge manual, Supabase, cloud key handling, render MP4 native tetap dipertahankan.

## Alur penggunaan

1. Masuk **Pengaturan AI**, simpan Gemini API Key atau OpenRouter Key (jangan tulis di source/GitHub).
2. Tulis/buat naskah di tab utama dan atur gaya visual, durasi, serta jumlah detik per scene.
3. Buka **Scene & Video** → **✨ Buat storyboard dengan AI**. AI mengerjakan prompt berurutan dalam batch; saat gagal, storyboard lama tidak ditimpa.
4. Lihat **Pemeriksa perbedaan setiap scene**. Perbaiki scene yang terdeteksi mirip melalui tombol **✨ Revisi adegan mirip via AI**, atau edit manual.
5. Salin prompt scene → **Google Flow**; buat setiap MP4 scene **secara terpisah**, lalu impor ke kartu scene yang tepat. Jika dua atau lebih klip punya preview, gunakan pemeriksaan visual MP4.
6. Di Render, gabungkan klip dengan VO dan subtitle. Simpan/backup proyek JSON bila perlu.

## Batasan pengujian

- **Sudah diuji:** `node --check` JavaScript, 22 unit tests Node.js, struktur source ZIP. Tidak ada API key/keystore tertanam.
- **Belum diuji langsung:** panggilan AI Gemini/OpenRouter di perangkat, hasil video Google Flow, seek frame pada semua perangkat Android, build APK Android dengan SDK/keystore publikasi, encoding video nyata.
- Perbedaan **prompt** maupun fingerprint **frame** tidak menjamin seluruh video hasil Google Flow benar-benar berbeda. Tetap tonton preview dan cek klip sebelum render.
- File ini adalah **source ZIP**. Untuk update terpasang di HP, build APK release dengan signing key serta packageId asli agar update tidak memerlukan uninstall. APK debug belum tentu bisa meng-update APK produksi.
