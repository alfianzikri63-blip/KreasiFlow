# KreasiFlow Studio v5.0.37 — Progress Bar + Persentase Setiap Proses

Basis: source KreasiFlow v5.0.36, seluruh fitur storyboard AI beda footage dan pemeriksaan antar-scene tetap ada.

## Pembaruan
- Panel progres global berada di bawah navigasi tab, sehingga tetap terlihat ketika pengguna berpindah tab atau tampilan `render()` diperbarui.
- Masing-masing proses memiliki label, progress bar, persentase 0–100%, dan status tahapan.
- Pembuatan storyboard AI menunjukkan jumlah scene yang sudah selesai dari total scene, lalu validasi dan revisi duplikat.
- Pemeriksa perbedaan MP4 menunjukkan jumlah klip yang sudah dianalisis.
- Batch gambar/prompt video menampilkan progres per scene atau batch.
- Impor MP4 Google Flow, pengiriman VO, dan penyimpanan ekspor di Android menggunakan jumlah byte yang benar-benar ditransfer.
- Render MP4 menampilkan progres encoding native Android. Render di browser menunjukkan durasi frame yang sudah direkam.
- Transkripsi VO mengukur fase upload, lalu menampilkan status menunggu Gemini; tidak membuat persentase palsu selama permintaan belum selesai.
- Progres operasi yang berbeda tidak saling menimpa. Gagal/dibatalkan ditampilkan sebagai status gagal tanpa 100%; 100% hanya untuk tahap yang dilaporkan sukses.
- Auto Produksi lama tetap menggunakan progress bar tersendiri yang sudah ada di v5.0.29.

## Catatan akurasi
Persentase bertahap dari AI bukan persentase internal penyedia AI. Di waktu respons jaringan yang belum diketahui, angka tetap pada milestone yang sudah selesai dan pesan menunjukkan menunggu. 100% berarti tugas lokal/KreasiFlow sudah selesai; tidak menjamin klip Flow generasi eksternal bagus atau seluruh scene pasti unik.

## Pengujian
- `node --check` untuk kode modul dan JavaScript di `index.html`.
- `node --test tests/*.test.cjs` (26 lulus pada pengujian lokal).
- ZIP source divalidasi; compiler Android/SDK tidak tersedia dalam lingkungan pengujian ini, sehingga APK harus dibangun lewat GitHub Actions dan diuji di perangkat.

## Panduan GitHub
1. Gunakan file ZIP source **di dalam** paket ZIP-dalam-ZIP, atau ZIP source langsung, dan namai `KreasiFlow-Android-Update-V5-Source.zip`.
2. Unggah untuk mengganti file dengan nama sama di root repo GitHub.
3. Jalankan workflow uji debug build terlebih dahulu.
4. Build APK release menggunakan signing key lama, dan jangan pernah unggah API key atau kunci signing ke repo.
