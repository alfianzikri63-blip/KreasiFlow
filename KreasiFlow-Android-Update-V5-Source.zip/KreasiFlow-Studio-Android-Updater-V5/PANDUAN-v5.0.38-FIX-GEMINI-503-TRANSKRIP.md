# KreasiFlow Studio v5.0.38 — AI Transkrip VO: pulih dari Gemini HTTP 503

Basis: v5.0.37; fitur storyboard AI, audit beda footage, progress bar per proses, render, Google Flow dan Supabase tetap dipertahankan.

## Masalah
Gemini HTTP 503 berarti layanan sedang penuh sementara, bukan kegagalan API key. v5.0.37 hanya memiliki retry 503 untuk text generation, belum untuk operasi transkripsi audio dari VO.

## Perbaikan
- Pada satu klik AI Transkrip dari VO, file audio hanya ditransfer sekali dari WebView ke Android (asset ID yang sama dipakai ulang).
- Jika layanan mengembalikan HTTP 503, 502 atau 504, aplikasi mencoba maksimal tiga permintaan: pertama model `gemini-3.6-flash`, berikutnya `gemini-3.8-flash` (jeda 3 dan 8 detik).
- Bila model pertama tidak tersedia (404), aplikasi mencoba model alternatif. 429 / 401 / 403 tidak diulang otomatis.
- Progress bar tetap menampilkan persentase berdasarkan tahapan lokal dan label percobaan 1/3, 2/3, 3/3. Tidak mengarang kemajuan internal Gemini.
- Sebelum mengirim audio, dialog menjelaskan maksimal tiga permintaan dan potensi kuota/kredit. Tidak ada API key disalin ke JavaScript.
- Setelah semua upaya gagal, muncul pesan singkat berbahasa Indonesia dan subtitle lama tidak ditimpa. Tombol "Estimasi dari teks" dan "Impor SRT" tetap tersedia.
- Mode fallback hanya melalui allowlist native model. Tidak mengubah endpoint sembarangan.

## Pengujian
- Tes JS mencakup retry 503, fallback 404, stop pada 401/403/429, serta batas tiga panggilan.
- Struktur ZIP diperiksa dan `node --test tests/*.test.cjs` dijalankan.
- APK belum dibuild/dicoba pada perangkat Android. Uji lewat GitHub Actions lalu install signed-release memakai signature yang sama, bukan APK debug yang package berbeda.

## Untuk GitHub
Unggah ZIP sumber dalam paket dan ganti nama file source di root menjadi `KreasiFlow-Android-Update-V5-Source.zip`; build debug dahulu, lalu jalankan workflow release menggunakan kunci signing yang sudah ada.
