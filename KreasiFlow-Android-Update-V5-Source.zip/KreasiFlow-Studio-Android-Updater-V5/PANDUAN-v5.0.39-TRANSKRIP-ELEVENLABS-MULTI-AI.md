# KreasiFlow Studio v5.0.39 — Multi-AI Transkripsi VO

**Basis**: source KreasiFlow v5.0.38. Versi ini fokus pada jalur **AI Transkrip dari VO**, tanpa mengganti storyboard AI, audit perbedaan footage, Google Flow, Supabase, audio lain, subtitle manual, dan render video.

## Yang baru

- **Default ElevenLabs Scribe v3** menggunakan `POST https://api.elevenlabs.io/v1/speech-to-text`, multipart file, model `scribe_v3`, `timestamps_granularity=word`.
- **Fallback opsional Groq Whisper Large V3 Turbo**, menggunakan `POST https://api.groq.com/openai/v1/audio/transcriptions` dan `response_format=verbose_json`, word + segment timestamps.
- **Gemini** tetap tersedia, termasuk mode sebelumnya dan retry tiga model-percobaan ketika dipilih sendirian.
- Pemilihan provider dan centang **Fallback AI otomatis** berada pada bagian **6 · Transkrip & Subtitle Bertimestamp**.
- **Pengaturan AI** mendapat kotak ElevenLabs API key dan Groq API key. Disimpan lewat Android Keystore (AES-GCM), tidak ditulis ke ZIP/GitHub/JSON proyek dan dapat diikutsertakan dalam backup terenkripsi Supabase seperti key yang sudah ada.
- Transkrip bertimestamp per kata dari provider digabung menjadi *cue* SRT pendek yang mengikuti jeda dan tanda baca, hingga 250 cue. Pengecekan timestamp, preview pemutaran VO, editor waktu manual, dan ekspor SRT tetap digunakan.
- **Progress bar + persentase**: unggahan VO mengikuti jumlah byte; menunggu respons AI memperlihatkan status dan nomor percobaan, bukan angka palsu dari server; sesudah hasil diterima bar berlanjut ke validasi dan penyimpanan.
- Jika provider pilihan tidak dikonfigurasi dan fallback diaktifkan, aplikasi bisa memilih provider yang memiliki key. Jika server mengembalikan HTTP 429/500/502/503/504 dan key cadangan tersedia, akan berpindah satu kali per provider. Tidak otomatis mengulang bila error 400/401/402/403/404 atau timeout jaringan yang berpotensi sudah terhitung biaya.
- Subtitle lama **tidak ditimpa** sampai hasil baru selesai dan semua cue valid.

## Cara pakai di Android

1. Buka APK **KreasiFlow v5.0.39** → ⚙ **Pengaturan AI**.
2. Isi **ElevenLabs Scribe v3 API Key**, lalu **Simpan Pengaturan AI**; isi **Groq API Key** jika ingin fallback. Kedua penyedia dapat mengenakan biaya API tergantung paket.
3. Buka **Proses → 6 · Transkrip & Subtitle Bertimestamp**. Unggah VO (MP3/WAV/M4A/AAC/OGG/FLAC; maksimal 12 MB dan durasi maksimal 30 menit).
4. Pilih **elevenlabs** dan aktifkan **Fallback AI otomatis** bila ingin opsi cadangan; tekan **AI Transkrip dari VO**.
5. Baca dialog yang merinci urutan penyedia dan potensi biaya, lalu setujui. Lihat indikator progres di atas panel.
6. Periksa hasil dengan memutar audio dan mengedit timestamp jika perlu. Tekan **Ekspor SRT** atau lanjutkan render.

## Catatan penting

- Word timestamps Scribe/Groq menjadi subtitle dengan timestamp **cue** gabungan. Ini bukan subtitling per kata tunggal pada render; cue tetap berasal dari waktu audio, bukan perkiraan naskah.
- Fallback aktif hanya untuk kegagalan kapasitas atau rate limit, bukan setiap kesalahan. Tidak ada klaim jaminan availability dari provider.
- API key tidak disertakan dalam paket dan tidak dimasukkan ke dialog chat. Buat key sendiri di dashboard resmi ElevenLabs/Groq.
- Tidak ada panggilan API sungguhan dalam pengujian lokal; tes unit menggantikan respons provider dengan mock. Java transport dikompilasi menggunakan stub `org.json`; **build Android Gradle/APK belum bisa dijalankan di lingkungan ini**.
- Jika ingin update aplikasi existing tanpa uninstall, gunakan **APK signed release** yang ditandatangani dengan **keystore lama yang sama** (build debug memakai ID paket berbeda).
- File source GitHub **harus** bernama `KreasiFlow-Android-Update-V5-Source.zip` dan berada di root repo agar workflow sebelumnya mengenalinya. Unggah ZIP source, **bukan** paket luar ZIP-dalam-ZIP.

## Rujukan API

- https://elevenlabs.io/docs/api-reference/speech-to-text/convert
- https://elevenlabs.io/docs/overview/models
- https://console.groq.com/docs/speech-to-text
