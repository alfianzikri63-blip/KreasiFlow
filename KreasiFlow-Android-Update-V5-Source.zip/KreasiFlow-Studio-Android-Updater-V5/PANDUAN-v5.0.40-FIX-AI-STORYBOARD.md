# KreasiFlow Studio v5.0.40 — Fix AI Storyboard Berhenti 5%

Basis proyek: v5.0.39. Update ini mengatasi dua masalah aplikasi: error asli tidak muncul pada progress bar dan storyboard tidak mencoba API key cadangan yang sudah tersimpan.

## Perubahan

1. **Gemini ↔ OpenRouter fallback**: jika provider AI terpilih gagal, aplikasi mencoba provider kedua **hanya jika key-nya sudah disimpan**. Jika tidak ada key, aplikasi memberi pesan khusus. Status API key tersimpan tidak menjamin key valid, saldo/kuota tersedia, atau server dapat diakses.
2. **Respons JSON storyboard tahan variasi**: menerima JSON yang dibungkus code fence, sejumlah nama kolom alternatif, dan prompt gambar/video yang secara eksplisit dirangkai dari arahan shot yang benar-benar ditulis AI. Tanpa respons AI yang valid, aplikasi tidak membuat storyboard palsu.
3. **Batch lebih kecil**: dua scene per permintaan; jika gagal karena respons tidak lengkap atau gangguan provider (bukan 429/401/402/403), AI mencoba versi satu scene secara terbatas. Jangan mengulang permintaan secara berlebihan saat rate limit/kuota habis.
4. **Resume otomatis**: batch AI yang berhasil disimpan sementara di localStorage dengan fingerprint naskah, gaya, karakter dan rasio. Tekan tombol AI lagi untuk menyelesaikan scene yang belum berhasil. Ganti naskah/gaya/karakter akan membuat cache berbeda dan menghindari pencampuran storyboard.
5. **Error selalu terlihat**: pesan kegagalan disimpan di bawah tombol AI, dan progress card menampilkan sumber error aktual. Proyek dan scene lama tetap aman sampai seluruh storyboard baru selesai. Bila berhasil, pesan error dan cache sementara dibersihkan.
6. **Pemeriksa kemiripan footage** tetap berjalan setelah storyboard selesai. Subtitle SRT, ElevenLabs Scribe v3, Groq, Gemini, Google Flow, progress, Supabase, VO, SFX, ekspor dan render tidak diubah.

## Cara mencoba

1. Masuk ke Pengaturan AI (⚙), periksa Gemini API Key / OpenRouter API Key. Satu saja cukup; dua key membuat fallback tersedia. Jangan membagikan API key.
2. Buka Scene & Video → Mulai dari Naskah → **Buat storyboard dengan AI**.
3. Jika gagal, baca panel **Penyebab storyboard gagal**; misalnya HTTP 429 (rate limit/kuota), HTTP 503 (kapasitas provider), 401 (key), timeout, atau format AI tidak lengkap. Semua kasus berbeda tindak lanjutnya.
4. Jika masalah sementara, tekan tombol yang sama. Scene yang telah selesai dianalisis dapat dipakai ulang dari cache. Jika ada error 429, periksa limit akun/provider dulu.
5. Setelah semua scene terbentuk, buka **Pemeriksa perbedaan setiap scene**. Tetap tinjau hasil Google Flow secara visual; audit prompt tidak menjamin video pasti berbeda.

## Memasang update di GitHub

- Unggah ZIP source bernama **`KreasiFlow-Android-Update-V5-Source.zip`** ke root repository GitHub yang sudah memakai workflow V5.
- **Jangan** unggah paket ZIP-dalam-ZIP langsung sebagai source; jika memakai paket luar, ambil ZIP source di dalamnya.
- Jalankan GitHub Actions build seperti sebelumnya, lalu buat **signed release v5.0.40** memakai signing key **yang sama** dengan APK release lama. **APK debug** memakai ID paket tambahan sehingga bukan update inplace ke release.
- API key dan keystore tidak ada di source ZIP.

## Validasi dan batasan

- `node --check` lulus untuk script utama dan `storyboard-resilience.js`; 60 tes JavaScript lulus (termasuk batch retry/resume dan fallback provider dengan mock).
- ZIP source + paket luar diperiksa integritasnya.
- Tidak ada pengujian panggilan langsung dengan API key pengguna dan tidak ada build Gradle/tes di HP. Integrasi runtime perlu diuji setelah APK release diinstal.

Rujukan: https://openrouter.ai/docs/api/api-reference/chat/send-chat-completion-request dan https://ai.google.dev/gemini-api/docs
