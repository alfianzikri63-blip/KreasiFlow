# KreasiFlow Studio v5.0.41 — 4 Gaya Motion Graphic

Basis v5.0.40. Empat gaya ditambahkan ke **47 pilihan style sebelumnya**; kini ada **51**.

## Empat style baru

1. **Motion Graphic 2D** — animasi grafis vektor datar, parallax 2D, bentuk geometris dan transisi halus.
2. **Motion Graphic 3D** — geometri 3D stylized, material matte, rotasi, assembly, dan gerak kamera sinematik.
3. **Motion Graphic Edukasi** — diagram, panah, cutaway, alur proses, dan perubahan sebab-akibat yang jelas. Tidak merekayasa mekanisme faktual.
4. **Kinetic Typography** — animasi huruf dan kata kunci pendek; bukan subtitle. Teks AI dapat meleset ejaannya, jadi tinjau secara manual sebelum publikasi.

## Alur pakai

1. Buka tab **Proses** atau **Scene & Video → Pilih gaya visual**.
2. Pilih salah satu dari empat style. Perhatikan panel **Motion Style Lock** yang menegaskan aturan warna, material/garis, dan bahasa gerak.
3. Masukkan **Tokoh utama (opsional)** bila ada karakter berulang, misalnya `ASAQ, same character as the manually uploaded chibi reference image`; upload gambar referensi/ingredient yang sama **secara manual** di Google Flow pada setiap scene. Source ini **belum** mengunggah gambar karakter secara otomatis ke Google Flow.
4. Tekan **Buat storyboard dengan AI**. Aturan style ikut dikirim ke Gemini/OpenRouter. AI tetap harus membuat peristiwa/aksi/kamera berbeda per scene.
5. Salin **prompt Google Flow** per scene. Tiap prompt kini mencantumkan *Global Motion Graphic Visual Bible* secara eksplisit. Pemeriksa beda scene dan progress bar tetap tersedia.
6. Impor MP4 hasil Flow seperti sebelumnya, tinjau konsistensi karakter/style, lalu render.

## Catatan implementasi

- Modul baru: `app/src/main/assets/motion-graphic-styles.js`; digunakan untuk storyboard AI, AI refinement, prompt Flow, dan penjelasan style di UI.
- Cache AI storyboard versi lama tidak digunakan ulang bila aturan style berganti; konten proyek lama tetap dipertahankan.
- Pemilihan style bukan jaminan model video menuruti bentuk atau karakter dengan sempurna. Penguncian via gambar referensi Flow tetap memerlukan tindakan pengguna.
- Kinetic typography memerlukan pemeriksaan ejaan dan sering lebih akurat bila teks final ditambahkan saat editing video, bukan dipaksakan AI video.
- Tidak ada API key, kredensial, atau keystore signing di source ZIP. Struktur ZIP lama untuk GitHub dipertahankan.

## Uji

Jalankan `node --test tests/*.test.cjs` dari direktori proyek setelah ekstrak ZIP untuk pemeriksaan logika JS. Build APK dan pengujian langsung layanan AI/Flow memerlukan lingkungan Android/akun Google Flow.

## GitHub

Unggah ZIP *source* bagian dalam menggunakan nama **`KreasiFlow-Android-Update-V5-Source.zip`** ke root repo lama. Rilis APK **v5.0.41** dengan signing key release yang sama jika ingin memperbarui APK release yang terpasang. APK debug berbeda applicationId dengan release dan tidak dapat dipakai sebagai update langsung.
