# KreasiFlow Studio v5.0.42 — Render MP4 Latar Belakang & Notifikasi

## Mengapa v5.0.41 terhenti ketika layar HP terkunci?
Render MP4 native (slideshow maupun klip Google Flow) sebelumnya berjalan pada executor milik `MainActivity`. Ketika Android menghancurkan Activity, `onDestroy()` menghentikan executor dan menghapus cache media. Aplikasi WebView juga dapat membatasi JavaScript ketika berada di background.

## Yang diubah pada v5.0.42
- Renderer MP4 dipindahkan ke **RenderForegroundService** (`mediaProcessing`); tidak menyimpan referensi ke `WebView`/`Activity`.
- Saat pengguna menekan tombol render, konfigurasi dan path aset yang diverifikasi disalin ke file antrian privat aplikasi, lalu Android menjalankan foreground service.
- Render lokal tetap diproses menggunakan encoder H.264/AAC saat halaman ditutup/diminimalkan atau layar dikunci, selama Android tidak menghentikan servisnya.
- Notifikasi kanal `KreasiFlow — Proses render` menampilkan **persentase progress**, tahap encoding, tombol **Batalkan**, dan setelah selesai memberi tahu berkas berada di `Download/KreasiFlow`.
- Status render disimpan sehingga aplikasi bisa memperlihatkan kembali progress/hasil pada saat kembali ke depan.
- Permintaan izin notifikasi Android 13+ muncul saat render pertama kali. Pada manifest debug, izin notifikasi **tidak lagi dihapus**, sehingga APK Debug juga dapat menampilkan notifikasi setelah diizinkan.
- Saat layar dibuka ulang, progress bar membaca status native. Angka 100% hanya dicatat setelah file MP4 berhasil dipublikasikan ke MediaStore; angka sebelum publish dibatasi 99%.
- `MainActivity.onDestroy()` tidak lagi menghapus berkas render yang tengah dibutuhkan background service.
- `WAKE_LOCK` digunakan untuk partial CPU wakelock yang dibatasi selama render dan selalu dilepas pada akhir proses.
- Maksimal satu render berjalan bersamaan. Impor MP4, subtitle, VO, style Motion Graphic, karakter, storyboard AI, dan fitur lama tetap tersedia.

## Cara uji dari APK v5.0.42
1. Update `KreasiFlow-Android-Update-V5-Source.zip` di root repository GitHub. Jangan upload private keystore ke repository.
2. Di tab GitHub Actions, jalankan `Test KreasiFlow APK Build from ZIP`. Unduh artifact `Test-Debug-APK-Not-Updateable` (aplikasi debug terpisah).
3. Buka KreasiFlow > Render. Beri **izin notifikasi** ketika Android meminta. Jika sudah pernah ditolak, aktifkan melalui Pengaturan HP > Aplikasi > KreasiFlow > Notifikasi.
4. Mulai `Render MP4 Flow + VO + Subtitle Sinkron` atau `Slideshow MP4`.
5. Ketika notifikasi progress sudah muncul, tekan Home atau kunci layar 1–2 menit.
6. Buka bilah notifikasi: progress harus tetap bertambah. Buka aplikasi kembali: status harus tetap sesuai. Setelah 100%, cek `Download/KreasiFlow`.
7. Uji tombol **Batalkan** di notifikasi lalu coba jalankan render baru.
8. Untuk update aplikasi release terpasang, jalankan workflow `Publish Signed KreasiFlow APK from ZIP` versi `5.0.42` dengan signing key yang sama seperti rilis sebelumnya; jangan uninstall versi utama.

## Batasan Android yang perlu diketahui
- **Tidak mungkin menjamin 100% di seluruh perangkat:** Force Stop, kehabisan memori, sistem pembersih baterai vendor, matinya HP, serta restart proses dapat menghentikan layanan. Job yang terinterupsi dilaporkan secara jujur; proses diulang, bukan diklaim tetap berjalan.
- Android 15 memberi batas waktu kumulatif **6 jam per 24 jam** untuk foreground service jenis `mediaProcessing`. Rendering KreasiFlow dibatasi durasi video maksimal 10 menit, tetapi waktu encoding tergantung kemampuan HP.
- Jika izin notifikasi ditolak, foreground service masih bisa bekerja, namun notifikasi mungkin tidak terlihat di bilah notifikasi. Izinkan notifikasi agar progress dapat dipantau.
- **Yang benar-benar berjalan di background pada update ini adalah proses render MP4 native**. Proses naskah/storyboard AI bertahap, generate gambar, transkripsi yang dikendalikan JavaScript, dan render browser (MediaRecorder) belum dipindahkan ke antrean native background. Proses tersebut bisa dibatasi saat WebView disuspensi. Untuk mendukung semuanya, perlu antrian native/WorkManager dengan checkpoint terpisah, bukan sekadar wakelock.
- File media yang diimpor berada dalam cache internal. Saat sistem menghapus cache akibat kehabisan storage, impor ulang diperlukan.

## Validasi pada lingkungan pembuat
- Pengujian unit JavaScript (termasuk pemeriksaan integrasi status dan manifest): 74/74 berhasil.
- XML manifest diperiksa secara statis; struktur ZIP diuji dan daftar file diverifikasi.
- **Belum dilakukan** kompilasi APK dengan Android SDK, uji perangkat fisik Android, dan uji kunci layar nyata. Wajib menjalankan workflow build dan tes di HP sebelum dianggap rilis stabil.

Dokumentasi Android resmi: https://developer.android.com/about/versions/15/changes/foreground-service-types ; https://developer.android.com/develop/ui/compose/notifications/notification-permission
