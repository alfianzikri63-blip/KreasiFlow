# KreasiFlow Studio v5.0.43 — AI Background dengan Notifikasi Android

## Tujuan

Pembuatan judul, naskah, storyboard AI per dua scene, dan transkripsi VO tidak lagi harus menunggu di WebView. Permintaan berjalan di `AiForegroundService` (jenis foreground service `dataSync`), dimulai **saat pengguna menekan tombol ketika aplikasi masih terbuka**.

Pekerjaan dapat berlangsung ketika aplikasi diminimalkan atau layar dikunci. Notifikasi Android menampilkan persentase dan tahapan, serta **Batalkan**. Setelah selesai, hasil disimpan di penyimpanan internal aplikasi; buka KreasiFlow untuk menerapkan hasil tersebut. Proses render MP4 menggunakan `RenderForegroundService` dari v5.0.42.

## Cara memakai

1. Bangun APK v5.0.43 dari ZIP source. Berikan izin notifikasi Android saat diminta.
2. Masukkan API key Gemini/OpenRouter untuk judul, naskah, storyboard. Untuk transkrip, masukkan ElevenLabs (utama), Groq (cadangan), atau Gemini.
3. Tekan **Buat judul AI**, **Buat naskah AI**, **Buat storyboard dengan AI**, atau **AI Transkrip dari VO**.
4. Setelah status *berjalan di background* dan notifikasi muncul, HP boleh dikunci. Jangan **Paksa Berhenti** aplikasi.
5. Buka aplikasi kembali untuk membaca hasil AI dan menyimpan proyek. Tombol ekspor SRT tetap tersedia pada tab Proses.

## Perilaku penting

- Persentase storyboard berdasarkan batch selesai; selama menunggu respons provider persentasenya tidak bergerak palsu.
- Hasil tiap batch storyboard disimpan secara bertahap; jika sebuah batch gagal, lanjutkan lewat tombol storyboard. Hasil sebelumnya tidak harus diminta lagi.
- Android Keystore tetap mengelola API key. Key tidak diekspor ke proyek atau berkas pekerjaan.
- Foreground service memegang *partial wake lock* selama tugas dalam batas wajar. Jaringan internet dan kuota API tetap diperlukan. Fallback provider dapat menghabiskan kuota/kredit lebih dari satu provider.
- Output yang siap diterapkan tidak akan otomatis menimpa perubahan naskah yang baru dibuat tanpa konfirmasi.
- Notifikasi hanya muncul apabila diizinkan; pada sebagian Android jika izin ditolak, pekerjaan bisa berjalan tetapi notifikasi biasa tidak tampil.

## Batasan teknis yang perlu diketahui

- Android masih boleh menghentikan pekerjaan akibat *force-stop*, manajemen baterai vendor, memori rendah, hilang jaringan, atau pembatasan sistem. Status **interrupted** akan dilaporkan; pekerjaan bisa dijalankan ulang. Bukan jaminan proses terus hidup tanpa batas.
- Pada Android 15+, foreground `dataSync` dapat dikenai batas kumulatif 6 jam/24 jam untuk aplikasi yang menargetkan API 35+. Source ini menargetkan API 34, tetapi tetap menghormati perubahan sistem dan menyediakan `onTimeout`.
- **Hanya** judul, naskah AI, storyboard AI, transkrip VO dan render native yang telah dipindah ke service. Batch gambar AI, video dari Google Flow di Chrome, pemrosesan WebView lainnya, serta tombol **Auto Produksi judul sampai gambar** belum dipindah sepenuhnya; jangan kunci HP ketika memakai jalur tersebut jika tidak ingin proses berhenti.
- Google Flow tetap situs eksternal dan tidak dikendalikan otomatis oleh KreasiFlow.
- Source sudah diverifikasi `node --check`, tes Node, struktur ZIP, dan pemeriksaan sintaks Java sejauh alat lokal memungkinkan. **Belum ada kompilasi APK Android penuh atau uji nyata HP terkunci** pada sesi ini. Jalankan workflow `Test KreasiFlow APK Build from ZIP` di GitHub untuk memastikan build.

## GitHub

Unggah source ZIP internal dengan nama tepat `KreasiFlow-Android-Update-V5-Source.zip` menggantikan file source lama di root repository. Jalankan workflow Test Debug, lalu rilis bertandatangan dengan kunci lama (APK debug bukan update untuk APK release).
