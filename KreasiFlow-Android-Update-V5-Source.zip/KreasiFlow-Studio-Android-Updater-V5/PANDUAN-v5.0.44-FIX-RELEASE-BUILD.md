# KreasiFlow Studio v5.0.44 — Fix build release APK

## Error asli yang diperbaiki

GitHub Actions run #44967583078 (`Publish Signed KreasiFlow APK from ZIP`) gagal pada task `:app:compileReleaseJavaWithJavac`. Compiler melaporkan dua kesalahan di `MainActivity.java:653`: `unreported exception JSONException; must be caught or declared to be thrown`.

Akar masalah: pada `catch(Exception e)` di `startBackgroundAi`, dua pemanggilan `JSONObject.put` dapat melempar `JSONException` dan tidak tertangani. Sekarang respons error dibentuk sebagai JSON valid menggunakan `JSONObject.quote(...)` tanpa checked exception sehingga `javac` dapat mengompilasinya. Tidak ada API key yang dimasukkan ke ZIP.

Perubahan v5.0.44 hanya memperbaiki kesalahan compiler ini dan memperbarui nomor versi. Fitur v5.0.43—AI background (judul, naskah, storyboard, transkripsi), render background, notifikasi progres—tetap dipertahankan.

## Upload source ke GitHub

1. Unggah berkas `KreasiFlow-Android-Update-V5-Source.zip` dari paket ini ke root repo **alfianzikri63-blip/KreasiFlow**, menggantikan nama yang sama. Jangan unggah ZIP luar sebagai source.
2. Jalankan Actions → `Test KreasiFlow APK Build from ZIP` terlebih dahulu (tes kompilasi APK).
3. Jika test build sukses, jalankan `Publish Signed KreasiFlow APK from ZIP`, isi versi **5.0.44**. Gunakan GitHub Secrets signing yang sudah ada.
4. APK debug adalah package berbeda (`.videotest`) dari APK rilis dan tidak bisa meng-update APK rilis. Untuk meng-update instalasi produksi, gunakan signed release dengan kunci dan applicationId yang sama.

## Verifikasi & batasan

Sudah: sumber ZIP divalidasi, `node --check`, tes JS, perbaikan lokasi error berdasarkan log GitHub yang sebenarnya. Tidak tersedia SDK/Gradle Android pada lingkungan ini, sehingga build APK Android sepenuhnya belum diverifikasi. Jalankan test build GitHub di atas sebelum mendistribusikan release.
