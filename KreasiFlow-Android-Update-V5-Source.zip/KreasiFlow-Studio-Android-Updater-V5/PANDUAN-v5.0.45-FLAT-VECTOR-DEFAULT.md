# KreasiFlow Studio v5.0.45 — Default 2D Flat Vector Motion Graphic

## Perubahan
- Galeri style: **2D Flat Vector Motion Graphic** adalah pilihan pertama (★ Default); total sekarang **52** style.
- Proyek baru otomatis memakai style ini. Pengaturan `sceneStyle` pada proyek lama, proyek JSON yang diimpor, dan riwayat lama **tetap dipertahankan** agar proyek yang sudah berjalan tidak berubah tanpa izin.
- Untuk memakai style pada proyek yang sudah ada: tab **Scene & Video** → **Pilih gaya visual** → pilih **2D Flat Vector Motion Graphic** pada dropdown atau galeri. Semua prompt Google Flow berikutnya mengambil style baru; prompt edit manual lama mungkin perlu ditinjau/diregenerasi.
- Visual Bible mewajibkan bentuk geometri dan warna solid, outline tegas, **murni 2D**, menolak CGI, 3D, perspektif 3D, photorealism, material realistis, bokeh, dan pencahayaan volumetrik.
- Style lock disertakan dalam permintaan storyboard AI, perencanaan scene dan prompt gambar awal, motion prompt serta master Google Flow. Identitas karakter yang disediakan pengguna tetap dipertahankan, sambil variasi aksi/komposisi berbeda per scene.
- Fitur v5.0.44 tetap ada: background AI (judul/naskah/storyboard/transkrip), background render, progress notifikasi, ElevenLabs/Groq/Gemini, scene checker dan Google Flow.

## Build
1. Upload ZIP source **KreasiFlow-Android-Update-V5-Source.zip** ke root repo GitHub lama untuk menggantikan file lama.
2. Jalankan workflow **Test KreasiFlow APK Build from ZIP**.
3. Bila berhasil, jalankan workflow release signed dengan versi **5.0.45**, gunakan signing key lama.

Catatan: ini aturan prompt. AI Google Flow dapat tetap menyimpang dari style; periksa hasil final serta gunakan master character reference jika perlu konsistensi karakter.
