# KreasiFlow Studio v5.0.46 — FPS 60 dan Frame Blend Opsional

## Apa yang berubah
- Render → Pengaturan render → **FPS**: tersedia **24 / 30 / 60**.
- Proyek baru memakai **30 FPS**. Proyek lama mempertahankan FPS tersimpan.
- 60 FPS dapat digunakan pada **slideshow** dan **kompilasi MP4 Google Flow + VO** lewat renderer Android.
- Renderer video Flow yang sebelumnya mengambil gambar hanya 12 kali/detik kini memakai laju frame yang ditulis di metadata video sumber (fallback 30 jika metadata tidak ada).
- Checkbox **Interpolasi ringan (Frame Blend)**: hanya aktif untuk video hasil impor ketika output dipilih 60 FPS dan klip sumber ber-FPS lebih rendah. Membaurkan dua frame bertetangga dengan alpha agar transisinya tidak sepenuhnya duplikasi frame. Ini **bukan** optical-flow / frame generation AI; bisa menyebabkan ghosting ketika gerakan cepat.
- 60 FPS diuji terhadap kemampuan codec H.264 perangkat; bila ukuran + FPS tidak didukung, muncul pesan agar memilih 540p / 30 FPS.
- Encoding tetap berlangsung melalui Foreground Service dengan progres/notifikasi Android sebagaimana v5.0.42+, dan fitur AI background lain dipertahankan.

## Cara pakai
1. Setelah instal APK baru, masuk **Render → Pengaturan render**.
2. Pilih **30 FPS** untuk hasil paling stabil, atau **60 FPS** untuk percobaan.
3. Untuk klip Flow 24/30 FPS, centang **Interpolasi ringan (Frame Blend)** bila ingin mencoba transisi lebih halus. Jika muncul bayangan ganda/berat, nonaktifkan.
4. Mulai dari **540×960 / 60 FPS**, klip singkat (mis. 10–20 detik), lalu bandingkan dengan 30 FPS. Naikkan ke 720p hanya jika encoder HP mampu.
5. Gunakan file MP4 H.264 yang biasa; simpan hasil render di Download/KreasiFlow.

## Batasan teknis
- Video sumber 30 FPS **tidak berubah menjadi 60 FPS motion asli**. Blend hanya menghasilkan frame antara berupa campuran dua gambar, bukan estimasi pergerakan objek.
- Decoder gambar berbasis MediaMetadataRetriever `OPTION_CLOSEST` bisa lambat di sebagian HP, terlebih pada 60 FPS, resolusi tinggi, atau video panjang. Baterai, panas, dan ukuran hasil bisa meningkat.
- Rekaman browser/WebView masih memerlukan halaman aktif; fitur render background mengandalkan APK Android.
- Tidak ada perubahan ke signing key, applicationId, storage API key, atau format proyek.

## Untuk GitHub
Unggah file **KreasiFlow-Android-Update-V5-Source.zip** (ZIP source langsung, bukan ZIP kit luar) di root repo menggantikan yang lama. Jalankan `Test KreasiFlow APK Build from ZIP` sebelum `Publish Signed KreasiFlow APK from ZIP` versi `5.0.46` dengan signing key lama.

## Pemeriksaan dalam paket
- Syntax JavaScript index.html dan tes Node dijalankan lokal.
- Struktur arsip sumber valid.
- Build Gradle Android sesungguhnya dan pengujian visual/render pada HP belum dijalankan di lingkungan pembuat paket; uji melalui GitHub Actions dan ponsel diperlukan.
