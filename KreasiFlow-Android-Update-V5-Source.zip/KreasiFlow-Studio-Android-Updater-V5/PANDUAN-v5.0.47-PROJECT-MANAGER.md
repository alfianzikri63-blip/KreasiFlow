# KreasiFlow Studio v5.0.47 — Project Manager & Backup Lengkap

## Fitur yang ditambahkan

- **Simpan Proyek** sekarang menyimpan metadata proyek, scene, judul/naskah, storyboard, subtitle bertimestamp, pengaturan render, serta media VO, musik, gambar scene, MP4 Flow yang telah diimpor, dan referensi karakter/edukasi yang tersedia.
- **Autosave metadata** sekitar satu detik setelah perubahan, **sinkronisasi media** sekitar 2,5 detik setelah perubahan. Media besar disalin ke penyimpanan privat Android, bukan disimpan dalam `localStorage` atau diserialisasi ke JSON.
- **Buka Proyek** memuat ulang file media permanen dan meregistrasi ID media native baru untuk renderer. Tidak perlu upload ulang VO/MP4 selama filenya sudah disimpan lengkap.
- **Duplikat Proyek** menggandakan metadata dan media, tanpa mengubah proyek awal.
- **Hapus Proyek** menghapus folder metadata dan media setelah konfirmasi. Tidak dapat dipulihkan tanpa backup ZIP.
- **Backup ZIP** memakai pemilih lokasi Android (DocumentsUI). ZIP berisi `project.json` dan `media/*`, tanpa API key/keystore. **Impor backup ZIP** menyediakan salinan proyek dengan ID baru sehingga tidak menimpa proyek lama.
- **Ekspor/Impor JSON lama** tetap tersedia sebagai format ringan teks saja.

## Cara pakai dari HP

1. Perbarui aplikasi **release v5.0.47** dengan signing key lama, atau gunakan debug baru terpisah untuk pengujian.
2. Buka editor → **Simpan Proyek** atau **Riwayat/Proyek**. Beri nama proyek, tekan **Simpan proyek lengkap**. Periksa notifikasi jika ada aset yang gagal tersimpan.
3. Tekan **Riwayat/Proyek** untuk melihat daftar proyek, membuka, menduplikasi, membuat backup, dan menghapus.
4. Tekan **Backup ZIP** → pilih lokasi di Files/Drive yang bisa diakses melalui pemilih berkas Android. Untuk memindahkan ke HP lain, instal KreasiFlow → **Impor backup ZIP** → pilih ZIP.
5. Setelah membuka proyek, periksa VO, gambar, MP4 setiap scene, timestamp subtitle, dan pengaturan render. Lakukan render ulang bila diperlukan.

## Batasan yang wajib diketahui

- Proyek harus **disimpan satu kali setelah update** agar media yang ada dalam sesi dapat dipindahkan dari cache ke folder permanen. Media yang sudah hilang sebelum v5.0.47 dipasang tidak bisa direkonstruksi otomatis.
- Android bisa menunda WebView saat layar mati sebelum autosave media selesai. Untuk proyek dengan MP4 besar, tekan **Simpan proyek lengkap** dan pastikan tidak ada pesan gagal sebelum meninggalkan aplikasi.
- **Aplikasi di-uninstall atau data aplikasi dihapus akan menghapus folder proyek privat**. Backup ZIP di lokasi eksternal adalah satu-satunya cara portabel yang dijamin dalam rancangan ini. Pembaruan release dengan packageId dan sertifikat sama tidak menghapus data.
- File media dibatasi 250 MB per klip, VO/audio hingga 150 MB pada transfer, dan total backup ZIP tidak lebih dari 2 GB isi. Pastikan ruang kosong cukup karena duplikasi dan impor membutuhkan salinan penuh.
- Backup ZIP tidak memuat API key, akun provider, keystore penandatanganan, atau hasil render MP4 final di folder Downloads (hanya media sumber dan konfigurasi proyek). File MP4 final tetap di Downloads/KreasiFlow.
- **Render yang sudah terhenti tidak akan dilanjutkan dari persen terakhir**. Proyek bisa dibuka dan render dimulai ulang.
- **Impor JSON** adalah mode lama, tidak membawa file media; gunakan ZIP bila memindahkan pekerjaan penuh.
- Klip dari provider yang tidak pernah terunduh ke Android mungkin tidak bisa dibackup; aplikasi menampilkan pesan media gagal dan tidak menyatakan backup lengkap.

## Pemeriksaan & pengujian

- Uji JavaScript syntax dan semua tes Node yang tersedia.
- Kompilasi sintaks Java kelas ProjectStore dengan stubs; **bukan pengganti kompilasi Android SDK**.
- **Build Gradle release dan uji real-device belum dilakukan di lingkungan ini**. Jalankan workflow `Test KreasiFlow APK Build from ZIP` di GitHub sebelum `Publish Signed KreasiFlow APK from ZIP` versi 5.0.47.
- Jangan unggah keystore, API key, atau backup pribadi ke repository publik.
