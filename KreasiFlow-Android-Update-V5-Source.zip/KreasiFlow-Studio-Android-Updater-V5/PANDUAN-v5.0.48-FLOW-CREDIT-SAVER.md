# KreasiFlow Studio v5.0.48 — Flow Credit Saver

## Fokus update

Mode *Image-to-Video* dijadikan default **untuk proyek baru**, dan prompt **Text-to-Image** (gambar/frame awal) ditampilkan kembali secara langsung pada setiap scene. Pilihan per scene:

1. **Image-to-Video** (default): AI storyboard menghasilkan prompt Text-to-Image; salin prompt lalu buat gambar AI melalui Gemini/Cloudflare yang sudah terhubung di APK (atau unggah hasil eksternal). Simpan frame, unggah frame yang sama secara manual di Google Flow pada mode Frames to Video, lalu salin prompt motion yang lebih singkat. Unduh MP4 dari Flow dan impor kembali ke scene KreasiFlow.
2. **Text-to-Video**: pilihan alternatif seperti v5.0.47, langsung salin prompt video ke Google Flow.
3. **Animasi gambar lokal**: gunakan gambar diam yang dianimasikan sederhana melalui pan/zoom/fade pada renderer slideshow Android. Bukan AI motion graphics kompleks, tidak membutuhkan video generatif Google Flow. Jika proyek berisi campuran MP4 dan gambar, renderer bergerak dapat menggabungkan keduanya; jika hanya gambar, render slideshow Android dipakai.

## Estimasi kredit Google Flow

Pilih angka kredit per video sesuai **mode/model/resolusi/durasi yang tampil di akun Google Flow** dan jumlah video output per scene. Rumus: scene yang memakai video Flow × kredit per output × jumlah output per scene. Bukan cek real-time tarif/kuota Google dan tidak memasukkan biaya API gambar atau percobaan ulang. Pemendekan prompt **tidak langsung menurunkan kredit per generasi**, tetapi dapat membuat instruksi lebih terarah dan berpotensi mengurangi retry.

## Konsistensi

Prompt Image-to-Video yang ringkas mempertahankan identitas visual, karakter, palet, dan properti **dari gambar awal yang benar-benar diunggah ke Google Flow**. KreasiFlow tidak mengklaim bisa mengunggah gambar atau menekan Generate di akun Google secara otomatis. Scene Uniqueness/Style Lock lama tetap aktif.

## Penyimpanan proyek

Default alur dan perkiraan kredit tersimpan dalam snapshot proyek; pilihan metode per scene ikut tersimpan pada objek scene. Metadata media (gambar/frame/MP4) tetap menggunakan Project Manager v5.0.47. Backup ZIP tidak memuat API key.

## Catatan teknis

Source memakai Android package ID dan signing konfigurasi yang sama. Verifikasi JavaScript dilakukan dengan `node --test tests/*.test.cjs` termasuk regression test untuk Project Manager, render 60 FPS, background AI dan kontrol biaya.

APK Android **belum dikompilasi/diuji di perangkat** dalam lingkungan pembuat paket. Lakukan GitHub Actions test build sebelum release.

Untuk workflow lama, gunakan file bernama persis `KreasiFlow-Android-Update-V5-Source.zip` di root repository. Jangan unggah ZIP luar. Release versi `5.0.48` harus memakai signing key lama.
