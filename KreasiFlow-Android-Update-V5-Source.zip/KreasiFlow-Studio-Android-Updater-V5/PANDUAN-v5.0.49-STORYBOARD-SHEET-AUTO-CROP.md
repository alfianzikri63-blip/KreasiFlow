# KreasiFlow Studio v5.0.49 — Storyboard Sheet Gemini + Auto Crop

## Kenapa perbaikannya begini?
Google Flow **tidak** otomatis membuat tujuh video terpisah dari satu gambar kolase. Pada mode Frames-to-Video, setiap klip memakai start frame yang sesuai dengan scene itu. Jangan unggah gambar sheet lengkap sebagai start frame Scene 01–07.

## Alur hemat pekerjaan
1. Buka **Scene & Video** dan buat storyboard AI (scene + prompt) terlebih dahulu.
2. Di bagian **7a · Satu Gambar Storyboard Gemini + Auto Crop**, pilih susunan grid. Untuk tujuh scene, default adalah **4 kolom × 2 baris** (slot terakhir kosong). Jika sumber eksternal memakai **2 kolom × 4 baris**, ubah pilihan kolom ke `2` sebelum upload.
3. Klik **Buat 1 sheet dengan Gemini AI**. Perhatikan konfirmasi: permintaan gambar AI dapat menggunakan kuota/kredit Gemini. Alternatif: tekan **Salin 1 prompt storyboard Gemini**, buat sendiri di Gemini, lalu **Upload 1 gambar storyboard (auto potong)**.
4. KreasiFlow memotong gambar sheet menjadi PNG untuk setiap scene (9:16 atau 16:9 sesuai pengaturan proyek), secara lokal di HP. Periksa urutan, fokus, gambar yang terpotong dan kemiripan. Anda boleh mengganti satu gambar scene tanpa membuat ulang keseluruhan sheet.
5. Klik **Simpan seluruh frame scene** untuk menyimpan PNG `KreasiFlow-Frame-01.png`, `KreasiFlow-Frame-02.png`, dan seterusnya di Downloads, dengan satu tombol.
6. Pada setiap scene, klik **Salin prompt & buka Google Flow**; di Flow pilih Video → Frames dan pilih **frame hasil potongan untuk scene tersebut**. Tempel prompt Image-to-Video singkat; lakukan Generate **per scene** sesuai pilihan model. Unduh dan impor MP4 tiap scene ke KreasiFlow.
7. Render gabungan bersama VO, subtitle, dan media lain seperti sebelumnya. Media sheet dan potongan ikut disimpan lewat Project Manager/Backup ZIP di APK, selama penyimpanan native tersedia.

## Kredit dan kualitas
- Menghasilkan satu gambar Gemini bisa menghemat jumlah permintaan **AI gambar**, bukan harga/kredit Flow per video. Google Flow tetap dapat mengenakan kredit untuk setiap klip, sesuai model, resolusi, durasi, dan jumlah output.
- Satu sheet berisi banyak panel membuat setiap panel mendapat resolusi lebih kecil. Untuk hasil terbaik, gunakan sheet resolusi tinggi dan koreksi panel yang salah secara individual.
- AI tidak selalu mengikuti layout grid dengan presisi. Auto-crop memakai grid geometris yang ditentukan user, bukan pembacaan otomatis isi panel. Bila grid tidak tepat, pilih jumlah kolom yang sesuai dan upload ulang.
- Aplikasi **tidak** mengendalikan Chrome, mengunggah gambar ke Google Flow, menekan Generate, atau mengakses akun Google otomatis.
- Tombol progress bar untuk Gemini menggambarkan tahap menunggu respons dan pemotongan lokal, bukan persentase render server AI secara real-time.

## Kompatibilitas
- Semua fitur v5.0.48 dipertahankan, termasuk ElevenLabs, storyboard AI, pemeriksa scene, progress bar, Project Manager, render background dan 24/30/60 FPS.
- ZIP source dipasang ke root repo GitHub dengan nama `KreasiFlow-Android-Update-V5-Source.zip`.
- Gunakan workflow **Test KreasiFlow APK Build from ZIP** terlebih dulu, kemudian buat release APK `5.0.49` dengan signing key lama. Build APK final dan pengujian Gemini/Flow langsung belum dilakukan di lingkungan pembuatan ini.
