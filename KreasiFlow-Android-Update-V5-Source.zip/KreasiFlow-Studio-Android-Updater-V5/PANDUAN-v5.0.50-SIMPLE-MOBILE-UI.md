# KreasiFlow v5.0.50 — Tampilan Ringkas Mobile

## Perubahan UI
- Menghapus toolbar Android kedua yang memuat Gemini, OpenRouter, Cloudflare dan AI Studio. Semua layanan tetap bisa diakses dari Pengaturan (⚙), menu lainnya (⋯) atau melalui alur editor.
- Header tunggal bertuliskan KREASIFLOW, dengan akses cepat Google Flow, riwayat proyek, dan pengaturan.
- Empat tab ringkas: **Mulai · Audio · Scene · Render**. Navigasi tetap kompatibel dengan state tab sebelumnya.
- Panel **Buat Otomatis**: satu tombol utama. Kontrol jumlah gambar, uji klip video, informasi biaya dan tautan AI Studio tetap tersedia di **Opsi produksi & biaya** (buka saat perlu).
- Progres tetap tampil, tetapi tugas selesai dipadatkan menjadi satu baris. Progres berjalan dan error tetap memperlihatkan persentase serta detail.
- Bagian bawah memiliki **⋯ Menu Lainnya**, Simpan, dan Baru. Menu Lainnya berisi Kelola Proyek, Backup Cloud, Ekspor JSON, Impor ZIP, Google Flow, AI Studio dan Pengaturan. Update APK release tersedia melalui menu/pengaturan.
- Seluruh fungsi backend, kunci AI terenkripsi, transkripsi, storyboard sheet + auto crop, prompt Google Flow, background service, 60 FPS, serta Project Manager tidak diubah.

## Uji di HP
1. Dari tab Mulai, tombol Buat Otomatis harus terlihat tanpa perlu scroll panjang.
2. Cek `⋯`: Kelola Proyek, Impor ZIP, dan ekspor JSON tetap bekerja.
3. Cek `⚙`: semua pengaturan provider masih dapat diakses dan tersimpan.
4. Cek tab Audio, Scene dan Render, termasuk job berjalan di background dan notifikasi.
5. Ketika update source di Github, test debug terlebih dulu; buat APK release dengan keystore yang sama.

Paket ini adalah source; belum menjadi APK teruji di perangkat.
