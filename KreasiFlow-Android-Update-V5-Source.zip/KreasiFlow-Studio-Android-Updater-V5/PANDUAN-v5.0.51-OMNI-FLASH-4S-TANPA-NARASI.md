# KreasiFlow v5.0.51 — Omni 1.1 Flash / 4 Detik / Tanpa Narasi

- Default **Image-to-Video**: Omni 1.1 Flash, 4 detik, 9:16 (atau rasio proyek), single continuous shot.
- Durasi Flow tidak mengubah pembagian scene atau panjang VO. Jika VO 10 detik namun Flow hanya menghasilkan 4 detik, lengkapi dengan footage lain/scene tambahan atau sesuaikan timeline.
- Mode audio default **Tanpa audio (paling aman)**. Alternatif **Hanya SFX lingkungan**; keduanya secara eksplisit melarang voice-over, dialog, suara manusia, lip-sync, nyanyian, suara TV/radio, musik.
- Prompt edited lama tetap dipertahankan tetapi ditambahkan audio-lock dan penegasan durasi.
- AI Flow mungkin masih mengeluarkan suara walau telah dilarang dalam prompt. Untuk video final, default renderer membisukan seluruh audio bawaan Flow: Settings Render → Audio Flow → Matikan seluruh audio Flow. VO terpisah (Google AI Studio) tetap dapat dipakai.
- Jika ingin SFX Flow, pilih kembali mode SFX di Render setelah mendengarkan klip (SFX mungkin mengandung suara manusia yang dihasilkan model; aplikasi tidak melakukan source separation).
- Buka Google Flow di Chrome dan atur model/durasi yang sama secara manual. KreasiFlow hanya menyalin prompt, tidak mengatur akun atau model Flow otomatis.
- Pengaturan: tab Scene & Video → Opsi produksi & biaya → Durasi Image-to-Video, Audio saat generate Flow.
- Catatan: pengaturan default 4 detik tidak mengurangi biaya jika harga Google Flow tidak berubah pada akun/model terkait; periksa kredit sebelum generate.
