# KreasiFlow Studio v5.0.51 — Hide / Unhide Scene

Perubahan dari source v5.0.50:

- Di tab **Scene**, daftar **Prompt Google Flow & Impor MP4** sekarang ringkas: hanya nomor scene, judul dan durasi.
- Ketuk header scene untuk membuka/menutup editor prompt, gambar, pengaturan metode, dan impor MP4.
- Secara default scene tertutup pada saat proyek pertama dibuka. Hanya satu scene terbuka jika memilih scene satu per satu.
- Tombol **Buka semua** dan **Tutup semua** terletak di atas daftar scene.
- Mode editor text-to-video dan kartun yang memakai komponen scene yang sama juga memakai header lipat.
- Buka/tutup scene **hanya mengubah tampilan**; data proyek, prompt, gambar, klip, dan setelan scene tetap dipertahankan.
- Status panel lipat dipertahankan selama berpindah tab/rerender dalam proyek yang sama. Pada proyek berbeda status dimulai dari tertutup.

## Build APK lewat GitHub Actions

1. Buka ZIP bagian dalam **KreasiFlow-Android-Update-V5-Source.zip** lalu ekstrak isinya.
2. Upload **seluruh isi folder `KreasiFlow-Studio-Android-Updater-V5`** ke root repository GitHub KreasiFlow. Jangan mengunggah ZIP mentah sebagai satu file jika ingin GitHub Actions membaca source.
3. Workflow **Test Build Debug APK** berjalan setelah push ke `main`. File APK debug berada di Artifacts workflow.
4. Untuk APK release yang bisa memperbarui pemasangan release sebelumnya (signature sama), jalankan workflow **Publish Signed KreasiFlow APK** dengan versi **5.0.51**. Keempat GitHub Actions secrets signing harus tetap tersedia.

Catatan: source ini **belum** menjadi APK siap instal. Build release akan menggunakan signing yang tersimpan pada GitHub; jangan mengganti key jika ingin update instalasi release yang sudah ada.
