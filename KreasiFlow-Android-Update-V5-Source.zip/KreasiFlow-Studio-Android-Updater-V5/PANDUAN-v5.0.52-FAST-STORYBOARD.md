# KreasiFlow v5.0.52 — Fast Storyboard AI

## Masalah diperbaiki
Pada versi 5.0.51, panggilan Gemini untuk storyboard mewarisi timeout 180 detik dan retry berlapis dari pembuat naskah. Pada VO 52 detik dengan durasi klip 4 detik, sebanyak 14 scene dipecah menjadi tujuh batch; batch pertama bisa terlihat macet di 7%.

## Perubahan
- Jalur storyboard Gemini khusus memakai Gemini 3.5 Flash-Lite (sekali panggil, batas baca respons 45 detik). Jika model tidak tersedia (404), coba Gemini 3.8 Flash satu kali. Jika layanan gagal/timeout, gunakan OpenRouter jika key-nya tersedia.
- Pengulangan model/provider tidak lagi bersarang pada storyboard. Proses judul, naskah, transkripsi, dan render tidak diubah.
- 3 scene per batch (14 scene menjadi 5 batch). Prompt AI lebih padat, tetap scene unik dan style konsisten.
- Respons JSON dicek segera sebelum dicatat sebagai batch selesai. Progres menampilkan jumlah scene selesai sebenarnya; batch yang berhasil disimpan permanen untuk percobaan berikutnya.
- Perlu dicatat bahwa batas baca HTTP adalah timeout operasi baca, bukan jaminan batas wall-clock total pada semua kondisi jaringan. Model/server tetap dapat lambat.

## Cara uji
1. Upload source ZIP bernama `KreasiFlow-Android-Update-V5-Source.zip` ke root repository GitHub dan jalankan test build.
2. Build release APK versi 5.0.52 dengan kunci signing lama.
3. Buka proyek yang sudah ada, lihat notifikasi AI lama dan batalkan jika masih berjalan; tekan Buat Storyboard dari naskah lagi.
4. Pantau `Scene 1–3 dari N` dan setelah berhasil `Storyboard 3/N scene tersimpan`.
5. Kunci layar dan buka lagi; hasil batch sebelumnya harus tetap ada.

## Batasan
Belum ada pengujian live terhadap akun Gemini/OpenRouter pengguna atau build APK Android lengkap dalam lingkungan ini. Free-tier dapat mengalami antrean/429. Ketika keduanya gagal, proses menampilkan alasannya dan hasil batch yang sudah berhasil tetap tersimpan.
