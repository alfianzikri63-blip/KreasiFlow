# KreasiFlow Studio v5.0.52 — Perbaikan Text-to-Image Gemini

## Perbaikan inti

1. Prompt gambar dari scene/storyboard sheet yang melebihi 3.000 karakter tidak lagi ditolak lokal. Batas aman aplikasi menjadi maksimal 60.000 karakter. Prompt tidak dipotong diam-diam.
2. Panggilan native Gemini ke endpoint Interactions sekarang secara eksplisit meminta `response_format` berupa `image`, `mime_type=image/jpeg`, `image_size=1K` (dukungan resmi Gemini 3.1 Flash Lite Image), dan `aspect_ratio`.
3. Rasio 9:16 dan 16:9 dipilih dari rasio proyek untuk tiap scene. Untuk satu storyboard sheet, rasio gambar disesuaikan dengan jumlah kolom dan baris agar auto-crop tidak terlalu banyak membuang area.
4. Parser native membaca output gambar yang tersedia sebagai `steps[].content[]` atau `output_image`, jika ada.
5. Pesan error gambar membedakan prompt/API (400), akses model (403/404), dan kuota (429). Panel progres untuk scene gagal memperlihatkan error sebenarnya, bukan sekadar “dibatalkan”.
6. Menambah tombol **Tes 1 gambar Gemini** di Pengaturan AI. Tes ini berbiaya/kuota dan meminta konfirmasi. Tes tidak mengganti gambar scene atau file proyek.
7. Menjaga fitur accordion Hide/Unhide Scene pada v5.0.51.

## Penting tentang biaya dan batas API

- Gemini 3.1 Flash Lite Image (`gemini-3.1-flash-lite-image`) tidak tersedia di API free tier. Anda memerlukan akses tier API berbayar pada proyek Gemini API key yang dipakai. Langganan Google AI Pro/Google Flow tidak otomatis mengaktifkan billing Gemini Developer API.
- Tombol **Uji koneksi Gemini** memeriksa API key saja. Tombol **Tes 1 gambar Gemini** benar-benar membuat satu gambar dan dapat dikenakan biaya.
- Tidak ada percobaan berulang otomatis untuk gambar AI (mencegah biaya ganda). Bila mendapat HTTP 429/limit 0, cek billing/kuota di Google AI Studio. Jika memilih Cloudflare sebagai provider gambar, siapkan token dan Account ID Cloudflare di Pengaturan.
- Hasil 1 storyboard sheet dibatasi output 1K oleh model Lite, sehingga frame hasil auto-crop untuk banyak scene bisa kecil; fitur ini tidak mengurangi kredit Google Flow untuk generasi video.

Dokumentasi acuan: https://aistudio.google.com/docs/image-generation dan https://aistudio.google.com/docs/models/gemini-3.1-flash-lite-image

## Cara pasang

1. Buka ZIP luar, ekstrak file `KreasiFlow-Android-Update-V5-Source.zip`.
2. Ekstrak ZIP source itu. Unggah **isi folder** `KreasiFlow-Studio-Android-Updater-V5` (bukan file ZIP mentah) ke root repository GitHub aplikasi.
3. Push ke branch main agar workflow debug melakukan build otomatis.
4. Untuk pembaruan aplikasi release terpasang, jalankan `Publish Signed KreasiFlow APK`, versi **5.0.52**, dengan empat GitHub Secrets signing yang sama seperti sebelumnya.
5. Di APK hasil build, buka Pengaturan > Gemini API Key > Uji koneksi; lalu pilih Tes 1 gambar Gemini. Jika berhasil, buka tab Scene > scene yang dipilih > Buat gambar AI.

## Validasi

- Pengujian test suite Node: 133 tes sukses.
- Sintaks inline JavaScript diperiksa dengan `node --check`.
- Tidak ada pengujian API langsung karena key privat tidak disertakan, dan source belum dikompilasi/diuji di perangkat Android dari lingkungan ini.
