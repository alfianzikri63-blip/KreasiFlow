# KreasiFlow v5.0.53 — Pemulihan Storyboard AI (OpenRouter Kosong + Gemini 503)

## Kenapa gagal?
Jika status menunjukkan **OpenRouter merespons tanpa teks terlihat**, model dapat menghasilkan respons tanpa konten final yang dapat dipakai. Penggunaan `openrouter/free` secara acak bisa memilih model dengan perilaku berbeda. **Gemini HTTP 503** berarti layanan sementara sedang padat; tidak selalu menandakan API key salah atau kuota habis.

## Yang diubah
- Jalur storyboard Android menggunakan **Google Gemma 4 26B A4B IT Free** (`google/gemma-4-26b-a4b-it:free`) saat pengaturan OpenRouter masih `openrouter/free`, lalu **Ling 3.2 Flash Free** (`inclusionai/ling-3.2-flash:free`) bila respons kosong, invalid, atau terjadi gangguan. Saat pengguna memilih model spesifik, pilihan tersebut tetap dipakai; tidak otomatis dialihkan ke model berbayar.
- Untuk kedua model gratis tersebut, permintaan meminta **JSON**, mengatur penalaran menjadi `none` bila didukung, dan menambah ruang jawaban final menjadi **6.000 token**.
- Batas tunggu pembacaan respons OpenRouter khusus storyboard adalah **60 detik**, sedangkan jalur Gemini storyboard tetap 45 detik per respons. Ini timeout baca koneksi, bukan jaminan durasi absolut proses jaringan.
- Pesan kegagalan sekarang menjelaskan provider dan model yang gagal; penerimaan JSON tetap divalidasi sebelum batch dianggap berhasil.
- Tombol **Buat Draft Scene Tanpa AI (cadangan)** tersedia di tab Scene. Ini membagi narasi menjadi scene dan menyiapkan prompt dasar *lokal*, **bukan hasil AI**. Pengguna harus meninjau gambar, peristiwa, dan urutan scene sebelum dipakai di Google Flow. Tombol ini tidak pernah bekerja otomatis atau mengaku mengakses provider AI.
- Proyek, cache batch AI yang sudah jadi, flow prompt, transkrip, dan render tetap dipertahankan.

## Cara pakai
1. Upload source ZIP ke root repository GitHub dengan nama `KreasiFlow-Android-Update-V5-Source.zip`.
2. Jalankan workflow test/debug terlebih dahulu dan pastikan build sukses.
3. Build signed release `5.0.53` dengan keystore dan package ID lama.
4. Buka proyek. Setelah memastikan tidak ada pekerjaan background yang masih berjalan, tekan **Buat storyboard dengan AI**.
5. Jika layanan API masih gagal, tekan **Buat Draft Scene Tanpa AI (cadangan)** untuk melanjutkan penyusunan scene. Draft masih perlu disunting untuk kualitas visual.

## Batasan
- API key pengguna tidak disertakan dalam ZIP. Tidak ada panggilan API langsung saat pengujian source, karena lingkungan build ini tidak memakai key pengguna.
- Gratis tidak berarti tanpa pembatasan kuota/rate limit; ketersediaan model bisa berubah.
- Build APK Android dan uji di perangkat belum dilakukan di lingkungan ini. Pengujian JavaScript dan pemeriksaan struktur source bukan pengganti kompilasi Gradle maupun uji nyata Google Flow.
