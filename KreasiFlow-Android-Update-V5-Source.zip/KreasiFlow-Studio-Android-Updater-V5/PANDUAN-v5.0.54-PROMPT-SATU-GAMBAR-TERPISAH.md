# KreasiFlow v5.0.54 — 1 Prompt, Gambar Terpisah Tiap Scene

## Yang berubah
- **Bukan storyboard sheet / kolase lagi.** Di tab **Scene** terdapat bagian **Gambar Terpisah per Scene**. Jika ada tujuh scene, hasil yang ditargetkan adalah tujuh gambar 9:16 terpisah.
- **Salin 1 Prompt Semua Gambar**: membuat satu teks instruksi lengkap berurutan untuk digunakan di Gemini Chat. Tekan **Salin Prompt & Buka Gemini** dan tempel ke Gemini. Gemini tidak selalu memproduksi semua gambar sekaligus; mungkin perlu melanjutkan percakapan untuk output berikutnya. Jangan menggunakan gambar kolase sebagai pengganti.
- **Buat Semua Gambar AI (1 Klik)**: APK menggunakan key Gemini yang sudah tersimpan dan meminta gambar **satu per scene secara berurutan**. Ini satu tombol, bukan satu panggilan API. Setiap gambar dapat menghabiskan kuota/biaya API masing-masing; batch mematuhi hasil yang sudah ada dan tidak mengulangi gambar yang berhasil.
- **Ulang Hanya Gambar Gagal**: setelah kegagalan API, hanya scene berstatus gagal yang dikerjakan lagi.
- **Impor Banyak Gambar Sekaligus**: dari Gemini Chat atau file lokal, pilih beberapa PNG/JPG/WebP sekaligus. Jika nama file `Scene-01.png`, `Scene-02.png`, dst, pemetaan mengikuti nomornya; jika tanpa nomor, urut berdasarkan nama file. Penamaan yang bercampur atau duplikat ditolak untuk mencegah salah urutan.
- **Simpan Frame yang Ada**: menyimpan frame yang tersedia dalam file terpisah untuk digunakan sebagai start frame di Google Flow.
- Semua **fitur storyboard sheet lama tetap dapat membuka cadangan proyek lama**, tetapi sheet tidak lagi ditampilkan sebagai alur utama.

## Alur
1. Buat storyboard dari naskah seperti biasa.
2. Buka **Scene → Gambar Terpisah per Scene**.
3. Pilih **Buat Semua Gambar AI (1 Klik)** atau salin satu master prompt ke Gemini.
4. Periksa gambar Scene 01, 02, dst. Gambar tiap scene dapat diganti secara manual.
5. Buat video di Google Flow **per scene**, gunakan Image-to-Video Omni 1.1 Flash 4 detik dan prompt gerakan singkat.
6. Impor MP4 per scene lalu render video final di KreasiFlow.

## Batasan dan biaya
- Prompt satu kali di Gemini Chat tidak menjamin keluaran beberapa file image terpisah. Gemini dapat hanya menghasilkan satu gambar. Batch native APK melakukan permintaan API independen per gambar.
- Batch gambar APK saat ini berjalan di antarmuka WebView. Jangan mengunci layar saat batch gambar masih berjalan; background native AI telah tersedia untuk judul, naskah, storyboard, dan transkripsi, namun belum untuk batch gambar baru ini.
- Satu permintaan gambar per scene dapat menggunakan API quota/kredit. Ini **tidak** menghilangkan kredit pembuatan setiap klip di Google Flow.
- Konsistensi visual ditingkatkan melalui master style, deskripsi karakter, dan prompt scene, tetapi gambar 100% identik belum dijamin tanpa referensi gambar yang benar-benar disertakan ke model yang mendukung.
- Jumlah scene dan VO tidak diubah, prompt Image-to-Video tetap terpisah dan tidak mengandung narasi Flow.

## Update APK melalui GitHub
Upload **KreasiFlow-Android-Update-V5-Source.zip** ke root repository menggantikan versi lama. Jalankan workflow **Test KreasiFlow APK Build from ZIP**. Setelah sukses, jalankan workflow release versi **5.0.54** dengan signing key lama. APK debug bukan update langsung APK release.

## Pemeriksaan
147 unit test JavaScript lulus dan sintaks halaman utama diperiksa. Belum ada full Gradle APK build atau uji API Gemini/Google Flow dari perangkat.
