# KreasiFlow Studio v5.0.55 — Prompt langsung ke Google Flow

## Perubahan

- **Gambar awal tidak perlu diimpor ke KreasiFlow.** Buat gambar dan simpan di proyek Google Flow, kemudian gunakan gambar tersebut langsung di **Frames to Video**.
- Tab Scene menyediakan **Salin 1 Prompt Semua Scene** dan **Salin & Buka Google Flow**.
- Setiap scene punya **Prompt Text-to-Image** (satu gambar mandiri) dan **Prompt Image-to-Video** yang terpisah.
- Tombol **Buat Gambar AI**, **Unggah Gambar**, **Impor Banyak Gambar**, dan **Simpan Frame** disembunyikan dari alur normal. Pembuatan judul/naskah otomatis tidak meminta API gambar.
- **Hanya MP4 Google Flow** yang diimpor ke KreasiFlow untuk sinkronisasi VO/subtitle dan render.
- Klip Flow harus dihasilkan satu per satu jika Google Flow tidak mendukung generasi banyak gambar/video sekaligus. Satu master prompt bukan jaminan satu submit akan menghasilkan semua gambar.
- Mode animasi lokal dari proyek lama tetap dikenali untuk kompatibilitas proyek lama. Mode tersebut memerlukan media gambar lama; mode baru fokus Google Flow.

## Langkah di Android

1. Mulai → siapkan judul/naskah/VO.
2. Scene → buat storyboard AI.
3. Pilih **Salin 1 Prompt Semua Scene** → buka Google Flow; jika tidak dapat menghasilkan seluruh gambar terpisah, gunakan tombol **Salin prompt gambar** per scene.
4. Di Google Flow buat gambar **Scene 01**, **Scene 02**, dst, masing-masing sebagai gambar utuh, bukan kolase.
5. Di Google Flow gunakan tiap gambar di **Frames to Video**. Dari KreasiFlow salin prompt video Scene yang sama. Default Omni 1.1 Flash / 4 detik / tanpa narasi.
6. Setelah video didownload dari Google Flow, kembali ke Scene KreasiFlow → **Impor MP4 hasil Flow** per scene → tab Render.

## Batasan penting

- KreasiFlow tidak mengklik Generate di situs Flow, tidak mengupload gambar ke akun Flow, dan tidak memantau saldo/kredit akun. Semua interaksi Flow lewat browser tetap dilakukan pengguna.
- Prompt gambar seluruh scene tidak menjamin Google Flow mendukung batch generate dari satu prompt.
- SFX/narasi bisa tetap dihasilkan model video walau prompt melarangnya. Default render membisukan audio Flow agar VO utama tetap bersih.
- Media gambar dari proyek lama tetap dapat dipulihkan. Jangan hapus data APK sebelum membuat backup proyek.

## GitHub dan pengujian

Upload file **KreasiFlow-Android-Update-V5-Source.zip** ke root repository lama. Jalankan workflow **Test KreasiFlow APK Build from ZIP**. Sesudah test build berhasil, buat release **5.0.55** memakai keystore yang sama. APK debug tidak dapat memperbarui APK release dengan kunci berbeda.

Validasi lokal: 154/154 tes JavaScript lulus, HTML script lolos pemeriksaan sintaks, arsip ZIP tervalidasi. Build APK penuh / pengujian langsung Google Flow **belum** dilakukan pada lingkungan pengembangan ini.
