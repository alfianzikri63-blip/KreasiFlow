# KreasiFlow Studio v5.0.56 — Impor Semua MP4 Flow Sekaligus

## Cara menggunakan
1. Buat storyboard, gambar dan video langsung di Google Flow. Unduh semua file MP4.
2. Disarankan beri nama **Scene-01.mp4**, **Scene-02.mp4** dst sesuai nomor storyboard sebelum memilih file.
3. Di KreasiFlow, tab **Scene**, tekan **⬆ Pilih semua MP4 Flow** dan tandai semua MP4 (multi-select).
4. Aplikasi membaca nomor scene dari nama file, lalu menampilkan daftar pemasangan video sebelum melanjutkan.
5. Bila tidak ada nomor scene pada semua nama file, aplikasi mengurutkannya *natural* (video2 sebelum video10), lalu memasang mulai Scene 01. Periksa pratinjau! Nama unduhan acak dapat menyebabkan urutan tidak cocok.
6. File bernomor sama, campuran bernomor/tanpa nomor, file bukan MP4, atau nomor di luar jumlah scene akan ditolak sebelum transfer.
7. Jika sebagian scene sudah punya klip, penggantian akan dikonfirmasi. File lain tidak berubah.
8. Pengiriman ke renderer Android berjalan satu per satu secara otomatis dengan progres keseluruhan dan penyimpanan ke Project Manager.
9. Setelah impor, buka **Render** untuk menggabungkan klip dengan VO + subtitle.

**Catatan:** Pemilih file Android harus mendukung memilih banyak file; di beberapa galeri/file manager perlu tekan-lama file terlebih dahulu. Pengurutan sepenuhnya berdasarkan nama file, bukan konten video. KreasiFlow tidak mengambil MP4 langsung dari akun Google Flow; video harus diunduh dahulu. Fitur ganti satu MP4 tetap ada dalam menu detail scene sebagai opsi pemulihan.

**Uji:** JavaScript dan ZIP lokal diperiksa. Build APK Gradle dan interaksi pemilih file Android asli tetap perlu dites lewat workflow/perangkat.
