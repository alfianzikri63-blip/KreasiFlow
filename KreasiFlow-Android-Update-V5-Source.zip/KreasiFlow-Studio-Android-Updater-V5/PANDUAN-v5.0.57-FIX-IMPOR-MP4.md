# KreasiFlow v5.0.57 — Perbaikan Impor Semua MP4 Google Flow

## Masalah yang diperbaiki
Di v5.0.56, ketika pengguna memilih banyak video (contoh: 14 video) dari Galeri Android, video tidak selalu sampai ke halaman KreasiFlow. Jalur sebelumnya menggunakan `<input type="file" multiple>` di WebView lalu memindahkan MP4 ke Android melalui potongan Base64. Pada sebagian galeri/pemilih Android, proses ini bermasalah.

## Perbaikan
- Tombol utama **Impor Semua MP4 dari Galeri** sekarang memanggil pemilih native Android.
- Pilihan cadangan **Pilih dari File Manager** memakai Android DocumentsUI bila Galeri tidak mengembalikan semua video.
- Android memproses seluruh `ClipData` yang dipilih, bukan hanya URI pertama.
- Nama file dan nomor scene tetap dipetakan secara otomatis. Jika tidak ada nomor scene, tampilkan urutan alami berdasarkan nama file untuk dikonfirmasi.
- Android menyalin MP4 langsung dari `ContentResolver` ke media native melalui streaming 128 KB; tidak memakai Base64 lewat WebView untuk impor massal.
- Progress bar tampil untuk seluruh proses dan per file. Satu kegagalan tidak menghapus impor yang sudah berhasil.
- Setelah diterima, semua klip disimpan bersama proyek. Ketika proyek dibuka ulang, ID media native dipulihkan untuk render.
- Impor MP4 satu-satu tetap tersedia di opsi detail scene.

## Cara menguji pada HP
1. Perbarui APK dari source v5.0.57. Untuk APK debug, jalankan **Test KreasiFlow APK Build from ZIP**; untuk release gunakan signing key lama.
2. Buka proyek dengan 14 scene, kemudian pada tab **Scene** tekan **Impor Semua MP4 dari Galeri**.
3. Pilih 14 video, tekan **Selesai**. Jika pemilih Galeri bermasalah, gunakan **Pilih dari File Manager** dan pilih banyak video sekaligus.
4. Periksa konfirmasi pasangan nama video → Scene 01–14 sebelum melanjutkan. Jika nama file tidak mencerminkan urutan sebenarnya, ubah nama file lebih dahulu, misalnya `Scene-01.mp4` hingga `Scene-14.mp4`.
5. Tunggu sampai indikator impor selesai. Buka kembali proyek untuk memastikan klip tersimpan, kemudian coba render pendek.

## Batasan dan kehati-hatian
- Maksimal 36 MP4 per batch, 250 MB per MP4, sesuai jumlah scene yang tersedia. Untuk file yang jauh lebih besar, impor per batch.
- Pastikan penyimpanan HP cukup: selama impor, Android memerlukan ruang untuk file sementara dan salinan proyek.
- Jangan menutup paksa aplikasi saat proses **impor** masih berjalan. Render MP4 memiliki layanan background sendiri; impor massal belum dipindahkan ke foreground service.
- Jika nama file otomatis dari Google Flow tidak menyertakan nomor scene, urutan berdasarkan nama file tidak selalu sama dengan urutan cerita. Periksa pratinjau pemetaan.
- Test source (170 tes JavaScript) dan parse 18 file Java berhasil. Build Android lengkap serta uji langsung pada perangkat belum dilakukan.

## Source ZIP untuk GitHub
Unggah `KreasiFlow-Android-Update-V5-Source.zip` di root repository untuk mengganti file bernama sama. Jalankan workflow pengujian APK sebelum rilis `5.0.57`.
