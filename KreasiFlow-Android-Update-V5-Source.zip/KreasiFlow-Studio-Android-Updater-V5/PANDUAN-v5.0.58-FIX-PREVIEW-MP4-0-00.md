# KreasiFlow v5.0.58 — Fix MP4 0:00 / video tidak terbaca

Perbaikan dari v5.0.57.

- Setelah file dipilih, native Android memeriksa jalur video dan durasi >0 sebelum menyatakan impor berhasil. File rusak/format gagal dikenali dilaporkan per scene; klip lain tidak hilang.
- Tombol **Putar MP4 Scene** membuka VideoView native Android, bukan preview WebView yang pada beberapa HP tampak 0:00 walaupun salinan tersimpan.
- File dari Project Manager tetap bisa diputar setelah proyek dibuka ulang melalui FileProvider path privat.
- Impor banyak MP4, urut nama, VO, subtitle, progress, background render, dan fitur lain dipertahankan.

## Tes di HP
1. Upload source ZIP ke GitHub, jalankan workflow test build, buat APK versi 5.0.58.
2. **Jangan hapus data/uninstall APK lama**; buka proyek tersimpan.
3. Di tab Scene ketuk **Putar MP4 Scene** pada scene terpasang.
4. Kalau proyek lama tidak menampilkan klip, buka melalui menu Proyek/Riwayat (pemulihan native ID), lalu coba lagi.
5. Jika video gagal di decoder, pilih File Manager dan impor ulang MP4 asli yang sudah diunduh dari Google Flow. Lihat pesan kesalahan untuk scene yang bermasalah.
6. Setelah video bisa diputar, uji render beberapa scene terlebih dahulu.

Validasi metadata tidak menjamin semua codec dapat di-render; video harus lolos uji pemutaran/render di perangkat. Build Android lengkap belum diverifikasi di lingkungan lokal.
