# KreasiFlow v5.0.59 — Perbaikan preview MP4 hitam

## Masalah
Pada v5.0.58, pemutar Android dapat menampilkan layar hitam pada frame akhir. Screenshot menunjukkan klip 4 detik pada posisi 00:03/00:03, sehingga layar hitam belum membuktikan file MP4 rusak.

## Perubahan
- Preview MP4 menggunakan `TextureView` dan `MediaPlayer` native (bukan `VideoView`).
- Thumbnail diekstrak dari data MP4 pada awal klip sebelum playback agar tidak langsung hitam.
- Klip 4 detik berulang otomatis; tersedia tombol Putar/Jeda, Ulang, dan scrubber.
- Tombol `Player HP` membuka file memakai aplikasi video eksternal melalui `FileProvider`.
- Pesan status membedakan gagal ekstrak frame, decoder gagal, dan pemutaran yang berhasil.
- Seluruh fitur impor massal, Project Manager, storyboard AI, VO, subtitle, dan render dipertahankan.

## Cara uji setelah APK terpasang
1. Buka proyek lama (jangan hapus data aplikasi), pilih Scene 1 → Putar MP4 Scene.
2. Periksa apakah thumbnail terlihat dan video bergerak berulang (bukan berhenti di akhir).
3. Jika tetap hitam, tekan `Player HP` untuk membandingkan dengan pemutar bawaan.
4. Jika Player HP juga hitam, uji file original Google Flow dari File Manager; kemungkinan file atau codec yang perlu diperiksa.
5. Uji scene berbeda lalu lakukan render singkat untuk memastikan seluruh jalur video aktif.

## Batasan validasi
Pengujian JavaScript otomatis tidak menggantikan kompilasi penuh di Android SDK dan uji video/codec nyata pada HP. Jalankan workflow GitHub test APK sebelum release. Gambar preview tidak menjamin semua format video kompatibel dengan decoder perangkat.
