# KreasiFlow v5.0.60 — Pemeriksa footage MP4 native Android

- Perbaikan utama: MP4 hasil impor massal disimpan sebagai ID file native tanpa URL WebView. Pemeriksa lama hanya memeriksa URL, sehingga frame selalu gagal terbaca.
- Pemeriksa kini meminta dua sampel frame (28% dan 72% durasi) kepada MediaMetadataRetriever Android untuk tiap ID MP4. Tidak membuat ulang atau mengubah video asli.
- Progress menampilkan jumlah frame terbaca dan gagal. Detail error tiap scene bisa dibuka di hasil pemeriksaan.
- Frame kurang detail/polos tidak dipakai untuk menyimpulkan dua scene duplikat.
- Deteksi kemiripan bersifat heuristik, bukan jaminan identitas atau variasi semua frame. Periksa manual bila dicurigai mirip.
- Fitur lain dan data media proyek dipertahankan; tidak perlu uninstall APK lama. Gunakan workflow test terlebih dahulu sebelum release.
- Pekerjaan ini belum diuji langsung pada GPU/decoder HP, dan pemutar/encoder sesungguhnya bisa memiliki keterbatasan codec.
