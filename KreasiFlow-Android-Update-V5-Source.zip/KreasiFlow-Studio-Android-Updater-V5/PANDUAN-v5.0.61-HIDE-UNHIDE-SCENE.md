# KreasiFlow v5.0.61 — Hide/Unhide detail per scene

Di **Scene & Video**, setiap scene memiliki tombol **▾ Buka / ▴ Tutup** pada judul. Scene pertama terbuka secara default agar pengguna langsung menemukan prompt; scene lain tertutup untuk menghemat layar.

- **Tutup Semua** merangkum setiap scene.
- **Buka Semua** menampilkan detail seluruh scene.
- Kondisi tampil/sembunyi disimpan dengan proyek dan dipertahankan ketika tampilan dirender ulang.
- Ini hanya meringkas UI; **narasi, gambar, prompt, MP4 impor, urutan, dan render tidak dihapus atau dinonaktifkan**.

Perubahan ditambahkan di atas source v5.0.60 agar perbaikan inspeksi footage MP4 tetap ada.

Untuk GitHub, unggah `KreasiFlow-Android-Update-V5-Source.zip` yang ada dalam paket dan gunakan workflow test build sebelum merilis v5.0.61.
