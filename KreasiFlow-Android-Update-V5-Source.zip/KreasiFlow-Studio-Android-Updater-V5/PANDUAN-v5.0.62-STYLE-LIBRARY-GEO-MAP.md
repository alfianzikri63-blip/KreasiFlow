# KreasiFlow Studio v5.0.62 — Ultimate Style Library & Geo Map

Berbasis source asli v5.0.61. 52 style lama + 22 style baru (74 total), tanpa perubahan package ID, signing, renderer, impor MP4 atau Hide/Unhide. Default tetap 2D Flat Vector Motion Graphic.

## Cara pakai
1. Di Upload, pilih tema Geo Map sesuai topik; gunakan Cari ide judul (lokal) atau Kembangkan judul AI. Klik Pakai style rekomendasi jika diinginkan.
2. Di Audio & Subtitle atau Scene & Video, pilih style dari grup Animasi 3D / Artistik & Storytelling / Geo Map. Pilih sebelum membuat storyboard. Jika mengganti style setelah storyboard, tinjau/regenerasi prompt scene; media lama tidak otomatis dibuat ulang.
3. Buat naskah dan storyboard. Salin Master T2I ke Google Flow. Buat gambar per scene.
4. Salin Master I2V atau prompt Flow per scene, gunakan gambar yang benar sebagai first frame. Flow mungkin membutuhkan permintaan terpisah; tidak ada otomatisasi batch atau jaminan render. Audio mengikuti pengaturan Omni yang sudah ada.
5. Impor MP4 dan render seperti sebelumnya.

Geo Map bukan mesin GIS: sumber peta, rute, batas, label, data, dan tanggal harus diverifikasi pengguna. Tanpa referensi akurat, hasil bersifat ilustratif. Tambahkan label/data asli saat editing. Tidak ada API berbayar baru.

## Upload
Ekstrak ZIP luar. Unggah hanya `KreasiFlow-Android-Update-V5-Source.zip` ke root repo yang sama, replace file lama, lalu test build dan release v5.0.62. Pertahankan signing secret lama.

## Pengujian
- Node.js: 189/189 lulus (183 regresi sebelumnya + 6 tes baru), dan seluruh file JavaScript lolos syntax check.
- Semua file source lama dipertahankan; Java/manifest/workflow/signing tidak diubah.
- Pengujian UI browser penuh terhalang kebijakan akses browser di lingkungan kerja. Build APK Android, uji di HP, dan hasil generasi Google Flow belum diuji. Jalankan workflow test sebelum release.
