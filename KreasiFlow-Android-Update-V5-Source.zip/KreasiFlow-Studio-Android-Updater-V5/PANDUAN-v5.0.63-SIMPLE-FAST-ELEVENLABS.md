# KreasiFlow V5.0.63 — Simple, Fast & ElevenLabs

- Mulai: topik, tema, judul AI/lokal, style, durasi, bahasa, naskah. Opsi lama dilipat.
- Audio: tempel Voice ID yang tersedia pada akun ElevenLabs. Simpan API key di Pengaturan AI, dengan izin Text to Speech dan Speech to Text jika ingin transkripsi. Flash v2.5 (default) atau Multilingual v2. Generate VO membutuhkan kuota; tidak ada retry otomatis TTS. Audio MP3 diterapkan setelah metadata valid, dapat diputar dan disimpan ke proyek. Impor audio dan Google AI Studio tersedia sebagai cadangan.
- Transkrip AI tetap memakai provider yang dipilih (default ElevenLabs Scribe v3); estimasi teks dan SRT masih tersedia. Transkripsi tetap terpisah dari TTS.
- Scene: storyboard, master prompt, impor MP4 tetap tersedia. Kredit, pemeriksa, pengaturan karakter dan master gabungan dilipat. Semua preset V5.0.62 (74 style, Geo Map) dipertahankan.
- Judul/naskah: native background memakai Gemini Flash-Lite terlebih dahulu, atau model OpenRouter terpilih, dengan batas token menyesuaikan durasi dan satu percobaan per rute. Provider cadangan tersimpan tetap tersedia. Kecepatan riil tergantung API, jaringan, panjang naskah. Narasi panjang dapat perlu revisi jika terpotong.
- Flash v2.5 menerima hingga 40.000 karakter per permintaan API, Multilingual v2 10.000; kuota, akses voice, timeout dan ukuran audio tetap membatasi hasil. Jangan mengirim ulang sebelum status jelas. Jika voice tidak diizinkan, gunakan Voice ID lain yang tersedia di akun.
- Paket aplikasi dan konfigurasi signing tetap sama. Ekstrak ZIP luar, upload KreasiFlow-Android-Update-V5-Source.zip menggantikan source lama, lalu test build/release dengan versi 5.0.63.
- Pengujian lokal: 193 tes Node dan pemeriksaan sintaks JavaScript. Build Android, API berbayar nyata dan kecepatan di perangkat belum diuji.
