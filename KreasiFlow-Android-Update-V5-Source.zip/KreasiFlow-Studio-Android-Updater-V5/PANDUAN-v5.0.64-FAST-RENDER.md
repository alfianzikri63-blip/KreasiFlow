# KreasiFlow Studio V5.0.64 — Fast Render

Berbasis source V5.0.63; style library, Geo Map, ElevenLabs, scene, login, package ID, dan konfigurasi signing tetap. Tidak mengubah proyek yang tersimpan atau pengaturan subtitle/VO.

## Perubahan
- Optimasi decode MP4 default aktif. Cache hingga 8 frame berurutan dengan batas estimasi bitmap 24 MiB; cache dilepas saat ganti scene. Hanya digunakan jika metadata frame count, durasi, dan FPS konsisten; ini bukan jaminan CFR. Jika API pengambilan frame indeks gagal atau tidak kompatibel, metode timestamp sebelumnya tetap tersedia. Matikan optimasi bila menemukan ketidaksesuaian timing (misalnya MP4 variable frame rate).
- Pengisian YUV menggunakan buffer baris reusable dan metadata plane yang dicache; konversi BT.601 tetap sama, termasuk chroma 2x2. Tidak mengganti codec dengan renderer baru.
- Preset cepat 540p/24 FPS, seimbang 540p/30 FPS, HD 720p/30 FPS. Preset mematikan frame blend, mengaktifkan optimasi, tanpa mengubah subtitle/audio. FPS 60 dan pengaturan manual tetap tersedia.
- Subtitle tertanam, watermark, efek scene, audio mixer, timeline VO dan render background tetap menggunakan jalur lama.

## Upload
1. Ekstrak ZIP luar saja.
2. Upload `KreasiFlow-Android-Update-V5-Source.zip` ke repo KreasiFlow menggantikan source lama.
3. Jalankan workflow test build, lalu release dengan version name 5.0.64 / version code 5000064 (jika diminta). Gunakan signing secrets sebelumnya.
4. Instal APK release di atas versi lama, jangan uninstall.

## Validasi
197 tes Node lulus (193 regresi + 4 tes kontrak render), sintaks JavaScript lulus. Tes kontrak memeriksa integrasi dan source, bukan hasil video native. Android SDK tidak tersedia: build APK, kompatibilitas codec, hasil visual, dan waktu render di HP belum diuji. Bandingkan proyek yang sama dengan resolusi/FPS sama untuk mengukur optimasi; preset 24 FPS memang mengurangi jumlah frame 20% dibanding 30 FPS, tetapi tidak menjamin penurunan waktu yang sama. Render Google Flow tetap terpisah.
