# KreasiFlow Studio v5.0.65 — Fix Audio Navigation

Basis: v5.0.64 Fast Render, dengan seluruh style dan integrasi ElevenLabs sebelumnya.

- Perbaikan runtime: renderProcess() sekarang mendefinisikan actual dan shots sebelum membangun panel opsi scene. Sebelumnya ReferenceError menghentikan render setelah tab Audio disorot.
- Tab Audio: Upload VO (MP3/WAV/M4A) langsung terlihat, tidak lagi berada di panel lipat. Generate ElevenLabs tetap tersedia. Google AI Studio menjadi opsi manual.
- Daftar rekomendasi judul terbuka otomatis saat tersedia.
- Package ID, konfigurasi signing, dan native renderer tidak diubah.

Cara update: ekstrak ZIP luar, unggah KreasiFlow-Android-Update-V5-Source.zip menggantikan file di root repo lama, jalankan test build dan release dengan versi 5.0.65. Tidak perlu mengganti secret. Jangan uninstall aplikasi lama bila ingin mempertahankan data lokal.

Pengujian: 201 tes Node (termasuk test-story-continuity.js) lulus. Tes fitur baru menjalankan renderProcess dengan berbagai jumlah scene, memastikan input audio tidak tersembunyi, dan memeriksa daftar judul terbuka. Chromium diblokir pada navigasi file lokal; APK Android, pemilihan file native dan panggilan API ElevenLabs belum diuji langsung.
