# KreasiFlow Studio v5.0.66 — Copy Prompt & Manual VO

Basis: v5.0.65 Fix Audio Navigation.

- T2I (master semua scene dan per scene): tombol salin saja, tanpa membuka browser. Mode kartun juga menggunakan tombol salin gambar. Referensi kartun tetap dapat disimpan melalui kontrol ekspor referensi.
- I2V pada mode image-first: tombol salin prompt video saja, dengan prompt Omni/Audio Lock yang tetap sama. Mode Text-to-Video terpisah tidak diubah. Google Flow dapat dibuka lewat ikon header.
- Audio: Salin narasi, Buka ElevenLabs (situs TTS), Upload VO (MP3/WAV/M4A dan format audio lain yang didukung), lalu pratinjau dan transkripsi. Voice ID, pilihan model, dan jalur API TTS dihapus. API ElevenLabs Scribe tetap untuk transkripsi, bukan TTS. Pengaturan signing, ID aplikasi, Fast Render, dan style tidak diubah.

Update: ekstrak ZIP luar, unggah KreasiFlow-Android-Update-V5-Source.zip ke root repository KreasiFlow untuk menggantikan source lama. Jalankan test build dan release 5.0.66. Pertahankan secret signing dan jangan uninstall untuk menjaga data lokal.

Pengujian lokal: 203 tes Node lulus (termasuk test-story-continuity.js); sintaks JavaScript lulus. Android build, interaksi clipboard native, upload audio native, dan pembukaan situs ElevenLabs di HP belum diuji.
