# KreasiFlow v5.0.69 — Fast Script
- Source v5.0.68. Package ID, konfigurasi signing, workflow, render, VO manual, storyboard dan judul cepat tidak diubah.
- Naskah menggunakan anggaran token output dinamis 1.600–8.192 (sesuai durasi dan Smart Outro). Ini batas maksimum, bukan jumlah token yang selalu digunakan.
- Gemini Flash-Lite menggunakan thinkingLevel MINIMAL. OpenRouter/free untuk naskah dipetakan ke google/gemma-4-26b-a4b-it:free dengan reasoning effort none; pilihan model eksplisit pengguna tetap dipertahankan. Ling yang dipilih eksplisit juga meminta effort none. Dukungan dan ketersediaan provider dapat berubah.
- Batas baca per percobaan 25/40/60 detik sesuai anggaran output; koneksi Gemini 12 detik dan OpenRouter 7 detik. Background mencoba sekali per provider yang punya key, lalu beralih ke provider lain apabila tersedia. Batas baca bukan batas waktu total. Tidak ada retry berulang khusus naskah.
- Respons terpotong karena batas token ditolak. Naskah lama tidak ditimpa bila gagal. Tidak ada draf faktual palsu otomatis. Periksa hasil dan panjang naskah sebelum VO.
- 217 tes Node lulus (termasuk tes statis Java, tes kontinuitas dan 4 tes baru), sintaks JS valid. Build APK, panggilan API nyata, dan benchmark HP belum diuji.
- Ekstrak ZIP luar, unggah KreasiFlow-Android-Update-V5-Source.zip ke repo lama dan jalankan workflow versi 5.0.69. Jangan ganti secret signing.
