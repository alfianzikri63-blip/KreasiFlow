# KreasiFlow 5.1.1 — Script Recovery (Beta)
Basis: 5.1.0 Ultimate Production Beta. Tidak mengubah package ID, signing, renderer, maupun mode VO manual.

- Native background naskah: `openrouter/free` menggunakan Gemma 4 26B free, lalu Gemma 4 31B free jika kegagalan model sementara atau output kosong/terpotong. Model spesifik pilihan pengguna tetap dihormati. Gemini dan OpenRouter bergantian jika key tersedia. Satu percobaan per route; autentikasi, saldo, kuota global tidak diulang. Batas koneksi/baca per permintaan tetap seperti 5.1.0, bukan batas total wall-clock; fallback dapat memerlukan waktu tambahan.
- Status kegagalan tampil Gagal, bukan persentase aktif. Pesan lebih panjang menampilkan diagnosis beberapa provider. Respons kosong/kurang dari 12 kata ditolak; naskah tersimpan tidak ditimpa saat gagal.
- Tab Mulai: Salin prompt naskah untuk ChatGPT/Gemini manual dan Draf lokal (template perlu diedit dan diverifikasi). Tempel hasil ke kotak naskah. Bila memakai [OUTRO] atau outro custom, buka Opsi naskah & narasi > Terapkan naskah tempel sebelum VO. Jangan terapkan dua kali pada naskah yang sudah selesai diproses.
- Semua 228 pengujian Node (termasuk tes regresi dan empat tes baru) serta sintaks JS inline lolos. Tes native Android dan API sungguhan belum dijalankan. Tidak menjamin ketersediaan layanan eksternal atau kuota gratis.

Ekstrak ZIP luar, upload `KreasiFlow-Android-Update-V5-Source.zip` ke repo KreasiFlow yang sama. Jalankan workflow build/release dengan version name 5.1.1 dan version code 5001001 (atau kode lebih tinggi daripada versi terpasang). Gunakan signing yang sama.
