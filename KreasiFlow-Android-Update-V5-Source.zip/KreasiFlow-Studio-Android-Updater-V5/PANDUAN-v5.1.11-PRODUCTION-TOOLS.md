# KreasiFlow Studio V5.1.11 — Production Tools

Baseline: source V5.1.10 (Manual Storyboard Fix), confirmed by user that generation is working and faster. The AI request flow, scene generation, manual storyboard import, render engine, signing configuration and existing features are unchanged. New optional modules are under **Render → Alat produksi · Cek kualitas, Brand & Cover**.

- Cek kualitas: inspect timeline, subtitle, missing footage, stored MP4 metadata, clip duration/orientation, repeated file IDs and audio volume settings. Optional deeper sampling uses existing frame fingerprinting to flag low-detail/possibly dark footage and similar samples. It does not measure actual loudness or scan every frame; no automatic changes or render blocking.
- Brand Kit: save up to 20 named local profiles with text watermark, outro channel name, subtitle color, preset, size and position. Apply a chosen profile to the current project. Profiles use local storage; no cloud synchronization or graphic logo watermark in this update.
- Editor cover JPG: choose a scene image or a native MP4 frame (at approximately one third of the clip), or upload JPG/PNG/WebP. Edit title, ratio (9:16, 1:1, 16:9), font family, color, layout and brand text. Preview and export JPG. Native Android extracts a single frame using MediaMetadataRetriever; image upload and JPG export also work in browser. No API or Flow credits. Native frame extraction and Android downloads require device testing.

## Install
Extract outer ZIP. Upload only `KreasiFlow-Android-Update-V5-Source.zip` to the existing repository, replacing the previous source. Run test build and release workflow with versionName 5.1.11, versionCode 5001011. Preserve signing secrets and app ID. Keep V5.1.10 for rollback. No keys are added.

## Validation
264 Node tests passed (259 existing with version expectations updated, 5 new). Scene continuity passed. Chromium actual-click tests passed for manual storyboard, invalid JSON, valid import, outro timing, quality check, Brand Kit save/apply and real JPEG export (1080 square). Native Android build, MP4 extraction, real Android storage and full render not tested here (Android SDK/Gradle unavailable). Test these on a copy of a project before production. New modules are optional and do not change default render behavior.
