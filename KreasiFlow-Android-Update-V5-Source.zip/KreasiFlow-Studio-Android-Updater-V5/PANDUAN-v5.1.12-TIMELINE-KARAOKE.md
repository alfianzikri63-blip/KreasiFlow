# KreasiFlow Studio V5.1.12 — Timeline & Karaoke

Baseline: V5.1.11. Package ID, workflow release dan signing tidak diubah. Generator judul, naskah, storyboard AI/manual, provider dan prompt tetap sama. Draft scene lokal tetap tidak tersedia.

## Timeline Editor
- Tab Render → Sinkronisasi Klip Google Flow + VO → Timeline Editor.
- Ketuk blok scene atau pilih nomor scene. Playhead dapat digeser; audio VO dapat diputar jika tersedia. Panel memperlihatkan narasi, gambar (jika ada) dan status footage. Ini preview waktu/narasi, bukan pemutar gabungan MP4.
- Untuk scene 2 dan seterusnya, isi waktu mulai atau gunakan posisi playhead. Terapkan batas, kemudian Simpan timeline. Perubahan baru tersimpan setelah tombol Simpan. Batas bertumpuk ditolak. Scene pertama mulai pada 0, durasi total dan urutan scene/footage tetap.
- Berlaku untuk jalur render MP4 Flow yang menggunakan sceneStarts; bukan editor trim/reorder klip atau jalur slideshow gambar. Reset batas di Pengaturan batas scene (angka) jika ingin kembali ke sinkronisasi otomatis.

## Subtitle Karaoke
- Upload VO dan Transkrip AI menggunakan ElevenLabs atau Groq yang mengirim word timestamps. Timestamp kata disimpan bersama subtitle kalimat yang lama.
- Tab Render → Subtitle Pro & Smart Render → preset Karaoke. Tampilan MP4 native: satu kata aktif warna kuning sesuai timestamp asli. Tidak menyisipkan estimasi jika data kata tidak tersedia. Jeda ucapan dapat membuat teks kosong. Maksimum 2.000 kata untuk preset ini (preset lain tetap maksimum 250 cue).
- Transkrip proyek lama mungkin belum menyimpan timestamp kata. Transkrip ulang jika perlu. Edit subtitle, impor SRT, estimasi, geser subtitle atau unggah VO baru menghapus data karaoke lama agar timing tidak keliru. Preset lain tetap dapat digunakan. Ekspor SRT tetap memakai cue kalimat yang ada, bukan mode karaoke.
- Outro gabungan tetap dipisahkan dari timeline utama; subtitle untuk render utama dipotong di batas outro seperti sebelumnya.

## Uji
268/268 tes Node lulus; kontinuitas narasi dan sintaks JS lulus. Chromium: klik timeline, penolakan batas salah, simpan dan buka kembali, payload karaoke dan penolakan jika timestamp tidak ada; storyboard manual, quality checker, Brand Kit, ekspor JPG lulus. Tidak ada SDK/Gradle Android di lingkungan ini, jadi build APK, tampilan karaoke MP4 native, pemutaran VO di HP dan API STT langsung belum diuji. Simpan V5.1.11 dan V5.1.10 sebagai cadangan. Smart Transition dan Batch Production belum ditambahkan.

Ekstrak ZIP luar, unggah KreasiFlow-Android-Update-V5-Source.zip ke repository seperti biasa.
