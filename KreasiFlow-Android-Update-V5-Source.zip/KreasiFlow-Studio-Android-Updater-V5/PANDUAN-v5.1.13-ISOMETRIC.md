# KreasiFlow Studio V5.1.13 — Isometric Cinematic Director

Baseline: V5.1.12 Timeline & Karaoke. Package ID tetap id.kreasiflow.studio. Versi default 5.1.13 (5001013).

## Style
- Isometric 3D Cinematic (nama lama dipertahankan): lingkungan kontinu memenuhi frame, tanpa alas kotak atau potongan tanah. Style ini memakai variasi framing otomatis meski opsi Cinematic Director umum tidak aktif.
- Isometric 3D Diorama: miniatur beralas, tersedia terpisah untuk yang menginginkan style lama.
- Isometric 3D Hybrid: scene bernomor 1 sebagai diorama, scene 2 dan berikutnya sebagai full environment. Tidak ada perubahan bentuk di tengah klip.
- Jumlah preset 76. Default umum proyek baru tetap 2D Flat Vector Motion Graphic.

## Cara pakai
1. Pilih preset Isometric pada pilihan gaya visual. Untuk proyek yang sebelumnya memilih Isometric 3D Cinematic, nama pilihan tetap sama tetapi aturannya sekarang full environment.
2. Generate Scene AI (atau storyboard manual jika perlu). Jika proyek lama sudah memiliki prompt lama, buat ulang prompt/storyboard bila diperlukan; periksa perubahan sebelum menghapus atau mengganti scene lama. Hasil edit manual dan override prompt tidak otomatis ditulis ulang.
3. Salin master atau prompt T2I per scene, buat gambar di Google Flow. Gunakan gambar full environment yang baru untuk I2V; jangan gunakan gambar diorama lama jika menginginkan footage full-frame.
4. Salin master atau prompt I2V per scene dan buat video di Flow. Impor MP4 seperti biasa.

Aturan visual masuk ke style bible AI dan manual, master serta per-scene T2I/I2V. Kamera otomatis bervariasi dengan framing luas, medium, tracking untuk beberapa narasi transportasi, detail dan overhead. Aturan global dan per-scene mengurangi konflik prompt; hasil dari Flow tidak dapat dijamin karena model eksternal. Tidak ada panggilan API tambahan. Tidak ada perubahan mesin AI, draft lokal, renderer native atau signing. Style lain tetap sama.

## Verifikasi
- 272 tes Node lulus (268 regresi, 4 tes baru); ekspektasi versi/jumlah preset dikalibrasi.
- Tes kontinuitas narasi, sintaks JavaScript lulus.
- Chromium: klik salin master T2I/I2V untuk 3 preset dengan clipboard simulasi, prompt per-scene, dialog storyboard manual dan impor JSON serta timing outro lulus.
- Build APK, Android WebView, API live, dan hasil visual Google Flow belum diuji.

## Paket
Ekstrak ZIP luar lalu unggah KreasiFlow-Android-Update-V5-Source.zip ke repo KreasiFlow yang sudah dipakai. Simpan V5.1.12 dan V5.1.10 sebagai cadangan. Jangan ubah signing secret.
