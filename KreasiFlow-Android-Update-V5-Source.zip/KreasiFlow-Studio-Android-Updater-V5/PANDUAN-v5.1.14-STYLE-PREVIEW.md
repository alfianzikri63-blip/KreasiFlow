# KreasiFlow V5.1.14 — Visual Style Preview

Baseline V5.1.13. Pilih style di tab Mulai, atau opsi style pada Audio/Scene. Panel preview langsung menampilkan gambar, nama, dan deskripsi style aktif. Pemilihan melalui galeri juga memperbarui panel.

- 76 ilustrasi WebP berukuran 640 × 360, disertakan sebagai Android assets; tidak memakai API, kredit, atau jaringan. AssetLoader yang sudah ada melayani file lokal tersebut. Tidak ada perubahan pada Java, engine AI, prompt, storyboard, render, maupun penyimpanan proyek.
- Preview adalah ilustrasi referensi sederhana yang dibuat secara programatik; bukan gambar fotoreal hasil model Google Flow. Style yang mirip dapat terlihat mirip. Peta hanya ilustrasi, bukan geografi faktual.
- Isometric Cinematic memperlihatkan lingkungan penuh; Diorama memperlihatkan alas; Hybrid memakai inset diorama dan lingkungan penuh.
- Source gambar dapat diregenerasi dengan `python tools/generate-style-previews.py` (Pillow dan CairoSVG); tidak diperlukan saat build APK karena WebP sudah tersedia.
- 274 tes Node dan tes kontinuitas narasi lulus. Chromium: 76 opsi, decode semua preview, Audio, Scene, pemilihan galeri, penyimpanan preferensi. Lingkungan browser menolak file://, sehingga tes menyimulasikan pengiriman aset lokal lewat data URL; bukan pengujian WebView Android. Build APK dan tes perangkat belum dilakukan.

Update seperti sebelumnya: ekstrak ZIP luar, upload `KreasiFlow-Android-Update-V5-Source.zip` ke repository KreasiFlow yang sama, jalankan workflow. Package ID dan signing tidak berubah. Simpan versi lama sebagai cadangan.
