# KreasiFlow 5.1.17 — Smart Transition

Basis: V5.1.13 Isometric Full Footage (76 preset). V5.1.14–16 style preview tidak diteruskan sesuai permintaan. Tidak perlu secret atau workflow Cloudflare baru. Application ID dan konfigurasi signing tetap sama.

## Penggunaan
1. Upload inner `KreasiFlow-Android-Update-V5-Source.zip` ke repo seperti biasa. Build dengan workflow yang sudah ada; versi 5.1.17 / 5001017. Jangan menghapus proyek atau API key.
2. Buka tab Render → Pengaturan render → Transisi antar-scene (MP4 Android).
3. Pilih pengaturan fade lama (default, menghormati checkbox lama), Hard cut, Otomatis sesuai style, Dissolve, Dip to black, atau Flash lembut.
4. Render MP4 Flow + VO + Subtitle atau Slideshow MP4 native. Transisi baru memengaruhi piksel saja, tidak mengubah timeline, VO, subtitle, atau outro. Efek pan/zoom per-scene tetap merupakan pengaturan terpisah.

Otomatis menggunakan dip untuk gaya gelap/misteri dan dissolve untuk gaya lain. Dissolve menahan visual frame terakhir klip keluar, lalu memudarkannya selama maksimum 0,32 detik di awal klip masuk; bukan blending dua klip bergerak secara simultan. Dip memudarkan visual menuju gelap (hingga 85% opasitas) sekitar batas scene. Flash lembut menggunakan overlay putih maksimum 30% dengan durasi maksimal 0,16 detik di setiap sisi batas. Durasi transisi dipendekkan untuk scene pendek. Tidak menambahkan transisi pada outro. Efek baru memerlukan encoding normal; mode hard cut tetap dapat menggunakan Smart Render jika semua persyaratan lama terpenuhi. Preview browser tidak mensimulasikan efek baru. Tanpa kredit AI.

## Verifikasi
- 275 tes Node lulus (272 baseline dan 3 baru), scene continuity, sintaks JS.
- Tes perhitungan timing Java dengan javac lulus.
- Chromium: pemilihan menu, state setelah render UI, mode otomatis; regresi storyboard manual dan impor JSON lulus.
- Build Android, visual hasil render MP4, performa native dan kompatibilitas codec belum diuji di perangkat. Backup source lama sebelum update.
