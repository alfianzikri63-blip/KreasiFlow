# KreasiFlow V5.1.18 — Settings Cleanup

Basis V5.1.17 (tanpa preview style). Header: Flow, Proyek, Setelan. Footer: Menu, Simpan, Baru dengan status penyimpanan di baris terpisah. Enam provider aktif dikelompokkan dalam kartu lipat; model OpenRouter, gambar AI opsional, fallback transkripsi dan monitor masih tersedia. Form video AI berbayar dan pengisian token Replicate dihapus dari UI utama; key tersimpan tidak dihapus otomatis, dan masih dapat dihapus melalui Opsi lanjutan. Tidak ada perubahan pada generator AI atau renderer native. Fitur loop belum ditambahkan. Nomor versi 5.1.18 / 5001018.

Upload ZIP source bagian dalam dengan nama yang sama seperti update sebelumnya. Secret, package ID dan workflow tidak berubah. Tes Node dan kontinuitas lulus; navigasi Chromium diblokir oleh lingkungan uji sehingga layout HP dan build APK belum diverifikasi langsung.
