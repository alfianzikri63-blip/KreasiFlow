# KreasiFlow v5.1.18 — UI Cleanup + Fokus Workflow

## Yang diperbarui
- Tombol header dirapikan dan diberi label: **Flow**, **Proyek**, **Setelan**.
- Tombol footer dirapikan: **Menu**, **Simpan**, **Baru**.
- Status footer disederhanakan agar lebih bersih.
- Form **Video AI berbayar** di tab Render disembunyikan agar alur utama lebih fokus.
- Render sekarang lebih menekankan workflow utama: **Google Flow → impor MP4 → render Android**.
- Pesan bantu di tab Render diperbarui agar pengguna tidak bingung dengan fitur AI yang jarang dipakai.

## Catatan
- Update ini fokus ke kerapian UI dan penyederhanaan form.
- Fitur loop penuh / seamless loop belum ditambahkan di update ini.
- Beberapa fungsi AI lama di belakang layar tidak dihapus total dari source; yang diubah adalah tampilan/form yang tidak dipakai agar UI lebih ringkas.
