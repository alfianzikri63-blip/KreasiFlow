# KreasiFlow v5.1.2 — Theme-Based Outro Template (Beta)
Berbasis source v5.1.1. applicationId dan signing tetap. VersionCode 5001002.

## Alur
1. Pilih tema dan Outro Template → Otomatis sesuai tema (default Tanpa outro agar proyek lama tidak berubah). Bisa pilih manual.
2. CTA Komentar, Follow atau Subscribe. Durasi minimum 3, 5, atau 8 detik. Kartu penutup memiliki desain grafis animasi lokal berbeda per tema, bukan klip AI 3D/MP4 yang dihasilkan Flow.
3. Opsional: buka panel VO penutup reusable, salin teks outro, buat suara di ElevenLabs manual sekali, upload MP3/WAV/M4A yang dapat dibaca WebView (maks 12 MB dan 15 detik). Pustaka menyimpan audio berdasarkan preset, bahasa dan CTA di IndexedDB perangkat. Bisa putar, hapus, ganti audio. Nama channel opsional. Audio tidak otomatis dibuat.
4. Generate judul/naskah, upload VO utama, transkripsi dan storyboard seperti sebelumnya. Tidak ada permintaan AI untuk outro. Outro lama yang sudah menjadi bagian VO/naskah tidak dihapus; hindari dua penutup dengan menonaktifkan template pada proyek lama.
5. Render native Android: outro muncul setelah durasi utama, dengan audio penutup reusable jika ada. Durasi minimum diperpanjang sampai pembulatan ke atas durasi VO outro bila perlu. Total maksimal 600 detik. Musik proyek dapat berlanjut dengan ducking pada kedua VO. Tanpa VO outro, hanya teks/grafis dan musik latar jika tersedia.

## Catatan
- Smart Remux tetap tersedia bila outro nonaktif; outro animasi lokal memerlukan encoding video normal. Tidak ada klaim percepatan render.
- Pustaka VO perangkat terpisah dari backup proyek dan tidak sinkron ke cloud; simpan file audio asli sendiri. Menghapus data aplikasi dapat menghapus pustaka.
- Browser export tidak mendukung outro ini. Gunakan APK native.
- 232 tes Node (.test.cjs) lulus, ditambah skrip uji scene continuity dan pemeriksaan sintaks JS. Tes source tidak menggantikan build Android atau pengujian codec, penyimpanan dan audio langsung di HP.

## Upload
Ekstrak ZIP luar, unggah KreasiFlow-Android-Update-V5-Source.zip ke root repository yang sama. Jalankan workflow build test dan release versi 5.1.2. Gunakan signing secrets lama. Uji render dengan outro off, on tanpa VO, dan on dengan VO tersimpan; cek durasi, subtitle utama, dan audio. Uji kembali setelah menutup/membuka aplikasi dan membuka proyek lain.
