# KreasiFlow V5.1.20 — Narrative Loop Fix

Basis V5.1.19; seluruh pengaturan, visual loop, storyboard, dan native renderer dipertahankan. Tidak perlu secret atau workflow baru.

- Prompt naskah loop kini meminta klausa pengantar akhir bertanda titik dua, disambungkan langsung ke kalimat berita pembuka, bukan sekadar penutup dengan tema yang sama. AI diminta membaca pasangan akhir-awal sebelum mengirim.
- Jalur AI foreground, background, dan salin prompt memakai buildScriptPrompt yang sama.
- Panel Naskah menampilkan bagian akhir dan awal serta status pemeriksaan struktur. Sebelum lanjut VO atau menyalin narasi, jika pola belum terdeteksi, konfirmasi meminta pengguna memeriksa sambungan. Naskah tidak ditimpa dan pengguna dapat melanjutkan jika sudah menilai sendiri.
- Ini pemeriksaan heuristik tanda baca/struktur, bukan verifikasi semantik, kelancaran VO, atau hasil Google Flow. Tidak ada panggilan API tambahan otomatis. Jika perlu gunakan Generate Naskah ulang atau edit akhir sendiri; buat ulang VO dan storyboard jika narasi berubah.
- Mode normal tidak mendapat aturan atau peringatan loop. Tidak ada perubahan kode native.

Uji: 284 tes Node, kontinuitas scene, sintaks JS inline; semuanya lulus. Ekspektasi nomor versi dan regex copy-voice diperbarui untuk guard baru. Build APK, API aktual, browser UI, dan pengujian langsung Android belum dilakukan.
