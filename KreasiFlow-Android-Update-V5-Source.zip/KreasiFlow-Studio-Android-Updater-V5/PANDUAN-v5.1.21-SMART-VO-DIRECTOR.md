# KreasiFlow V5.1.21 — Smart VO Director

Update source dari V5.1.20, application ID dan signing tetap. Upload inner ZIP ke repo seperti biasa. Tidak memerlukan secret atau workflow baru.

- Naskah AI ditulis satu paragraf. Hasil AI, input/paste multiline dan naskah lama dinormalisasi menjadi satu paragraf tanpa Enter. Teks tetap dapat membungkus secara visual di layar. Parser narasi lama tetap menghapus catatan produksi sebelum penggabungan.
- Tab Audio: Smart VO Director memilih preset lokal berdasarkan gaya narasi, genre, kategori dan judul; dapat dipilih manual atau Teks polos. Tidak ada panggilan AI tambahan. Preview dapat dibuka sebelum menyalin.
- Salin naskah bersih (Mulai) tetap tanpa audio tags. Salin VO + intonasi (Audio) memasukkan audio tags ke salinan terpisah. Mode loop mengarahkan nada pembuka dan akhir agar sama, tidak menambah ucapan atau mengubah tanda baca. Mode normal dan outro gabungan tetap tersedia.
- Di website ElevenLabs pilih Eleven v4/v3 yang mendukung audio tags; untuk model lain pilih Teks polos. Tag hanya arahan, tidak menjamin intonasi atau durasi. Upload VO hasil generate, transkrip dan periksa sinkronisasi seperti biasa. Storyboard dan acuan subtitle menggunakan narasi bersih.
- 289 tes Node dan kontinuitas scene lulus. Sintaks JS valid. Pengujian Chromium halaman penuh diblokir kebijakan lingkungan (ERR_BLOCKED_BY_ADMINISTRATOR); handler input diuji di VM. APK/Android, ElevenLabs aktual, dan hasil render tidak diuji.

Rujukan: https://elevenlabs.io/docs/help-center/product/core-capabilities/text-to-speech/how-do-audio-tags-work-with-eleven-v3-and-v4
