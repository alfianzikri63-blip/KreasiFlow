# KreasiFlow 5.1.22 — Smart Loop Frame Lock

Update dari 5.1.21. Upload ZIP source bagian dalam menggunakan workflow yang sama. Tidak perlu secret tambahan. Simpan backup versi lama.

## Alur Loop
1. Aktifkan Smart Seamless Loop di Mulai sebelum membuat naskah. VO tetap melalui ElevenLabs manual; Smart VO Director tetap tersedia.
2. Generate Scene AI atau impor storyboard manual. Scene tengah mengikuti narasi; untuk minimal dua scene, visual penutup mengambil prompt dan kamera pembuka, tanpa membuang narasi terakhir. Prompt lama yang bertentangan tidak digunakan untuk penutup. Kedua endpoint memakai image-to-video.
3. Salin master T2I atau prompt per scene. Aturan lock ada di dalam deskripsi tiap endpoint. Buat gambar Scene 01 terlebih dahulu; gunakan sebagai referensi untuk gambar awal scene terakhir. Simpan gambar pembuka.
4. Generate MP4 Scene 01, impor ke KreasiFlow. Di panel Storyboard, tekan Simpan frame pembuka MP4 untuk memperoleh sampel JPEG dari awal klip asli di Download/KreasiFlow. Di Google Flow, pilih model yang mendukung start dan end frame; masukkan gambar awal scene terakhir sebagai start frame, dan frame pembuka Scene 01 sebagai end frame. Salin prompt video khusus scene terakhir. Aplikasi tidak mengirim file ke Flow otomatis.
5. Impor kedua MP4 (dan semua scene tengah). Tekan Periksa sambungan footage. Aplikasi membandingkan sampel gambar awal dan akhir MP4 asli yang didekode Android, memperlihatkan kedua gambar, dan memberi skor kemiripan piksel, perbedaan kecerahan serta warna. Ambang konservatif: beda RGB rata-rata >8%, beda kecerahan >6%, atau beda warna rata-rata >6% memicu review. Jarak batas subtitle ke awal/akhir VO adalah estimasi jika timestamp tersedia, bukan pengukuran waveform atau intonasi. Periksa manual juga.
6. Jika perbedaan besar, generate ulang klip terakhir. Saat render MP4 bergerak, peringatan akan ditampilkan jika sampel berbeda atau belum bisa dibaca; pengguna boleh memilih lanjut. Blend loop lama tetap sebagai penyempurna, durasi dan VO tetap.

## Batasan
- Prompt maupun frame lock bukan jaminan output Flow identik. Input start/end frame harus dipasang manual dan didukung model. Sampel JPEG native menggunakan decoder Android (maksimum dimensi 960, frame terdekat, bukan jaminan frame terakhir persis). Pemeriksaan gambar bersifat heuristik, bukan AI semantik atau analisis gerak; belum memeriksa frame hasil final yang sudah disesuaikan timeline dan subtitle. Perbedaan skor tidak selalu berarti loop buruk.
- Render native, APK Android, dan Flow belum diuji langsung. 294 tes Node lulus, sintaks JS valid, tes kontinuitas narasi lulus. Pembanding diuji dengan sampel frame MP4 yang dikirim pengguna, hasil 87% kemiripan, 10% beda kecerahan, 10% beda warna, memicu review; ini pengujian offline dan hasil native dapat berbeda.
- Mode non-loop tetap seperti sebelumnya. Tidak ada API baru. Mode legacy khusus tidak memakai Frame Lock.
