# KreasiFlow V5.1.23 — Reference-Based Loop

Basis: V5.1.22. Application ID, signing, engine AI, VO Director, timeline, transition and render pipeline are retained. No new API keys or workflow.

## Cara penggunaan
1. Aktifkan Smart Seamless Loop seperti biasa, sebelum naskah. Untuk proyek yang sudah sesuai mode loop, prompt baru dapat disalin tanpa generate storyboard ulang selama naskah, style, dan VO masih sama.
2. Master T2I dalam loop dengan N scene meminta hanya N-1 gambar baru. Scene penutup tidak perlu gambar independen. Jumlah scene dan video tetap N.
3. Buat Scene 1 di Flow dan impor MP4-nya ke scene pertama (buka detail Scene 1, Ganti MP4 Scene 1). Tekan **Simpan frame pembuka MP4** pada panel Smart Loop. JPEG kualitas 95, ukuran asli sampai sisi panjang 1920 px, tersimpan ke Download/KreasiFlow.
4. Di Flow, gunakan mode Frames to Video dengan model yang menerima dua frame. Untuk scene terakhir, masukkan file JPEG pembuka yang SAMA ke Start Frame dan End Frame. Salin prompt I2V khusus penutup; arah gerakan kecil kembali ke komposisi awal. Jangan generate gambar penutup baru. Jika model tidak menyediakan dua input, pindah model. Aplikasi tidak dapat memasang input Flow sendiri.
5. Impor MP4 scene terakhir. Tekan **Periksa sambungan footage** untuk skor RGB, kecerahan, warna, struktur lokal, dan perbedaan tepi. Angka ini heuristik berbasis sampel 64x64, bukan penilaian semantik atau optical flow. Tekan **Preview sambungan loop**: sampel 6 frame dari masing-masing batas diputar berulang, sekitar 6 fps, tanpa suara, bukan hasil render final.
6. Jika masih tidak cocok, regenerate hanya scene terakhir; periksa gerakan kamera, subtitle dan VO secara manual. Render tetap memakai blend singkat versi sebelumnya; tidak menjamin seamless jika footage sumber berbeda. Durasi VO, jumlah scene, dan subtitle tidak diubah.

## Pengujian
- 298/298 tes Node, termasuk 4 regresi baru, lulus.
- Tes kontinuitas narasi dan sintaks JS lulus.
- Sampel FFmpeg dari awal 273549.mp4 dan akhir 273550.mp4: RGB similarity 86%, brightness difference 2%, color difference 1%, structure 17%, edge difference 75%, review=true. Frame identik: structure 100%, review=false. Ini pengujian algoritme lokal, bukan decoder Android.
- Build APK, WebView/decoder native Android, dan generate Flow belum diuji. Preview berupa sampel frame, bukan playback full-motion atau audio. Model Flow dapat mengabaikan referensi atau mengubah gerakan.

## Upload
Ekstrak ZIP luar. Upload KreasiFlow-Android-Update-V5-Source.zip seperti update sebelumnya. Jangan ubah secret signing dan workflow. Simpan source versi sebelumnya.
