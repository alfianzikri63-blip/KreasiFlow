# KreasiFlow v5.1.25 — Simplified Scene Workflow

Basis: v5.1.24. Application ID, signing, data proyek, dan workflow release tidak diubah.

- Hapus panel Pemeriksa scene & footage, indikator kemiripan per scene, tombol Cek ulang semua scene, serta Revisi adegan mirip via AI dari tab Scene.
- Hapus pemanggilan revisi kemiripan otomatis (maksimal dua putaran) setelah storyboard dibuat. AI tetap menerima instruksi pembeda aksi, kamera, dan konteks pada prompt awal. Opsi manual untuk memperjelas prompt tetap tersedia dan hanya berjalan bila diminta.
- Hapus perbandingan pasangan sampel MP4 pada cek kualitas Render. Cek teknis tetap tersedia: kelengkapan media, durasi, orientasi, file yang sama, keterbacaan dan sampel minim detail. Cek frame sambungan loop tetap terpisah.
- Pertahankan perbaikan loop v5.1.24: N-1 gambar, N video jika Smart Loop aktif (N >= 2); scene terakhir tidak meminta T2I. Jika loop mati, seluruh scene merupakan scene biasa.
- Tidak ada perubahan engine render atau API key. Tidak ada jaminan hasil visual berbeda/seamless tanpa verifikasi footage aktual.

## Update
1. Ekstrak ZIP luar, upload `KreasiFlow-Android-Update-V5-Source.zip` dengan nama yang sama ke repo KreasiFlow, branch main.
2. Jalankan workflow build/release yang biasa digunakan, isi versi `5.1.25`.
3. Setelah APK signed tersedia, pasang sebagai update tanpa uninstall APK lama (gunakan signing yang sama). Sebaiknya simpan cadangan proyek.
4. Buka tab Scene: panel Pemeriksa scene & footage tidak ada lagi; salin master T2I terbaru. Proyek 17 scene dengan Smart Loop aktif tetap 16 gambar + 17 MP4.

## Validasi
301/301 pengujian Node lulus, termasuk regresi penghapusan checker, satu tahap perencanaan storyboard tanpa revisi otomatis, dan slot loop 17. Tes lama yang mengharuskan fitur terhapus diperbarui/dipensiunkan. Sintaks JavaScript inline lolos `node --check`. Build APK signed dan uji di HP/Google Flow belum dijalankan. Tidak menggunakan kredit AI.
