# KreasiFlow v5.1.26 — Smart Seamless Bridge

Basis: v5.1.25. Fitur cek kemiripan scene tetap dihapus. Package ID, signing, workflow release dan format proyek tidak diubah.

## Alur 17 scene (berlaku juga untuk jumlah scene lain)
1. Salin master T2I terbaru. Generate Scene 1–16; tidak ada gambar tambahan untuk Scene 17.
2. Scene 16 menggunakan gambar Scene 1 sebagai referensi fisik: lokasi, kamera, skala, subjek, waktu dan cahaya yang sama. Buat posisi subjek lebih awal di lintasan dan sisakan jarak gerak untuk Scene 17. Pembeda visual di bagian tengah cerita tetap ada.
3. Generate MP4 Scene 1 dan Scene 16. Jangan sampai subjek pada akhir Scene 16 melewati posisi pembuka Scene 1. Bila tidak kompatibel, jangan lanjut generate bridge.
4. Impor MP4 tersebut ke slot yang benar. Di panel Smart Seamless Bridge pilih END: simpan awal Scene 1, dan START: simpan akhir Scene 16. Aplikasi mengekspor sampel frame JPEG dari MP4 ke Download/KreasiFlow. Android mengambil frame terdekat pada batas waktu klip.
5. Di Google Flow pilih model Frames to Video dengan dua input frame, pasang START dari akhir Scene 16 dan END dari awal Scene 1, serta salin prompt I2V Scene 17. Jangan gunakan gambar identik pada kedua input.
6. Impor MP4 Scene 17 dan uji sambungan 16 → 17 → 1. Isi semua MP4 sebelum render. Tidak perlu revisi AI kemiripan. Preview/cek batas loop teknis tetap tersedia.

## Perubahan renderer
Pada klip video pembuka, persiapan, dan bridge, durasi sumber dipetakan ke slot timeline; efek zoom/slide tambahan dinonaktifkan. Transisi masuk ke bridge dan crossfade paksa ke pembuka pada bridge MP4 dinonaktifkan. Fallback gambar lama tetap memiliki blend akhir. Penyesuaian durasi dapat mengubah kecepatan, sehingga cocokkan durasi klip dan timeline saat pengujian.

## Update
Ekstrak ZIP luar, upload KreasiFlow-Android-Update-V5-Source.zip menggantikan file sumber pada repository KreasiFlow, jalankan workflow release versi 5.1.26. Cadangkan proyek sebelum update. Untuk storyboard lama, salin ulang prompt terbaru; tidak perlu mengulang semua adegan, tetapi Scene 16 dan 17 perlu disesuaikan dengan boundary baru.

## Validasi dan batasan
305/305 pengujian Node lulus, termasuk simulasi ekspor dua frame, hitungan gambar, penyesuaian scene sebelumnya, dan regresi source renderer. Tes lama untuk versi/kontrak frame identik diperbarui. Sintaks JS diperiksa. APK signed, perangkat Android, dan Google Flow belum diuji; tidak ada kredit AI yang digunakan. Prompt anti-boomerang bukan jaminan hasil visual; model I2V tetap dapat melanggar arah gerak atau mengubah detail. Ekspor tidak berarti piksel identik (JPEG dan pengambilan frame terdekat).
