# KreasiFlow v5.1.27 — Smart Visual Diversity

Basis: v5.1.26 Smart Seamless Bridge. Package ID, signing, format proyek dan workflow tetap.

## Perubahan
- Master dan prompt per scene membedakan konsistensi style/identitas dari komposisi. Setting, ukuran shot, fokus objek dan pencahayaan mengikuti narasi masing-masing.
- Framing eksplisit dalam prompt gambar diutamakan. Kamera storyboard menjadi fallback, bukan pola nomor scene yang menimpa framing. Catatan director T2I kedua yang berpotensi bentrok dihapus. Prompt manual tidak ditambah action/setting lama.
- Instruksi storyboard AI baru dan manual menekankan objek, setting dan ukuran shot yang berbeda. Cache storyboard lama tidak dipakai pada pembuatan ulang storyboard. Proyek tersimpan tidak dihapus atau diubah otomatis.
- Hanya scene persiapan loop yang memakai komposisi pembuka. Jika 17 slot dengan loop aktif, T2I 16 gambar; scene 17 Frames to Video memakai akhir MP4 16 sebagai START dan awal MP4 1 sebagai END. UI diperbarui sesuai alur tersebut.
- Tidak mengembalikan pemeriksa kemiripan scene atau revisi AI otomatis.

## Penggunaan
Ekstrak ZIP luar, upload KreasiFlow-Android-Update-V5-Source.zip menggantikan source lama pada repository, jalankan workflow release versi 5.1.27. Cadangkan proyek sebelum update. Salin ulang master T2I dari proyek lama; gunakan tombol salin gambar per scene untuk shot yang kurang berbeda. Jangan lampirkan gambar pembuka sebagai referensi komposisi scene biasa. Gunakan gambar pembuka khusus untuk scene persiapan bridge. Bila deskripsi storyboard tersimpan sendiri sudah terlalu serupa, edit prompt scene yang perlu saja. Tidak perlu mengulang semua gambar atau VO. Uji satu detail lensa dan satu interior terlebih dahulu sebelum I2V. Untuk proyek tanpa loop, seluruh scene tetap memiliki T2I.

## Validasi
309/309 pengujian Node lulus, termasuk empat tes baru untuk komposisi independen, prioritas framing, prompt manual, jumlah scene dan keterangan loop. Tes regresi versi diperbarui; kontrak lama berupa tambahan catatan sutradara T2I diganti dengan kontrak satu framing. Sintaks skrip inline diperiksa. APK signed belum dibangun, belum diuji pada HP atau Google Flow; instruksi baru tidak menjamin hasil visual model. Tidak menggunakan kredit AI.
