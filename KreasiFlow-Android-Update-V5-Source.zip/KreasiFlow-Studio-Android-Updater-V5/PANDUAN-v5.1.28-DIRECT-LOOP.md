# KreasiFlow v5.1.28 — Direct Loop & Safe Scene Mapping

## Pembaruan
- Proyek baru: bila Smart Loop diaktifkan, Direct Loop menjadi metode default. Scene narasi terakhir sekaligus penutup; tidak ada klip bridge tambahan. N scene = N gambar dan N video.
- Proyek lama: mode Bridge lama tetap menjadi default untuk proyek yang belum memiliki pengaturan metode. Semua aset dan slot tetap tersimpan. Tombol metode di panel Smart Loop dapat mengganti metode tanpa menghapus media atau mengurangi jumlah scene.
- Penutup Direct Loop dibuat dengan referensi gambar asli Scene 1 dan posisi/pose lebih awal yang dapat bergerak ke opening. Scene tengah tidak ikut dikunci. Buat gambar penutup secara terpisah, bukan sekaligus tanpa referensi.
- I2V penutup: START = gambar scene terakhir; END = frame pertama MP4 Scene 1. Ekspor END dari panel loop. Jangan menggunakan dua frame identik untuk objek yang bergerak translasi. Jika posisi, arah, lokasi, framing atau jarak tidak cocok, jangan generate sebelum memperbaiki referensi.
- Preview sambungan akhir video ke awal, perbandingan frame lokal, dan ekspor JPG tetap tersedia; nama sumber dan gambar frame ditampilkan setelah ekspor. Skor visual bukan jaminan kontinuitas gerakan.
- Renderer Direct Loop mencoba mempertahankan sampel terakhir sumber saat menyesuaikan durasi penutup ke VO. Tidak memaksa crossfade untuk MP4 loop. Ini tidak memperbaiki footage yang secara visual tidak kompatibel.
- Nama e-01.mp4, e-16.mp4, Scene-01.mp4 dan format lama bernomor dikenali langsung; nomor yang terlewat tetap kosong. Nama campuran yang tidak dikenali ditolak seperti sebelumnya.
- Pemeriksa kemiripan seluruh adegan tidak dikembalikan.

## Cara pakai proyek baru
1. Aktifkan Smart Loop sebelum naskah/VO/storyboard.
2. Generate gambar dan video Scene 1 terlebih dahulu, lalu impor MP4 Scene 1.
3. Buat scene tengah sesuai prompt masing-masing.
4. Buat gambar scene terakhir sebagai edit berdasarkan gambar Scene 1. Cek posisi, arah gerak, framing, dan jarak.
5. Ekspor END (awal MP4 Scene 1). Di Flow Frames to Video, lampirkan gambar scene terakhir sebagai START dan END yang diekspor. Salin prompt video penutup. Pilih model dua frame.
6. Impor klip sesuai nomor scene, preview sambungan dan render hard cut. Jaga timing VO; perubahan kecepatan dapat memengaruhi kontinuitas.

## Proyek ETLE yang sudah selesai
Jangan regenerasi hanya untuk update ini. Biarkan metode Bridge lama dan 17 slot yang ada. Jika ingin mengubah metode, jumlah slot tidak otomatis berkurang karena slot narasi dan timing dipertahankan. Tidak ada jaminan footage lama menjadi seamless otomatis.

## Build
Ekstrak ZIP luar; upload KreasiFlow-Android-Update-V5-Source.zip seperti biasa, workflow release versi 5.1.28. Application ID dan signing config tetap.

Validasi lokal: 314/314 tes Node lulus (termasuk 5 tes baru), syntax script HTML valid. Build Android signed, runtime Android dan Google Flow belum diuji. Tidak menggunakan kredit AI.
