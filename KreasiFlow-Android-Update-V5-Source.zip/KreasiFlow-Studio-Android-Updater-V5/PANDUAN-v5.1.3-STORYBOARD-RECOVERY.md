# KreasiFlow V5.1.3 — Storyboard Recovery
Basis: V5.1.2. Package ID, signing, native renderer, VO manual, template outro dan 74 style tetap.

- Tab Audio: Buat Scene Instan tanpa AI → langsung tab Scene. Tidak mengirim request Gemini/OpenRouter.
- Tab Scene: draft lokal dan AI opsional. Jika AI gagal dan belum ada scene pada proyek yang sama, draft lokal dibuat otomatis. Batch AI valid tetap tersimpan untuk percobaan berikutnya. Storyboard yang sudah ada tidak ditimpa otomatis.
- Draft lokal memakai pembagian narasi dan durasi VO, style, framing, konteks kalimat serta prompt video. Periksa prompt dan sinkronisasi sebelum dipakai; kualitas interpretasi draft lokal tidak sama dengan storyboard AI. Google Flow tetap manual dan dapat memakai kredit.
- Jika AI masih berjalan, tombol lokal menunggu pekerjaan berhenti untuk menghindari dua penulisan scene bersamaan. Jika proyek, narasi, style atau durasi berubah selama pekerjaan AI, hasil lama tidak diterapkan.
- Pengujian: node --test tests/*.test.cjs: 237 lulus; inline JS: node --check lulus. Build Android, API nyata dan pengujian HP belum dilakukan.

Ekstrak ZIP luar, upload KreasiFlow-Android-Update-V5-Source.zip ke root repository yang sama, lalu jalankan workflow test build dan release 5.1.3 (versionCode 5001003). Tidak perlu ubah secret signing.
