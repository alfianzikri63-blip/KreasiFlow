# KreasiFlow V5.1.4 — AI Reliability Engine
Basis V5.1.3. Package ID dan signing tidak diubah. Semua aset dan renderer lama dipertahankan.

1. Pengaturan AI: simpan Groq API key (key yang sama dengan Groq Whisper jika sudah tersimpan). Pilih groq di AI Judul & Naskah. Model teks: openai/gpt-oss-20b, reasoning effort low. Ketersediaan dan kuota bergantung pada akun Groq. https://console.groq.com/keys
2. Aktifkan pemilihan provider otomatis jika ingin memakai riwayat kecepatan/keberhasilan, atau pilih provider secara manual. Untuk naskah dan storyboard, provider cadangan mengikuti key yang tersedia. Judul tetap satu percobaan lalu ide lokal. Native worker melewati provider dengan cooldown 60 detik (429) atau 30 detik (503) selama proses aplikasi masih hidup; tidak menjamin kuota pulih.
3. Storyboard: batch maksimal 2 scene, hasil valid disimpan untuk dilanjutkan. Tekan Batalkan AI background atau notifikasi jika perlu berhenti; permintaan jaringan aktif mungkin baru berhenti setelah timeout.
4. Tab Scene > Storyboard manual (ChatGPT / Gemini) > Salin Master Prompt Storyboard. Tempel prompt di layanan AI pilihan, salin JSON lengkap yang dikembalikan, tempel di dialog aplikasi, lalu Validasi & impor storyboard. Tidak perlu key di aplikasi untuk jalur ini. Nomor scene, jumlah, field wajib dan prompt divalidasi; waktu dan narasi mengikuti planner aplikasi, bukan hasil AI. Tinjau hasil sebelum membuat footage; prompt edit manual dipertahankan jika narasi cocok.
5. Draft lokal masih tersedia jika tidak ada AI. Layanan eksternal mempunyai kuota/biaya sesuai akun.

Pengujian: 242 tes Node lulus, termasuk tes regresi dengan ekspektasi versi/batch diperbarui dan 5 tes tambahan. Sintaks JS lulus. Build APK, API Groq nyata, UI Android dan pembatalan native belum diuji. Tidak ada benchmark kecepatan.

Ekstrak ZIP luar dan unggah KreasiFlow-Android-Update-V5-Source.zip ke root repo seperti biasa. Test build, kemudian release 5.1.4 (5001004). Tidak perlu ganti secret signing.
