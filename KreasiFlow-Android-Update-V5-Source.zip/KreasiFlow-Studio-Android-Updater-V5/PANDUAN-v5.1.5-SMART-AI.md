# KreasiFlow V5.1.5 — Smart AI Engine
Basis V5.1.4. Package ID dan konfigurasi signing tidak diubah.

## AI tambahan
- Cloudflare Workers AI: gunakan token Workers AI dan Account ID (32 karakter hex) yang sama untuk teks/gambar. Teks menggunakan `@cf/meta/llama-3.3-70b-instruct-fp8-fast` melalui endpoint Chat Completions resmi. Pengaturan rejectIfBusy mempercepat fallback jika kapasitas tidak tersedia.
- NVIDIA NIM: simpan NVIDIA API key. Teks menggunakan `google/gemma-4-31b-it` melalui `https://integrate.api.nvidia.com/v1/chat/completions`. Key NVIDIA hanya tersimpan terenkripsi lokal; belum termasuk cloud backup. NVIDIA tidak dipakai untuk transkripsi, gambar atau VO.
- Pengaturan AI > simpan kredensial > Tes teks Cloudflare / Tes NVIDIA > pilih provider teks atau aktifkan Auto Select berdasarkan riwayat. Tes memanggil API dan memakai kuota. Cloudflare: https://dash.cloudflare.com/ ; NVIDIA: https://build.nvidia.com/google/gemma-4-31b-it
- Gemini, OpenRouter dan Groq tetap tersedia. Naskah/storyboard menggunakan fallback provider yang siap dan cooldown 429/503 seperti sebelumnya. Judul tetap satu percobaan jaringan lalu ide lokal. Model/kuota dapat berubah, layanan eksternal dapat mengenakan biaya sesuai akun. Tidak ada klaim benchmark kecepatan.

## Outro gabungan tanpa AI
- Tab Mulai > Outro Template > Otomatis sesuai tema > Suara penutup > Menyatu dengan VO utama. Mode lama reusable tetap tersedia; proyek lama tidak otomatis diubah.
- Buat naskah utama seperti biasa; teks CTA template muncul terpisah di bawah editor, otomatis ikut saat Salin naskah/narasi. Kirim teks lengkap sekali ke ElevenLabs manual, lalu upload VO.
- Di tab Audio, dengarkan pemutar, masukkan detik awal kalimat penutup (misalnya 60.4 jika VO 68 detik). Rentang outro 1–15 detik. Gunakan timestamp hasil transkripsi atau dengarkan sendiri. Batas ini perlu ditentukan manual, bukan deteksi otomatis.
- Buat ulang storyboard jika timeline berubah. Storyboard standar memakai narasi dan durasi utama, tidak membuat scene Flow outro. Render native memakai animasi template lokal di akhir dan suara dari satu file VO penuh; panjang final tidak menambah durasi outro dua kali. Teks CTA tampil pada kartu outro; subtitle utama dipotong pada batas outro.
- Mode gabungan hanya tersedia pada storyboard standar; mode Edu3D/Toon/Flow Text lama gunakan reusable. Jika mengubah narasi/tema/CTA setelah upload, upload VO yang sesuai lagi. Proyek lama dengan outro AI di naskah perlu menghapus penutup lama atau membuat naskah baru.

## Pengujian
247 tes Node lulus (242 regresi dengan penyesuaian harness/versi dan 5 tes baru), tes kontinuitas scene, sintaks JS dan integritas arsip. Build APK, pengujian Android, API asli, dan sinkronisasi audio native belum dilakukan. Tes Node bukan bukti build atau keberhasilan API.

Ekstrak ZIP luar, upload `KreasiFlow-Android-Update-V5-Source.zip` ke repo lama, test build lalu release 5.1.5 (5001005). Jangan ubah secret signing.
