# KreasiFlow 5.1.6 — Simple Storyboard

Basis: V5.1.5, applicationId dan konfigurasi signing tidak berubah.

- Audio: satu tombol Lanjut Scene. Durasi, VO, subtitle, edit narasi dan style tetap tersedia. Tidak memulai AI saat navigasi.
- Scene: satu tombol utama Generate Storyboard. Provider teks tersedia → AI; tidak ada provider terkonfigurasi → draft lokal. Jika provider gagal, fallback yang sudah ada tetap menjaga scene lama. Mode lama Text-to-Video/Kartun/Edu3D memakai jalur storyboard masing-masing.
- Opsi cadangan memuat draft lokal dan storyboard manual JSON (ChatGPT/Gemini), termasuk detail error terakhir. Tombol batal hanya terlihat saat AI background berjalan.
- Pengaturan kamera, prompt per scene, impor MP4, subtitle, outro, dan renderer tidak diubah. Tidak ada perubahan API maupun jaminan bahwa provider bebas dari 429/503. VO gabungan masih perlu detik awal outro yang valid.
- 251 tes Node lulus, uji kontinuitas narasi lulus, sintaks JS valid. Build Android dan pengujian UI fisik/API langsung belum dilakukan.

## Upload
Ekstrak ZIP luar, unggah `KreasiFlow-Android-Update-V5-Source.zip` ke root repository KreasiFlow menggantikan source lama. Jalankan test build dan release dengan versi 5.1.6 (versionCode 5001006). Gunakan signing lama. Simpan cadangan proyek sebelum upgrade.
