# KreasiFlow 5.1.7 — Generate Scene AI
Basis V5.1.6. Tombol utama tab Scene kini bernama Generate Scene AI pada mode storyboard standar. Membuat prompt T2I dan I2V melalui jalur AI yang sudah ada. Tanpa API key teks, tampil pesan dan pengaturan AI, bukan diam-diam menjalankan draft lokal. Draft manual tetap di Opsi cadangan; fallback saat provider gagal tetap dipertahankan. Mode produksi lama tetap memakai tombol dan jalur khusus. Tab Audio cukup Lanjut Scene. Tidak mengubah renderer, signing, atau API.

252 tes Node lulus, uji kontinuitas lulus, sintaks JavaScript valid. Browser headless timeout; build Android dan panggilan API asli belum diuji. Tidak menjamin provider bebas 429/503.

Ekstrak ZIP luar lalu unggah source ZIP ke repository lama. Versi 5.1.7, versionCode 5001007. Pertahankan konfigurasi signing lama dan cadangkan proyek sebelum update.
