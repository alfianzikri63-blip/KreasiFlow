# KreasiFlow Studio v5.0.6 — Perbaikan Penyimpanan API Key

## Akar masalah

Versi v5.0.5 meminta AndroidKeyStore/AES-GCM mengenkripsi dengan IV (nonce)
yang diberikan aplikasi lewat `GCMParameterSpec` pada mode ENCRYPT. AndroidKeyStore
secara default **melarang IV yang disediakan pemanggil saat enkripsi** untuk
menjamin IV acak. Akibatnya, `ProviderSecrets.save()` melempar
`InvalidAlgorithmParameterException`, menelan kesalahan sebagai `false`, dan
UI menampilkan "Gagal menyimpan: openrouter, fal, elevenlabs".

## Perbaikan

- Inisialisasi AES/GCM ENCRYPT tanpa `GCMParameterSpec`; AndroidKeyStore
  menghasilkan IV sendiri lewat `Cipher.getIV()`.
- IV acak tetap digabung dengan ciphertext seperti struktur lama sehingga
  dekripsi yang sudah ada tetap kompatibel; penyimpanan tetap terenkripsi.
- Jika gagal, form tetap terbuka dan menampilkan alasan yang aman (tanpa
  pernah menampilkan API key di error).
- Source ini juga menyertakan modul render MP4 native dari paket v5.0.6
  sebelumnya serta menjaga ID paket, Signing, dan GitHub Releases updater.

## Upload via HP

1. Upload ulang ZIP `KreasiFlow-Android-Update-V5-Source.zip` di root repo
   `alfianzikri63-blip/KreasiFlow` dengan **Replace existing**.
2. Actions -> **Test KreasiFlow APK Build from ZIP**.
3. Jika berhasil, jalankan **Publish Signed KreasiFlow APK from ZIP** dengan
   `version = 5.0.6`, menggunakan empat GitHub signing Secrets yang sama.
4. Instal APK dari GitHub Releases. **Jangan uninstall versi lama**, agar
   proyek lokal tetap tersimpan.
5. Buka API Keys -> isi satu key -> Simpan. Buka ulang Settings, pastikan
   statusnya berubah menjadi `✓ tersimpan`. Ulangi untuk provider lain.

## Batasan

Belum menjalankan build Android/tes pada HP fisik; cek hasil workflow dan
uji aplikasi pada perangkat. Uji otomatis UI yang disertakan menggunakan
browser mock, bukan AndroidKeyStore sesungguhnya. Jangan upload API key.
