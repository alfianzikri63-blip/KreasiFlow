# KreasiFlow Studio v5.0.6 — Render Video MP4

## Yang baru

Tahap **4. Render** kini disambungkan ke renderer native Android, bukan hanya perekaman `canvas` WebView. Tombol `Generate sampai VIDEO MP4` menggabungkan proses OpenRouter (judul/naskah/prompt) → ElevenLabs (suara) → fal.ai (gambar terpilih) → MP4 lokal. Tombol `Render MP4 sekarang` memungkinkan render ulang dari aset yang sudah ada.

- MP4 video H.264 + audio AAC hasil konversi voice-over (MP3/format yang dapat dibaca decoder Android).
- Rasio 9:16 atau 16:9, pilihan 360/540/720, FPS 24/30.
- Efek zoom halus atau slide pelan antar gambar, subtitle berdasarkan perkiraan scene, fade, watermark.
- Hasil tersimpan ke folder `Download/KreasiFlow` menggunakan MediaStore, dan dapat dibuka melalui tombol `Buka hasil MP4`.
- Jika sebuah scene tidak memiliki gambar, renderer menampilkan kartu judul dengan latar gradien, bukan mengarang visual.
- Progres render dilaporkan di tab Render; render dilakukan di thread kerja aplikasi.
- API key OpenRouter, fal.ai, ElevenLabs tetap disimpan oleh ProviderSecrets dan tidak dikirim ke renderer atau ke repository.
- Package ID `id.kreasiflow.studio`, penandatanganan, updater GitHub Releases dan workflow ZIP tidak diubah.

## Batasan penting

**Video yang dihasilkan adalah video dari gambar diam dengan pergerakan kamera/zoom, bukan video animasi AI hasil model text-to-video.** Aplikasi ini tidak mengendalikan layanan Google Flow melalui Chrome. Musik latar pada versi ini tidak tercampur ke MP4 native (fitur audio yang masuk adalah narasi). Subtitle diselaraskan menurut pembagian waktu scene, bukan hasil pengenalan ucapan atau timestamp setiap kata. Batas render native 10 menit. Untuk menghemat baterai, coba 360p atau 540p terlebih dulu dan jangan tutup aplikasi selama proses.

Menambahkan 10 gambar via fal.ai bisa dikenakan biaya; pengguna harus memilih jumlahnya secara sadar. Default tetap 0 gambar (mode hemat) sehingga yang dihasilkan adalah video dari kartu teks jika tak ada gambar yang sudah dibuat atau di-upload.

## Status dan pengujian

- JavaScript parser (Node.js): lolos.
- Pengujian UI otomatis (Playwright, respons API simulasi): 6 permintaan AI, transfer tiga aset (satu audio dan dua gambar), pemanggilan renderer native, callback progres dan tautan membuka MP4: lolos.
- Renderer native Android H.264/AAC: **belum dikompilasi dan belum diuji langsung di Android**. Keberhasilan workflow GitHub dan pengujian on-device **tetap diperlukan**.
- Pengujian layanan AI sungguhan tidak dilakukan; memakai API key asli dan saldo provider milik pemilik aplikasi.

## Pembaruan lewat GitHub Releases

1. Ganti satu file di root repository dengan arsip source versi ini: `KreasiFlow-Android-Update-V5-Source.zip` (nama file tetap sama).
2. Jalankan workflow `Test KreasiFlow APK Build from ZIP`.
3. Jika tes berhasil, jalankan workflow `Publish Signed KreasiFlow APK from ZIP` dengan versi `5.0.6`.
4. **Gunakan empat GitHub Secrets signing yang SAMA** seperti versi 5.0.x sebelumnya; jangan unggah kunci ke git dan jangan ganti `applicationId`.
5. Instal hasil `KreasiFlow-Studio.apk` dari Release `v5.0.6` di atas versi sebelumnya (Android meminta izin).
6. Uji `Render MP4 sekarang` dari dua atau tiga gambar dan narasi pendek, lalu pastikan hasil ada di Download/KreasiFlow dan ada audionya.

Jika workflow gagal, buka langkah `Build signed release APK` atau `Build debug` dan kirim bagian error (tanpa API key atau password). Jika APK berhasil dibuka tetapi render gagal, kirim pesan kesalahan yang muncul di tab Render. Untuk mendapatkan stacktrace, ambil logcat dengan filter `KreasiFlowRender` dari perangkat.
