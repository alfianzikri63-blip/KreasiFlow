# KreasiFlow v5.0.24 — StoryLab AI native tersambung

## Perbaikan
- Tombol **Cari dengan AI** dan **Tulis dengan AI** di StoryLab sekarang menggunakan Gemini API Key atau OpenRouter API Key yang tersimpan di aplikasi KreasiFlow Android, tanpa memerlukan backend untuk dua fungsi ini.
- Utamakan Gemini; bila Gemini tidak tersedia dan OpenRouter tersedia, gunakan OpenRouter.
- Kunci API tetap disimpan di Android Keystore / ProviderSecrets, tidak diekspor ke halaman, proyek JSON atau GitHub.
- Callback native Android sekarang menerima hasil AI saat halaman `storylab/index.html` aktif (sebelumnya hasil hanya diteruskan saat halaman KreasiFlow utama aktif).
- Pesan diagnostik memandu ke menu **🔑 API Keys** jika belum disetel.
- Pengguna masih boleh memakai server sendiri melalui **Alamat server aplikasi** di pengaturan StoryLab; prioritas server jika URL diisi.
- Video HeyGen tetap memerlukan backend/layanan video sendiri. Perubahan ini memperbaiki AI judul dan narasi, bukan otomatisasi produksi MP4.
- Fitur lain, skema penyimpanan, updater, signing dan fitur lama KreasiFlow dipertahankan.

## Cara pakai
1. Jika memasang APK debug, ingat paket `.videotest` menyimpan kunci API **terpisah** dari APK rilis karena applicationIdSuffix. Buka `🏠 KreasiFlow` → `🔑 API Keys` → simpan Gemini atau OpenRouter pada APK debug.
2. Buka `📚 StoryLab`, pastikan **Alamat server aplikasi** di halaman Pengaturan dikosongkan untuk memakai native AI.
3. Ketuk `✨ Cari dengan AI`, pilih judul, lalu `✨ Tulis dengan AI`.
4. Bila provider mengembalikan HTTP error, uji kunci/model/kuota di halaman KreasiFlow utama.

## Update GitHub tanpa ekstrak
Upload file ZIP lengkap bernama persis `KreasiFlow-Android-Update-V5-Source.zip` menggantikan ZIP pada root repo `alfianzikri63-blip/KreasiFlow` dan jalankan workflow existing `Test KreasiFlow APK Build from ZIP`.

Catatan: Tidak ada build Android yang sukses di lingkungan pembuatan ini; pemeriksaan kode dan sintaks JavaScript dilakukan secara statis.
