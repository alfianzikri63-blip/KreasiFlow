# KreasiFlow v5.0.25 — StoryLab → Google Flow Only

## Fitur
- StoryLab kini hanya memiliki opsi **Google Flow** untuk video AI, tidak ada HeyGen/PixVerse/API key video.
- Tab Buat Video: pilih 1 dari 5 scene, mode Ingredients (dua referensi karakter), Frames to Video, atau Text-to-Video.
- Per scene dibuat 1 prompt lengkap dengan konteks dan konsistensi karakter (ASAQ 70 cm/topi beruang, ZAYN 89 cm/rambut cokelat).
- Tombol **Salin Prompt & Buka Flow** memakai bridge Android `launchFlowWithPrompt`: menyalin ke clipboard dan membuka Google Flow di browser Chrome untuk login Google, tanpa otomasi browser.
- Tombol **Simpan gambar ASAQ / ZAYN** memakai file referensi bawaan serta NativeBridge.beginSave/appendSave/finishSave, menyimpan ke Download/KreasiFlow.
- Prompt dan storyboard dapat disalin/diekspor sebagai teks.
- AI judul/narasi tetap bisa memakai Gemini/OpenRouter di KreasiFlow; tidak ada penambahan API key video.
- Seluruh fitur lama KreasiFlow termasuk backup, AI Studio VO dan Google Flow tetap ada.

## Cara pakai
1. Buka StoryLab, cari judul dan buat narasi/storyboard (lokal atau AI).
2. Di tab Buat Video, simpan foto referensi ASAQ dan ZAYN.
3. Pilih scene dan mode **Ingredients / Referensi** untuk kontinuitas; sentuh **Salin Prompt & Buka Flow**.
4. Login akun Google di Flow/Chrome, upload referensi, paste prompt, Generate menurut kuota dan fitur yang tersedia.
5. Download klip jika selesai; ulangi untuk scene lain dan gabungkan di editor.

## Batasan penting
Google Flow adalah layanan eksternal. APK tidak memiliki izin mengoperasikan tombol Generate, mengakses data akun, mengambil hasil otomatis, atau menghindari kredit/rate-limit; tidak ada API key Flow. Kredit gratis harian dan model yang tersedia bergantung kebijakan Google. Tidak ada garansi 1 video utuh per hari. Pembuat cerita AI Gemini/OpenRouter menggunakan layanan terpisah.

## ZIP dalam ZIP
Nama ZIP luar unik per versi. Di dalamnya hanya ada `KreasiFlow-Android-Update-V5-Source.zip` untuk upload menggantikan nama yang sama di root GitHub repo serta panduan.
Workflow lama `Test KreasiFlow APK Build from ZIP` menerima format folder internal `KreasiFlow-Studio-Android-Updater-V5`.
