# V6.0.2
- Clear pending downloads whose release version is not newer than installed version; cancel obsolete update notification.
- Shared script prompt adds factual safeguards and optional user-provided source excerpts. No live source retrieval or independent fact verification.
- Android build and device behavior not tested here.
