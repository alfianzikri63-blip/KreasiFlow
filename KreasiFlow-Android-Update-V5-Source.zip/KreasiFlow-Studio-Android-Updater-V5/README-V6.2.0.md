V6.2.0: dashboard proyek aktif, navigasi bawah, akses cepat, tema Dark/AMOLED. 332 tes Node lulus setelah ekspektasi versi dan label navigasi diperbarui. Browser diblokir lingkungan; APK belum diuji.
