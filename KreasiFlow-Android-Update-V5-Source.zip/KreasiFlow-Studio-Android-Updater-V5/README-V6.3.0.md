V6.3.0 Social Publisher (manual handoff)

Render MP4, buka tab Render, pilih Social Publisher dan platform. Konfirmasi video terakhir. Caption disalin dan video dibagikan melalui Android ACTION_SEND. Aplikasi tujuan dapat mengabaikan caption atau tidak menerima video; chooser menjadi fallback. Posting akhir dilakukan pengguna. Tidak ada OAuth, API upload, penjadwalan atau status publikasi. Uji Android diperlukan.
