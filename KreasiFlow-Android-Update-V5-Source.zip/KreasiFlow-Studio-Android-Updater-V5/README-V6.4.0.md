# V6.4.0 Aurora Edition
Aurora default theme with previous Dark and AMOLED options, new launcher vector, dashboard gradient ring and publisher cards. Existing production handlers and native sharing retained. Direct publishing, OAuth and scheduling are not implemented. Version code 6004000. 332 existing automated tests passed with version expectations updated; APK and device UI not tested.
