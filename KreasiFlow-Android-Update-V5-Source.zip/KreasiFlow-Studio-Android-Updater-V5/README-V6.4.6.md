V6.4.6: fixed timeline 4/6/8 seconds, strict VO duration and transcript validation, no automatic VO generation or padding. Auto mode retained. Android build not tested.
