V6.4.7: Manual VO per scene, automatic silence padding; original transcript required. No TTS automation. Android build untested.
