V6.4.8: project master reference preview and text character roster. Attach original image manually in Flow. Existing gallery SVG unchanged. Android build not tested.
