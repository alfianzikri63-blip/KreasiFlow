V6.4.9: Individual character photo preview and manual voice direction. References must be attached manually in Flow; no automatic voice cloning or cross-episode lock. Existing gallery unchanged.
