V6.5.0 preview: continuation copies character profiles, visual settings and recent script context into a new project. Native runtime not tested. Gallery and automatic dialogue remain pending.
