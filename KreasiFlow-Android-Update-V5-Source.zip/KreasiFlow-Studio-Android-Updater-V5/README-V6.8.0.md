# KreasiFlow V6.8.0

Paket ini berisi source Android kumulatif dari KF670. Struktur direktori, ID aplikasi `id.kreasiflow.studio`, konfigurasi release signing, dan GitHub Actions dipertahankan. Versi default adalah `6.8.0` dengan versionCode `6008000`.

## Alur utama

- **Short Studio** menyediakan alur judul, naskah, audio, storyboard, dan render video pendek.
- **Story Studio** menyediakan Standalone Story dan Series Story. Pilih karakter utama untuk mengarahkan judul dan naskah ke sudut pandang orang pertama. Series Story menampilkan episode, part, cover, dan riwayat.
- Galeri memuat 20 ilustrasi orisinal hasil generasi gambar. File WebP disertakan dalam aset APK. Galeri karakter dan lokasi menyimpan contoh isian dan gambar acuan per proyek.
- Template konsistensi visual menggunakan gaya, karakter, dan acuan proyek. Cinematic Director aktif untuk proyek baru dan memberikan arahan kamera tiap scene. Prompt yang diedit manual tetap disimpan. Menu khusus Google Flow via Chrome dihapus. Prompt dan impor MP4 tersedia di tab Scene.
- Batas storyboard tersedia dalam 4, 6, atau 8 detik. Sebelum VO diunggah, durasi memakai estimasi proyek. Setelah diunggah, jumlah scene memakai durasi VO. Proyek lama dengan pilihan durasi di luar preset baru dapat menampilkan nilai lamanya selama masih dalam batas 8 detik.
- Untuk percakapan, isi dan terapkan draf dialog. Setiap karakter punya pilihan intonasi, tombol salin teks, dan kolom audio. Unggah SRT/VTT atau gunakan transkripsi AI. Penggabungan mencocokkan transkrip dengan dialog, memberi jeda sampai slot berikutnya, dan menolak dialog yang melebihi slot.

## Cakupan pengujian

- Lihat `TEST-RESULTS-V6.8.0.txt` untuk hasil aktual.
- Pengujian audio lokal memakai WAV dan SRT. Alur teks AI, transkripsi AI langsung, ElevenLabs, Google Flow, dan render native belum diuji dengan layanan atau perangkat nyata.
- Intonasi menggunakan arahan teks yang disalin ke model suara. Audio dibuat lewat layanan TTS atau rekaman sendiri. Durasi klip eksternal mengikuti model di Flow.
- Build debug lokal tidak berjalan karena Gradle dan Android SDK tidak tersedia. Paket source ini tidak menyertakan APK bertanda tangan. Workflow release tetap menggunakan sertifikat yang tersimpan di GitHub Secrets.
