# KreasiFlow V6.0.0 — preview tahap 1
Basis: ZIP V5.1.28. Application ID, signing, native renderer dan provider lama dipertahankan.
- Ringkasan produksi: checklist topik, naskah, VO, storyboard, media scene; bukan validasi render.
- Status kegagalan simpan draft lokal ditampilkan. Saat startup, draft lebih baru untuk ID yang sama memulihkan field teks saja (judul, pilihan judul, naskah, narasi), bukan aset atau timeline.
- CI menjalankan tes Node sebelum build debug/release. Ekspektasi versi pada tes lama diperbarui ke 6.0.0; tes fungsi lama dipertahankan.
- 320 tes Node lulus. Belum diuji pada Android/WebView, API live, migrasi perangkat, atau build APK.

## Build
Gunakan branch terpisah. Jalankan workflow Test Build Debug APK. Uji proyek lama, simpan/keluar/buka ulang, checklist, AI, impor MP4, VO, subtitle, loop dan render. Debug memakai application ID berbeda. Jangan hapus instalasi lama. Setelah validasi dan backup, gunakan Publish Signed KreasiFlow APK dengan versi 6.0.0 dan signing key lama. Jangan publikasi preview ke pengguna produksi sebelum uji perangkat.

## Berikutnya
Smart AI routing/retry, pengukuran biaya, timeline pro, loop, benchmark renderer, audit keamanan native dan UX menyeluruh belum diimplementasikan pada preview ini.
