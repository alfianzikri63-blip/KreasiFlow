# KreasiFlow v5.0.26 – Opsi FreeLLMAPI

Menambah opsi **FreeLLMAPI** pada pengaturan **AI Judul & Naskah** tanpa menghapus Gemini dan OpenRouter. StoryLab ASAQ/ZAYN mengikuti provider yang dipilih di KreasiFlow, termasuk FreeLLMAPI. Generator prompt gambar/video memakai provider teks aktif; Google Flow tetap handoff manual untuk video.

## Menyiapkan
1. Jalankan FreeLLMAPI dari https://freellmapi.co dan tambahkan API key provider gratis Anda ke dashboard gateway. FreeLLMAPI merupakan self-hosted router, **bukan** API publik tanpa konfigurasi.
2. Agar Android dapat terhubung, ekspos gateway Anda melalui domain **HTTPS** dengan endpoint `/v1` (contoh `https://router.contoh.com/v1`). `localhost` pada HP bukan alamat komputer/server Anda. Jangan mengekspos gateway tanpa keamanan.
3. Dari KreasiFlow buka **Pengaturan AI**: masukkan **Unified API Key** FreeLLMAPI, alamat HTTPS, model `auto` atau model dari katalog server; pilih FreeLLMAPI pada **AI Judul & Naskah**, lalu **Simpan Pengaturan AI**.
4. Ketuk **Uji koneksi FreeLLMAPI** untuk cek endpoint `/v1/models` tanpa membuat konten. Setelah sukses, coba generate 1 judul, naskah, atau StoryLab.

## Keamanan dan ketentuan
- Key disimpan melalui Android Keystore (enkripsi AES-GCM), tidak diekspos dalam HTML, log, GitHub, atau ZIP. Key turut disertakan dalam backup Supabase **terenkripsi oleh passphrase** (hanya setelah backup dijalankan).
- URL dan model disimpan sebagai pengaturan proyek lokal (bukan key); mengubah proyek lama dapat mengubah pilihan provider.
- Android menolak URL `http://`, URL ber-parameter, dan host lokal. Gunakan HTTPS dari server dengan TLS valid.
- FreeLLMAPI mengikuti kuota dan kebijakan gratis **setiap provider upstream**. Tidak menjamin permintaan selalu gratis atau tak terbatas; periksa ketentuan upstream.
- FreeLLMAPI di integrasi ini untuk *teks* saja, **bukan** menghasilkan MP4 secara langsung.
- ZIP luar berisi ZIP source dengan nama **KreasiFlow-Android-Update-V5-Source.zip** yang harus diunggah ke root repo lama `alfianzikri63-blip/KreasiFlow`. Cukup keluarkan ZIP dalam dari paket ZIP luar (tidak perlu ekstrak source Android dan tidak perlu rename).
- Pertahankan aplikasi ID, sertifikat tanda tangan dan backup sebelum memasang update agar penyimpanan key lama tetap aman.
