# KreasiFlow v5.0.30 — Satu Master Prompt Google Flow dengan narasi

- Memuat semua scene beserta narasi asli berbahasa Indonesia, prompt gambar tidak kosong, arahan gerakan dan audio per scene.
- Dua mode audio: narasi tunggal Google AI Studio (default, tidak meminta Flow membacakan ulang) atau narasi per klip di Flow (eksperimental, suara tidak selalu stabil).
- Tombol **Salin 1 MASTER PROMPT + narasi**, **Salin & buka Flow**, **Download master TXT** tersedia di tab Scene & Video, baik pada mode biasa maupun Text-to-Video dari Naskah.
- Pembagian scene baru diarahkan ke batas kalimat/anak kalimat agar narasi tidak terputus tepat setelah kata sambung. Sumber teks asli tidak ditambah/dihapus; potongan yang terlalu panjang mungkin memerlukan penyesuaian durasi klip.
- Pengiriman 1 master prompt ke Google Flow Agent tidak menjamin batch 8 klip otomatis. Jika Flow Agent tidak mendukungnya di HP/akun, jalankan prompt per scene.
- Tidak mengubah key, backend, rendering Android, paket ID, atau mengaktifkan StoryLab ASAQ & ZAYN.
- Build APK belum dijalankan pada device.
