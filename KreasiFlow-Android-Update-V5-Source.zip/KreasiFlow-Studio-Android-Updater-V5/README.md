# KreasiFlow v5.0.22 — Mode ASAQ & ZAYN

Versi ini menambahkan prompt gambar (Text-to-Image) dan gerak (Image-to-Video) per scene, dengan Character Lock ASAQ ±70 cm dan ZAYN ±89 cm. **Lihat `PANDUAN-v5.0.22-ASAQ-ZAYN.md`** untuk panduan dan batasan.

---

# KreasiFlow Studio v5.0.18 — Mode Animasi 3D Edukasi (opsional)

Source Android ini melanjutkan v5.0.17, **bukan aplikasi baru**. Mode lama tetap ada.
Untuk panduan spesifik, baca `PANDUAN-v5.0.18-EDU3D.md`.

**Perubahan**: Character/Style/Object/Setting Bible, opsi 3 foto Ingredients tersimpan lokal,
10 scene contoh animasi cara kerja AC, prompt Google Flow per scene, ekspor SRT
per kata dengan waktu perkiraan, dan renderer cepat MP4 yang mencoba menjaga
audio AAC asli dari klip Flow. Subtitle tidak dibakar ke MP4 otomatis; sinkronkan
ke suara asli dalam editor video. Tanpa otomasi login/Generate/download Google Flow.

**Cara uji**: Ganti ZIP root `KreasiFlow-Android-Update-V5-Source.zip` di repo yang
sudah ada, jalankan `Test KreasiFlow APK Build from ZIP` dan unduh APK debug.
Jangan mempublikasikan signed release sebelum lolos uji di perangkat asli.
Kunci signing/APIs tidak disertakan.

---

# KreasiFlow Studio v5.0.9 — Cloudflare Images (Workers AI)

## Migrasi provider gambar

- **OpenRouter**: judul, naskah, storyboard.
- **ElevenLabs**: voice-over MP3.
- **Cloudflare Workers AI**: gambar FLUX.1 Schnell melalui endpoint REST resmi, tanpa fal.ai.
- **Render**: gambar scene + suara → MP4 native Android.
- **Update**: tetap dari `alfianzikri63-blip/KreasiFlow` GitHub Releases.

### Menyiapkan Cloudflare (gratis dengan batas harian)

1. Daftar/login https://dash.cloudflare.com/
2. Buka **AI > Workers AI > Use REST API**.
3. Salin **Account ID** dan buat **Workers AI API Token** melalui tombol resmi.
4. KreasiFlow → ⚙ → simpan dua kolom **Cloudflare API Token** dan **Cloudflare Account ID**.
5. Di Scene & Gambar, coba satu scene terlebih dahulu.

Alokasi Workers Free saat dokumen dibuat: 10.000 neurons/hari. Ini bukan janji jumlah gambar tertentu. Jatah bisa habis dan model mungkin mengalami perubahan. FLUX.1 Schnell Cloudflare tidak memiliki parameter rasio dalam API contoh resmi, sehingga hasil gambar bisa dipotong untuk video 9:16 saat render.

### Deploy tanpa menimpa data

ZIP ini mempertahankan struktur folder `KreasiFlow-Studio-Android-Updater-V5` dan nama ZIP `KreasiFlow-Android-Update-V5-Source.zip`. Upload ZIP tersebut ke root GitHub menggantikan yang lama; workflow `Test KreasiFlow APK Build from ZIP` masih kompatibel. Debug memakai applicationId `id.kreasiflow.studio.debug`, dapat dipasang berdampingan dengan APK release, serta tidak memicu auto-update. Jangan buat release sebelum test selesai dan uji pada HP. Setelah itu publish versi **5.0.9** dengan signing keystore tetap. Kunci Cloudflare disimpan terenkripsi di HP, jangan di repo atau GitHub Secrets.

## Catatan keamanan

API token BYOK dikirim langsung dari native Android ke endpoint HTTPS Cloudflare, bukan dibagikan ke kode web. API token dapat tetap diekstrak dari perangkat yang sudah dikompromikan. Untuk distribusi publik berskala besar disarankan backend terautentikasi dengan pembatasan penggunaan.

# KreasiFlow Studio v5.0.5 — Multi-Provider AI

**Source APK Android untuk mengganti ZIP di GitHub, bukan APK jadi.** Proyek melanjutkan v5.0.4, mempertahankan `applicationId: id.kreasiflow.studio`, GitHub Release auto-updater, Chrome eksternal dan file/proyek lama.

## AI provider

| Tahap | Provider | Endpoint yang digunakan |
|---|---|---|
| Judul, naskah, storyboard prompt | OpenRouter | `POST https://openrouter.ai/api/v1/chat/completions` (`openrouter/free` secara default) |
| Gambar tiap scene | fal.ai | `POST https://fal.run/fal-ai/flux/schnell` (FLUX.1 Schnell) |
| Voice-over | ElevenLabs | `POST https://api.elevenlabs.io/v1/text-to-speech/{voice_id}` (`eleven_multilingual_v2`, MP3) |

### Persiapan API key

Setelah APK v5.0.5 terpasang buka **⚙ Pengaturan Multi-Provider** dan isi key sendiri:

1. OpenRouter: https://openrouter.ai/settings/keys — model default `openrouter/free`, bisa diganti dengan model lain yang didukung OpenRouter.
2. fal.ai: https://fal.ai/dashboard/keys — memerlukan saldo/kuota. Gambar default 0 agar tidak langsung mengenakan biaya.
3. ElevenLabs: https://elevenlabs.io/app/settings/api-keys — masukkan key dan **Voice ID** (bisa diperoleh dari akun ElevenLabs). Default contoh `JBFqnCBsd6RMkjVDRZzb` berasal dari contoh dokumentasi resmi, tetapi suara tersebut belum tentu tersedia pada akun.

**API key disimpan terenkripsi dalam Android Keystore dan preferensi privat**, tidak dimasukkan ke JavaScript LocalStorage atau file proyek. Jangan menyisipkan key ke kode atau Secrets GitHub. Untuk aplikasi yang didistribusikan kepada banyak pengguna, lebih aman gunakan backend/proxy autentikasi dan batasi kuota setiap pengguna. Kunci lokal masih bisa bocor jika perangkat diretas.

## Jalankan build GitHub milikmu

Repository target: https://github.com/alfianzikri63-blip/KreasiFlow

- Upload dan **replace** file root `KreasiFlow-Android-Update-V5-Source.zip` dengan ZIP yang disediakan. Struktur ZIP berisi folder `KreasiFlow-Studio-Android-Updater-V5/` (persis seperti yang diharapkan workflow lama).
- Buka Actions → **Test KreasiFlow APK Build from ZIP**. Setelah sukses, jalankan **Publish Signed KreasiFlow APK from ZIP** dengan input `version: 5.0.5`.
- Gunakan **empat signing secrets lama** tanpa mengubah nilainya. Jangan simpan keystore atau password di ZIP / repo.
- Dari GitHub Releases unduh `KreasiFlow-Studio.apk`. Instal di atas APK lama (tanpa uninstall). Android akan memeriksa package ID dan sertifikat signing.
- Setelah install: cek ⚙, isi API keys, coba judul/naskah dulu, TTS satu kali, lalu **1 gambar** untuk memastikan kredit fal.ai tidak terbuang.

Workflow rilis yang **sudah ada** di `.github/workflows/release-apk-from-zip.yml` tidak perlu diedit jika masih sesuai alur v5.x sebelumnya. File APK dan `SHA256SUMS.txt` tetap diterbitkan melalui GitHub Releases agar update otomatis terus berfungsi.

### Batasan dan keamanan

- Belum ada build APK di mesin pembuat paket ini (Android SDK tidak tersedia). JavaScript dan end-to-end alur UI diuji dengan mock respons. Provider API sungguhan belum dipanggil karena tidak ada API key pengguna.
- Model gratis OpenRouter memiliki batas request; fal.ai bisa berbayar bahkan bila model teks gratis. ElevenLabs suara juga mengikuti kuota.
- Gambar dibuat satu per satu. API fal.ai dapat gagal jika kredit tidak cukup, tetapi judul, naskah dan gambar sebelumnya tetap tersimpan selama sesi.
- Proyek hanya menyimpan naskah dan prompt. Audio dan gambar Blob tidak disimpan dalam riwayat/JSON; unduh hasil ketika selesai sebelum tutup aplikasi.
- Rendering MP4 bergantung MediaRecorder Android WebView/codec yang tersedia; saat tidak didukung, hasil bisa berupa WebM.
- Google AI Studio, Google Flow dan Gemini bisa dibuka melalui Chrome; tidak ada otomatisasi input website Google, karena AI utama diakses lewat API resmi ketiga provider.
- `ElevenLabs` menggunakan MP3. Durasi audio diperoleh dari metadata jika tersedia.


## Perbaikan 5.0.7 — OpenRouter 401

- `OpenRouter key tersimpan` menandakan adanya key di Keystore, bukan autentikasi sudah berhasil.
- Di ⚙️ Pengaturan AI, simpan API key OpenRouter, lalu tekan **Uji koneksi OpenRouter** (GET `/api/v1/key`, tidak membuat konten/token AI).
- Tempel hanya kunci `sk-or-...` dari OpenRouter. Jika menempel `Bearer sk-or-...`, aplikasi membersihkan prefix sebelum menyimpan.
- Kredensial tetap dienkripsi Android Keystore, tidak dicetak/log atau dikirim ke halaman web.
- Jika uji koneksi 401, buat key baru melalui dashboard OpenRouter dan isi ulang; jika uji sukses namun generate gagal, periksa model OpenRouter dan kuota.

Source ini belum dibuild menjadi APK atau diuji menggunakan key pengguna. Pertahankan keystore signing yang sama untuk rilis v5.0.7.

## v5.0.8 — Voice-over hanya membaca dialog narator

- Fungsi `extractNarration()` sekarang mengenali kalimat `Voice Over: "..."` dan mengambil **hanya** kalimat di dalamnya.
- Header `[HOOK]`, `[PEMBUKA]`, `[PUNCAK]`, `[END SCREEN / CTA]`, arahan `(Musik: ...)`, `(Efek suara: ...)`, serta catatan `[PERLU VERIFIKASI: ...]` tidak dikirim ke ElevenLabs.
- Ketika naskah tidak berisi label Voice Over, parser memakai mode fallback yang menghapus instruksi produksi standar.
- Di tab Upload → Naskah & narasi ada tombol **Bersihkan teks VO** untuk menampilkan dan mengedit hasil final sebelum menekan Generate Suara AI.
- Perlindungan juga berlaku untuk Voice-over otomatis (tombol Generate sampai VIDEO MP4) dan pratinjau suara browser.
- Audio MP3 lama tidak diubah; untuk memperbaiki audio lama perlu **generate ulang** dengan teks bersih, yang dapat memakai kredit ElevenLabs.
- GitHub Releases updater, `applicationId`, keystore signing, OpenRouter/fal.ai/ElevenLabs, dan render MP4 native tidak diubah.

Pengujian pada lingkungan pembuat: sintaks JS lolos, parser lewat uji contoh stage directions dan `Voice Over:`. Build Android serta panggilan ElevenLabs nyata belum diuji.


## Debug v5.0.10 — HTTP 409 / 8007 Cloudflare
- Tambahan tombol **Tes 1 gambar sederhana** (satu inference, memakai neurons). Tes tidak mengubah scene.
- Error internal 409/8007 diberi penjelasan khusus dan referensi request ketika ada; tidak dianggap otomatis sebagai masalah token/billing.
- Tidak ada retry otomatis untuk menghindari pemborosan kuota. OpenRouter, ElevenLabs, renderer MP4, dan GitHub auto-update tidak diubah.
- Build dan Cloudflare API sungguhan belum diuji dalam paket ini; gunakan GitHub Test Build from ZIP lalu tes di HP.


## Hotfix Gemini HTTP 404 (v5.0.12)

- Gemini teks bawaan sekarang `gemini-3.8-flash`, bukan `gemini-2.5-flash` yang menolak sebagian pengguna dengan HTTP 404.
- Saat model utama mengembalikan HTTP 404, aplikasi mencoba `gemini-3.5-flash-lite` **sekali**. Tidak fallback pada 401/403/429 atau server error.
- Label progres judul/naskah/storyboard kini mengikuti provider yang sebenarnya (Gemini atau OpenRouter).
- API key tetap hanya di penyimpanan terenkripsi Android.
- Build dan panggilan API sungguhan masih perlu diuji pada perangkat Android.

## v5.0.42 — Render native tetap berjalan di latar (perlu uji APK)
Layanan render MP4 `RenderForegroundService` menggantikan render di thread `MainActivity`. Rendering MP4 dan notifikasi progres bisa tetap berjalan saat layar dikunci atau aplikasi diminimalkan selama Android mengizinkan layanannya. Lihat `PANDUAN-v5.0.42-RENDER-LATAR-NOTIFIKASI.md` untuk langkah uji, izin notifikasi, dan batasan sistem. Storyboard AI/WebView belum dipindahkan ke native background queue.
