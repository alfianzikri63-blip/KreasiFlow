# KreasiFlow Studio V5 – Android APK dengan Pembaruan GitHub Releases

Source Android (Java + Android WebView) dua-panel. **Ini adalah source; file APK final baru tersedia setelah GitHub Actions berhasil membangun rilis bertanda tangan.**

## Cara sistem update bekerja

1. Saat app dibuka, APK membaca `https://api.github.com/repos/OWNER/REPO/releases/latest`.
2. Saat app di background, Android WorkManager memeriksa versi tiap **sekitar 6 jam** (tidak dijamin persis; Android bisa menunda). Release `draft` dan `prerelease` tidak diambil.
3. Versi terbaru dibandingkan secara numerik (`v5.0.1` > `v5.0.0`). Notifikasi muncul **satu kali per tag versi** jika izin notifikasi diberikan; juga ada dialog ketika app dibuka dan tombol **⬆** untuk cek manual.
4. Pengguna bisa melihat catatan rilis, unduh APK dari asset bernama **KreasiFlow-Studio.apk**, verifikasi SHA-256 (metadata `digest` GitHub), dan pilih instalasi. Sistem Android akan menanyakan izin instal APK yang tidak berasal dari toko aplikasi.
5. App tidak memasang APK diam-diam; Android akan memverifikasi **package name** dan **sertifikat penandatanganan**.

Penting: setiap APK versi 5.x harus berasal dari **repository GitHub publik yang sama** dan memakai **kunci tanda tangan release yang sama**. Jangan pernah memakai APK debug sebagai rilis update.

## Build APK dari source proyek penuh

Proyek di sini dapat dibuka di Android Studio, atau dikirim langsung ke repository bersama `.github/workflows/publish-release-apk.yml`. Workflow publikasi menggunakan `workflow_dispatch` dan menerima `version`, contoh `5.0.0`, lalu membuat rilis `v5.0.0`. Perlu GitHub Actions aktif dan empat **repository secrets** untuk signing.

## Build GitHub dari HP, hanya upload ZIP source

Dalam `KreasiFlow-GitHub-Update-Kit` tersedia 2 file utama:

- `KreasiFlow-Android-Update-V5-Source.zip` — source proyek lengkap, langsung upload ke **root** repo GitHub.
- `.github/workflows/release-apk-from-zip.yml` — workflow yang mengekstrak ZIP, membuat APK release signed, dan menerbitkannya ke **GitHub Releases**.

Di GitHub, buat repo publik baru misalnya `kreasiflow-studio-android`. Upload ZIP source. Kemudian di `Add file -> Create new file` buat path `.github/workflows/release-apk-from-zip.yml` dan isi dari workflow yang tersedia.

### Pengaturan kunci penandatanganan pertama kali

Sebelum klik *Run workflow*, tambahkan di **Settings → Secrets and variables → Actions → New repository secret**:

- `KREASIFLOW_KEYSTORE_B64`: isi base64 dari file keystore release (`base64 -w 0 signing-keystore.jks`).
- `KREASIFLOW_STORE_PASS`: password keystore.
- `KREASIFLOW_KEY_ALIAS`: alias kunci, misalnya `kreasiflow`.
- `KREASIFLOW_KEY_PASS`: password key (bisa sama dengan password keystore).

**Simpan cadangan file keystore dan passwords di lokasi privat. Jangan upload ke repository, mengirim di chat publik, atau membagikannya.** Jika kehilangan keystore, APK baru tidak bisa menggantikan versi lama tanpa menghapus data aplikasi. Untuk produksi sebaiknya buat keystore sendiri pada perangkat yang dipercaya; paket **PRIVATE Signing Keys** disediakan sebagai unduhan TERPISAH dari source publik. Jangan pernah unggah paket kunci privat ke repository.

### Terbitkan versi pertama dan versi berikutnya

1. Buka repo GitHub → **Actions → Publish Signed KreasiFlow APK → Run workflow**.
2. Isi `version`: versi perdana `5.0.0`; pembaruan berikutnya `5.0.1`, `5.1.0`, dst.
3. Jika build berhasil, GitHub membuat tab **Releases** dan file **KreasiFlow-Studio.apk**. Unduh dan instal APK rilis dari tab Releases.
4. Di versi terpasang, tekan **⬆** untuk cek manual; ketika versi baru ada, aplikasi juga akan memeriksa berkala dan mengirim notifikasi (izin diperlukan).

`versionCode` dihitung stabil: `major*1,000,000 + minor*1,000 + patch`. Tidak boleh turun. Contoh `5.0.0 → 5000000`, `5.0.1 → 5000001`. Asset otomatis diberi nama tetap `KreasiFlow-Studio.apk` agar updater menemukannya.

## Batasan dan keamanan

- Aplikasi GitHub tidak memakai push instan. Notifikasi didasarkan pada **pemeriksaan berkala** dan saat app dibuka; mode penghemat baterai bisa menunda cek.
- Android 13+ meminta izin notifikasi. Android 8+ meminta izin **Install unknown apps** jika memasang APK dari dalam app.
- Hanya release **stabil dan publik** yang terbaca tanpa token GitHub. Repo privat tidak bisa diperiksa tanpa mekanisme autentikasi khusus.
- Pada beberapa browser WebView, Google melarang login menggunakan embedded browser. Gunakan tombol Chrome untuk AI Studio/Flow.
- Versi V5 ini belum diuji dengan emulator/HP nyata di lingkungan pembuat source. Periksa hasil build dan uji manual sebelum distribusi.
- `BuildConfig.GITHUB_OWNER` dan `GITHUB_REPOSITORY` diisi otomatis dari `${{ github.repository }}` saat GitHub Actions. Build lokal tanpa setting repo akan menampilkan pesan konfigurasi untuk cek update.

**Jika V4 lama terpasang dari APK debug atau cert berbeda**, update V5 signed tidak bisa dipasang langsung; simpan/ekspor proyek dulu sebelum uninstall V4. Setelah memakai V5 signed, update 5.0.1 dapat menggantikan 5.0.0 tanpa menghapus data lokal apabila kunci sama.


## Hotfix v5.0.1 – crash saat startup pada Android 14/15/16

- Daftarkan receiver DownloadManager menggunakan flag ekspor eksplisit (kompatibilitas Android 14+).
- Jika receiver / WorkManager / izin notifikasi bermasalah, **panel utama tetap terbuka**.
- Jika WebView gagal inisialisasi, tampilkan layar pemulihan dengan detail error dan tautan Chrome.
- Perbaiki restoreState() bila state WebView kosong.
- Jadikan pemanggilan updater.onResume() nonfatal.

**Penting:** Penyebab crash pada HP belum dapat dipastikan tanpa logcat. Patch ini memperbaiki sumber risiko yang ditemukan melalui audit kode; keberhasilannya perlu dibuktikan dengan build + uji perangkat.

Workflow release dari ZIP tetap digunakan. Rilis dengan input **5.0.1** dan *secrets signing yang SAMA* seperti v5.0.0. Karena v5.0.0 crash saat dibuka, unduh v5.0.1 lewat Chrome/GitHub Releases dan install di atas aplikasi lama, tanpa uninstall.
