# KreasiFlow Studio v5.0.5 — Multi-Provider AI

**Source APK Android untuk mengganti ZIP di GitHub, bukan APK jadi.** Proyek melanjutkan v5.0.4, mempertahankan `applicationId: id.kreasiflow.studio`, GitHub Release auto-updater, Chrome eksternal dan file/proyek lama.

## AI provider

| Tahap | Provider | Endpoint yang digunakan |
|---|---|---|
| Judul, naskah, storyboard prompt | OpenRouter | `POST https://openrouter.ai/api/v1/chat/completions` (`openrouter/free` secara default) |
| Gambar tiap scene | fal.ai | `POST https://fal.run/fal-ai/flux/schnell` (FLUX.1 Schnell) |
| Voice-over | ElevenLabs | `POST https://api.elevenlabs.io/v1/text-to-speech/{voice_id}` (`eleven_multilingual_v2`, MP3) |

### Persiapan API key

Setelah APK v5.0.5 terpasang buka **⚙ Pengaturan Multi-Provider** dan isi key sendiri:

1. OpenRouter: https://openrouter.ai/settings/keys — model default `openrouter/free`, bisa diganti dengan model lain yang didukung OpenRouter.
2. fal.ai: https://fal.ai/dashboard/keys — memerlukan saldo/kuota. Gambar default 0 agar tidak langsung mengenakan biaya.
3. ElevenLabs: https://elevenlabs.io/app/settings/api-keys — masukkan key dan **Voice ID** (bisa diperoleh dari akun ElevenLabs). Default contoh `JBFqnCBsd6RMkjVDRZzb` berasal dari contoh dokumentasi resmi, tetapi suara tersebut belum tentu tersedia pada akun.

**API key disimpan terenkripsi dalam Android Keystore dan preferensi privat**, tidak dimasukkan ke JavaScript LocalStorage atau file proyek. Jangan menyisipkan key ke kode atau Secrets GitHub. Untuk aplikasi yang didistribusikan kepada banyak pengguna, lebih aman gunakan backend/proxy autentikasi dan batasi kuota setiap pengguna. Kunci lokal masih bisa bocor jika perangkat diretas.

## Jalankan build GitHub milikmu

Repository target: https://github.com/alfianzikri63-blip/KreasiFlow

- Upload dan **replace** file root `KreasiFlow-Android-Update-V5-Source.zip` dengan ZIP yang disediakan. Struktur ZIP berisi folder `KreasiFlow-Studio-Android-Updater-V5/` (persis seperti yang diharapkan workflow lama).
- Buka Actions → **Test KreasiFlow APK Build from ZIP**. Setelah sukses, jalankan **Publish Signed KreasiFlow APK from ZIP** dengan input `version: 5.0.5`.
- Gunakan **empat signing secrets lama** tanpa mengubah nilainya. Jangan simpan keystore atau password di ZIP / repo.
- Dari GitHub Releases unduh `KreasiFlow-Studio.apk`. Instal di atas APK lama (tanpa uninstall). Android akan memeriksa package ID dan sertifikat signing.
- Setelah install: cek ⚙, isi API keys, coba judul/naskah dulu, TTS satu kali, lalu **1 gambar** untuk memastikan kredit fal.ai tidak terbuang.

Workflow rilis yang **sudah ada** di `.github/workflows/release-apk-from-zip.yml` tidak perlu diedit jika masih sesuai alur v5.x sebelumnya. File APK dan `SHA256SUMS.txt` tetap diterbitkan melalui GitHub Releases agar update otomatis terus berfungsi.

### Batasan dan keamanan

- Belum ada build APK di mesin pembuat paket ini (Android SDK tidak tersedia). JavaScript dan end-to-end alur UI diuji dengan mock respons. Provider API sungguhan belum dipanggil karena tidak ada API key pengguna.
- Model gratis OpenRouter memiliki batas request; fal.ai bisa berbayar bahkan bila model teks gratis. ElevenLabs suara juga mengikuti kuota.
- Gambar dibuat satu per satu. API fal.ai dapat gagal jika kredit tidak cukup, tetapi judul, naskah dan gambar sebelumnya tetap tersimpan selama sesi.
- Proyek hanya menyimpan naskah dan prompt. Audio dan gambar Blob tidak disimpan dalam riwayat/JSON; unduh hasil ketika selesai sebelum tutup aplikasi.
- Rendering MP4 bergantung MediaRecorder Android WebView/codec yang tersedia; saat tidak didukung, hasil bisa berupa WebM.
- Google AI Studio, Google Flow dan Gemini bisa dibuka melalui Chrome; tidak ada otomatisasi input website Google, karena AI utama diakses lewat API resmi ketiga provider.
- `ElevenLabs` menggunakan MP3. Durasi audio diperoleh dari metadata jika tersedia.


## Perbaikan 5.0.7 — OpenRouter 401

- `OpenRouter key tersimpan` menandakan adanya key di Keystore, bukan autentikasi sudah berhasil.
- Di ⚙️ Pengaturan AI, simpan API key OpenRouter, lalu tekan **Uji koneksi OpenRouter** (GET `/api/v1/key`, tidak membuat konten/token AI).
- Tempel hanya kunci `sk-or-...` dari OpenRouter. Jika menempel `Bearer sk-or-...`, aplikasi membersihkan prefix sebelum menyimpan.
- Kredensial tetap dienkripsi Android Keystore, tidak dicetak/log atau dikirim ke halaman web.
- Jika uji koneksi 401, buat key baru melalui dashboard OpenRouter dan isi ulang; jika uji sukses namun generate gagal, periksa model OpenRouter dan kuota.

Source ini belum dibuild menjadi APK atau diuji menggunakan key pengguna. Pertahankan keystore signing yang sama untuk rilis v5.0.7.
