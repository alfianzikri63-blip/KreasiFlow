# KreasiFlow Studio v5.0.3 — Auto Produksi AI

Android aplikasi satu layar penuh: **judul → naskah → narasi → suara AI → storyboard → gambar scene**, tanpa copy-paste ke website. Semua generasi menggunakan Gemini API milik pengguna melalui request HTTPS dari Android native; tidak menyuntikkan teks ke situs Google Flow.

Untuk mulai: pasang APK v5.0.3, buka ⚙ Pengaturan AI, masukkan Gemini API key milikmu (hanya di memori selama aplikasi hidup), lalu tekan **⚡ Generate semuanya otomatis**. Secara default 2 gambar per proses agar biaya terkendali. Pilih 0 untuk menghindari pemakaian model gambar. TTS menggunakan model `gemini-3.8-flash-tts` dan gambar menggunakan `gemini-3.1-flash-image`.

Buka Google Flow / AI Studio via Chrome tetap disediakan sebagai cadangan, tetapi **tidak dikendalikan otomatis**. Render komposisi video dari gambar dan audio masih menggunakan fitur Render lokal dan memerlukan tindakan pengguna serta dukungan codec WebView.

API key tidak ditanam pada source/APK/GitHub. Android menyampaikan key ke endpoint resmi melalui HTTPS, untuk sesi aktif saja. Model TTS dan gambar mungkin memerlukan billing/kuota dan dapat gagal jika tidak tersedia. Sumber tidak menjalankan background auto-generation. Jangan membagikan key.

Upgrade: unggah ZIP source ini ke root repo `alfianzikri63-blip/KreasiFlow` sebagai `KreasiFlow-Android-Update-V5-Source.zip`; jalankan `Test KreasiFlow APK Build from ZIP`, kemudian workflow rilis bertanda tangan dengan versi **5.0.3** memakai secrets signing yang sama. Tidak perlu menambah izin sensitif atau secrets baru.

**Batasan pengujian**: Kode telah diperiksa secara statis tetapi permintaan langsung ke API dan build APK belum dapat diuji dengan key pengguna pada environment ini. Uji di perangkat nyata diperlukan. Jika API gagal, aplikasi menunjukkan pesan kesalahan dan mempertahankan tahapan yang sudah selesai.
