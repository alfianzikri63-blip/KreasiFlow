(function(root,factory){
 const api=factory();
 if(typeof module==='object'&&module.exports)module.exports=api;
 else root.KFGeneration=api;
})(globalThis,function(){
 'use strict';
 const modes={
  fast:{idea:16,script:38,scene:32,batch:5,storyBatch:12},
  balanced:{idea:22,script:55,scene:46,batch:4,storyBatch:16},
  quality:{idea:30,script:75,scene:58,batch:3,storyBatch:16}
 };
 function classify(error){
  const text=String(error?.message||error);
  if(error?.name==='AbortError'||/\bcancelled\b|dibatalkan/i.test(text))return 'cancelled';
  if(/input proyek berubah|durasi berubah saat/i.test(text))return 'stale';
  if(/\b(401|403)\b|credential|autentikasi|api key.*(tidak|ditolak)/i.test(text))return 'auth';
  if(/\b429\b|rate.limit|kuota habis/i.test(text))return 'rate';
  if(/\b404\b|model.*(tidak tersedia|not found|unavailable|unsupported)/i.test(text))return 'model';
  if(/\b408\b|timeout|batas (baca|tunggu|waktu)|timed out|melewati batas/i.test(text))return 'timeout';
  if(/\b(500|502|503|504)\b|connection (abort|reset|refused)|socket|network|jaringan|unknownhost/i.test(text))return 'network';
  if(/\b(400|402|422)\b|permintaan tidak valid/i.test(text))return 'request';
  return 'response';
 }
 const messages={
  stale:'Input proyek berubah sewaktu AI bekerja. Hasil sebelumnya tetap tersimpan.',
  cancelled:'Permintaan dibatalkan.', auth:'Autentikasi ditolak. Periksa API key dan izin model di Settings.',
  rate:'Provider membatasi permintaan. Tunggu kuota pulih sebelum mencoba lagi.',
  model:'Model tidak tersedia untuk akun ini. Pilih model atau provider lain secara manual.',
  timeout:'Respons melewati batas waktu. Coba lagi dengan model lebih cepat atau naskah lebih pendek.',
  network:'Koneksi ke provider terputus atau server sedang sibuk. Coba lagi.',
  request:'Provider menolak permintaan. Periksa model, konfigurasi dan saldo akun.',
  response:'Respons kosong, terpotong, atau formatnya tidak lengkap. Hasil sebelumnya tetap tersedia.'
 };
 function abortError(){return Object.assign(Error('Permintaan dibatalkan.'),{name:'AbortError'});}
 function wait(ms,signal){
  return new Promise((resolve,reject)=>{
   if(signal?.aborted){reject(abortError());return;}
   function abort(){clearTimeout(timer);reject(abortError());}
   const timer=setTimeout(()=>{signal?.removeEventListener('abort',abort);resolve();},ms);
   signal?.addEventListener('abort',abort,{once:true});
  });
 }
 async function request(send,{signal,deadline,onRetry,retries=2,backoff=wait,clock=Date.now}={}){
  for(let attempt=0;;attempt++){
   if(signal?.aborted)throw abortError();
   const remaining=deadline-clock();
   if(remaining<=0)throw Error('Batas waktu pekerjaan terlampaui');
   try{return await send(remaining);}
   catch(error){
    const code=classify(error),delay=600*(2**attempt);
    if(attempt>=retries||!['timeout','network'].includes(code)||deadline-clock()<delay+2500)throw error;
    onRetry?.(attempt+1,code);
    await backoff(delay,signal);
   }
  }
 }
 async function batch(items,size,parallel,work){
  const groups=[];
  for(let i=0;i<items.length;i+=size)groups.push(items.slice(i,i+size));
  const errors=[];
  let cursor=0;
  await Promise.all(Array.from({length:Math.min(parallel,groups.length)},async()=>{
   for(;;){
    const group=groups[cursor++];
    if(!group)return;
    try{await work(group);}
    catch(error){errors.push(error);if(['auth','rate','model','request','cancelled'].includes(classify(error)))cursor=groups.length;}
   }
  }));
  if(errors.length)throw errors[0];
 }
 return {modes,classify,messages,request,batch};
});
