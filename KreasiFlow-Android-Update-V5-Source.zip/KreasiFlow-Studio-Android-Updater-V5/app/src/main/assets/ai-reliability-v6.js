(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.KFAIReliability=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
 const providers=['gemini','groq','openrouter','cloudflare','nvidia'];
 function recoverable(error){const s=String(error?.message||error);return !/cancel|batal|safety|blocked|policy|moderation|timeout|batas waktu|melewati batas|belum merespons/i.test(s)&&/\b(429|500|502|503|504)\b|overload|rate.limit|unavailable|respons teks kosong|tidak ada teks|respons tanpa teks/i.test(s);}
 async function run(primary,ready,request,onFallback){try{return await request(primary);}catch(error){if(!recoverable(error))throw error;const next=providers.find(p=>p!==primary&&ready(p));if(!next)throw error;if(onFallback)onFallback(next);return await request(next);}}
 return {recoverable,run};
});
