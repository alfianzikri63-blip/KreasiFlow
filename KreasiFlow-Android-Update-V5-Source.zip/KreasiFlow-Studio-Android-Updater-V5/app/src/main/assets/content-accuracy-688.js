(function(root,factory){
 const api=factory();
 if(typeof module==='object'&&module.exports)module.exports=api;
 root.KFContentAccuracy=api;
})(typeof window!=='undefined'?window:globalThis,function(){
'use strict';
const clean=value=>typeof value==='string'?value.replace(/\s+/gu,' ').trim():'';
const norm=value=>clean(value).normalize('NFKD').replace(/\p{M}/gu,'').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();
const words=value=>norm(value).split(' ').filter(Boolean);
const stop=new Set('apa bagaimana mengapa kenapa cara kerja bekerja terbentuk terjadi di ke dari pada untuk tentang yang dan atau dengan dalam ini itu dunia unik menarik fakta sejarah terbaik teratas tercepat tertinggi termegah terbesar masa depan terbaru paling top of the in how a an and is are works work world formed'.split(' '));
const aliases={
 black:['lubang hitam'],hole:['lubang hitam'],bor:['drill','mata bor'],listrik:['motor','electric'],
 luka:['wound','pendarahan'],kulit:['skin','jaringan'],sembuh:['penyembuhan','memulih','healing'],
 stadion:['stadium','arena','tribun','lapangan'],stadium:['stadion','arena'],
 hewan:['animal','satwa','spesies'],bangunan:['building','gedung','menara','pencakar langit']
};
const patterns=[
 ['comparison',/\b(vs\.?|versus|perbandingan|bandingkan|comparison|compare|beda(?:nya)?|perbedaan)\b/i,'Bandingkan kedua objek dengan kriteria yang sama, lalu simpulkan perbedaan dan batasnya.'],
 ['biography',/\b(biografi|profil|riwayat hidup|kisah hidup|biography|life of|siapa sebenarnya)\b/i,'Kenalkan tokohnya, susun tonggak hidup secara kronologis dan bedakan dampak dari interpretasi.'],
 ['history',/\b(sejarah|asal usul|asal-usul|history|origin|kronologi)\b/i,'Mulai dari asal atau konteks, susun peristiwa secara kronologis dan sebutkan perubahan yang menjawab judul.'],
 ['science',/\b(terbentuk|sembuh|bereaksi|berkembang|berevolusi|menguap|terjadinya|terjadi|formed|heal\w*)\b/i,'Jelaskan tahapan ilmiah dalam urutan sebab-akibat. Sebutkan mekanisme dan syaratnya, lalu jawab pertanyaan pada penutup.'],
 ['mechanism',/\b(cara kerja|cara .*bekerja|bekerja|bagaimana cara|how .*works?|mekanisme)\b/i,'Jelaskan input, komponen utama, mekanisme dan keluaran. Gunakan urutan proses yang konkret.'],
 ['mystery',/\b(misteri|mystery|belum terpecahkan|teka-teki)\b/i,'Kenalkan pertanyaan, bedakan bukti, hipotesis, dan legenda. Tutup dengan batas pengetahuan.'],
 ['story',/\b(kisah|cerita|story|storytelling|dongeng)\b/i,'Susun awal, perkembangan dan penutup yang menjawab judul. Tandai fiksi atau dramatisasi, jika ada.'],
 ['fact',/\b(fakta|keunikan|tahukah|did you know|fun fact)\b/i,'Sebutkan fakta konkret, jelaskan mengapa menarik dan beri konteks yang sesuai judul.']
];
const counted={dua:2,tiga:3,empat:4,lima:5,enam:6,tujuh:7,delapan:8,sembilan:9,sepuluh:10,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9,ten:10};
function includes(text,part){return (' '+norm(text)+' ').includes(' '+norm(part)+' ');}
function intent(title){
 title=clean(title);
 const m=/^(?:(?:top|daftar|ranking|peringkat)\s+)?(\d{1,3}|dua|tiga|empat|lima|enam|tujuh|delapan|sembilan|sepuluh|two|three|four|five|six|seven|eight|nine|ten)\s+([^\d].*)$/i.exec(title);
 const count=m?(counted[m[1].toLowerCase()]||Number(m[1])):0;
 const numbered=count>=2&& !/^(?:tahun|hari|jam|menit|detik|abad|persen|kilometer|meter|ton|rupiah|dolar|years?|days?|hours?|minutes?|seconds?|percent)\b/i.test(m[2]);
 const subject=numbered?clean(m[2]):title;
 const subjective=/\b(termegah|terbaik|terindah|terkeren|terfavorit|menakjubkan|paling megah|best|most (?:beautiful|magnificent|impressive))\b/i.test(title);
 const scope=/\b(?:di|dalam|se-|in|across)\s+(.+?)[?.!]*$/i.exec(subject)?.[1]||'';
 const criteria=words(subject).filter(w=>/^(?:ter(?:cepat|tinggi|megah|baik|besar|indah|kecil|panjang|baru|tua|favorit)|fastest|highest|tallest|best|largest|oldest|biggest)$/.test(w));
 const anchors=[...new Set(words(subject).filter(w=>w.length>=3&&!stop.has(w)&&!criteria.includes(w)&&!/^\d+$/.test(w)))];
 const compared=title.split(/\s+(?:vs\.?|versus)\s+/i).map(s=>s.trim());
 const match=patterns.find(([,rule])=>rule.test(title));
 return {title,type:numbered?'list':match?.[0]||'education',subject,compared:compared.length===2?compared:[],count:numbered?count:0,scope,criteria,subjective,anchors,
  rule:numbered?'Susun objek berbeda dalam urutan pembahasan. Jelaskan bagaimana tiap objek memenuhi kriteria judul.':match?.[2]||'Jawab informasi yang dijanjikan judul, lalu jelaskan alasan, contoh yang relevan dan simpulan.'};
}
const types={
 auto:['Otomatis AI (Rekomendasi)','documentary',''],
 list:['Daftar / Listicle','documentary','Kenalkan kriteria, bahas tiap objek dan tutup dengan rangkuman.'],
 ranking:['Ranking / Top','viral','Tetapkan metrik, batasan dan urutan; jelaskan posisi tanpa mengklaim daftar resmi tanpa sumber.'],
 fact:['Fakta Unik','casual','Buka dengan temuan konkret, jelaskan konteks dan mengapa temuan itu unik.'],
 mechanism:['Cara Kerja','science','Susun input, komponen, mekanisme dan keluaran dalam urutan kerja.'],
 science:['Proses Ilmiah','documentary','Susun kondisi awal, pemicu, perubahan tahap demi tahap dan hasil.'],
 history:['Sejarah & Dokumenter','documentary','Susun konteks, peristiwa kronologis, akibat dan signifikansi.'],
 recreation:['Reka Ulang Adegan','documentary','Ceritakan tindakan berurutan: kondisi awal, perkembangan konflik, klimaks dan hasil adegan. Pakai parafrasa, tanpa menyalin dialog.'],
 recap:['Alur Cerita / Recap','casual','Ringkas peristiwa utama dalam cakupan dan urutan sumber yang dipilih.'],
 character:['Analisis Karakter','documentary','Kenalkan karakter dengan contoh kemampuan, latar atau perubahan dalam cakupan; bedakan interpretasi dari fakta karya.'],
 whatif:['What If / Skenario Alternatif','casual','Jelaskan titik perubahan, konsekuensi, reaksi tokoh dan hasil hipotetis. Sebutkan sejak pembuka bahwa versi ini alternatif.'],
 comparison:['Perbandingan','science','Bandingkan objek dengan kriteria yang sejajar, jelaskan kelebihan, batas, dan konteks.'],
 mystery:['Misteri & Horor','mystery','Pisahkan bukti, teori, legenda dan unsur fiksi. Gunakan ketegangan sesuai konteks.'],
 story:['Storytelling','emotion','Tunjukkan konflik, perubahan dan penyelesaian secara natural.'],
 education:['Edukasi','science','Jawab judul dengan penjelasan konkret dan relevan.'],
 biography:['Biografi','documentary','Susun tonggak kehidupan secara kronologis.']
};
const settings={
 list:[['Count','Jumlah objek','number'],['Criteria','Kriteria pemilihan'],['Order','Urutan pembahasan']],
 ranking:[['Count','Jumlah objek','number'],['Criteria','Dasar pemeringkatan'],['Order','Urutan peringkat']],
 mechanism:[['Subject','Objek utama'],['Parts','Komponen'],['Stages','Tahapan mekanisme'],['Depth','Kedalaman','depth']],
 science:[['Subject','Fenomena utama'],['Stages','Tahapan proses'],['Depth','Kedalaman','depth']],
 recreation:[['Work','Karya asal'],['Scope','Adegan / versi'],['Characters','Karakter yang terlibat']],
 recap:[['Work','Karya asal'],['Scope','Episode, season atau arc'],['Focus','Cakupan ringkasan']],
 character:[['Subject','Nama karakter'],['Work','Karya asal'],['Focus','Fokus analisis','focus']],
 whatif:[['Initial','Kondisi awal'],['Change','Perubahan utama'],['Impact','Dampak perubahan'],['Outcome','Kemungkinan hasil']],
 story:[['Point','Sudut pandang','point'],['Delivery','Gaya penyampaian'],['StoryKind','Jenis cerita','story'],['Creativity','Kreativitas','depth']]
};
const fidelityLabels={canon:'Sesuai Cerita Asli',adaptation:'Adaptasi Kreatif',alternative:'Versi Alternatif'};
const sourceTypes=['recreation','recap','character','whatif'];
const chronology=['history','biography','recreation','recap','mechanism','science','story','whatif'];
const legacy={ 'Sejarah penemuan':'history','Bagaimana jika':'whatif','Hidup di zaman dulu':'history','Kisah tokoh / biografi':'character','Fakta aneh':'fact','Misteri belum terpecahkan':'mystery','Top / ranking':'ranking','Cara kerja':'mechanism','Perbandingan':'comparison','Cerita rakyat Nusantara':'story','Drama viral (2 suara)':'story' };
const contextual=[
 ['whatif',/^(?:bagaimana jika|seandainya|andaikan|what if)\b\s*/i],
 ['recreation',/^(?:reka ulang(?: adegan| pertarungan)?|rekonstruksi(?: adegan| pertarungan)?|reenact(?:ment)?)\b\s*/i],
 ['recap',/^(?:alur cerita|ringkasan cerita|rekap|recap|sinopsis)\b\s*/i],
 ['character',/^(?:analisis karakter|analisis tokoh|profil karakter|mengapa .+ (?:sangat |begitu )?(?:kuat|terkenal)\b)/i],
 ['story',/^(?:petualangan|dongeng|cerita fiksi)\b\s*/i],
];
let recentTitle='',recentDetection;
function detect(title){
 title=clean(title);
 if(title===recentTitle&&recentDetection)return recentDetection;
 const base=intent(title);
 const signal=contextual.find(([,regex])=>regex.test(title));
 const rank=/^(?:top|ranking|peringkat)\b/i.test(title)&&!!base.count;
 const type=signal?.[0]||(rank?'ranking':base.type);
 const body=signal?clean(title.replace(signal[1],'')):title;
 const source=/\s+(?:dari serial|dari film|dari anime|dari manga|dari novel|from)\s+(.+?)[?.!]*$/i.exec(title)?.[1]||'';
 const subject=type==='recap'?body.split(/\s+\b(?:episode|season|arc|musim)\b\s+/i)[0]:
  type==='character'?(/^(?:mengapa|kenapa)\s+(.+?)\s+(?:sangat|begitu|kuat)\b/i.exec(title)?.[1]||body||title):
  ['mechanism','science'].includes(type)?title.replace(/^(?:bagaimana|cara kerja|cara)\s+/i,'').replace(/\s+(?:bekerja|terbentuk|sembuh|terjadi)\??$/i,''):
  type==='recreation'?body.replace(/\s+(?:dari serial|dari film|dari anime|dari manga|dari novel|from)\s+.*$/i,''):
  base.subject;
 const pair=subject.replace(/^(?:perbandingan|bandingkan)\s+/i,'').split(type==='recreation'?/\s+(?:vs\.?|versus|melawan)\s+/i:/\s+(?:vs\.?|versus|dan)\s+/i);
 const characters=type==='recreation'&&pair.length===2?pair:type==='character'?[subject]:type==='whatif'?[body.split(/\s+(?:menjadi|tidak|memilih|bergabung|jadi)\s+/i)[0]].filter(Boolean):[];
 const compared=type==='comparison'?(pair.length===2?pair:base.compared):[];
 const focus=base.anchors[0]==='stadion'?'Arsitektur, fasilitas, sejarah, dan keunikan stadion':
  ['mechanism','science','recreation','whatif'].includes(type)?{mechanism:'Komponen dan mekanisme',science:'Tahapan pembentukan atau perubahan',recreation:'Kronologi dan hasil adegan',whatif:'Konsekuensi perubahan fiksi'}[type]:'';
 const anchors=signal?words(subject).filter(w=>w.length>2&&!stop.has(w)).slice(0,12):base.anchors;
 recentDetection={...base,type,subject,compared,characters,work:source||(type==='recap'?subject:''),focus,anchors,clarity:!!signal||rank||base.type!=='education'};
 recentTitle=title;
 return recentDetection;
}
function planDirector(title,input={}){
 const inferred=detect(title);
 const manual=Object.hasOwn(types,input.mode)?input.mode:legacy[input.legacy]||'auto';
 const type=manual==='auto'?inferred.type:manual;
 const details={};
 for(const [key] of settings[type]||[]){
  const value=clean(input.fields?.[key]).slice(0,380);
  if(value)details[key]=value;
 }
 const isList=type==='list'||type==='ranking';
 const requested=Number(details.Count);
 const requestedCount=Number.isInteger(requested)&&requested>=2&&requested<=50?requested:0;
 const conflict=[];
 const isInferredList=['list','ranking'].includes(inferred.type);
 if(inferred.count&&!isList)conflict.push('Judul menjanjikan '+inferred.count+' objek. Pilih Daftar, Ranking atau Otomatis.');
 if(!isInferredList&&inferred.clarity&&manual!=='auto'&&type!==inferred.type&&
   !(inferred.type==='biography'&&type==='character')&&!(type==='story'&&['recap','recreation'].includes(inferred.type)))
  conflict.push('Judul mengarah ke '+types[inferred.type][0]+'. Sesuaikan jenis atau edit judul.');
 if(inferred.count&&details.Count&&requested!==inferred.count)conflict.push('Jumlah objek pada judul adalah '+inferred.count+'.');
 if(details.Count&&!requestedCount)conflict.push('Jumlah objek harus berupa bilangan bulat 2–50.');
 const fidelity=sourceTypes.includes(type)?(Object.hasOwn(fidelityLabels,input.fidelity)?input.fidelity:(type==='whatif'?'alternative':'canon')):'';
 if(type==='whatif'&&fidelity==='canon')conflict.push('What If memerlukan Versi Alternatif atau Adaptasi Kreatif.');
 const plan={...inferred,type,manual,detectedType:inferred.type,subject:details.Subject||inferred.subject,details,
  count:isList?(inferred.count||requestedCount||5):0,work:details.Work||inferred.work,
  characters:details.Characters?details.Characters.split(/[,;]/).map(clean).filter(Boolean).slice(0,12):inferred.characters,
  version:clean(input.version).slice(0,140),fidelity,conflict,chronology:chronology.includes(type),structured:!!isList||sourceTypes.includes(type),
  factual:!['whatif','story'].includes(type),voice:types[type][1],
  rule:type===inferred.type&&['education','biography'].includes(type)?inferred.rule:types[type][2]};
 return plan;
}
function contentPrompt(plan){
 const f=plan.fidelity;
 const advanced=sourceTypes.includes(plan.type);
 const data={...plan.details};
 delete data.Count;
 const context={subject:plan.subject,focus:plan.focus,work:plan.work,characters:plan.characters,version:plan.version,settings:data,fidelity:f};
 const compact=Object.fromEntries(Object.entries(context).filter(([,value])=>typeof value==='object'?Object.keys(value).length:value));
 return (Object.keys(compact).length?' Konteks tambahan: '+JSON.stringify(compact)+'.':'')+
  ' Buka langsung dengan objek, fakta, tindakan atau kondisi yang dijanjikan judul. Gunakan kalimat padat, hindari basa-basi, pengulangan dan pertanyaan retoris tanpa informasi.'+
  (f==='canon'?' Ikuti edisi yang dipilih. Pertahankan karakter, lokasi, kronologi, tindakan kunci dan hasil; jangan mencampur versi. Seluruh dialog cukup diparafrasakan. Jika ambiguitas edisi mengubah inti adegan dan belum ada pilihan/cakupan, kembalikan hanya {"clarify":["pilihan edisi/cakupan singkat","pilihan lainnya"]}.':'')+
  (f==='adaptation'?' Jaga inti cerita, tandai adaptasi secara eksplisit di pembuka, dan batasi perubahan pada penyederhanaan serta penyampaian.':'')+
  (f==='alternative'?' Tandai skenario alternatif secara eksplisit di pembuka; pisahkan premis asli dan hasil hipotetis.':'')+
  (advanced?' Jawab dalam JSON {"opening":"","work":"","scope":"","beats":[{"stage":"","narration":"","characters":[""],"location":"","action":""}],"closing":"","objects":[{"name":"","kind":"","visual":""}],"verify":[""],"differences":[""]}. Urutkan beats sesuai cerita; minimal tiga isi berbeda yang bisa divisualisasikan. Untuk Reka Ulang gunakan setup, conflict, climax, outcome dalam urutan tersebut. Untuk edisi canon yang tidak dapat dipastikan, beri catatan verifikasi atau ajukan pilihan. Ketidakpastian tidak boleh diisi dengan dugaan faktual.':'')+
  (plan.count?' Pada item boleh tambahkan kind dan visual singkat jika ciri sudah diketahui.':'')+
  (plan.manual==='auto'&&!plan.clarity?' Bila konteks judul memerlukan penafsiran, gunakan satu JSON {"narration":"","context":{"type":"fact|history|story|mystery|mechanism|science|comparison|education|biography"},"verify":[],"differences":[]} dan pilih satu type.':'');
}
function sourceUrls(sources){
 return [...new Set((clean(sources).match(/https?:\/\/[^\s<>"']+/gi)||[])
  .map(value=>value.replace(/[.,;!?\])}]+$/g,'')).filter(value=>value.length<=500))].slice(0,5);
}
function referenceStatus(sources,plan,evidence=[]){
 const text=clean(sources);
 const supplied=sourceUrls(text);
 const hasUrl=supplied.length>0;
 const notes=clean(text.replace(/https?:\/\/\S+/gi,''));
 const canonical=url=>String(url||'').replace(/\/$/,'');
 const requested=new Set(supplied.map(canonical));
 const checked=Array.isArray(evidence)?evidence.filter(r=>r?.urlRetrievalStatus==='URL_RETRIEVAL_STATUS_SUCCESS'&&requested.has(canonical(r.retrievedUrl))).map(r=>String(r.retrievedUrl)).slice(0,5):[];
 const label=plan.fidelity==='alternative'||plan.fidelity==='adaptation'||plan.type==='story'?'Fiksi atau adaptasi':
  plan.subjective?'Opini atau penilaian subjektif':checked.length?'Sumber berhasil diperiksa provider; klaim tetap perlu ditinjau':
  notes?'Berdasarkan referensi pengguna':'Belum terverifikasi';
 return {label,urlOnly:hasUrl&&!notes,hasUrl,external:checked.length>0,checked,
  unresolved:supplied.filter(url=>!checked.some(v=>canonical(v)===canonical(url)))};
}
function targetWords(minutes,language,plan,voice){
 const rate=({science:132,documentary:138,emotion:128,casual:142,viral:150,mystery:130})[voice]||145;
 const lexical=language==='English'?1.04:1;
 return Math.max(1,Math.round((Number(minutes)||1)*rate*lexical));
}
function instruction(plan){
 const {title,type,count,scope,criteria,subjective,rule}=plan;
 return 'TITLE INTENT LOCK. Judul terpilih '+JSON.stringify(title)+' adalah sumber utama isi. Jenis: '+type+
  (count?' dengan tepat '+count+' objek berbeda.':' .')+(scope?' Ruang lingkup '+JSON.stringify(scope)+'.':'')+
  (criteria.length?' Kriteria '+criteria.join(', ')+'.':'')+' '+rule+
  ' Tema acak, genre, visual, director dan gaya tutur tidak boleh mengubah objek, jumlah atau maksud. Jangan masukkan horor yang tidak relevan. Jangan karang angka, sejarah, referensi, studi, kutipan atau peringkat. Bedakan fakta, opini, fiksi dan legenda. Nyatakan ketidakpastian jika perlu.'+
  (subjective?' Pilihan bersifat kurasi editorial. Jangan nyatakan sebagai peringkat resmi.':'')+
  (count?' Kembalikan satu JSON saja: {"opening":"hook singkat","items":[{"name":"nama objek nyata","detail":"penjelasan spesifik yang dapat dibacakan untuk objek ini"}],"closing":"penutup yang menjawab judul","verify":["klaim yang belum bisa diperiksa, jika ada"]}. Tepat '+count+' item berurutan. Opening dan closing tidak menambah objek daftar. Nama akan dimasukkan ke VO jika belum disebut di detail. Tanpa markdown, label visual atau CTA.':'');
}
const citation=/https?:\/\/|\bdoi\s*:|\[(?:\d{1,3}(?:\s*,\s*\d{1,3})*|sumber[^\]]*)\]|\b(?:sumber|referensi)\s*:/i;
const invented=/\b(?:menurut penelitian|menurut sebuah studi|para ilmuwan membuktikan|statistik resmi menunjukkan|a recent study|studies prove)\b/i;
const horror=/\b(?:hantu|arwah gentayangan|roh jahat|kerasukan|kutukan maut|pocong|ghost|demonic curse)\b/i;
const official=/\b(?:peringkat resmi|ranking resmi|daftar resmi|official ranking)\b/i;
const neutralOfficial=/\b(?:bukan|tanpa|bukanlah|not an?)\s+(?:merupakan\s+)?(?:peringkat resmi|ranking resmi|daftar resmi|official ranking)\b/gi;
const domains={
 stadion:/\b(stadion|stadium|arena|tribun|pertandingan|lapangan|sepak bola|penonton|kandang klub|football|soccer|pitch|grandstand)\b/i,
 hewan:/\b(hewan|satwa|spesies|terbang|menukik|berenang|berlari|sayap|laut|mangsa|predator|darat|binatang|bird|animal|wings|dive|swim)\b/i,
 bangunan:/\b(bangunan|gedung|menara|lantai|arsitektur|struktur|pencakar langit|tower|building|floor|skyscraper)\b/i
};
const precise=/\d[\d.,]*\s*(?:%|persen\b|km(?:\/jam)?\b|meter\b|m\b|mph\b|kg\b|jiwa\b)|\b(?:19|20)\d{2}\b|\b(?:tercatat resmi|rekor resmi|nomor satu dunia)\b/i;
function namedKey(name){
 return norm(name.replace(/\([^)]*\)/g,'').split(/\s(?:\/|alias|aka|atau)\s/i)[0]).replace(/^(?:the|stadion|stadium|gedung|menara) /,'').replace(/ (?:stadium|stadion|tower)$/,'');
}
function parse(value){
 try{return typeof value==='string'?JSON.parse(value.trim().replace(/^```(?:json)?\s*|\s*```$/gi,'')):value;}
 catch(_){return null;}
}
function repeated(text){
 const seen=new Set();
 for(const span of text.split(/[.!?]+/)){
  const k=norm(span);
  if(words(k).length<5)continue;
  if(seen.has(k))return true;
  seen.add(k);
 }
 return false;
}
function validate(raw,plan,{target=145,sources='',loop=false,evidence=[]}={}){
 let text='',items=[],opening='',closing='',needsReview=false;
 const fail=error=>({ok:false,error});
 const decoded=(plan.count||plan.structured||typeof raw==='object'||/^\s*(?:```(?:json)?\s*)?\{/i.test(String(raw)))?parse(raw):null;
 const proposed=clean(decoded?.context?.type);
 const inferredByAI=plan.manual==='auto'&&!plan.clarity&&['fact','history','story','mystery','mechanism','science','comparison','education','biography'].includes(proposed);
 if(inferredByAI)plan={...plan,type:proposed,chronology:chronology.includes(proposed)};
 const advanced=plan.structured&&!plan.count;
 let beats=[];
 if(plan.conflict?.length)return fail(plan.conflict[0]);
 if(advanced&&Array.isArray(decoded?.clarify)&&!plan.version&&!plan.details?.Scope&&plan.fidelity==='canon'){
  const choices=[...new Set(decoded.clarify.map(v=>clean(v).slice(0,140)).filter(v=>v.length>=4))].slice(0,4);
  if(choices.length>=2)return {ok:false,choices,error:'Pilih versi atau cakupan adegan sebelum meneruskan.'};
 }
 if(advanced){
  if(!Array.isArray(decoded?.beats)||decoded.beats.length<3||decoded.beats.length>30)return fail('Susun sedikitnya tiga bagian berurutan dengan tindakan atau isi konkret.');
  opening=clean(decoded.opening);closing=clean(decoded.closing);
  beats=decoded.beats.map(b=>({stage:clean(b?.stage).slice(0,60),narration:clean(b?.narration),location:clean(b?.location).slice(0,100),
   characters:Array.isArray(b?.characters)?b.characters.map(n=>clean(n).slice(0,80)).filter(n=>n&&includes(b.narration,n)).slice(0,5):[],action:clean(b?.action).slice(0,140)}));
  if(words(opening).length<4||words(closing).length<4||beats.some(b=>!b.stage||words(b.narration).length<6))return fail('Lengkapi pembuka, isi tiap tahap, dan penutup.');
  if(plan.type==='recreation'){
   const sequence=['setup','conflict','climax','outcome'].map(phase=>beats.findIndex(b=>norm(b.stage)===phase));
   if(sequence.some((step,i)=>step<0||(i>0&&step<=sequence[i-1]))||beats.some(b=>!b.action))
    return fail('Reka ulang memerlukan setup, conflict, climax dan outcome berurutan, dengan tindakan setiap bagian.');
  }
  if(plan.fidelity==='canon'&&!plan.work&&!clean(decoded.work))return fail('Karya asal belum jelas. Isi karya atau minta pilihan versi.');
  if(plan.fidelity==='canon'&&plan.work&&clean(decoded.work)&&!includes(decoded.work,plan.work)&&!includes(plan.work,decoded.work))return fail('Karya asal berbeda dari pilihan pengguna.');
  if((plan.type==='whatif'||plan.fidelity==='alternative')&&!/alternatif|what if|andaikan|seandainya|skenario hipotetis|imagine/i.test(opening))return fail('Pembuka harus menandai versi alternatif.');
  if(plan.fidelity==='adaptation'&&!/adaptasi|adaptation|diadaptasi/i.test(opening))return fail('Pembuka harus menandai adaptasi.');
  text=[opening,...beats.map(b=>b.narration),closing].join(' ');
  if(plan.characters.some(name=>!includes(text,name)))return fail('Karakter inti belum disebut lengkap.');
  if((text.match(/["“][^"”]{90,}["”]/gu)||[]).length)return fail('Parafrasakan dialog panjang dari karya asal.');
 }

 if(plan.count){
  if(plan.count>50)return fail('Daftar maksimal 50 objek per naskah. Pecah judul menjadi beberapa bagian.');
  const value=decoded;
  if(!Array.isArray(value?.items)||value.items.length!==plan.count)return fail('Judul meminta '+plan.count+' objek berbeda. Respons harus memuat tepat '+plan.count+' item terstruktur.');
  opening=clean(value.opening);closing=clean(value.closing);
  if(words(opening).length<4||words(closing).length<4)return fail('Pembukaan atau penutup belum lengkap.');
  const keys=new Set(),details=new Set(),domain=domains[plan.anchors[0]];
  for(const row of value.items){
   const name=clean(row?.name),detail=clean(row?.detail),key=namedKey(name);
   const generic=norm(name);
   if(!key||name.length>110||/^(?:(?:stadion|stadium|hewan|bangunan|objek|item|nomor|pilihan|object|animal|building) (?:[a-z]|\d{1,2})|(?:pertama|kedua|ketiga|first|second|third))$/i.test(generic)||includes(plan.subject,name)&&norm(name)===norm(plan.anchors[0]||''))return fail('Sebutkan nama objek nyata untuk setiap item.');
   if(keys.has(key))return fail('Objek terulang: '+name+'.');
   if(domain&&!domain.test(name+' '+detail))return fail('Penjelasan '+name+' belum menunjukkan objek dari kategori judul.');
   if(words(detail).length<6||details.has(norm(detail)))return fail('Penjelasan '+name+' terlalu singkat atau berulang.');
   keys.add(key);details.add(norm(detail));items.push({name,detail,kind:clean(row.kind).slice(0,45),visual:clean(row.visual).slice(0,160)});
  }
  if(items.some((item,index)=>items.some((other,j)=>index!==j&&includes(item.detail,other.name))))
   return fail('Penjelasan per item harus tetap pada satu objek; pindahkan objek lain ke bagian masing-masing.');
  if(items.some(item=>includes(opening,item.name)||includes(closing,item.name)))
   return fail('Pembukaan dan penutup harus merangkum kriteria tanpa mengulang nama setiap item.');
  const withName=items.map(({name,detail})=>includes(detail,name)?detail:(name+'. '+detail));
  text=[opening,...withName,closing].join(' ');
  needsReview=Array.isArray(value.verify)&&value.verify.some(v=>clean(v));
 }else if(!advanced){
  text=clean(decoded?.narration)||clean(raw);
  if(words(text).length<9||/^[{[]/.test(text))return fail('Naskah kosong atau belum lengkap.');
  opening=text.split(/[.!?]/)[0];
  closing=text.replace(/[.!?]+\s*$/,'').split(/[.!?]/).at(-1);
 }
 if(citation.test(text)||invented.test(text)&&!clean(sources))return fail('Hapus rujukan yang belum didukung oleh kutipan sumber pengguna.');
 if(plan.subjective&&official.test(text.replace(neutralOfficial,'')))return fail('Kriteria subjektif tidak boleh disajikan sebagai peringkat resmi.');
 if(!['story','mystery',...sourceTypes].includes(plan.type)&&!horror.test(plan.title)&&horror.test(text))return fail('Unsur horor tidak relevan dengan judul.');
 const tokens=words(text);
 const relevant=anchor=>tokens.some(t=>t===anchor||(anchor.length>=4&&t.includes(anchor)))||(aliases[anchor]||[]).some(alias=>includes(text,alias));
 if(plan.anchors.length&&!plan.anchors.some(relevant))return fail('Isi belum menyebut objek utama atau padanan objek dalam judul.');
 if(plan.compared.length&&plan.compared.some(part=>!includes(text,part)))return fail('Kedua objek harus disebut dan dibandingkan.');
 if(['mechanism','science'].includes(plan.type)&&plan.anchors.length>1&&!plan.anchors.slice(0,2).every(relevant))
  return fail('Objek utama mekanisme atau proses belum dibahas lengkap.');
 if(['mechanism','science','comparison'].includes(plan.type)&&text.split(/[.!?]+/).filter(x=>words(x).length>=4).length<2)
  return fail('Tambahkan tahapan atau poin pembanding yang konkret.');
 if(['mechanism','science'].includes(plan.type)&&!/(?:\b(?:karena|ketika|saat|setelah|sehingga|lalu|kemudian|mengubah|menggerakkan|memutar|membentuk|memicu|because|when|after|then|causes?)\b)/i.test(text))
  return fail('Jelaskan hubungan sebab-akibat atau tahap proses yang dijanjikan judul.');
 if(/^(?:pernahkah anda bertanya.tanya|di balik semua itu terdapat misteri|rahasia kelam yang tersembunyi|fakta yang tidak diketahui banyak orang)\b/i.test(text)&&plan.type!=='mystery')
  return fail('Ganti pembuka klise dengan tindakan atau fakta langsung yang sesuai judul.');
 if(repeated(text)||norm(opening)===norm(closing))return fail('Naskah mengulang isi atau menutup dengan menyalin pembukaan.');
 const warnings=[],count=clean(text).split(/\s+/u).length;
 if(count<target*.68||count>target*1.35)warnings.push(count+' kata; target sekitar '+target+'. Periksa durasi baca.');
 if(!clean(sources)||needsReview||precise.test(items.length?items.map(x=>x.detail).join(' ')+' '+opening+' '+closing:text))
  warnings.push('Klaim faktual perlu verifikasi sebelum dipublikasikan. Pemeriksaan judul tidak memverifikasi sumber.');
 const review=decoded?.verify;
 const reference=referenceStatus(sources,plan,evidence);
 if(reference.unresolved.length)warnings.push('Isi '+reference.unresolved.length+' URL belum berhasil diakses.');
 if(plan.count&&target<plan.count*12+14)warnings.push('Durasi target sangat pendek untuk seluruh objek; gunakan uraian ringkas atau tambah durasi.');
 for(const note of Array.isArray(decoded?.differences)?decoded.differences.slice(0,3):[]){
  const line=clean(note).slice(0,140);
  if(line&&!citation.test(line))warnings.push('Perbedaan sumber yang perlu diperiksa: '+line);
 }
 if(Array.isArray(review)){
  for(const note of review.slice(0,3)){
   const claim=clean(note).slice(0,140);
   if(claim&&!citation.test(claim))warnings.push('Periksa klaim: '+claim);
  }
 }
 if(plan.subjective)warnings.push('Pilihan editorial berdasarkan kriteria judul.');
 if(loop&&norm(closing).split(' ').length<4)warnings.push('Periksa sambungan akhir ke awal sebelum membuat VO.');
 const allowed=[...new Set([plan.subject,...(plan.characters||[]),...beats.flatMap(b=>b.characters),...beats.map(b=>b.location)].filter(Boolean))];
 const rawObjects=Array.isArray(decoded?.objects)?decoded.objects.slice(0,24):[];
 const objects=(items.length?items:allowed).map(value=>{
  const item=typeof value==='string'?rawObjects.find(o=>norm(o?.name)===norm(value))||{name:value}:value;
  return {id:'obj-'+norm(item.name).replace(/ /g,'-').slice(0,90),name:clean(item.name),
   kind:clean(item.kind).slice(0,45)||(plan.anchors||[])[0]||'',visual:clean(item.visual).slice(0,160)};
 });
 return {ok:true,text,items:items.map(x=>x.name),ending:plan.count||advanced?closing:'',opening,beats,objects,warnings,
  work:plan.work||clean(decoded?.work).slice(0,140),scope:plan.version||plan.details?.Scope||clean(decoded?.scope).slice(0,140),reference,resolvedType:plan.type,inferredByAI,
  count,structure:advanced?'Bagian berurutan':plan.count?'Daftar terstruktur':'Narasi',chronology:advanced?'Urutan bagian diperiksa':plan.chronology?'Urutan diinformasikan oleh naskah; periksa isi':null};
}
function find(sequence,part,start,end=sequence.length){
 if(!part.length)return -1;
 for(let i=Math.max(0,start);i<=Math.min(end,sequence.length-part.length);i++){
  if(part.every((word,j)=>word===sequence[i+j]))return i;
 }
 return -1;
}
function align(narration,scenes,subjects,ending=''){
 const tokens=words(narration),positions=[];
 let previous=0;
 for(const name of subjects){
  const pos=find(tokens,words(name),previous);
  if(pos<0)return scenes.map(()=>[]);
  positions.push({name,pos});previous=pos+words(name).length;
 }
 const closing=find(tokens,words(ending),previous);
 let cursor=0;
 return scenes.map(scene=>{
  if(scene.outro)return [];
  const text=words(scene.voice);
  if(!text.length)return [];
  let start=find(tokens,text,cursor,cursor+Math.max(50,text.length));
  if(start<0)start=find(tokens,text.slice(0,Math.min(text.length,4)),Math.max(0,cursor-6),cursor+36);
  if(start<0){
   const named=positions.filter(x=>x.pos>=cursor-3&&includes(scene.voice,x.name));
   if(named.length){cursor=named.at(-1).pos+words(named.at(-1).name).length;return named.map(x=>x.name);}
   start=cursor;
  }
  const end=Math.min(tokens.length,start+text.length);
  cursor=Math.max(cursor,end);
  const active=positions.filter((item,i)=>item.pos<end&&(positions[i+1]?.pos??(closing>=0?closing:tokens.length))>start);
  return active.map(x=>x.name);
 });
}
function visualContext(narration,scenes,metadata,listSubjects){
 const tokens=words(narration),beats=Array.isArray(metadata?.beats)?metadata.beats:[];
 let at=0;
 const ranges=beats.map(beat=>{
  const start=find(tokens,words(beat.narration),at);
  if(start>=0)at=start+words(beat.narration).length;
  return {beat,start,end:at};
 }).filter(range=>range.start>=0);
 const objects=Array.isArray(metadata?.objects)?metadata.objects:[];
 let cursor=0;
 return scenes.map((scene,i)=>{
  if(scene.outro)return null;
  const block=words(scene.voice);
  if(!block.length)return null;
  let start=find(tokens,block,Math.max(0,cursor-3),cursor+80);
  if(start<0)start=find(tokens,block.slice(0,Math.min(4,block.length)),Math.max(0,cursor-4),cursor+55);
  const end=start<0?cursor:start+block.length;
  if(start>=0)cursor=Math.max(cursor,end);
  const overlapping=start<0?[]:ranges.filter(r=>r.start<end&&r.end>start);
  const activeNames=listSubjects[i]?.length?listSubjects[i]:overlapping.length?
   overlapping.flatMap(r=>[...(r.beat.characters||[]),r.beat.location]).filter(Boolean):
   beats.length||metadata?.items?.length?[]:objects.slice(0,1).map(o=>o.name);
  const selected=objects.filter(o=>activeNames.some(n=>norm(n)===norm(o.name))).slice(0,6);
  const first=overlapping[0],last=overlapping.at(-1);
  const stage=overlapping.map(r=>r.beat.stage).join(' → ');
  const indexOf=entry=>ranges.indexOf(entry);
  if(!stage&&!selected.length)return null;
  return {stage,objects:selected,characters:[...new Set(overlapping.flatMap(r=>r.beat.characters||[]))].slice(0,6),
   location:[...new Set(overlapping.map(r=>r.beat.location).filter(Boolean))].join(' → '),
   action:overlapping.map(r=>r.beat.action).filter(Boolean).join(' → ').slice(0,250),
   goal:stage?'Visualkan tahap ini sesuai urutan narasi.':'Pertahankan identitas dan komponen objek yang dijelaskan.',
   previous:first?ranges[indexOf(first)-1]?.beat.stage||'':'',next:last?ranges[indexOf(last)+1]?.beat.stage||'':''};
 });
}
function contextualRow(row,context){
 if(!context?.objects?.length&&!context?.stage)return row;
 const identity=(context.objects||[]).map(o=>o.name+(o.visual?' ('+o.visual+')':'')).join('; ');
 const text=[identity&&'Keep these identities consistent: '+identity+'.',context.stage&&'Show only current narrative phase: '+context.stage+'.',
  context.location&&'Location context: '+context.location+'.'].filter(Boolean).join(' ');
 if(!text)return row;
 return {...row,action:text+' '+row.action,image_prompt:text+' '+row.image_prompt,video_prompt:text+' '+row.video_prompt};
}
function lockRow(row,subjects,ordered){
 if(!ordered.length)return row;
 const wrong=ordered.filter(name=>!subjects.includes(name));
 for(const name of wrong)if([row.action,row.setting,row.image_prompt,row.video_prompt].some(value=>includes(value,name)))
  throw Error('Scene '+row.scene+' menyebut objek di luar urutan: '+name+'.');
 if(!subjects.length)return row;
 const prefix=subjects.length===1?'Primary subject: '+subjects[0]+'. Preserve its real identity. ':
  'Show these exact subjects in narration order: '+subjects.join(' → ')+'. Preserve each real identity. ';
 return {...row,action:prefix+row.action,image_prompt:prefix+row.image_prompt,video_prompt:prefix+row.video_prompt};
}
function verifyLoopEndpoints(plan,first,last,subjects){
 const text=first+' '+last;
 if(citation.test(text)||invented.test(text)||plan.subjective&&official.test(text.replace(neutralOfficial,'')))
  return false;
 if(!['story','mystery',...sourceTypes].includes(plan.type)&&!horror.test(plan.title)&&horror.test(text))return false;
 return !subjects.some(name=>includes(text,name));
}
return {intent,instruction,validate,align,lockRow,verifyLoopEndpoints,types,settings,fidelityLabels,detect,planDirector,contentPrompt,referenceStatus,sourceUrls,targetWords,visualContext,contextualRow};
});
