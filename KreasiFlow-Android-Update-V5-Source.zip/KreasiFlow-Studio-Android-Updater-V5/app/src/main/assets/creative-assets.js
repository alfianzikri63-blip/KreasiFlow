(function(root){
 'use strict';
 let connection;
 function open(){
  if(!connection)connection=new Promise((resolve,reject)=>{
   const request=indexedDB.open('kreasiflow-creative-681',1);
   request.onupgradeneeded=()=>request.result.createObjectStore('assets',{keyPath:'id'});
   request.onsuccess=()=>resolve(request.result);
   request.onerror=()=>reject(request.error);
  });
  return connection;
 }
 async function run(mode,operation){
  const db=await open();
  return new Promise((resolve,reject)=>{
   const tx=db.transaction('assets',mode),req=operation(tx.objectStore('assets'));
   tx.oncomplete=()=>resolve(req.result);
   tx.onerror=()=>reject(tx.error||req.error);
   tx.onabort=()=>reject(tx.error||Error('Penyimpanan aset dibatalkan.'));
  });
 }
 root.KFCreative={list:()=>run('readonly',store=>store.getAll()),get:id=>run('readonly',store=>store.get(id)),
  put:value=>run('readwrite',store=>store.put(value)),remove:id=>run('readwrite',store=>store.delete(id)),
  id:()=>typeof crypto.randomUUID==='function'?crypto.randomUUID():Array.from(crypto.getRandomValues(new Uint8Array(16)),x=>x.toString(16).padStart(2,'0')).join('')};
})(globalThis);
