/* KreasiFlow v5.0.57 — natural filename sorting and safe batch scene assignment. */
(function(root,factory){
  const lib=factory();
  if(typeof module==='object'&&module.exports)module.exports=lib;
  if(root)root.KFFlowBatchImport=lib;
})(typeof globalThis!=='undefined'?globalThis:null,function(){
  'use strict';
  function sceneNumber(filename){
    const name=String(filename||'').replace(/\.mp4$/i,'');
    const named=name.match(/(?:^|[^a-z0-9])(?:scene|sc|adegan|clip|klip|shot)(?:[\s._#(-]*)(0*[1-9][0-9]{0,2})(?![0-9])/i);
    if(named)return Number(named[1]);
    const shortName=name.match(/(?:^|[^a-z0-9])s(0*[1-9][0-9]{0,2})(?![0-9a-z])/i);
    if(shortName)return Number(shortName[1]);
    const initial=name.match(/^0*([1-9][0-9]{0,2})(?=$|[\s._(-])/);
    return initial?Number(initial[1]):null;
  }
  function naturalCompare(a,b){
    const left=String(a||'').normalize('NFKC'),right=String(b||'').normalize('NFKC');
    return left.localeCompare(right,'en',{numeric:true,sensitivity:'base'});
  }
  function plan(files,sceneCount){
    const count=Number(sceneCount);
    if(!Number.isSafeInteger(count)||count<1)throw Error('Buat storyboard sebelum mengimpor MP4.');
    const input=Array.from(files||[]);
    if(!input.length)throw Error('Pilih minimal satu video MP4.');
    if(input.length>count)throw Error('Jumlah MP4 ('+input.length+') melebihi '+count+' scene. Pilih video yang sesuai.');
    for(const f of input){
      if(!f||!/\.mp4$/i.test(f.name||'')||!(f.type==='video/mp4'||f.type==='application/octet-stream'||!f.type))throw Error('File harus MP4: '+String(f&&f.name||'tidak dikenal'));
      if(!Number.isFinite(f.size)||f.size<=0||f.size>250*1024*1024)throw Error('Ukuran MP4 tidak valid (maks 250 MB): '+f.name);
    }
    const entries=input.map(file=>({file,number:sceneNumber(file.name)}));
    const recognized=entries.filter(x=>x.number!==null).length;
    if(recognized!==0&&recognized!==entries.length)throw Error('Nama file bercampur: sebagian ada nomor scene dan sebagian tidak. Samakan nama (Scene-01.mp4) atau gunakan nama tanpa nomor semua.');
    const numbered=recognized===entries.length;
    if(numbered){
      const used=new Set();
      for(const entry of entries){
        if(entry.number>count)throw Error(entry.file.name+' menyebut Scene '+entry.number+' tetapi proyek hanya punya '+count+' scene.');
        if(used.has(entry.number))throw Error('Nomor Scene '+entry.number+' ditemukan lebih dari sekali. Ubah nama file agar tidak tertukar.');
        used.add(entry.number);
      }
      entries.sort((a,b)=>a.number-b.number);
    }else entries.sort((a,b)=>naturalCompare(a.file.name,b.file.name));
    return {mode:numbered?'numbered':'sorted',items:entries.map((item,i)=>({file:item.file,index:numbered?item.number-1:i,scene:numbered?item.number:i+1}))};
  }
  return {sceneNumber,naturalCompare,plan};
});
