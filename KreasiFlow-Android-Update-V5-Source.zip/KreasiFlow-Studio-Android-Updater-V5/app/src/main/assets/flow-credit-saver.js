/* KreasiFlow v5.0.51: Omni 1.1 Flash 4s voice-free image-to-video prompt. No Flow API calls. */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.KFFlowSaver=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const MODES=['image-first','text-to-video','local'];
  function mode(scene,defaultMode){const value=scene&&scene.flowClipMode||defaultMode;return MODES.includes(value)?value:'image-first';}
  function clean(value,words=24){return String(value||'').replace(/\s+/g,' ').trim().split(' ').filter(Boolean).slice(0,words).join(' ').replace(/[.;,]+$/,'');}
  // Omni 1.1 Flash can generate audio even without any request for speech.
  // Keep a strict audio instruction on BOTH generated and manually edited prompts.
  function duration(value){const n=Number(value);return [4,6,8,10].includes(n)?n:4;}
  function audioRule(mode){
    if(mode==='sfx')return 'Audio: natural environmental and object Foley ONLY. No human or synthetic voice, no narration, no voice-over, no dialogue, no speech, whispering, singing, vocalizations, background conversation, radio/TV voices, lip-sync, and no music. Do not read the script aloud.';
    return 'Audio: SILENT. No narration, no voice-over, no dialogue, no speech, no human or synthetic voice, lip-sync, whispers, singing, vocalizations, background conversations, music, ambience or sound effects. Never read the narration/script aloud.';
  }
  function enforceOmniAudio(prompt,options={}){
    const d=duration(options.duration);
    const original=String(prompt||'').trim()
      .replace(/\n\s*OMNI 1\.1 FLASH AUDIO LOCK:[\s\S]*$/i,'').trim()
      .replace(/\bDuration\s*:?\s*\d+(?:\.\d+)?\s*(?:seconds?|s)\b/gi,`Duration ${d} seconds`);
    return original+`\n\nOMNI 1.1 FLASH AUDIO LOCK: EXACTLY ${d} seconds, one continuous unbroken shot. ${audioRule(options.audioMode)} Do not create extra shots, subtitles, titles, or watermarks.`;
  }
  function imageToVideoPrompt(options={}){
    const d=duration(options.duration);
    const ratio=String(options.ratio||'9:16').includes('16:9')?'16:9':'9:16';
    const style=clean(options.style||'2D flat vector motion graphic',12);
    const character=clean(options.character,15);
    const action=clean(options.action||'The visible subject performs one clear natural action',25);
    const camera=clean(options.camera||'One subtle camera push',12);
    const flat=/(flat|vector|motion graphic 2d)/i.test(style);
    const body=`GOOGLE FLOW / OMNI 1.1 FLASH / IMAGE-TO-VIDEO — SCENE ${Number(options.index)+1||1}. Duration ${d} seconds, ${ratio}. `+
      `Use the uploaded first-frame image. Preserve exact ${style} shapes, colors, framing and ${character?character+' identity':'subject identity'}. `+
      `ACTION: ${action}. CAMERA: ${camera}. `+
      (options.styleRules?`STYLE-SPECIFIC MOTION (overrides incompatible generic camera guidance): ${String(options.styleRules).trim()} `:'')+
      `One continuous unbroken shot; restrained natural motion, no new props, cuts `+
      (flat?'or cuts into 3D. Pure 2D only; no 3D.':'or identity changes.');
    return enforceOmniAudio(body,options);
  }
  function summary(scenes,defaultMode,creditsPerVideo,outputsPerScene){
    const totals={imageFirst:0,textToVideo:0,local:0,videoCount:0,credits:0};
    for(const scene of Array.isArray(scenes)?scenes:[]){const m=mode(scene,defaultMode);if(m==='local')totals.local++;else if(m==='image-first')totals.imageFirst++;else totals.textToVideo++;}
    totals.videoCount=totals.imageFirst+totals.textToVideo;
    const rate=Math.max(0,Math.min(1000,Number(creditsPerVideo)||0));
    const qty=Math.max(1,Math.min(4,Math.floor(Number(outputsPerScene)||1)));
    totals.credits=totals.videoCount*rate*qty;
    totals.creditsPerVideo=rate;totals.outputsPerScene=qty;
    return totals;
  }
  return Object.freeze({mode,summary,imageToVideoPrompt,enforceOmniAudio,duration});
});
