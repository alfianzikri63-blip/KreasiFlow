/* KreasiFlow v5.0.48: credit-aware scene plan. No Flow API calls and no tariff claims. */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.KFFlowSaver=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  const MODES=['image-first','text-to-video','local'];
  function mode(scene,defaultMode){const value=scene&&scene.flowClipMode||defaultMode;return MODES.includes(value)?value:'image-first';}
  function clean(value,words=24){return String(value||'').replace(/\s+/g,' ').trim().split(' ').filter(Boolean).slice(0,words).join(' ').replace(/[.;,]+$/,'');}
  function imageToVideoPrompt(options={}){
    const duration=Math.max(2,Math.min(12,Number(options.duration)||8));
    const ratio=String(options.ratio||'9:16').includes('16:9')?'16:9':'9:16';
    const style=clean(options.style||'2D flat vector motion graphic',12);
    const character=clean(options.character,15);
    const action=clean(options.action||'The visible subject performs one clear natural action',27);
    const camera=clean(options.camera||'One subtle camera push',13);
    const flat=/(flat|vector|motion graphic 2d)/i.test(style);
    return `GOOGLE FLOW — IMAGE-TO-VIDEO, SCENE ${Number(options.index)+1||1}. ${duration}s, ${ratio}. `+
      `Animate the uploaded first-frame image; preserve its ${style} style, exact shapes, colors, layout and ${character?character+' identity':'subject identity'}. `+
      `${action}. ${camera}. `+
      `Keep motion smooth and restrained; one continuous shot. `+
      (flat?'Pure 2D only; no 3D, photorealism or new objects. ':'No new characters, objects or scene cuts. ')+
      `Ambient SFX only; no speech, music, subtitles or watermark.`;
  }
  function summary(scenes,defaultMode,creditsPerVideo,outputsPerScene){
    const totals={imageFirst:0,textToVideo:0,local:0,videoCount:0,credits:0};
    for(const scene of Array.isArray(scenes)?scenes:[]){const m=mode(scene,defaultMode);if(m==='local')totals.local++;else if(m==='image-first')totals.imageFirst++;else totals.textToVideo++;}
    totals.videoCount=totals.imageFirst+totals.textToVideo;
    const rate=Math.max(0,Math.min(1000,Number(creditsPerVideo)||0));
    const qty=Math.max(1,Math.min(4,Math.floor(Number(outputsPerScene)||1)));
    totals.credits=totals.videoCount*rate*qty;
    totals.creditsPerVideo=rate;totals.outputsPerScene=qty;
    return totals;
  }
  return Object.freeze({mode,summary,imageToVideoPrompt});
});
