/* KreasiFlow visual MP4 similarity: conservative 2-frame dHash heuristic. */
(function(root,factory){
 const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;
 root.KFFootageAudit=api;
})(typeof globalThis==='object'?globalThis:this,function(){
 'use strict';
 function validHash(s){return typeof s==='string'&&/^[01]{64}$/.test(s);}
 function distance(a,b){if(!validHash(a)||!validHash(b))throw Error('Hash frame tidak valid');let d=0;for(let i=0;i<64;i++)if(a[i]!==b[i])d++;return d;}
 function analyse(entries){
  const usable=entries.filter(x=>Array.isArray(x.hashes)&&x.hashes.length===2&&x.hashes.every(validHash));
  const lowDetail=usable.filter(x=>x.lowDetail).map(x=>x.scene);
  const comparable=usable.filter(x=>!x.lowDetail);
  const suspects=[];
  for(let i=0;i<comparable.length;i++)for(let j=i+1;j<comparable.length;j++){
   const a=comparable[i],b=comparable[j];let score=64;
   for(const ha of a.hashes)for(const hb of b.hashes)score=Math.min(score,distance(ha,hb));
   if(score<=11)suspects.push({a:a.scene,b:b.scene,distance:score,level:score<=6?'tinggi':'perlu cek'});
  }
  return {suspects,lowDetail,comparable:comparable.length};
 }
 return {validHash,distance,analyse};
});
