/* KreasiFlow v5.0.35 — per-scene cinematic shot planning without media generation.
 * Keep style/characters continuous; separate the *event* and camera from other scenes.
 */
(function (root, factory) {
 const api=factory();
 if(typeof module==='object' && module.exports)module.exports=api;
 root.KreasiFlowFlowShots=api;
})(typeof window!=='undefined'?window:globalThis, function(){
'use strict';
const cameras=[
 {shot:'Wide establishing shot',move:'slow lateral dolly revealing the physical setting and the starting action'},
 {shot:'Medium tracking shot',move:'follow the main subject from the side as the action begins'},
 {shot:'Close-up insert',move:'steady gentle push-in on the hands, wings, or object executing this action'},
 {shot:'Over-the-shoulder composition',move:'arc slightly to expose the subject of the action'},
 {shot:'Low-angle three-quarter shot',move:'short rising dolly while the action completes'},
 {shot:'Tight detail shot',move:'controlled micro-tracking of the distinctive visible result'},
 {shot:'High-angle medium shot',move:'gentle descending crane to clarify the spatial relationship'},
 {shot:'Side-profile action shot',move:'smooth parallel tracking along the direction of motion'},
 {shot:'Reaction medium close-up',move:'gradual dolly-in as the subject responds to the event'},
 {shot:'Wide resolution shot',move:'slow pull-back to reveal the outcome without restarting earlier actions'}
];
// Physical verbs in Indonesian/English, highest specificity first. The output never
// prescribes a new prop or location: objects must come from the supplied VO.
const actions=[
 {id:'ice', re:/\b(es batu|potongan es|ice cubes?|es dimasukk|memasukkan es)\b/i, shot:'A close visible action involving the ice explicitly mentioned in this scene, showing its actual transfer or movement and the immediate result'},
 {id:'pour',re:/\b(menuang|dituang|dituangkan|pour|penuang)\w*\b/i,shot:'The subject visibly pours the liquid or material named in the narration in one uninterrupted action; show the direction of the flow and where it goes'},
 {id:'microwave-open',re:/\b(membuka|dibuka|open)\w*[^.!?]{0,65}\b(microwave|mikrowave)\b|\b(microwave|mikrowave)\b[^.!?]{0,60}\b(membuka|dibuka|open)\w*/i,shot:'The subject opens the microwave door using the handle, with a clear view of the door movement'},
 {id:'microwave-insert',re:/\b(memasukkan|meletakkan|menaruh|dimasukkan|masuk|insert|place)\w*[^.!?]{0,70}\b(microwave|mikrowave)\b/i,shot:'The subject places the named item inside the microwave and releases it, showing the item entering the oven'},
 {id:'microwave-switch',re:/\b(menekan|memencet|menyalakan|mengatur|tombol|timer|menyala|turns on|start)\w*[^.!?]{0,70}\b(microwave|mikrowave)\b|\b(microwave|mikrowave)\b[^.!?]{0,80}\b(menekan|memencet|menyalakan|mengatur|tombol|timer|menyala)\w*/i,shot:'The subject operates the microwave controls and the display or light responds, with the interaction visible'},
 {id:'microwave-out',re:/\b(mengambil|mengeluarkan|dikeluarkan|removed|remove)\w*[^.!?]{0,75}\b(microwave|mikrowave)\b/i,shot:'The subject carefully takes the named item out of the microwave, revealing the outcome of the action'},
 {id:'wing',re:/\b(membuka sayap|mengembangkan sayap|membentangkan sayap|sayap.*(terbuka|mengembang)|spread.*wings?)\b/i,shot:'The bird opens and fully spreads its wings in a clearly visible single motion, with the feathers visible in frame'},
 {id:'dance',re:/\b(menari|tarian|dance|berlenggak|menggoyang|berjoget)\b/i,shot:'The animal or character performs the distinctive dance or display described in this narration; emphasize the exact visible body movement'},
 {id:'fly',re:/\b(terbang|melayang|mengepak|takeoff|fly|flying)\b/i,shot:'The subject visibly takes flight or flies along the direction described by this narration'},
 {id:'observe',re:/\b(mengamati|menyaksikan|melihat|memperhatikan|menatap|watch|observe)\w*\b/i,shot:'Show who is observing whom, with a readable eyeline and a visible reaction to the specifically named event'},
 {id:'approach',re:/\b(mendekat|mendekati|menghampiri|approach|bertemu)\w*\b/i,shot:'The subject physically approaches the other named subject or destination; the change of distance is visible'},
 {id:'enter',re:/\b(memasuki|masuk ke|memasuki arena|enter|menembus)\w*\b/i,shot:'The subject enters the location named here, visibly crossing the threshold or moving into the space'},
 {id:'walk',re:/\b(berjalan|melangkah|berlari|menuju|walk|run|melintasi)\w*\b/i,shot:'The subject travels across the location actually described here; show the direction and distance covered'},
 {id:'open',re:/\b(membuka|dibuka|open)\w*\b/i,shot:'The named subject visibly opens the specifically named object, revealing what the narration says is inside'},
 {id:'press',re:/\b(menekan|memencet|mengklik|memutar kenop|press|tap)\w*\b/i,shot:'A clear physical hand or tool interaction pressing or turning the control named in the narration and its immediate visible response'},
 {id:'heat',re:/\b(memanas|dipanas|panas|mendidih|boil|heat|menguap|uap)\w*\b/i,shot:'The exact item being heated visibly changes as described, with the temperature effect or process clearly framed'},
 {id:'mix',re:/\b(mencampur|mengaduk|mengocok|menggabungkan|mix|stir)\w*\b/i,shot:'The character mixes the actual named ingredients in the narrated container with a clearly visible stirring motion'},
 {id:'cut',re:/\b(memotong|mengiris|membelah|cut|slice)\w*\b/i,shot:'The subject visibly cuts the specific item identified in this scene, showing the before-and-after change'},
 {id:'hold',re:/\b(memegang|menggenggam|mengangkat|membawa|holding|angkat|mengambil)\w*\b/i,shot:'The named subject picks up or holds the specific object in the narration, visibly transferring it into position'},
 {id:'drop',re:/\b(menjatuh|jatuh|terjatuh|drop|tumpah)\w*\b/i,shot:'The specific narrated object falls or spills and the resulting physical change is visible'},
 {id:'discover',re:/\b(menemukan|ditemukan|menyadari|muncul|mengungkap|discover|reveals?)\w*\b/i,shot:'Reveal the specific narrated discovery visually, showing the main subject noticing the named change or object'},
 {id:'explain',re:/\b(menunjukkan|memperlihatkan|menjelaskan|memperagakan|show|demonstrat)\w*\b/i,shot:'The named subject visibly demonstrates the exact object or movement referred to in this scene, not a generic pose'},
 {id:'finish',re:/\b(akhirnya|hasilnya|berhasil|selesai|pada akhirnya|finish|result|outcome)\w*\b/i,shot:'Show the outcome of the exact action and its physical result, without restarting the earlier activity'}
];
function normalize(t){return String(t||'').replace(/\s+/gu,' ').trim();}
function extractCandidate(sentence,previousId){
 const matches=actions.filter(r=>r.re.test(sentence));
 return matches.find(x=>x.id!==previousId)||matches[0]||null;
}
// A 60s narration cut into 10 clips can split sentences mid-phrase.
// Restore the containing *complete sentence* for visual grounding, then show
// an escalating start/action/result instead of regenerating identical motion.
function semanticContext(voices,index){
 const texts=(voices||[]).map(normalize);
 const full=texts.join(' ');
 let offset=0;
 const spans=texts.map(t=>{const a=offset;offset+=t.length+1;return [a,a+t.length];});
 const sentences=[];
 const re=/[^.!?]+(?:[.!?]+[”"']*|$)/gu;let m;
 while((m=re.exec(full))!==null){if(m[0].trim())sentences.push({text:normalize(m[0]),start:m.index,end:m.index+m[0].length});}
 const overlap=(a,b,c,d)=>Math.max(0,Math.min(b,d)-Math.max(a,c));
 const [start,end]=spans[index]||[0,0];
 const chosen=sentences.reduce((best,v)=>overlap(start,end,v.start,v.end)>overlap(start,end,best.start,best.end)?v:best,sentences[0]||{text:texts[index]||'',start:0,end:0});
 const siblings=spans.map(([a,b],i)=>overlap(a,b,chosen.start,chosen.end)>0?i:-1).filter(i=>i>=0);
 const phase=Math.max(0,siblings.indexOf(index));
 return {text:chosen.text,phase,total:siblings.length,original:texts[index]||''};
}
function makeShot(voices,index,enhancement){
 const texts=(voices||[]).map(normalize);
 const context=semanticContext(texts,index);
 const text=context.text||texts[index]||'';
 const prevIndex=Math.max(0,index-1),prior=semanticContext(texts,prevIndex);
 const previous=extractCandidate(prior.text,null)?.id;
 const selected=extractCandidate(text,context.total>1?null:(index===0?null:previous));
 const profile=cameras[index % cameras.length];
 const safety='Do not restart, re-enact or repeat the same generic pose from an earlier clip.';
 const fallback=`Interpret the complete narration sentence as one concrete visible event, preserving its exact named subject and objects: “${text.slice(0,350)}”. ${safety}`;
 const described=enhancement&&typeof enhancement==='object'&&normalize(enhancement.action).length>=20;
 const baseAction=selected?`${selected.shot}. Complete sentence: “${text.slice(0,290)}”. ${safety}`:fallback;
 const progress=context.total>1?(
  context.phase===0?'FIRST STAGE ONLY: show the subject physically starting to carry out this event; emphasize initiating contact or movement, and do NOT complete the action yet.':
  context.phase===context.total-1?'FINAL STAGE ONLY: show the immediate visible physical RESULT of this same event; do NOT go back and repeat the setup.':
  'MIDDLE STAGE ONLY: show the actual decisive MOVEMENT already initiated in the preceding clip, but not the final reaction.'
 ):'SINGLE STAGE: show one clear beginning, physical action and its outcome within this clip.';
 return {
  id:(selected?.id||'narration')+'-'+context.phase+'of'+context.total,
  action:described?normalize(enhancement.action):`${progress} ${baseAction}`,
  setting:described?normalize(enhancement.setting||''):'Only the established setting and specific props grounded in the narration.',
  camera:described&&normalize(enhancement.camera)?normalize(enhancement.camera):`${profile.shot}; ${profile.move}`,
  previous:texts[index-1]||'',next:texts[index+1]||'',
  uniqueId:`Scene ${index+1} / ${texts.length}`
 };
}

function all(voices,enhancements=[]){return (voices||[]).map((_,i)=>makeShot(voices,i,enhancements[i]));}
return {makeShot,semanticContext,all,actions,cameras};
});
