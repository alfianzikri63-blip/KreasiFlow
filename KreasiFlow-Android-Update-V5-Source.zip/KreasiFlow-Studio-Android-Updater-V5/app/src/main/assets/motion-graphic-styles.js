/* KreasiFlow v5.0.41 — shared motion-graphics style bible for storyboard + Google Flow. */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.KreasiFlowMotionStyles=api;
})(typeof globalThis!=='undefined'?globalThis:null,function(){
 'use strict';
 const STYLES=Object.freeze({
  '2D Flat Vector Motion Graphic':Object.freeze({
    icon:'🟦',description:'★ Default · Minimalis, garis tegas, geometri datar, warna solid; tidak realistis/3D',
    bible:'PURE 2D FLAT VECTOR MOTION GRAPHIC ONLY. Every object, environment, character and effect uses clean editable-looking vector silhouettes, flat geometric circles, rectangles, triangles and simple curves, strong consistent crisp outlines, solid opaque color fills and a limited coherent palette. Flat uniform backgrounds, uncluttered negative space, deliberate graphic hierarchy. Preserve the same line thickness, palette, scale and character identity across every scene. STRICT NO-3D RULE: NO CGI, no extruded objects, no photorealism or live action, no realistic material textures, no fabric/skin detail, no depth-of-field, no bokeh, no cinematic lighting, no realistic shadow gradients, no volumetric lighting, no 3D perspective, no realistic depth, no isometric rendering, no glossy reflections. Must look like pure polished 2D vector artwork at all times.',
    movement:'Flat-plane 2D motion only: shape translation, squash and stretch, flat rotation, scale, masked reveals, clean hard-edge wipes, rhythmic timing and smooth easing. Each scene must show a DISTINCT story-driven action, prop interaction and 2D composition without changing the recurring character design or geometric visual language. No 3D orbit, dolly or perspective camera simulation; no cinematic realism.',
    preview:'Default baru · Murni 2D flat vector: geometri datar, outline tegas, warna solid, tanpa bayangan realistis/CGI.'
  }),
  'Motion Graphic 2D':Object.freeze({
    icon:'🟩',description:'Vektor 2D, bentuk dinamis, transisi halus',
    bible:'Flat 2D vector motion graphics, clean geometric shapes, consistent bold silhouettes, polished smooth easing, a compact stable color palette, crisp graphic edges, layered 2D parallax, minimalist editorial composition. Strictly 2D: no photoreal people, no live action, no volumetric 3D, no random changes of illustration medium.',
    movement:'Animate shapes through deliberate slide, scale, rotation and mask reveals. Make each scene a unique visual event with one clear kinetic transformation and a fresh but coherent camera framing.',
    preview:'Animasi vektor datar; bentuk dan warna konsisten antar-scene.'
  }),
  'Motion Graphic 3D':Object.freeze({
    icon:'🧊',description:'Geometri 3D, rotasi objek, kamera sinematik',
    bible:'Stylized 3D motion design using clean consistent geometric objects, satin/matte material finishes, studio-quality soft shadows, controlled reflections, coherent lighting direction and a unified limited palette. Maintain identical object geometry and material identity when the same subject returns. No photoreal humans, random styles, changing shape language or inconsistent scale.',
    movement:'Animate purposeful 3D rotations, assembly, stacking, unfolding and dolly/orbit camera moves around one principal object. Vary action and composition between scenes while keeping material, palette and geometry locked.',
    preview:'Bentuk 3D dengan material, pencahayaan dan palet yang stabil.'
  }),
  'Motion Graphic Edukasi':Object.freeze({
    icon:'📊',description:'Diagram edukasi, alur proses, infografis bergerak',
    bible:'Clear educational explanatory motion graphics with a consistent flat/isometric visual system, clean labeled-free diagrams, legible color-coded arrows and icons, precise spatial relationships, uncluttered backgrounds and consistent palette. Prioritize causal explanations over decoration. Keep factual mechanics and diagram symbols consistent across the film. No irrelevant objects or false physical mechanisms.',
    movement:'Demonstrate one specific stage of a process per clip by animating a flow path, clean cutaway, cause-and-effect reveal, or an unambiguous before-and-after state. Scenes must build understanding without repeating the same process step.',
    preview:'Diagram dan aliran informasi yang bergerak sesuai naskah.'
  }),
  'Kinetic Typography':Object.freeze({
    icon:'🔤',description:'Huruf bergerak, ritme tipografi, komposisi dinamis',
    bible:'Premium 2D kinetic typography motion design with one consistent typography family, type weights, brand palette, visual hierarchy, negative space, and baseline grid across the entire film. Sharp readable letterforms, stable line spacing and no accidental spelling changes. No photographic subjects or inconsistent font families.',
    movement:'Use rhythmic animated letterforms, tracking, scale, sliding, wipe and mask transitions synchronized to a clear concept. Include at most one or two SHORT keywords from the supplied narration where wording is necessary; if legibility cannot be assured, animate abstract letterforms instead. No subtitle transcription, no watermarks, no fabricated claims.',
    preview:'Pergerakan bentuk huruf; teks hasil generatif perlu dicek ejaannya.'
  })
 });
 function get(name){return Object.prototype.hasOwnProperty.call(STYLES,name)?STYLES[name]:null;}
 function isMotion(name){return !!get(name);}
 function isTypography(name){return name==='Kinetic Typography';}
 function rule(name){const x=get(name);if(!x)return '';return 'MOTION GRAPHIC STYLE LOCK — APPLY TO EVERY SCENE: '+x.bible+' MOTION LANGUAGE: '+x.movement+' CONTINUITY: same palette, line weight or material, recurring objects, and character design throughout; vary only the narration-matched event, action, camera and framing.';}
 function aiTextRule(name){return rule(name)+(isTypography(name)?' NOTE: the animated typographic words are design elements, NOT subtitles or narration captions; use exact short words only if supplied by the narration.':'');}
 return Object.freeze({STYLES,get,isMotion,isTypography,rule,aiTextRule,names:()=>Object.keys(STYLES)});
});
