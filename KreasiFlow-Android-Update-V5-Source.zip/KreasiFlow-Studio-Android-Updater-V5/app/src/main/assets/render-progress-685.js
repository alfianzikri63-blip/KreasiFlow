(function(root,factory){const api=factory();if(typeof module==='object')module.exports=api;else root.KFRender685=api;})(globalThis,function(){
 'use strict';
 function frameProgress(telemetry,phase){
  const total=Number(telemetry?.frameTotal),frames=Number(telemetry?.frames);
  if(phase!=='video'||!Number.isFinite(total)||total<=0||!Number.isFinite(frames)||frames<0)return null;
  return {value:Math.min(total,frames),total};
 }
 function activity(state,age){
  if(state==='queued')return 'Menunggu layanan Android.';
  if(state==='running'&&age>=90000)return 'Belum ada kemajuan terukur selama 90 detik. Layanan masih melaporkan render aktif.';
  if(state==='running'&&age>=25000)return 'Tahap ini berjalan lambat atau sedang menunggu codec.';
  if(state==='cancelled')return 'Render dibatalkan.';
  if(state==='interrupted')return 'Render terhenti.';
  if(state==='error')return 'Render gagal.';
  return '';
 }
 function immutableKey(project,source,kind,options=[]){
  if(typeof source!=='string'||!source.startsWith('blob:'))return '';
  return JSON.stringify([project,source,kind,options]);
 }
 class AssetCache {
  constructor(limit=128*1024*1024,maximum=110){this.entries=new Map();this.limit=limit;this.maximum=maximum;this.bytes=0;}
  get(key,valid){
   if(!key)return null;
   const row=this.entries.get(key);
   if(!row)return null;
   if(!valid(row.id)){this.drop(key);return null;}
   this.entries.delete(key);this.entries.set(key,row);return row.id;
  }
  drop(key){
   const row=this.entries.get(key);
   if(row){this.entries.delete(key);this.bytes-=row.bytes;}
   return row?.id;
  }
  remember(key,id,bytes){if(!key)return false;this.drop(key);this.entries.set(key,{id,bytes});this.bytes+=bytes;return true;}
  trim(protectedIds=new Set(),incoming=0,items=0){
   const released=[];
   for(const [key,row] of this.entries){
    if(this.bytes+incoming<=this.limit&&this.entries.size+items<=this.maximum)break;
    if(!protectedIds.has(row.id))released.push(this.drop(key));
   }
   return released;
  }
 }
 return {frameProgress,activity,immutableKey,AssetCache};
});
