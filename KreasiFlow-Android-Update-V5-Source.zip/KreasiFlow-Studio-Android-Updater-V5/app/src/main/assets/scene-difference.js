/* KreasiFlow v5.0.36 — offline checker for storyboard shot descriptions.
 * Compares physical actions and camera design, not recurring character identity.
 * Does NOT claim to compare generated pixels; MP4 verification is separate.
 */
(function(root,factory){
 const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;
 root.KreasiFlowSceneDifference=api;
})(typeof window!=='undefined'?window:globalThis,function(){
 'use strict';
 const stop=new Set(('the a an and or with on in at of into to from for by as this that is are then will when after before same scene shot footage clip video camera subject character main person continues once first second finally next previous cinematic frame image visible shows show depicting unique distinct realistic high quality naturally smooth slow gentle dynamic portrait landscape medium shot close up view angle matching story scene action camera motion no text subtitles narration style identity consistent without avoid different').split(' '));
 function normalize(s){return String(s||'').toLowerCase().replace(/[^\p{L}\p{N} ]/gu,' ').replace(/\s+/g,' ').trim();}
 function tokens(s){return new Set(normalize(s).split(' ').filter(x=>x.length>2&&!stop.has(x)));}
 function similarity(a,b){const x=tokens(a),y=tokens(b);if(!x.size&&!y.size)return 0;let n=0;for(const v of x)if(y.has(v))n++;return n/Math.max(1,x.size+y.size-n);}
 function fields(sc){const d=sc?.flowShot||{};return {action:String(d.action||sc?.videoPrompt||''),camera:String(d.camera||''),setting:String(d.setting||''),visual:String(sc?.prompt||'')};}
 function compare(a,b){const x=fields(a),y=fields(b),action=similarity(x.action,y.action),camera=similarity(x.camera,y.camera),setting=similarity(x.setting,y.setting),visual=similarity(x.visual,y.visual);
  const score=.58*action+.25*camera+.07*setting+.10*visual;
  const risk=action>=.79||(action>=.61&&camera>=.52)||score>=.68||(action>=.48&&camera>=.90);
  const review=!risk&&(action>=.57||score>=.48||camera>=.87&&action>=.30);
  return {score:Math.round(score*100),action:Math.round(action*100),camera:Math.round(camera*100),setting:Math.round(setting*100),visual:Math.round(visual*100),status:risk?'risk':review?'review':'distinct'};
 }
 function audit(scenes){const items=(scenes||[]).map((_,i)=>({scene:i+1,status:'distinct',nearest:0,score:0,action:0,camera:0}));const conflicts=[];
  for(let i=0;i<items.length;i++)for(let j=0;j<i;j++){
   const c=compare(scenes[i],scenes[j]);if(c.score>items[i].score){Object.assign(items[i],{nearest:j+1,score:c.score,action:c.action,camera:c.camera});}
   if(c.status==='risk'||c.status==='review')conflicts.push({scene:i+1,against:j+1,...c});
  }
  items.forEach((item,i)=>{const local=conflicts.filter(x=>x.scene===i+1||x.against===i+1);item.status=local.some(x=>x.status==='risk')?'risk':local.length?'review':'distinct';});
  return {items,conflicts,risk:conflicts.filter(x=>x.status==='risk').length,review:conflicts.filter(x=>x.status==='review').length};
 }
 return {normalize,tokens,similarity,fields,compare,audit};
});
