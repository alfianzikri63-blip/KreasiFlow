/* KreasiFlow v5.0.30 — sentence-aware, deterministic, no API or DOM. */
(function(root,factory){
 const api=factory(); if(typeof module==='object'&&module.exports)module.exports=api;
 root.KreasiFlowScenePlanner=api;
})(typeof window!=='undefined'?window:globalThis,function(){
'use strict';
function normalize(text){return String(text||'').replace(/\s+/gu,' ').trim();}
function wordCount(text){return normalize(text).split(/\s+/u).filter(Boolean).length;}
function sentenceUnits(text){
 const paragraphs=String(text||'').replace(/\r\n?/g,'\n').split(/\n{2,}/u).map(normalize).filter(Boolean);
 return paragraphs.flatMap(para=>para.match(/[^.!?]+(?:[.!?]+["”']*|$)/gu)||[para]).map(normalize).filter(Boolean);
}
function semanticSplit(text,wordBudget=12){
 const source=normalize(text);if(!source)return [];
 const budget=Math.max(5,Math.round(Number(wordBudget)||12));
 const sentences=sentenceUnits(source);
 const result=[];
 let current='',length=0;
 for(const sentence of sentences){
  const count=wordCount(sentence);
  // Use real punctuation as the default scene boundary, never split solely by
  // word count. A longer sentence stays intact instead of ending after 'kecuali'.
  if(current && length+count>Math.ceil(budget*1.25)){
   result.push(current);current='';length=0;
  }
  current+=(current?' ':'')+sentence;length+=count;
 }
 if(current)result.push(current);
 if(normalize(result.join(' '))!==source)throw Error('Pembagian scene tidak cocok dengan sumber narasi');
 return result;
}
function plan(text,totalSeconds,secondsPerScene=5,maximumScenes=100){
 const clean=normalize(text);if(!clean)return [];
 const duration=Math.max(1,Number(totalSeconds)||60);
 const clip=Math.max(2,Number(secondsPerScene)||5);
 const budget=Math.max(6,Math.round(clip*2.35));
 let chunks=semanticSplit(clean,budget);
 const limit=Math.min(100,Math.max(1,Math.round(Number(maximumScenes)||100)));
 // If there are more separate sentences than allowed scenes, merge neighboring
 // sentences; never discard one or split at a dangling conjunction.
 if(chunks.length>limit){
  const all=chunks;chunks=[];
  for(let i=0;i<limit;i++){
   const start=Math.floor(i*all.length/limit),end=Math.floor((i+1)*all.length/limit);
   chunks.push(all.slice(start,Math.max(start+1,end)).join(' '));
  }
 }
 const totalWords=wordCount(clean);
 let elapsedWords=0;
 return chunks.map((voice,i)=>{
  const startSec=duration*elapsedWords/totalWords;
  elapsedWords+=wordCount(voice);
  const endSec=i===chunks.length-1?duration:duration*elapsedWords/totalWords;
  return {voice,startSec,endSec,durationSec:endSec-startSec,estimated:true};
 });
}
function narrationMatches(text,scenes){return normalize(text)===normalize((scenes||[]).map(s=>s.voice||'').join(' '));}
return {normalize,wordCount,sentenceUnits,semanticSplit,plan,narrationMatches};
});
