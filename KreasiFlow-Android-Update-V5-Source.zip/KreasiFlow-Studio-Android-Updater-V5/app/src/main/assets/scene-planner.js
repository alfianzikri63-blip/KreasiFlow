/* KreasiFlow v5.0.30 — sentence-aware, deterministic, no API or DOM. */
(function(root,factory){
 const api=factory(); if(typeof module==='object'&&module.exports)module.exports=api;
 root.KreasiFlowScenePlanner=api;
})(typeof window!=='undefined'?window:globalThis,function(){
'use strict';
function normalize(text){return String(text||'').replace(/\s+/gu,' ').trim();}
function wordCount(text){return normalize(text).split(/\s+/u).filter(Boolean).length;}
function sentenceUnits(text){
 const paragraphs=String(text||'').replace(/\r\n?/g,'\n').split(/\n{2,}/u).map(normalize).filter(Boolean);
 return paragraphs.flatMap(para=>para.match(/[^.!?]+(?:[.!?]+["”']*|$)/gu)||[para]).map(normalize).filter(Boolean);
}
function semanticSplit(text,wordBudget=12){
 const source=normalize(text);if(!source)return [];
 const budget=Math.max(5,Math.round(Number(wordBudget)||12));
 const sentences=sentenceUnits(source);
 const result=[];
 let current='',length=0;
 for(const sentence of sentences){
  const count=wordCount(sentence);
  // Use real punctuation as the default scene boundary, never split solely by
  // word count. A longer sentence stays intact instead of ending after 'kecuali'.
  if(current && length+count>Math.ceil(budget*1.25)){
   result.push(current);current='';length=0;
  }
  current+=(current?' ':'')+sentence;length+=count;
 }
 if(current)result.push(current);
 if(normalize(result.join(' '))!==source)throw Error('Pembagian scene tidak cocok dengan sumber narasi');
 return result;
}
// Both the Process estimate and the actual storyboard use this exact calculation.
// Very short narrations get fewer scenes rather than duplicated filler.
function targetCount(text,totalSeconds,secondsPerScene=6,maximumScenes=100,outroText=""){
 if(outroText)return plan(text,totalSeconds,secondsPerScene,maximumScenes,outroText).length;
 const clean=normalize(text);if(!clean)return 0;
 const words=wordCount(clean),duration=Math.max(1,Number(totalSeconds)||60);
 const clip=Math.max(2,Number(secondsPerScene)||6);
 const limit=Math.min(100,Math.max(1,Math.round(Number(maximumScenes)||100)));
 return Math.min(limit,Math.max(1,Math.ceil(duration/clip)),Math.max(1,Math.ceil(words/5)));
}
function splitBalanced(text,requested){
 const source=normalize(text);if(!source)return [];
 const chunks=semanticSplit(source,Math.max(5,Math.ceil(wordCount(source)/requested)));
 // Use commas and sentence punctuation first when another scene is needed.
 function bisect(part){
  const words=part.split(/\s+/u),n=words.length;
  if(n<6)return null;
  let best=-1,score=Infinity;
  for(let i=3;i<=n-3;i++){
   const tail=words[i-1],next=words[i].toLowerCase().replace(/^[^\p{L}]+/u,'');
   const boundary=/[.!?;:]$/.test(tail)?-4:/[,]$/.test(tail)?-2:0;
   const connective=/^(dan|atau|yang|di|ke|dari|dengan|untuk|tetapi|namun|karena|sehingga|lalu|pada|the|and|or|of|to|in|a)$/i.test(next)?2:0;
   const cost=Math.abs((n-i)-i)*1.25+boundary+connective;
   if(cost<score){score=cost;best=i;}
  }
  return best>0?[words.slice(0,best).join(' '),words.slice(best).join(' ')]:null;
 }
 while(chunks.length<requested){
  let index=-1,weight=-1,parts=null;
  for(let i=0;i<chunks.length;i++){
   const candidate=bisect(chunks[i]);if(!candidate)continue;
   const n=wordCount(chunks[i]);if(n>weight){index=i;weight=n;parts=candidate;}
  }
  if(index<0)break;
  chunks.splice(index,1,...parts);
 }
 while(chunks.length>requested){
  let idx=0,best=Infinity;
  for(let i=0;i<chunks.length-1;i++){
   const cost=wordCount(chunks[i])+wordCount(chunks[i+1]);
   if(cost<best){idx=i;best=cost;}
  }
  chunks.splice(idx,2,chunks[idx]+' '+chunks[idx+1]);
 }
 if(normalize(chunks.join(' '))!==source)throw Error('Pembagian scene menghilangkan atau mengulang narasi');
 return chunks;
}
function plan(text,totalSeconds,secondsPerScene=5,maximumScenes=100,outroText=""){
 const full=normalize(text),tail=normalize(outroText),limit=Math.min(100,Math.max(1,Math.round(Number(maximumScenes)||100)));
 if(tail&&full.endsWith(' '+tail)&&limit>1){
  const body=full.slice(0,-tail.length).trim(),duration=Math.max(1,Number(totalSeconds)||60);
  const boundary=duration*wordCount(body)/wordCount(full);
  if(boundary>=1&&duration-boundary>=1){
   const outCount=Math.min(limit-1,targetCount(tail,duration-boundary,secondsPerScene,limit-1));
   const main=plan(body,boundary,secondsPerScene,limit-outCount);
   const end=plan(tail,duration-boundary,secondsPerScene,outCount).map(p=>({...p,startSec:p.startSec+boundary,endSec:p.endSec+boundary,outro:true}));
   return [...main,...end];
  }
 }

 const clean=normalize(text);if(!clean)return [];
 const duration=Math.max(1,Number(totalSeconds)||60);
 const target=targetCount(clean,duration,secondsPerScene,maximumScenes);
 const chunks=splitBalanced(clean,target);
 const totalWords=wordCount(clean);
 let elapsedWords=0;
 return chunks.map((voice,i)=>{
  const startSec=duration*elapsedWords/totalWords;
  elapsedWords+=wordCount(voice);
  const endSec=i===chunks.length-1?duration:duration*elapsedWords/totalWords;
  return {voice,startSec,endSec,durationSec:endSec-startSec,estimated:true};
 });
}
// Reserve bounded visual slots while keeping every spoken word in order.
function planCapped(text,totalSeconds,secondsPerScene=8,maximumScenes=100,outroText=""){
 const clean=normalize(text);
 if(!clean)return [];
 const duration=Math.max(1,Number(totalSeconds)||60);
 const clip=Math.min(8,Math.max(2,Number(secondsPerScene)||8));
 const limit=Math.min(100,Math.max(1,Math.round(Number(maximumScenes)||100)));
 const words=clean.split(' ');
 const tail=normalize(outroText);
 const tailWords=tail && clean.endsWith(' '+tail)?wordCount(tail):0;
 const segments=tailWords?[
  {words:words.slice(0,-tailWords),fraction:1-tailWords/words.length},
  {words:words.slice(-tailWords),fraction:tailWords/words.length,outro:true}
 ]:[{words,fraction:1}];
 let elapsed=0;
 const planned=segments.flatMap(({words:part,fraction,outro},index)=>{
  const end=index===segments.length-1?duration:duration*fraction;
  const start=elapsed;
  elapsed=end;
  const span=end-start;
  const count=Math.ceil(span/clip-1e-10);
  if(count>part.length||count>limit)return [];
  let cursor=0;
  return Array.from({length:count},(_,i)=>{
   const ideal=Math.round(part.length*(i+1)/count);
   const low=Math.max(cursor+1,ideal-2);
   const high=Math.min(ideal+2,part.length-(count-i-1));
   let boundary=i===count-1?part.length:Math.min(high,Math.max(low,ideal));
   if(i<count-1){
    const priority=n=>(/[.!?][”"']?$/.test(part[n-1])?4:/[,;:]$/.test(part[n-1])?2:0)-Math.abs(ideal-n);
    for(let n=low;n<=high;n++)if(priority(n)>priority(boundary))boundary=n;
   }
   const voice=part.slice(cursor,boundary).join(' ');
   cursor=boundary;
   const startSec=start+span*i/count,endSec=i===count-1?end:start+span*(i+1)/count;
   return {voice,startSec,endSec,durationSec:endSec-startSec,estimated:true,...(outro?{outro:true}:{})};
  });
 });
 return planned.length<=limit&&narrationMatches(clean,planned)?planned:[];
}
function narrationMatches(text,scenes){return normalize(text)===normalize((scenes||[]).map(s=>s.voice||'').join(' '));}
return {normalize,wordCount,sentenceUnits,semanticSplit,targetCount,splitBalanced,plan,planCapped,narrationMatches};
});
