/* KreasiFlow scene planner v5.0.27 — deterministic; no network, keys, or DOM. */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  root.KreasiFlowScenePlanner=api;
})(typeof window!=='undefined'?window:globalThis,function(){
'use strict';
function normalize(text){return String(text||'').replace(/\s+/gu,' ').trim();}
function wordCount(text){return normalize(text).split(/\s+/u).filter(Boolean).length;}
function plan(text,totalSeconds,secondsPerScene=5,maximumScenes=100){
 const clean=normalize(text);
 if(!clean)return [];
 const words=clean.split(/\s+/u);
 const duration=Math.max(1,Number(totalSeconds)||60);
 const size=Math.max(2,Number(secondsPerScene)||5);
 const upper=Math.min(100,Math.max(1,Math.round(Number(maximumScenes)||100)));
 // Do not fabricate narration or create dozens of empty/one-word scenes.
 const target=Math.max(1,Math.min(upper,Math.ceil(duration/size),Math.ceil(words.length/5)));
 const result=[];
 let used=0;
 for(let i=0;i<target;i++){
   const end=Math.max(used+1,Math.round((i+1)*words.length/target));
   const current=words.slice(used,end).join(' ');
   const startSec=duration*used/words.length;
   const endSec=i===target-1?duration:duration*end/words.length;
   result.push({voice:current,startSec,endSec,durationSec:endSec-startSec,estimated:true});
   used=end;
 }
 return result;
}
function narrationMatches(text,scenes){return normalize(text)===normalize((scenes||[]).map(s=>s.voice||'').join(' '));}
return {normalize,wordCount,plan,narrationMatches};
});
