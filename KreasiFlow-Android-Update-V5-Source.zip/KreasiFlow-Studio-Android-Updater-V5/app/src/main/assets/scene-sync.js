/* KreasiFlow 5.0.33 — align storyboard scene boundaries to actual VO timestamp cues.
 * No network calls; original audio is the master clock. Exported for Node regression tests.
 */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.KFSceneSync=api;})(typeof window!=='undefined'?window:(typeof globalThis!=='undefined'?globalThis:null),function(){'use strict';
function tokens(text){return String(text||'').toLocaleLowerCase('id-ID').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').match(/[a-z0-9]+/g)||[];}
function monotonic(starts,duration){let prev=0;for(let i=1;i<starts.length-1;i++){if(!Number.isFinite(starts[i])||starts[i]<=prev+.09||starts[i]>=duration-.09)return false;prev=starts[i];}return true;}
function weighted(counts,duration){let total=counts.reduce((a,b)=>a+b,0)||1,pos=0;const starts=[0];for(let i=0;i<counts.length-1;i++){pos+=duration*counts[i]/total;starts.push(pos);}starts.push(duration);return starts;}
function plan(scenes,cues,duration,overrides={}){
 const N=Array.isArray(scenes)?scenes.length:0,sec=Number(duration);
 if(!N||!Number.isFinite(sec)||sec<=0||sec>600)throw Error('Scene/durasi VO tidak valid');
 const words=scenes.map(s=>tokens(typeof s==='string'?s:(s.voice||s.narration||'')));
 const weights=words.map(w=>Math.max(1,w.length));let starts=weighted(weights,sec),method='proporsi kata narasi',matched=0;
 const cuesValid=Array.isArray(cues)&&cues.length&&cues.every(c=>Number.isFinite(Number(c.start))&&Number.isFinite(Number(c.end))&&Number(c.end)>Number(c.start)&&Number(c.start)>=0&&Number(c.end)<=sec+.2);
 if(cuesValid&&N>1){
  const source=words.flat(),voice=[];
  for(const cue of cues){const w=tokens(cue.text);const st=Number(cue.start),en=Number(cue.end);for(let i=0;i<w.length;i++){voice.push({token:w[i],time:st+(en-st)*i/w.length});}}
  if(source.length&&voice.length&&source.length<=2000&&voice.length<=2000){
   // Global LCS alignment tolerates minor speech-recognition edits without moving scene order.
   const m=voice.length,n=source.length,dp=new Uint16Array((n+1)*(m+1));
   for(let i=n-1;i>=0;i--)for(let j=m-1;j>=0;j--){const at=i*(m+1)+j;dp[at]=source[i]===voice[j].token?1+dp[at+m+2]:Math.max(dp[at+m+1],dp[at+1]);}
   const hit=new Map();let i=0,j=0;
   while(i<n&&j<m){const at=i*(m+1)+j;if(source[i]===voice[j].token){hit.set(i,j);matched++;i++;j++;}else if(dp[at+m+1]>=dp[at+1])i++;else j++;}
   if(matched>=Math.max(3,Math.ceil(Math.min(n,m)*.36))){
    const adjusted=[0];let pos=0;
    for(let s=0;s<N-1;s++){
     pos+=words[s].length;let before=-1,after=-1;
     for(let x=pos-1;x>=0;x--)if(hit.has(x)){before=hit.get(x);break;}
     for(let x=pos;x<n;x++)if(hit.has(x)){after=hit.get(x);break;}
     let newTime=starts[s+1];
     if(after>=0&&before>=0)newTime=(voice[after].time+voice[before].time)/2;
     else if(after>=0)newTime=voice[after].time;
     else if(before>=0)newTime=voice[before].time;
     adjusted.push(Math.max(.1,Math.min(sec-.1,newTime)));
    }
    adjusted.push(sec);
    if(monotonic(adjusted,sec)){starts=adjusted;method='cocok kata transkrip VO';}
   }
  }
 }
 // Per-scene user overrides take priority. Reject collisions rather than silently reordering visuals.
 const user=starts.slice();for(let i=1;i<N;i++)if(overrides&&overrides[i]!==undefined&&overrides[i]!==''&&overrides[i]!==null){const value=Number(overrides[i]);if(!Number.isFinite(value))throw Error('Timestamp manual scene '+(i+1)+' tidak valid');user[i]=value;}
 if(!monotonic(user,sec))throw Error('Batas scene bertumpuk/tidak urut. Koreksi waktu mulai scene.');
 return {starts:user.map(v=>+v.toFixed(3)),method,matched};
}
return {tokens,plan};
});
