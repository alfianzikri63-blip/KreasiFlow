(function(root){'use strict';function assemble(clips,seconds,rate=24000){if(![4,6,8,10].includes(seconds)||!clips.length||clips.length*seconds>600)throw Error('Timeline tidak valid');const slot=seconds*rate,n=slot*clips.length;const buffer=new ArrayBuffer(44+n*2),v=new DataView(buffer);const str=(p,s)=>{for(let i=0;i<s.length;i++)v.setUint8(p+i,s.charCodeAt(i));};str(0,'RIFF');v.setUint32(4,36+n*2,true);str(8,'WAVE');str(12,'fmt ');v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,1,true);v.setUint32(24,rate,true);v.setUint32(28,rate*2,true);v.setUint16(32,2,true);v.setUint16(34,16,true);str(36,'data');v.setUint32(40,n*2,true);clips.forEach((c,i)=>{if(!c.length||c.length>slot)throw Error('VO scene '+(i+1)+' melebihi '+seconds+' detik atau kosong. Rekam ulang narasi lebih singkat.');for(let j=0;j<c.length;j++){const x=Math.max(-1,Math.min(1,c[j]));v.setInt16(44+2*(i*slot+j),Math.round(x*(x<0?32768:32767)),true);}});return buffer;}function match(lines,cues){const norm=s=>String(s).toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();const spoken=cues.filter(cue=>norm(cue.text));let pos=0;const out=lines.map(line=>{const target=norm(line);let text='',start=pos;while(pos<spoken.length){text=norm(text+' '+spoken[pos++].text);if(text===target)return {start:spoken[start].start,end:spoken[pos-1].end};if(!target.startsWith(text+' '))break;}throw Error('Transkrip tidak cocok: '+line+' (perbaiki cue SRT sesuai dialog)');});if(pos!==spoken.length)throw Error('Ada cue transkrip tambahan');return out;}function pcm(clips,rate=24000){
 const length=clips.reduce((sum,clip)=>sum+clip.length,0);
 if(!length||length>rate*600)throw Error('Durasi rekaman tidak valid.');
 const buffer=new ArrayBuffer(44+length*2),v=new DataView(buffer);
 const write=(index,label)=>{for(const char of label)v.setUint8(index++,char.charCodeAt(0));};
 write(0,'RIFF');v.setUint32(4,36+length*2,true);write(8,'WAVE');write(12,'fmt ');
 v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,1,true);v.setUint32(24,rate,true);
 v.setUint32(28,rate*2,true);v.setUint16(32,2,true);v.setUint16(34,16,true);write(36,'data');v.setUint32(40,length*2,true);
 let offset=44;
 for(const clip of clips)for(const sample of clip){v.setInt16(offset,Math.round(Math.max(-1,Math.min(1,sample))*(sample<0?32768:32767)),true);offset+=2;}
 return buffer;
}
const api={assemble,match,pcm};if(typeof module==='object')module.exports=api;else root.KFSceneVoice=api;})(globalThis);
