/* KreasiFlow v5.0.54 — One MASTER text prompt, one image file PER scene.
 * Gemini API requests run individually: no claim that one API response contains all frames.
 */
(function(root,factory){
 const api=factory();
 if(typeof module==='object'&&module.exports)module.exports=api;
 if(root)root.KFSeparateFrames=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';
 function short(value,max=90){return String(value||'').replace(/\s+/g,' ').trim().split(' ').filter(Boolean).slice(0,max).join(' ');}
 function base(input={}){
  const ratio=String(input.ratio||'9:16').startsWith('16:9')?'16:9':'9:16';
  const style=short(input.style||'2D Flat Vector Motion Graphic',22);
  const rules=short(input.styleRules,input.fullStyleRules?500:105);
  const character=short(input.character,65);
  return {ratio,style,rule:`GLOBAL DESIGN LOCK: ${style}. ${rules||'Clean consistent color palette and recurring object shapes.'} `+
    (character?`Same recurring character in every applicable scene: ${character}. `:'')+
    `Keep recurring characters, outfit, geometry, material, scale and palette consistent; only actions, camera compositions and scene events differ. `+
    `Each resulting image must be a self-contained ${ratio} first frame, clean full-bleed composition, without panel borders, labels, numbers, typography or watermarks.`};
 }
 function scenes(input){if(!Array.isArray(input?.scenes)||input.scenes.length<1)throw Error('Buat storyboard terlebih dahulu.');return input.scenes;}
 function masterPrompt(input={}){
  const items=scenes(input),b=base(input);
  const lines=items.map((s,i)=>{
   const visual=short(s.prompt||s.flowShot?.action||s.voice||s.name,s.loopRule?250:56);
   const camera=short(s.flowShot?.camera,18);
   return `SCENE ${String(i+1).padStart(2,'0')} / ${short(s.name||'Adegan',12)}: ${visual}${camera?` Camera: ${camera}.`:''}${s.loopRule?' '+s.loopRule:''}`;
  });
  return `GEMINI IMAGE CREATION — ONE MASTER REQUEST FOR ${items.length} SEPARATE IMAGES.\n`+
   `Generate ${items.length} INDEPENDENT FULL-RESOLUTION images, one output image for EACH numbered scene below. `+
   `NOT a storyboard sheet, NOT a collage, NOT a grid, NOT several panels in one picture. `+
   `Do not put two scenes in one image. Every image must show only the single numbered scene. `+
   `Deliver individual image results in order (SCENE 01, SCENE 02, etc.); any scene numbers belong OUTSIDE image pixels. `+
   `If the image tool can only return one image per request, create Scene 01 first, then continue with Scene 02 onward as separate responses; do not combine them.\n`+
   `${b.rule}\n`+
   `PROJECT: ${short(input.title||'Video storyboard',22)}.\n`+
   `SCENES:\n${lines.join('\n')}\n`+
   `OUTPUT CHECK: Exactly one complete independent ${b.ratio} image per scene; same visual identity across the series; distinct composition and action for each scene. Never make a multi-panel image.`;
 }
 function scenePrompt(input={},index=0){
  const items=scenes(input);if(!Number.isSafeInteger(index)||index<0||index>=items.length)throw Error('Scene tidak ditemukan.');
  const b=base(input),s=items[index];
  return `GEMINI IMAGE — SCENE ${String(index+1).padStart(2,'0')}/${items.length}: Generate ONE standalone ${b.ratio} first-frame image ONLY. `+
   `Never create a contact sheet, collage, grid or multiple panels. ${b.rule} `+
   `Scene: ${short(s.prompt||s.flowShot?.action||s.voice||s.name,s.loopRule?250:72)}. `+
   `${s.flowShot?.camera?`Framing: ${short(s.flowShot.camera,22)}. `:''}`+
   (s.loopRule?s.loopRule+' ':'')+`No subtitles, no letters, no logos. Return ONE image file for this single scene.`;
 }
 function flowMasterPrompt(input={}){
  return masterPrompt(input)
    .replace(/^GEMINI IMAGE CREATION — ONE MASTER REQUEST/, 'GOOGLE FLOW / TEXT-TO-IMAGE — ONE MASTER REQUEST')
    .replace('If the image tool can only return one image per request, create Scene 01 first, then continue with Scene 02 onward as separate responses; do not combine them.',
      'Google Flow may only return one image at a time. If so, create the scenes in separate requests using their own scene prompts. One pasted prompt does not automate a batch.');
 }
 function flowScenePrompt(input={},index=0){
  return scenePrompt(input,index).replace(/^GEMINI IMAGE —/, 'GOOGLE FLOW / TEXT-TO-IMAGE —');
 }
 function orderFiles(files,count){
  const arr=Array.from(files||[]);if(!Number.isSafeInteger(count)||count<1)throw Error('Scene belum ada.');
  if(arr.length<1)throw Error('Pilih gambar terlebih dulu.');
  if(arr.length>count)throw Error(`File berjumlah ${arr.length}, lebih banyak dari ${count} scene.`);
  for(const f of arr){if(!['image/png','image/jpeg','image/webp'].includes(f.type)||f.size>12*1024*1024)throw Error('Gunakan PNG/JPG/WebP maksimum 12 MB per gambar.');}
  const matched=arr.map(f=>{const m=String(f.name||'').match(/(?:^|[^a-z0-9])(?:scene|frame|sc|s)[ _-]*0*(\d{1,3})(?:[^0-9]|$)/i);return m?Number(m[1])-1:null;});
  let indices;
  if(matched.every(Number.isInteger)){
   indices=matched;
   if(indices.some(i=>i<0||i>=count)||new Set(indices).size!==indices.length)throw Error('Nomor scene pada nama file duplikat atau di luar rentang. Periksa nama file Scene-01, Scene-02, dst.');
  }else if(matched.some(Number.isInteger))throw Error('Sebagian file punya nomor scene, sebagian tidak. Samakan semua nama atau hilangkan nomor, agar urutannya aman.');
  else {arr.sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),'en',{numeric:true,sensitivity:'base'}));indices=arr.map((_,i)=>i);}
  return arr.map((file,j)=>({index:indices[j],file})).sort((a,b)=>a.index-b.index);
 }
 return Object.freeze({base,masterPrompt,scenePrompt,flowMasterPrompt,flowScenePrompt,orderFiles});
});
