/* Smart narrated outro: one text request, no additional TTS API. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.KFSmartOutro=api;})(typeof window!=='undefined'?window:globalThis,function(){
'use strict';
const normalize=t=>String(t||'').replace(/\s+/gu,' ').trim();
const words=t=>normalize(t).split(/\s+/u).filter(Boolean).length;
const types={auto:'natural topic-specific conclusion and relevant question if appropriate',conclusion:'concise educational conclusion',question:'one thoughtful question inviting comments',cta:'natural invitation to follow or subscribe for related content',loop:'ending that naturally connects to the opening hook without repeating it',custom:'user-written outro'};
function config(s={}){const kind=Object.hasOwn(types,s.outroKind)?s.outroKind:'auto';const seconds=[4,8,12].includes(Number(s.outroSeconds))?Number(s.outroSeconds):8;return {enabled:s.outroEnabled===true,kind,seconds,custom:String(s.outroCustom||'').trim(),lang:s.lang||'Indonesia'};}
function extraWords(c){return !c.enabled?0:c.kind==='custom'?words(c.custom):Math.round(c.seconds*145/60);}
function rule(c){if(!c.enabled)return '';if(c.kind==='custom')return ' Naskah utama saja sesuai target kata utama. Jangan tambahkan CTA atau outro terpisah; aplikasi akan menambahkan outro pengguna setelah respons.';return ` Tambahkan OUTRO EKSTRA di luar target kata utama, sekitar ${extraWords(c)} kata (${c.seconds} detik pada 145 kata/menit). Gaya penutup: ${types[c.kind]}. Hubungkan dengan topik, tanpa fakta baru yang tidak terverifikasi. Khusus pemisahan ini, tulis penanda [OUTRO] sendirian pada baris baru setelah naskah utama, lalu teks outro yang dibacakan. Penanda bukan narasi. Hanya satu penanda, tidak ada label lain.`;}
function finish(raw,c,clean=x=>String(x||'').trim()){
 const text=String(raw||'').trim();const parts=text.split(/(?:^|\n)\s*\[OUTRO\]\s*(?:\n|$)/i);const body=clean(parts[0]);
 if(!body)throw Error('Naskah utama kosong.');
 if(!c.enabled)return {script:clean(text),outroText:'',seconds:0};
 let outro='';if(c.kind==='custom'){outro=clean(c.custom);if(!outro)throw Error('Isi narasi outro sendiri terlebih dahulu.');}
 else {outro=clean(parts.slice(1).join('\n'));if(!outro)throw Error('AI belum mengirim bagian outro. Ulangi Generate Naskah atau gunakan outro sendiri.');}
 const already=normalize(body).endsWith(' '+normalize(outro))||normalize(body)===normalize(outro);if(already)throw Error('Outro terduplikasi di naskah utama. Ulangi Generate Naskah.');
 return {script:body+'\n\n'+outro,outroText:outro,seconds:c.kind==='custom'?Math.max(1,Math.round(words(outro)*60/145)):c.seconds};
}
function local(c){const en=c.lang==='English';const options=en?{auto:'What other topic should we explore next? Share your ideas in the comments.',conclusion:'These details help us see how the pieces of this story fit together.',question:'Which part surprised you most? Share your thoughts in the comments below.',cta:'Follow for more stories and explanations like this. See you in the next video.',loop:'Now think back to our opening question. Does the story look different to you?'}:{auto:'Topik apa lagi yang ingin kamu ketahui? Bagikan ide kamu di kolom komentar.',conclusion:'Dari sini, kita bisa memahami hubungan antara berbagai bagian penting dalam kisah ini.',question:'Bagian mana yang paling mengejutkan menurut kamu? Ceritakan pendapatmu di kolom komentar.',cta:'Ikuti akun ini untuk cerita dan penjelasan menarik lainnya. Sampai jumpa di video berikutnya.',loop:'Sekarang, ingat kembali pertanyaan di awal. Apakah kamu melihat kisah ini dengan cara berbeda?'};return c.kind==='custom'?c.custom:options[c.kind]||options.auto;}
function suffix(text,outro){const a=normalize(text),b=normalize(outro);return b&&a.endsWith(' '+b)?{body:a.slice(0,-b.length).trim(),outro:b}:null;}
return {config,extraWords,rule,finish,local,suffix};
});
