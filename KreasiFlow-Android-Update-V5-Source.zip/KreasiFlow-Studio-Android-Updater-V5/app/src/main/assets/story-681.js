(function(root,factory){
 const api=factory();
 if(typeof module==='object'&&module.exports)module.exports=api;
 else root.KFStory=api;
})(globalThis,function(){
 'use strict';
 const caps=[4,6,8,10], perspectives=['auto','first','third','dialog'];
 const ratios={'9:16':[9,16],'16:9':[16,9],'1:1':[1,1],'4:5':[4,5],'21:9':[21,9]};
 const clean=(x,max=1000)=>String(x??'').replace(/\s+/gu,' ').trim().slice(0,max);
 const ratio=value=>Object.keys(ratios).find(key=>String(value).startsWith(key))||'9:16';
 function dimensions(value,resolution){
  const [w,h]=ratios[ratio(value)], size=Math.max(360,Math.min(2160,Number(resolution)||1080));
  const even=n=>Math.round(n/2)*2;
  return w>=h?[even(size*w/h),even(size)]:[even(size),even(size*h/w)];
 }
 function validateTimeline(starts,cap){
  if(!Array.isArray(starts)||starts.length<2||starts[0]!==0)throw Error('Timeline belum lengkap.');
  for(let i=1;i<starts.length;i++){
   const span=starts[i]-starts[i-1];
   if(!Number.isFinite(span)||span<=0||span>cap+1e-6)throw Error('Scene '+i+' melampaui batas '+cap+' detik atau tidak mempunyai durasi. Sesuaikan VO atau buat ulang storyboard.');
  }
 }
 function storyPrompt(kind,config,count,only){
  const schema=kind==='ideas'
   ?'{"ideas":[{"title":"","synopsis":"","conflict":"","characters":[""],"locations":[""],"mood":""}]}'
   :'{"scenes":[{"locationId":"","castIds":[""],"action":"","expression":"","camera":"","lighting":"","sfx":"","dialogues":[{"characterId":"", "text":"","emotion":"","delivery":"","expression":"","seconds":1}]}]}';
  return `Tulis cerita fiksi naratif dalam bahasa ${config.language}, dengan genre ${config.genre}. Hindari promosi, ulasan produk, rekomendasi belanja, dan judul edukasi.
 Sudut pandang: ${({auto:'pilih sesuai ide',first:'orang pertama melalui salah satu tokoh utama, identitas pembicara harus tetap jelas',third:'orang ketiga, narator opsional',dialog:'cerita dari aksi dan dialog tanpa narator'})[config.perspective]}. Ini sudut pandang narasi, bukan posisi kamera.
 ${config.adapt?'Pertahankan kejadian yang dinyatakan pengguna. Jangan mengarang kejadian, fakta, atau dialog yang tidak tersedia sebagai kenyataan. Gunakan dialog hanya jika informasi yang diberikan mendukungnya.':'Gunakan premis pengguna sebagai dasar cerita bebas.'}
 ${kind==='ideas'?'Beri tepat lima ide yang berbeda. Karakter dan lokasi usulan hanya berupa nama.':`Beri tepat ${only===undefined?count:1} scene${only===undefined?'':' pengganti untuk scene '+(only+1)}. Setiap aksi dan semua dialog dalam satu scene harus muat dalam ${config.slot?.toFixed(2)||config.cap} detik. Gunakan ID cast dan lokasi terdaftar saja. Untuk narasi gunakan characterId "narrator" jika mode mengizinkan. Jangan mengarang ID baru. Jika lokasi atau pemeran visual belum ditentukan, gunakan string atau daftar kosong. Dialog[] boleh kosong. Gunakan seconds sebagai durasi ucapan alami. Pisahkan percakapan panjang secara alami. Gunakan bahasa percakapan yang sesuai usia dan hubungan karakter. Isi emotion, delivery dan expression sebagai arahan terpisah dari kata yang dibaca.`}
 Kembalikan hanya JSON ${schema}.
 DATA CERITA: ${JSON.stringify(config)}`;
 }
 function ideas(result){
  if(!Array.isArray(result?.ideas)||result.ideas.length!==5)throw Error('AI harus mengembalikan lima ide.');
  return result.ideas.map(item=>{
   if(!['title','synopsis','conflict','mood'].every(key=>clean(item?.[key]))||!Array.isArray(item.characters)||!Array.isArray(item.locations))throw Error('Salah satu ide AI belum lengkap.');
   return Object.fromEntries(Object.entries(item).map(([key,value])=>[key,Array.isArray(value)?value.map(x=>clean(x,80)).slice(0,12):clean(value)]));
  });
 }
 function scenes(result,config,count,previous=[],offset=0){
  if(!Array.isArray(result?.scenes)||result.scenes.length!==count)throw Error('AI harus mengembalikan '+count+' scene.');
  const cast=new Map(config.cast.map(item=>[item.id,item.name])), locations=new Set(config.locations.map(item=>item.id));
  if(config.perspective!=='dialog')cast.set('narrator','NARATOR');
  const limit=config.slot||config.cap;
  return result.scenes.map((row,i)=>{
   const index=offset+i, prior=previous[index], id=prior?.id||'scene-'+(index+1);
   if(!clean(row?.action)||!Array.isArray(row.dialogues)||!Array.isArray(row.castIds))throw Error('Scene '+(index+1)+' belum lengkap.');
   const castIds=[...new Set(row.castIds)];
   if(castIds.some(key=>!cast.has(key)||key==='narrator'))throw Error('Scene '+(index+1)+' memakai karakter yang belum terdaftar.');
   const locationId=row.locationId||'';
   if(locationId&&!locations.has(locationId))throw Error('Scene '+(index+1)+' memakai lokasi yang belum terdaftar.');
   const dialogues=row.dialogues.map((dialogue,j)=>{
    const text=clean(dialogue.text,750), seconds=Number(dialogue.seconds);
    const characterId=dialogue.characterId;
    if(!cast.has(characterId)||!text||!Number.isFinite(seconds)||seconds<=0)throw Error('Dialog scene '+(index+1)+' memakai pembicara atau durasi yang tidak valid.');
    return {id:prior?.dialogues?.[j]?.characterId===characterId&&prior.dialogues[j].text===text?prior.dialogues[j].id:id+'-line-'+(j+1),sceneId:id,characterId,speaker:cast.get(characterId),text,seconds,order:j+1,
     emotion:clean(dialogue.emotion,80),delivery:clean(dialogue.delivery,180),expression:clean(dialogue.expression,140)};
   });
   const spoken=dialogues.reduce((acc,d)=>acc+Math.max(d.seconds,d.text.split(' ').length/2.8),0);
   if(spoken>limit+.05)throw Error('Dialog scene '+(index+1)+' terlalu panjang untuk '+limit.toFixed(1)+' detik. Ringkas atau buat ulang adegan.');
   const name='Scene '+String(index+1).padStart(2,'0');
   return {...prior,id,name,locationId,castIds,dialogues,voice:dialogues.map(d=>d.text).join(' '),action:clean(row.action),
    expression:clean(row.expression,180),camera:clean(row.camera,240),lighting:clean(row.lighting,140),sfx:clean(row.sfx,140),startSec:index*limit,endSec:(index+1)*limit,timeEstimate:true};
  });
 }
 function groups(scenes){
  const result=new Map();
  scenes.forEach((scene,i)=>{
   const rows=Array.isArray(scene.dialogues)?scene.dialogues:scene.speaker?[{speaker:scene.speaker,text:scene.voice,id:'legacy-'+i}]:[];
   rows.forEach((entry,j)=>{
    if(!clean(entry.text))return;
    const name=entry.speaker;
    if(!result.has(name))result.set(name,[]);
    result.get(name).push({...entry,i,j});
   });
  });
  return [...result];
 }
 function align(starts,segments,limit,rate){
  const clips=starts.slice(0,-1).map((start,i)=>new Float32Array(Math.round(starts[i+1]*rate)-Math.round(start*rate)));
  const cues=[];
  for(const segment of segments.sort((a,b)=>a.row.i-b.row.i||a.row.j-b.row.j)){
   const {row,samples}=segment;
   const offset=clips[row.i].used||0;
   if(offset+samples.length>clips[row.i].length)throw Error('Ucapan melebihi slot scene '+(row.i+1)+'. Koreksi timestamp atau pecah scene.');
   clips[row.i].set(samples,offset);
   clips[row.i].used=offset+samples.length+Math.round(.12*rate);
   cues.push({start:starts[row.i]+offset/rate,end:starts[row.i]+(offset+samples.length)/rate,text:row.text,dialogueId:row.id});
  }
  validateTimeline(starts,limit);
  return {clips,cues};
 }
 return {caps,perspectives,ratios,ratio,dimensions,validateTimeline,storyPrompt,ideas,scenes,groups,align,clean};
});
