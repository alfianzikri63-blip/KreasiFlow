/* KreasiFlow v5.0.30 — narration-to-Flow storyboard continuity helper.
 * Offline, deterministic and unit-testable. No API access and no account keys.
 */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  root.KreasiFlowStoryContinuity=api;
})(typeof window!=='undefined'?window:globalThis,function(planner){
'use strict';
const norm=t=>String(t||'').replace(/\s+/gu,' ').trim();
const words=t=>norm(t).split(/\s+/u).filter(Boolean);
function sentenceChunks(text){
 const p=String(text||'').replace(/\r\n?/g,'\n').split(/\n{2,}/).map(norm).filter(Boolean);
 return p.flatMap(para=>para.match(/[^.!?]+(?:[.!?]+["”']*|$)/gu)||[para]).map(norm).filter(Boolean);
}
function splitNarration(text,totalSeconds,clipSeconds=8,outroText=""){
 const source=norm(text);if(!source)return [];
 const clip=Math.max(4,Math.min(12,Number(clipSeconds)||8));
 // Use the same sentence-aware budget as the Process and regular storyboard tabs.
 // Timing is an estimate weighted by spoken words until subtitle cues provide real timestamps.
 if(planner?.plan)return planner.plan(source,totalSeconds,clip,100,outroText);
 const chunks=sentenceChunks(source);
 const dur=Math.max(1,Number(totalSeconds)||60);
 let count=0;const total=words(source).length;
 return chunks.map((voice,i)=>{const startSec=dur*count/total;count+=words(voice).length;const endSec=i===chunks.length-1?dur:dur*count/total;return {voice,startSec,endSec,durationSec:endSec-startSec,estimated:true};});
}
function narrationMatches(text,scenes){return norm(text)===norm((scenes||[]).map(s=>s.voice).join(' '))}
function wordCount(text){return words(text).length}
function sourceHash(text){ // quick stable hash — only for stale storyboard invalidation
 let h=2166136261;for(const c of String(text||'')){h=Math.imul(h^c.charCodeAt(0),16777619)}return (h>>>0).toString(36)
}
function assertScenes(text,scenes){
 if(!narrationMatches(text,scenes))throw Error('Narasi tidak cocok: potongan scene berubah atau terduplikasi');
 const seen=new Set();scenes.forEach((s,i)=>{if(!s.voice?.trim()||s.durationSec<=0||seen.has(i))throw Error('Scene kosong / durasi tak valid');seen.add(i)});
 return true;
}
return {normalize:norm,splitNarration,narrationMatches,wordCount,sourceHash,assertScenes};
});
