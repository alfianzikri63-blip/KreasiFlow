/* KreasiFlow v5.0.28 — narration-to-Flow storyboard continuity helper.
 * Offline, deterministic and unit-testable. No API access and no account keys.
 */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  root.KreasiFlowStoryContinuity=api;
})(typeof window!=='undefined'?window:globalThis,function(){
'use strict';
const norm=t=>String(t||'').replace(/\s+/gu,' ').trim();
const words=t=>norm(t).split(/\s+/u).filter(Boolean);
function sentenceChunks(text){
 const p=String(text||'').replace(/\r\n?/g,'\n').split(/\n{2,}/).map(norm).filter(Boolean);
 return p.flatMap(para=>para.match(/[^.!?]+(?:[.!?]+["”']*|$)/gu)||[para]).map(norm).filter(Boolean);
}
function splitNarration(text,totalSeconds,clipSeconds=8){
 const source=norm(text);if(!source)return [];
 const clip=Math.max(4,Math.min(12,Number(clipSeconds)||8));
 const all=words(source);
 const budget=Math.max(10,Math.min(30,Math.round(clip*2.35)));
 const chunks=[];
 let pos=0;
 while(pos<all.length){
  let end=Math.min(all.length,pos+budget);
  if(end<all.length){
   // Prefer a full-stop near the desired cut, but never repeat or drop words.
   const options=[];
   for(let k=Math.max(pos+Math.ceil(budget*.7),end-3);k<=Math.min(all.length,end+3);k++){
    if(/[.!?]["”']*$/u.test(all[k-1]||''))options.push(k);
   }
   if(options.length)end=options.sort((x,y)=>Math.abs(x-(pos+budget))-Math.abs(y-(pos+budget)))[0];
  }
  chunks.push(all.slice(pos,end).join(' '));pos=end;
 }
 return chunks.map((voice,i)=>({voice,startSec:i*clip,endSec:(i+1)*clip,durationSec:clip,estimated:true}));
}
function narrationMatches(text,scenes){return norm(text)===norm((scenes||[]).map(s=>s.voice).join(' '))}
function wordCount(text){return words(text).length}
function sourceHash(text){ // quick stable hash — only for stale storyboard invalidation
 let h=2166136261;for(const c of String(text||'')){h=Math.imul(h^c.charCodeAt(0),16777619)}return (h>>>0).toString(36)
}
function assertScenes(text,scenes){
 if(!narrationMatches(text,scenes))throw Error('Narasi tidak cocok: potongan scene berubah atau terduplikasi');
 const seen=new Set();scenes.forEach((s,i)=>{if(!s.voice?.trim()||s.durationSec<=0||seen.has(i))throw Error('Scene kosong / durasi tak valid');seen.add(i)});
 return true;
}
return {normalize:norm,splitNarration,narrationMatches,wordCount,sourceHash,assertScenes};
});
