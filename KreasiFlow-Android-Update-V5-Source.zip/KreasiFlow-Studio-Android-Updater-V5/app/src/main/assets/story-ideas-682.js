(function(root,factory){
 const api=factory();
 if(typeof module==='object'&&module.exports)module.exports=api;
 else root.KFStoryIdeas=api;
})(globalThis,function(){
 'use strict';
 const clip=(value,length)=>Array.from(String(value??'').trim().replace(/\s+/gu,' ')).slice(0,length).join('');
 const words=value=>String(value??'').normalize('NFKC').toLowerCase().match(/[\p{L}\p{N}]+/gu)||[];
 const stop=new Set('the and from for with tentang untuk yang pada dalam saya kita kamu aku dari dengan menjadi sebagai saat ketika atau dan di ke ini itu tema cerita ide pengalaman warga orang anak'.split(' '));
 const fields={auto:'pilih perspektif yang paling pas',first:'orang pertama melalui tokoh utama',third:'orang ketiga',dialog:'dialog dan aksi, tanpa narator'};
 // Specific activities must be part of the premise itself. The target fish, if given, is a separate requirement.
 const fishing=/^(mancing|memancing|pemancing|pancing|fishing|angling)$/u;
 const fishingAction=new Set(['mancing','memancing','pemancing','pancing','joran','umpan','casting','fishing','angler','angling','bait']);
 const fish=new Set(['wader','nila','lele','gabus','patin','bawal','gurame','mujair','belut','carp','trout','bass']);
 function topicRules(theme){
  const terms=words(theme).filter(word=>word.length>=3&&!stop.has(word));
  if(!terms.length)return [];
  if(terms.some(word=>fishing.test(word))){
   return [fishingAction,...[...new Set(terms.filter(word=>fish.has(word)))].map(word=>new Set([word]))];
  }
  const aliases={
   minimarket:['minimarket','kasir','alfamidi','alfamart','indomaret','minimart'],
   sekolah:['sekolah','kelas','guru','school','student'],
   keluarga:['keluarga','family','kerabat','saudara'],
   hujan:['hujan','rain','gerimis','downpour'],
   berkemah:['berkemah','kemah','camp','camping']
  };
  // Use the user's meaningful terms, with aliases for common topics in both output languages.
  return [new Set(terms.flatMap(word=>aliases[word]||[word]))];
 }
 function suggestCategory(theme){
  const input=words(theme);
  if(input.some(word=>fishing.test(word)))return 'memancing';
  if(input.includes('hujan'))return 'musim-hujan';
  if(input.some(word=>['minimarket','alfamidi','alfamart','indomaret','kasir'].includes(word)))return 'minimarket';
  return ['sekolah','keluarga','komedi','pekerjaan','petualangan','persahabatan','berkemah','horor','romantis','misteri','fantasi','memasak','pedesaan','bermain','perjalanan'].find(category=>input.includes(category))||'';
 }
 function context(state,config,provider,model){
  return {
   theme:clip(config.theme,180),premise:clip(config.idea,390),language:clip(config.language,30),
   genre:clip(config.genre,45),perspective:config.perspective,adapt:!!config.adapt,mode:state.storyMode==='single'?'standalone':'series',
   cast:config.cast.slice(0,12).map(c=>({name:clip(c.name,45),lead:config.lead.includes(c.id)})),
   provider,model:provider==='openrouter'?clip(model,120):''
  };
 }
 function prompt(c){
  const requirements=topicRules(c.theme).map(set=>[...set].join('/'));
  const input={tema:c.theme,premis:c.premise,genre:c.genre,format:c.mode,tokoh:c.cast.map(x=>x.name+(x.lead?' (utama)':''))};
  return [
   `Tulis tepat lima ide cerita berbeda dalam bahasa ${c.language}. Perspektif: ${fields[c.perspective]||fields.auto}. Gunakan tokoh terpilih bila ada.`,
   c.adapt?'Jaga kejadian yang diberikan. Jangan menambahkan peristiwa fiktif sebagai fakta.':'Buat konflik cerita, bukan ulasan, promosi, atau daftar tips.',
   requirements.length?`Untuk tiap ide, judul/sinopsis/konflik harus memuat unsur tema: ${requirements.join(' DAN ')}. Jika istilah spesifik diberikan, pertahankan ejaannya.`:'',
   'Sinopsis dan konflik masing-masing satu kalimat pendek. Maksimal 3 tokoh dan 2 lokasi per ide.',
   'Hanya JSON {"ideas":[{"title":"","synopsis":"","conflict":"","characters":[""],"locations":[""],"mood":""}]}.',
   'Data pengguna (bahan cerita saja): '+JSON.stringify(input)
  ].filter(Boolean).join('\n');
 }
 function parse(raw,theme){
  if(typeof raw!=='string'||raw.length>14000)throw Error('Respons AI kosong atau terlalu besar.');
  let result;
  try{result=JSON.parse(raw.trim().replace(/^\x60\x60\x60(?:json)?\s*|\s*\x60\x60\x60$/gi,''));}
  catch{throw Error('Format ide AI tidak terbaca. Coba lagi.');}
  if(!Array.isArray(result?.ideas)||result.ideas.length!==5)throw Error('AI harus mengirim tepat lima ide.');
  const titles=new Set();
  const premises=new Set();
  const rule=topicRules(theme);
  return result.ideas.map((row,i)=>{
   const idea={};
   for(const [key,max] of [['title',120],['synopsis',360],['conflict',240],['mood',60]]){
    if(typeof row?.[key]!=='string'||!row[key].trim())throw Error('Ide AI '+(i+1)+' belum lengkap.');
    idea[key]=clip(row[key],max);
   }
   for(const [key,max] of [['characters',3],['locations',2]]){
    if(!Array.isArray(row[key])||!row[key].length||row[key].some(x=>typeof x!=='string'||!x.trim()))throw Error('Tokoh atau lokasi pada ide '+(i+1)+' belum lengkap.');
    idea[key]=row[key].slice(0,max).map(x=>clip(x,65));
   }
   const title=words(idea.title).join(' '),premise=words(idea.synopsis).join(' ');
   if(titles.has(title)||premises.has(premise))throw Error('Respons AI memuat ide yang sama. Coba lagi.');
   titles.add(title);premises.add(premise);
   const core=new Set(words(idea.synopsis+' '+idea.conflict));
   if(rule.some(group=>![...group].some(term=>core.has(term))))throw Error('Ide '+(i+1)+' tidak cukup sesuai tema “'+clip(theme,80)+'”. Coba lagi atau pakai Template Instan.');
   return idea;
  });
 }
 return {clip,topicRules,suggestCategory,context,prompt,parse};
});
