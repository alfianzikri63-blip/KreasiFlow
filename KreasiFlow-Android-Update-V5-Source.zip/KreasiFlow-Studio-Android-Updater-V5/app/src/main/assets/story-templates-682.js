(function(root,factory){
 const api=factory();
 if(typeof module==='object'&&module.exports)module.exports=api;
 else root.KFStoryTemplates=api;
})(globalThis,function(){
 'use strict';
 // Handwritten offline premises. Rows contain title, premise, conflict and location.
 const source=[
 ['keseharian','Keseharian','Slice of Life',['Tokoh utama','Orang terdekat'],`
Sarapan Pukul Sebelas|Tokoh utama mencoba menyelamatkan sarapan yang kesiangan.|Bahan tinggal sedikit dan semua orang memesan menu berbeda.|Dapur rumah
Bel yang Salah|Sebuah paket tiba saat tokoh utama bersiap keluar.|Alamat hampir sama, tetapi penerima sebenarnya tidak bisa dihubungi.|Teras rumah, Gang
Alarm Tetangga|Bunyi alarm dari rumah sebelah mengacaukan rutinitas pagi.|Tokoh utama harus mencari sumber bunyi tanpa membangunkan penghuni lain.|Gang, Pagar tetangga
Antrean Isi Galon|Tokoh utama ikut antre isi ulang sebelum tamu datang.|Nomor antrean tertukar dan air di rumah sudah habis.|Depot air, Rumah
Hari Tanpa Lift|Tokoh utama harus naik tangga membawa belanjaan.|Kantong mulai robek dan salah satu tetangga butuh bantuan.|Tangga apartemen
Kembalian Seribu|Titipan belanja menyisakan kembalian yang sulit didapat.|Dua orang sama-sama mengira uang sisanya untuk mereka.|Warung, Teras
Catatan di Kulkas|Barang di kulkas berpindah mengikuti catatan tempel.|Seseorang menafsirkan pesan singkat sebagai aturan baru.|Dapur rumah
Baju Seragam Tetangga|Tokoh utama pulang membawa seragam dari penatu.|Seragam tampak sama, tetapi besok pemiliknya harus memakainya.|Penatu, Rumah
Kursi Paling Nyaman|Satu kursi di rumah jadi rebutan selama listrik padam.|Semua punya alasan untuk duduk di dekat jendela.|Ruang tengah
Sepuluh Menit Sebelum Tutup|Tokoh utama bergegas membeli barang yang telanjur dijanjikan.|Toko tutup lebih awal dan pilihan pengganti belum disetujui.|Toko, Jalan rumah`],
 ['memancing','Memancing','Petualangan',['Pemancing utama','Teman memancing'],`
Wader Sebelum Senja|Seorang pemancing mengajak temannya mencari wader sebelum gelap.|Arus berubah dan umpan yang biasanya ampuh tidak disentuh ikan.|Bantaran sungai, Jembatan kecil
Umpan yang Tertukar|Dua wadah umpan tertukar saat perjalanan memancing wader.|Keduanya enggan mengakui kesalahan dan hasil pancing berbeda jauh.|Tepi kali, Warung umpan
Pelampung di Bawah Bambu|Pelampung untuk memancing wader hanyut ke rumpun bambu.|Pemancing harus memilih pindah titik atau mengorbankan pelampung terakhir.|Rumpun bambu, Sungai dangkal
Sepakat Lepas Lagi|Seekor wader besar akhirnya menyambar dan memicu perdebatan.|Satu orang ingin membawa pulang ikan, yang lain sudah berjanji melepasnya.|Batu kali, Jalur pulang
Titik Pancing Tergenang|Hujan semalam menutup titik biasa memancing wader.|Teman yang baru belajar bersikeras menunggu di tempat lama.|Bendungan kecil, Pinggir sawah
Tiga Lemparan Terakhir|Sebelum pulang, kelompok sepakat mencoba tiga lemparan untuk wader.|Pancing pemula putus saat pelampung mulai bergerak.|Jembatan bambu, Tepi kali
Umpan dari Warung|Pemancing mencoba racikan sederhana untuk wader dari warung dekat sungai.|Resep berubah tanpa dicatat sehingga hasil pertama sulit diulang.|Warung, Bantaran sungai
Pancing Pinjaman|Tokoh utama meminjam joran untuk memancing wader.|Joran patah tersangkut ranting dan pemiliknya segera datang.|Sungai berbatu, Saung
Catatan Arus Pagi|Dua pemancing mencatat jam wader mulai aktif.|Catatan mereka bertentangan dan hujan menutup kesempatan menguji ulang.|Sungai kecil, Pos ronda
Janji Setelah Pancing|Tokoh utama minta satu kesempatan terakhir memancing wader sebelum membantu keluarga.|Ikan mulai menyambar saat waktu bantuan hampir tiba.|Tepi kali, Halaman rumah`],
 ['keluarga','Keluarga','Keluarga',['Anggota keluarga utama','Kerabat'],`
Foto yang Tidak Lengkap|Keluarga mencoba mengulang foto lama dengan susunan yang sama.|Satu kursi kosong memicu perbedaan pendapat tentang siapa yang harus ikut.|Ruang tamu, Halaman
Kotak Resep Milik Nenek|Dua kerabat memilih satu resep dari kotak lama.|Rebutan muncul karena resep ditulis tanpa takaran dan hasilnya berbeda.|Dapur keluarga
Kunci Rumah Lama|Sebelum menjual rumah lama, keluarga mencoba membukanya terakhir kali.|Kunci hilang dan hanya ada waktu sebelum calon pembeli tiba.|Teras rumah lama
Gantian Menjaga|Keluarga menyusun jadwal merawat anggota yang sedang pemulihan.|Jadwal terlihat adil sampai pekerjaan salah satu anggota berubah.|Ruang makan
Ulang Tahun Hari Selasa|Sebuah kejutan direncanakan di tengah minggu kerja.|Orang yang dirayakan justru mengajak semua pergi sebelum persiapan beres.|Rumah, Toko kue
Piring Warisan|Keluarga hendak membagi perlengkapan rumah lama.|Piring yang nilainya kecil ternyata penting bagi beberapa orang.|Lemari dapur
Pulang Tanpa Mengabari|Seorang anggota keluarga pulang lebih awal untuk memberi kejutan.|Rumah kosong dan semua mengira ia datang minggu depan.|Terminal, Rumah
Meteran di Tengah Malam|Air tiba-tiba berhenti ketika keluarga sedang beres-beres.|Perdebatan siapa yang lupa membayar menghalangi pencarian penyebab sebenarnya.|Halaman, Kamar mandi
Kotak Makan yang Kembali|Kotak makan pemberian orang tua pulang tanpa disentuh.|Tokoh utama harus menjelaskan alasannya tanpa meremehkan perhatian keluarga.|Meja makan
Album dan Ponsel|Dua generasi mencoba menyusun album digital bersama.|Nama dalam foto lama berbeda dari ingatan masing-masing.|Ruang keluarga`],
 ['sekolah','Sekolah','Sekolah',['Siswa utama','Teman sekelas','Guru opsional'],`
Praktikum Air Keruh|Kelompok praktikum mendapati sampelnya berbeda dari kelompok lain.|Anggota kelompok menimbang melaporkan temuan atau menyalin hasil teman.|Laboratorium
Loker Ganda|Dua siswa mendapat satu nomor loker yang sama.|Keduanya harus menyimpan benda yang tidak boleh tertukar.|Koridor
Kiper Pengganti|Siswa yang biasanya duduk di bangku cadangan diminta menjadi kiper.|Rekan satu tim terus mengubah taktik saat pertandingan hampir mulai.|Lapangan sekolah
Mading Belum Kering|Tim mading selesai menempel poster saat hujan mulai turun.|Hanya satu papan kosong tersisa dan panitia lain juga membutuhkannya.|Koridor, Papan mading
Kertas Ujian Pindah|Siswa menemukan jawabannya tertinggal di bawah meja lain.|Ia harus meminta bantuan tanpa terlihat mencoba menyontek.|Ruang ujian
Perpustakaan Sebelum Bel|Tokoh utama mengejar satu buku untuk tugas kelompok.|Buku sudah dipesan siswa lain dan waktu pinjam hampir habis.|Perpustakaan
Kostum yang Kebesaran|Satu pemeran pentas menerima kostum dengan ukuran yang salah.|Mengganti pemeran bisa menyelamatkan pentas tetapi melukai teman.|Aula, Belakang panggung
Jadwal Piket Disilang|Nama di papan piket diganti tanpa kesepakatan.|Dua kelompok merasa dibebani giliran ekstra menjelang inspeksi kelas.|Ruang kelas
Pesan untuk Kelas Sebelah|Pengumuman lomba tiba di grup yang salah.|Tim lama siap bertanding, sedangkan tim yang dimaksud belum tahu.|Kantin, Ruang guru
Bendera di Lemari|Perlengkapan upacara dikunci di lemari pengurus.|Siswa baru harus bergerak sebelum dituduh tidak siap.|Gudang, Lapangan`],
 ['pekerjaan','Pekerjaan','Pekerjaan',['Pekerja utama','Rekan kerja'],`
Rapat Tanpa Kabel|Presentasi penting dimulai ketika monitor tidak menemukan sambungan.|Tim memilih memecahkan masalah teknis atau mengubah cara presentasi.|Ruang rapat
Pesanan Pukul Empat|Pesanan mendadak datang saat satu orang masih menyelesaikan pekerjaan lama.|Kapasitas terbatas dan pembagian tugas tidak pernah disepakati.|Ruang kerja
Shift yang Tertukar|Dua pekerja datang untuk shift yang sama.|Pergantian semalam tidak tercatat dan shift berikutnya kosong.|Meja jadwal
File Paling Akhir|Tim menemukan dua versi dokumen yang sama-sama bernama final.|Jika memilih salah, isi laporan pelanggan berubah.|Ruang kerja
Suara di Ruang Sebelah|Rekan baru ingin bertanya saat obrolan penting di ruang sempit terdengar jelas.|Ia harus memilih waktu dan cara menyampaikan kekhawatiran.|Ruang kerja, Koridor
Bekal untuk Lembur|Satu bungkus makanan tersisa di meja saat lembur.|Kedua pekerja sama-sama belum makan dan tidak mau meminta.|Ruang istirahat
Papan Target yang Kosong|Papan target hilang isinya sebelum evaluasi mingguan.|Tim harus menyusun ulang berdasarkan catatan yang saling bertentangan.|Ruang rapat
Badge Satu Hari|Staf baru menerima izin akses yang kedaluwarsa terlalu cepat.|Ia harus menyelesaikan tugas tanpa meminjam identitas orang lain.|Pos masuk
Troli di Jalur Keluar|Barang kiriman memenuhi jalur kerja menjelang penutupan.|Merapikan sekarang menunda serah terima, menunggu membuat jalur tidak bisa dipakai.|Gudang kecil
Balasan yang Tertunda|Keluhan pelanggan terlewat di tengah antrean pesan.|Rekan berbeda pendapat apakah harus menjawab dulu atau mengecek detail.|Meja layanan`],
 ['petualangan','Petualangan','Petualangan',['Penjelajah','Rekan perjalanan'],`
Peta dari Karcis|Gambar di belakang karcis mengarah ke jalan pintas.|Dua penjelajah tidak sepakat apakah tanda terakhir masih berlaku.|Pos karcis, Jalur bukit
Bukit Sebelum Kabut|Kelompok naik untuk melihat matahari terbit.|Kabut tiba lebih cepat dan rute pulang tidak jelas.|Jalur bukit, Punggungan
Tali di Seberang|Sebuah tanda jalur hanya terlihat dari seberang sungai.|Arus membuat rute lama tidak bisa dipakai.|Sungai dangkal, Hutan
Jam Pasang|Tim ingin mencapai pulau kecil saat air surut.|Salah membaca waktu membuat mereka harus mencari rute lain.|Pantai, Jalur batu
Pasar yang Berpindah|Dua pengunjung mencari pasar musiman berdasar petunjuk lama.|Semua orang memberi arah ke lokasi berbeda.|Pasar, Rumah singgah
Senter untuk Berdua|Senter cadangan tidak menyala saat memasuki jalur bawah tanah yang dibuka untuk umum.|Keduanya berbeda pendapat antara menunggu pemandu dan melanjutkan.|Pintu jalur, Terowongan
Kode di Papan Jalur|Petunjuk arah tertutup papan baru.|Satu simbol dibaca terbalik dan membawa rombongan menjauh.|Persimpangan jalur
Sepeda Terakhir|Rombongan menyewa sepeda menuju kebun di balik bukit.|Sepeda terakhir tidak berfungsi dan waktu sewa berjalan.|Penyewaan sepeda, Jalan kebun
Suara dari Lembah|Tanda peluit terdengar ketika teman tidak terlihat.|Tokoh utama tidak tahu apakah itu pemandu atau gema dari arah berbeda.|Lembah, Jalur tanah
Karcis yang Terbawa|Karcis pulang ternyata terselip pada tas peserta yang sudah turun duluan.|Satu rombongan harus mencari cara berkumpul lagi sebelum loket tutup.|Pos wisata, Terminal`],
 ['komedi','Komedi','Komedi',['Tokoh utama','Rekan lawan main'],`
Dua Pesanan Satu Meja|Dua orang datang dengan nomor pesanan yang sama.|Menu mereka berlawanan dan masing-masing yakin petugas yang keliru.|Kedai
Rapat dengan Filter|Peserta rapat lupa mematikan filter panggilan.|Ia diminta menjelaskan topik serius sambil mencari tombol yang tepat.|Ruang kerja
Topi Pengganti|Tokoh utama meminjam topi yang tampak wajar di cermin kecil.|Topi itu ternyata seragam sebuah panitia dan ia terus diminta memberi arahan.|Aula, Halaman
Kue Berpesan Salah|Ucapan pada kue tertukar dengan pesanan lain.|Acara segera dimulai dan semua orang punya ide perbaikan yang lebih aneh.|Toko kue, Ruang pesta
Gagal Bisik|Dua teman mencoba menutupi kejutan lewat pesan suara.|Ponsel memutarnya keras ketika penerima datang.|Ruang tengah
Kursi Serbaguna|Satu kursi lipat dianggap bagian dari beberapa acara bersamaan.|Tokoh utama terus membawanya pindah sebelum sadar telah salah ruangan.|Aula
Bel Palsu|Tokoh utama menirukan bunyi bel untuk menguji teman.|Penghuni lain mengikuti instruksi yang mereka sangka resmi.|Koridor rumah
Resep Satu Kata|Instruksi singkat memasak disalahartikan sebagai nama bahan.|Kelompok bersaing menebak hasil yang seharusnya dibuat.|Dapur
Payung Promosi|Hanya satu payung tersedia saat pulang.|Bukaan payung menampilkan pesan yang menarik perhatian orang sepanjang jalan.|Teras toko, Trotoar
Latihan Antrean|Kelompok berlatih menyambut tamu memakai simulasi antrean.|Tamu sungguhan ikut mengantre dan semua orang bingung kapan berhenti.|Lobi, Pos masuk`],
 ['persahabatan','Persahabatan','Drama',['Dua sahabat','Teman penengah opsional'],`
Peta Pulang Berbeda|Dua sahabat memilih jalan pulang berbeda setelah berselisih.|Masing-masing menemukan petunjuk yang hanya berguna jika digabung.|Gang, Halte
Janji Minggu Depan|Satu sahabat lupa janji yang dianggap kecil.|Sahabat lain diam-diam sudah menolak undangan penting demi janji itu.|Kedai, Halaman
Sepasang Sketsa|Dua sahabat mendaftar lomba dengan rancangan yang dikerjakan bersama.|Panitia hanya menyediakan satu kolom nama.|Ruang seni
Tempat Biasa|Kursi yang jadi tempat bertemu lama dipindahkan.|Satu orang menunggu di lokasi baru dan yang lain menganggapnya ingkar.|Taman
Sepeda yang Dipinjam|Seorang teman mau meminjamkan sepeda dengan syarat sederhana.|Saat bersepeda, syarat itu tidak mungkin dipenuhi tanpa menjelaskan alasannya.|Jalan kampung
Suara untuk Teman|Tokoh utama dipercaya membacakan pesan seorang sahabat.|Pesannya terdengar berbeda ketika disampaikan di depan umum.|Aula kecil
Satu Meja Dua Pilihan|Dua sahabat ingin tetap satu kelompok tetapi memilih tugas berbeda.|Batas waktu pendaftaran memaksa keduanya bicara jujur.|Kantin
Kotak Tukar Buku|Tukaran buku tahunan berakhir dengan satu buku hilang.|Salah seorang menyembunyikan alasannya mengganti judul.|Perpustakaan, Rumah
Satu Bangku Sebelum Berangkat|Seorang sahabat akan pindah dan meminta pertemuan singkat.|Keduanya menghindari topik penting hingga keberangkatan hampir tiba.|Stasiun kecil
Ganti Lagu Terakhir|Daftar lagu untuk acara pertemanan hampir selesai.|Lagu terakhir mengingatkan salah satu orang pada perselisihan yang belum selesai.|Ruang latihan`],
 ['memasak','Memasak','Slice of Life',['Juru masak','Asisten atau pencicip'],`
Sambal Sebelum Tamu|Tokoh utama menyiapkan sambal untuk tamu.|Salah satu tamu tidak makan pedas dan sambal sudah terlanjur dicampur.|Dapur, Meja makan
Resep Tanpa Oven|Sebuah resep harus selesai sebelum kunjungan keluarga.|Oven rusak dan alat pengganti hanya tersedia di rumah tetangga.|Dapur, Rumah tetangga
Sup Terlalu Asin|Kelompok mencicipi sup menjelang waktu makan.|Sisa bahan tidak cukup untuk mengencerkan semuanya.|Dapur rumah
Nasi Tutup Panci|Tokoh utama mencoba memasak memakai alat pinjaman.|Tutup panci tidak pas dan jadwal makan tidak bisa digeser.|Dapur kontrakan
Belanja Setengah Resep|Belanjaan untuk menu andalan tidak lengkap.|Yang membeli memilih bahan pengganti tanpa memberi tahu juru masak.|Pasar, Dapur
Kue untuk Dua Meja|Dua acara memesan kue untuk waktu yang sama.|Hanya satu adonan berhasil dan kedua pemesan sudah berangkat.|Dapur, Ruang acara
Bekal yang Tidak Muat|Makanan untuk piknik hampir selesai.|Wadah terlalu kecil dan tokoh utama tidak ingin mencampur saus.|Dapur, Taman
Cicip Tanpa Melihat|Dua orang menguji resep dengan mata tertutup.|Salah satu rasa mengungkap bahan yang diam-diam diganti.|Meja makan, Dapur
Sayur Sisa Pagi|Tokoh utama mencoba memakai sisa sayur untuk hidangan baru.|Pencicip mengira semua akan dibuang dan sudah menyiapkan menu lain.|Dapur bersama
Sarapan Bergilir|Penghuni rumah sepakat memasak bergantian.|Giliran pertama bertabrakan dengan jadwal keberangkatan masing-masing.|Dapur bersama`],
 ['pedesaan','Pedesaan','Slice of Life',['Warga utama','Tetangga','Pengurus opsional'],`
Jadwal Air Sawah|Warga membuka aliran air sesuai giliran.|Sebuah sekat bergeser dan dua petak menunggu jatah yang sama.|Pematang, Saluran irigasi
Jalan ke Balai|Warga ingin membawa perlengkapan ke balai desa.|Jalan utama berlumpur dan kendaraan lewat terakhir sudah hampir berangkat.|Jalan desa, Balai
Lampu Pos Ronda|Lampu padam saat giliran jaga berganti.|Senter hanya satu dan harus dipakai untuk memeriksa dua ujung gang.|Pos ronda, Gang
Benih di Rak Atas|Warga hendak menukar benih sebelum musim tanam.|Label dua wadah terlepas dan petak percobaan tidak bisa diulang.|Lumbung, Sawah
Papan Pengumuman Pindah|Papan pengumuman dipindah selama perbaikan balai.|Setengah warga tidak tahu jadwal baru kegiatan.|Balai, Warung
Panen Perdana|Panen kecil direncanakan dibagi untuk tetangga.|Hasil lebih sedikit dari perkiraan dan nama penerima sudah diumumkan.|Kebun, Teras
Kambing di Pintu Kebun|Seekor kambing masuk ke kebun bersama.|Pemiliknya tidak ada dan pagar lama sudah patah.|Kandang, Kebun
Bakul di Jembatan|Warga hendak membawa titipan lewat jembatan sempit.|Orang dari arah seberang membawa bakul yang sama lebarnya.|Jembatan kayu
Pertunjukan di Lapangan|Hiburan desa sudah disiapkan di lapangan.|Hujan mengancam kabel dan penonton mulai berdatangan.|Lapangan, Balai
Pesan Keliling Kampung|Warga menyampaikan pengumuman dari rumah ke rumah.|Versi pesan berubah setiap kali dijelaskan ulang.|Gang kampung, Pos ronda`],
 ['minimarket','Minimarket','Pekerjaan',['Kasir','Rekan shift','Pelanggan opsional'],`
Kembalian Menjelang Tutup|Kasir menghitung laci sebelum toko tutup.|Pelanggan terakhir membayar tunai dan uang kecil sedang habis.|Kasir, Gudang
Shift Tanpa Scanner|Scanner kasir mati saat antrean baru terbentuk.|Rekan shift harus memilih mencari kode manual atau memindahkan antrean.|Meja kasir
Barang Titipan Pendingin|Pelanggan menitipkan produk di pendingin sambil pergi sebentar.|Rekan shift mengembalikannya ke rak dan pelanggan segera datang.|Pendingin, Kasir
Rak Paling Atas|Pegawai diminta mengecek barang di rak tinggi.|Tangga dipakai rekan lain sementara pelanggan menunggu.|Lorong rak
Bukti Belanja Hilang|Pelanggan kembali untuk mengecek selisih harga.|Bukti belanja tidak ditemukan dan kasir shift sebelumnya sudah pulang.|Kasir, Ruang staf
Hujan dan Kardus|Pengiriman datang ketika hujan deras.|Barang harus masuk gudang, tetapi kardus menghalangi pintu pelanggan.|Pintu toko, Gudang
Label Harga Jumat|Staf menemukan label lama ketika toko mulai ramai.|Perbaikan satu lorong membuat antrean bertanya soal harga.|Lorong rak, Kasir
Jadwal Istirahat Bersilang|Dua staf mengambil istirahat pada waktu yang sama karena catatan salah.|Antrean tumbuh sementara masing-masing mengira ada pengganti.|Kasir, Ruang staf
Toko Siap Buka|Pegawai pagi tiba dengan daftar persiapan lengkap.|Pelindung pintu macet dan pelanggan pertama sudah datang.|Pintu toko, Kasir
Troli di Sudut|Wadah pengiriman menghalangi jalur di antara rak.|Rekan shift ingin membongkar langsung, sementara kasir butuh lorong kosong.|Gudang, Lorong rak`],
 ['horor','Horor','Horor',['Tokoh utama','Saksi'],`
Lampu Lorong Kedua|Satu lampu di lorong menyala setiap tokoh utama lewat.|Bunyi langkah terdengar sesudah listrik utama diputus.|Lorong apartemen
Telepon Kamar Kosong|Telepon di kamar yang dikunci terus berdering.|Panggilan terakhir menyebut benda yang baru dipindahkan tokoh utama.|Rumah singgah
Tirai Terbuka Sendiri|Dua penghuni menutup tirai sebelum tidur.|Bayangan datang dari sisi yang tidak memiliki jendela.|Ruang tengah
Pintu Tanpa Nomor|Penjaga menemukan pintu baru di gedung lama.|Jadwal patroli berikutnya mengharuskannya melewati lorong yang sama.|Gedung lama
Tiga Ketukan|Tokoh utama mendengar ketukan yang selalu berhenti setelah tiga kali.|Saksi mendengar ketukan keempat dari dalam ruangan.|Teras, Ruang kerja
Jam Mati|Jam yang tidak dipakai bertahun-tahun tiba-tiba berdetak.|Tokoh utama menemukan detaknya terdengar dari beberapa lantai sekaligus.|Tangga rumah
Ruang Penyimpanan Suara|Saksi memutar rekaman ruangan kosong sebagai hiburan.|Satu potongan suara ternyata menjawab pertanyaan yang baru diucapkan.|Gudang, Ruang audio
Tanda di Cermin|Uap mandi menampilkan tulisan dari sisi dalam cermin.|Tulisan berubah setiap kali tokoh utama menyentuh gagang pintu.|Kamar mandi
Sepatu di Depan Pintu|Sepatu asing muncul setelah penghuni mengunci rumah.|Sepasang jejak kemudian terlihat mengarah ke dalam.|Teras, Lorong rumah
Suara di Gardu|Dua penjaga mendengar panggilan dari gardu yang tidak aktif.|Mereka harus menyelesaikan ronda sambil memastikan siapa yang membawa kunci.|Gardu, Jalan desa`],
 ['misteri','Misteri','Misteri',['Penyelidik amatir','Saksi'],`
Stempel Dua Waktu|Satu kuitansi memiliki dua cap waktu berbeda.|Pengurus mengaku datang terlambat, tetapi salah satu cap mendahului kedatangannya.|Loket
Laci Ketiga|Satu laci terkunci berisi secarik daftar tanpa nama.|Dua benda dalam daftar ternyata baru saja berpindah tempat.|Ruang arsip
Paket Berputar|Paket yang sudah dikembalikan datang lagi dengan label baru.|Nomor pengiriman sama, tetapi beratnya selalu berubah.|Loket paket, Teras
Papan yang Dihapus|Seorang warga melihat kalimat terakhir sebelum papan dibersihkan.|Dua saksi mengingat kata yang berbeda dan hanya satu yang cocok dengan kejadian.|Balai
Karpet Terbalik|Karpet sebuah ruangan selalu tampak terbalik setelah ditutup.|Kunci tersimpan di tempatnya dan tidak ada yang mengaku masuk.|Ruang pertemuan
Pintu yang Sudah Diganti|Catatan perawatan menyebut pintu diganti dua kali.|Orang yang menandatangani kedua catatan tidak berada di tempat saat itu.|Bengkel, Koridor
Payung Bergaris|Sebuah payung muncul dalam dua foto dari tempat berjauhan.|Pemiliknya mengaku hanya meninggalkan payung di satu lokasi.|Kedai, Halte
Kartu Perpustakaan Terakhir|Kartu lama menunjuk buku yang tidak pernah terdaftar.|Petugas harus melacaknya sebelum rak dikosongkan.|Perpustakaan, Arsip
Kertas di Balik Kalender|Membalik kalender menampilkan daftar tanggal yang dicoret.|Tanggal berikutnya tiba sore ini dan penulisnya belum ditemukan.|Ruang guru, Koridor
Kunci dari Gelas|Sebuah kunci ditemukan di gelas kedai yang baru dicuci.|Kunci itu membuka tempat yang diklaim tidak pernah dikunjungi pemilik kedai.|Kedai, Gudang`],
 ['romantis','Romantis','Romantis',['Tokoh utama','Orang yang disukai'],`
Satu Payung Dua Arah|Dua orang berbagi payung ketika rute mereka mulai berpisah.|Keduanya enggan mengakui bahwa mereka ingin berjalan lebih lama.|Trotoar
Meja Pojok|Sebuah meja yang biasa dipesan tiba-tiba terisi.|Tokoh utama harus memilih menyapa atau membiarkan waktunya berlalu.|Kedai
Karcis Kursi Sebelah|Orang yang selalu duduk di sebelah datang untuk perjalanan terakhir.|Salah satunya ingin bertukar kontak, tetapi terus menunggu momen tepat.|Stasiun, Kereta
Bukti Pinjam Buku|Seseorang menyimpan bukti pinjam dengan catatan kecil.|Buku harus dikembalikan sebelum penerima sempat membacanya.|Perpustakaan
Kopi yang Sama|Dua orang sama-sama hafal pesanan masing-masing.|Barista baru menukar pesanan dan membuka kebiasaan yang mereka sembunyikan.|Kedai kopi
Bunga dari Halaman|Tokoh utama memetik satu bunga untuk diberikan.|Bunga itu bagian dari tanaman yang sama-sama mereka rawat.|Halaman
Waktu Tambahan|Seseorang sengaja tinggal membantu menutup acara.|Orang yang ingin ditemui juga tinggal, tetapi mereka sibuk di ujung ruangan berbeda.|Aula
Catatan di Jaket|Sebuah jaket pinjaman kembali dengan catatan dalam saku.|Isinya sulit dipahami tanpa bertanya langsung.|Teras rumah
Rute yang Ditukar|Dua orang ingin menjumpai satu sama lain dengan mengambil rute berbeda.|Keduanya justru tiba di tempat yang sudah ditinggalkan orang lain.|Taman, Jalan pulang
Hari Pindah Kursi|Seseorang mengambil keputusan untuk pindah tempat duduk.|Perubahan kecil itu memaksa mereka menjelaskan perasaan yang lama ditunda.|Ruang kelas malam`],
 ['fantasi','Fantasi','Fantasi',['Tokoh utama','Pendamping atau penjaga'],`
Pintu Sebesar Buku|Sebuah pintu kecil dapat membesar ketika kisah yang tepat dibacakan.|Halaman terakhirnya hilang dan tokoh utama perlu keluar sebelum gelap.|Perpustakaan ajaib
Peta Bersinar|Peta hanya menyala ketika dua orang setuju soal tujuan.|Keduanya mempunyai tujuan yang sama penting tetapi berbeda.|Hutan ajaib
Sup Penukar Suara|Satu sendok kuah membuat suara dua orang berpindah.|Mereka harus menyelesaikan tugas sebelum penukar suara pulang.|Dapur istana
Jembatan dari Lagu|Sebuah jembatan bertahan selama lagunya terus terdengar.|Penghafal lirik lupa bait terakhir di tengah perjalanan.|Jurang, Jembatan
Benih Pembaca Cuaca|Benih tumbuh berdasarkan kata pertama yang didengarnya.|Dua orang mengucapkan kata berbeda saat benih dibuka.|Taman sihir
Kompas Emosi|Kompas mengarah ke orang yang paling cemas.|Dua pengguna tidak tahu apakah mereka sedang mendekati teman atau bahaya.|Pasar sihir
Topi Peminjam Ingatan|Topi meminjamkan satu kenangan setiap kali dipakai.|Tokoh utama harus memilih ingatan sendiri yang rela ditukar.|Kios tua
Jendela ke Musim Lain|Satu jendela menampilkan musim berbeda tiap dibuka.|Pemain utama meninggalkan barang berharga pada musim yang sulit diulang.|Kabin ajaib
Lonceng Pengundang Hujan|Lonceng kecil mengundang awan sesuai nada yang dimainkan.|Orang yang meminjamnya hanya tahu satu melodi yang tidak cocok.|Menara, Lapangan
Batu yang Mau Mendengar|Sebuah batu membuka jalan jika mendengar alasan jujur.|Tokoh utama ingin menyimpan alasan itu dari pendampingnya.|Gerbang gua`],
 ['berkemah','Berkemah','Petualangan',['Peserta utama','Teman kemah'],`
Pasak Tinggal Satu|Kelompok mendapati pasak tenda kurang ketika angin menguat.|Tenda lain juga membutuhkan pasak yang tersisa.|Bumi perkemahan
Api yang Tidak Menyala|Kelompok hendak memasak setelah hujan.|Persediaan bahan bakar basah dan makan malam belum siap.|Area masak kemah
Senter Bergilir|Satu senter dipakai untuk menuju fasilitas umum saat malam.|Dua kelompok harus berangkat pada waktu yang sama.|Tenda, Jalur kemah
Jalur ke Mata Air|Peta area menunjukkan jalur pendek menuju sumber air.|Jalur itu ternyata ditutup dan air kelompok sudah hampir habis.|Pos perkemahan, Jalur hutan
Alas Tenda Terbalik|Kelompok baru sadar alas dipasang terbalik saat malam mulai dingin.|Membongkar tenda membutuhkan waktu dan semua perlengkapan sudah masuk.|Tenda
Kantong Tidur Tertukar|Dua peserta membawa kantong tidur yang mirip.|Satu kantong lebih pendek dan pemiliknya sudah tidur.|Tenda bersebelahan
Daftar Makan Pagi|Kelompok punya bahan sarapan yang cukup untuk satu menu.|Dua peserta memiliki kebutuhan makan yang berbeda.|Dapur kemah
Suara dari Tenda Sebelah|Kelompok mendengar suara seseorang mencari sesuatu di luar.|Mereka harus memastikan siapa yang membutuhkan bantuan tanpa membangunkan semua orang.|Jalur tenda
Panji di Puncak|Sebuah panji harus dipasang sebelum kelompok pulang.|Satu anggota ingin terus naik dan yang lain mengingat batas waktu pemandu.|Bumi perkemahan, Bukit
Jejak Sepanjang Tali|Tali penanda jalur lepas ketika peserta pulang dari kegiatan.|Satu orang ingat belokan, tetapi penanda lain tidak cocok dengan ingatannya.|Jalur berkemah`],
 ['hewan-peliharaan','Hewan Peliharaan','Keluarga',['Perawat hewan','Teman atau keluarga'],`
Kalung di Pintu|Hewan peliharaan kehilangan kalung di halaman.|Tiga kalung serupa ditemukan dan tanda nama sudah lepas.|Halaman, Pagar
Makan Siang Kedua|Hewan peliharaan meminta makan setelah semua orang pulang.|Setiap penghuni mengira orang lain belum memberinya makan.|Ruang makan
Bantal di Bawah Meja|Perawat baru mencari tempat tidur yang disukai hewan.|Hewan terus memilih tempat yang perlu dikosongkan untuk tamu.|Ruang tengah
Kandang yang Berdecit|Suara kandang membuat hewan sulit tenang.|Orang yang biasa memperbaikinya belum pulang dan jam tidur mendekat.|Ruang hewan
Rute Jalan Baru|Pemilik pertama kali mencoba rute yang lebih pendek.|Hewan bersikeras menuju tempat lain yang biasa dikunjungi.|Trotoar, Taman
Kunci Pet Carrier|Kunci kotak angkut tersangkut menjelang janji dengan dokter hewan.|Pemilik perlu menenangkan hewan saat mencoba memindahkan perlengkapannya.|Teras, Klinik hewan
Mainan Hilang Bergilir|Mainan hewan hilang satu demi satu.|Pemilik menemukan tempat penyimpanan yang tidak bisa dibuka tanpa memindahkan perabot.|Ruang keluarga
Tetangga Penitip|Pemilik baru pindah dan meminta bantuan menjaga hewan selama satu sore.|Tetangga salah membaca instruksi kebiasaan hewan.|Apartemen, Halaman
Jendela Favorit|Hewan peliharaan terus kembali ke jendela yang sedang diperbaiki.|Pemilik harus mencari tempat lain yang tetap membuatnya nyaman.|Ruang duduk
Hadiah dari Taman|Hewan peliharaan pulang membawa benda asing.|Pemilik mencoba mengembalikannya sebelum ada yang mengira sengaja diambil.|Taman, Teras`],
 ['bermain','Bermain','Komedi',['Pemain utama','Teman bermain'],`
Bola ke Atap Rendah|Bola melambung ke atap saat pertandingan baru mulai.|Tidak ada bola pengganti dan tempat berikutnya sudah dipesan kelompok lain.|Lapangan, Gudang
Satu Kontroler Mati|Permainan bergiliran hampir mencapai babak akhir.|Kontroler cadangan tidak menyala dan aturan giliran belum jelas.|Ruang bermain
Rumah Kardus|Kelompok membangun rumah dari kardus bekas.|Dua rancangan memakai kardus besar yang sama.|Halaman
Garis Kapur Hilang|Lapangan permainan kehilangan satu garis batas setelah dibersihkan.|Dua tim mengingat letak garis dengan ukuran berbeda.|Halaman sekolah
Lima Menit di Ayunan|Beberapa teman sepakat bergiliran memakai ayunan.|Penghitung waktu hilang dan semua mengklaim giliran belum selesai.|Taman bermain
Permainan Ganti Aturan|Pemain baru menganggap aturan boleh berubah setiap putaran.|Yang lain harus menegosiasikan ulang cara memenangkan permainan.|Ruang tengah
Peta Harta Basah|Peta permainan rusak sebelum kelompok mencapai petunjuk terakhir.|Titik yang masih terlihat mengarah ke dua tempat berbeda.|Halaman, Taman
Kelereng Paling Jauh|Kelereng andalan keluar dari arena saat percobaan terakhir.|Satu pemain ingin mengulang, yang lain menganggap putaran sudah selesai.|Halaman rumah
Panggung Boneka Bergeser|Kelompok menyiapkan pertunjukan boneka kecil.|Panggung bergeser setiap tokoh masuk dan penonton sudah duduk.|Ruang bermain
Puzzle Tanpa Sudut|Teman-teman mengerjakan puzzle dengan waktu terbatas.|Bagian sudut yang hilang ternyata dipakai di proyek lain.|Meja bermain`],
 ['musim-hujan','Musim Hujan','Slice of Life',['Tokoh utama','Teman atau tetangga'],`
Jemuran Belum Diangkat|Tokoh utama pulang saat awan mulai gelap.|Tetangga butuh bantuan mengamankan dagangannya di saat yang sama.|Halaman, Gang
Hujan di Halte Terakhir|Dua penumpang turun di halte yang bocor.|Payung hanya cukup untuk satu orang sampai ke tujuan pertama.|Halte, Trotoar
Sepatu untuk Besok|Jalan pulang tergenang dan sepatu sekolah basah.|Tokoh utama harus menyiapkannya sebelum hari penting.|Gang, Teras
Jalur Paling Kering|Kelompok mencari jalur pulang yang masih bisa dilewati.|Rute paling kering lebih jauh dan salah satu orang harus segera tiba.|Gang, Jembatan
Bunyi Talang|Air dari talang jatuh tepat di meja belajar.|Orang yang bisa mengambil tangga masih terjebak hujan di jalan.|Rumah, Teras
Pesanan di Tengah Hujan|Kurir dan penerima berteduh di tempat yang berbeda.|Alamat yang samar membuat paket tidak bisa diserahkan tanpa bekerja sama.|Teras toko, Gang
Penutup Jok Terakhir|Pengendara berebut satu penutup jok di parkiran.|Kedua orang mempunyai barang yang rentan terkena hujan.|Parkiran
Janji di Taman|Pertemuan direncanakan di taman terbuka pada musim hujan.|Satu orang memindahkan lokasi tanpa memastikan pesan sampai.|Taman, Kedai
Burung di Bawah Atap|Tetangga melihat burung berteduh di dekat jendela.|Mereka berbeda pendapat apakah sebaiknya membiarkannya atau menutup jendela sebelum air masuk.|Jendela rumah
Tetes Pukul Dua|Air merembes ke ruang tidur saat hujan malam.|Menemukan sumber rembesan perlu memindahkan perabot bersama-sama.|Kamar, Teras`],
 ['perjalanan','Perjalanan','Petualangan',['Pelancong','Teman perjalanan'],`
Kursi di Gerbong Lain|Tokoh utama naik gerbong bersama teman.|Nomor kursinya benar, tetapi gerbong mereka berbeda dan waktu pindah singkat.|Peron, Kereta
Koper Serupa|Dua koper yang sama tertukar di penginapan.|Pemilik lain pergi lebih dahulu dan di dalam koper ada perlengkapan penting.|Penginapan, Terminal
Tiket Pulang Terakhir|Pelancong mengandalkan penjualan tiket di loket.|Tiket tinggal satu dan teman belum sampai di terminal.|Terminal
Rute Tanpa Sinyal|Dua pelancong kehilangan peta digital di persimpangan.|Ingatannya berbeda dan matahari mulai turun.|Jalan pegunungan
Sarapan saat Transit|Pelancong memesan sarapan di sela penerbangan.|Panggilan naik pesawat berubah lebih awal saat makanan baru disajikan.|Ruang transit
Tujuan yang Sama Nama|Dua teman merasa sudah turun di tempat tepat.|Nama desanya sama dengan tujuan, tetapi berada di rute seberang.|Persimpangan, Halte
Penginapan Dua Pintu|Alamat penginapan mengarah ke dua pintu dengan nomor sama.|Pemesanan tidak bisa dikonfirmasi sebelum resepsionis kembali.|Gang, Penginapan
Kartu Tol Tertinggal|Rombongan sudah menempuh sebagian perjalanan.|Kartu yang diperlukan tersimpan di tas teman yang baru turun.|Rest area, Gerbang tol
Kado dari Kota Tujuan|Tokoh utama ingin membawa pulang satu oleh-oleh untuk seseorang.|Tempat belanja tutup saat kendaraan pulang tinggal menunggu.|Pasar, Stasiun
Bus sebelum Fajar|Dua pelancong datang ke terminal dalam gelap.|Papan jadwal belum diperbarui dan bus yang terparkir tidak menunjukkan tujuan.|Terminal, Bus`]
 ];
 const artwork=[0,2,5,8,4,13,6,3,11,1,14,15,12,9,7,16,10,17,19,18];
 const directions=[
  'Mulai dari rutinitas kecil; akhiri dengan tindakan yang menunjukkan kebiasaan tokoh berubah.',
  'Gunakan perubahan arus, umpan, atau gerak pelampung sebagai petunjuk sebelum tokoh mengambil keputusan.',
  'Beri setiap anggota keluarga alasan yang masuk akal; perlihatkan perubahannya lewat tindakan kecil.',
  'Atur keputusan utama sebelum bel atau tenggat sekolah; tunjukkan dampaknya bagi teman sekelas.',
  'Tunjukkan pilihan kerja dalam dua langkah: keputusan saat tekanan tinggi, lalu konsekuensinya bagi rekan.',
  'Perlihatkan petunjuk rute lebih dahulu; jadikan keputusan berbalik atau lanjut sebagai titik balik.',
  'Bangun satu kesalahpahaman yang terlihat jelas bagi penonton dan perlihatkan reaksi saat tokoh menyadarinya.',
  'Tunjukkan perbedaan alasan dua sahabat, lalu berikan kesempatan untuk saling membantu.',
  'Manfaatkan tekstur, suara, dan waktu memasak; jadikan hasil masakan bagian dari penyelesaian konflik.',
  'Gunakan ritme lingkungan desa; libatkan tetangga lewat aksi yang memengaruhi pilihan tokoh.',
  'Mulai dari tugas selama shift; pakai bunyi pintu atau kasir untuk menandai perubahan situasi.',
  'Perkenalkan bunyi atau objek biasa secara halus, lalu ulangi setelah konteksnya berubah.',
  'Sisipkan petunjuk visual yang dapat dilihat sejak awal dan beri ruang bagi dugaan yang keliru.',
  'Tunjukkan perhatian lewat tindakan kecil sebelum tokoh berani menyampaikan maksudnya.',
  'Tetapkan satu aturan dunia melalui aksi, lalu buat tokoh menanggung akibat dari pilihannya.',
  'Perlihatkan pembagian tugas dan kondisi cahaya atau cuaca sebelum konflik mencapai puncak.',
  'Gunakan perilaku hewan sebagai petunjuk; perlihatkan cara tokoh menyesuaikan kebiasaan merawatnya.',
  'Peragakan aturan permainan dahulu; pakai perbedaan cara bermain untuk menggerakkan konflik.',
  'Gunakan hujan sebagai perubahan keadaan yang terlihat dan terdengar, lalu perlihatkan keputusan bersama.',
  'Berikan petunjuk arah atau tenggat keberangkatan lebih dahulu; gunakan perpindahan lokasi untuk menaikkan tekanan.'
 ];
 const categories=source.map(([id,label],index)=>({id,label,image:artwork[index]}));
 const templates=source.flatMap(([category,label,genre,roles,rows])=>rows.trim().split('\n').map((line,i)=>{
  const [title,synopsis,conflict,locations]=line.split('|');
  const direction=directions[categories.findIndex(item=>item.id===category)];
  const development=direction+' Tempatkan keputusan utama di '+locations.split(', ')[0].toLocaleLowerCase('id-ID')+'.';
  return {id:category+'-'+(i+1),category,label,genre,roles:[...roles],title,synopsis,conflict,development,locations:locations.split(', ')};
 }));
 const find=id=>templates.find(item=>item.id===id);
 function list(category,query=''){
  const words=String(query).trim().toLocaleLowerCase('id-ID').split(/\s+/u).filter(Boolean);
  return templates.filter(item=>{
   if(category&&category!=='all'&&item.category!==category)return false;
   const text=[item.title,item.label,item.synopsis,item.conflict,item.genre,...item.locations,...item.roles].join(' ').toLocaleLowerCase('id-ID');
   return words.every(word=>text.includes(word));
  });
 }
 function assign(template,cast=[],leads=[]){
  const priority=[...cast.filter(c=>leads.includes(c.id)),...cast.filter(c=>!leads.includes(c.id))];
  return template.roles.map((role,index)=>({role,name:priority[index]?.name||'',id:priority[index]?.id||''}));
 }
 return {categories,templates,find,list,assign};
});
