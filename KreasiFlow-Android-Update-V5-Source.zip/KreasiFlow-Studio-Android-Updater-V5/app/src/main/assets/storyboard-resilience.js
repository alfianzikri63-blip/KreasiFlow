/* KreasiFlow v5.0.40: reliable AI storyboard responses and bounded provider fallback.
 * Deliberately never creates a storyboard without a real AI response.
 */
(function(root,factory){
 const api=factory();
 if(typeof module==='object'&&module.exports)module.exports=api;
 root.KFStoryboardResilience=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';
 function parse(raw){
  if(raw&&typeof raw==='object')return raw;
  let s=String(raw||'').trim();
  if(!s)throw Error('Respons AI kosong. Coba model AI lain.');
  const fence=s.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if(fence)s=fence[1].trim();
  try{return JSON.parse(s)}catch(_){}
  const start=s.search(/[\[{]/);
  if(start<0)throw Error('AI tidak mengirim JSON storyboard.');
  const first=s[start],end=s.lastIndexOf(first==='{'?'}':']');
  if(end<start)throw Error('AI mengirim JSON yang terpotong.');
  try{return JSON.parse(s.slice(start,end+1))}
  catch(_){throw Error('Format JSON storyboard tidak lengkap; pilih model dengan dukungan JSON.');}
 }
 function get(row,...names){for(const name of names){if(typeof row?.[name]==='string'&&row[name].trim())return row[name].trim()}return ''}
 function rows(raw,indices){
  const doc=parse(raw);
  const a=Array.isArray(doc)?doc:Array.isArray(doc?.scenes)?doc.scenes:Array.isArray(doc?.storyboard)?doc.storyboard:Array.isArray(doc?.shots)?doc.shots:null;
  if(!a||a.length!==indices.length)throw Error('AI mengembalikan '+(a?.length??0)+' scene, seharusnya '+indices.length+'.');
  return a.map((r,k)=>{
   if(!r||typeof r!=='object')throw Error('Data scene '+(indices[k]+1)+' kosong.');
   const explicit=r.scene??r.scene_number??r.index;
   if(explicit!==undefined && Number(explicit)!==indices[k]+1)throw Error('Nomor scene AI tidak berurutan pada scene '+(indices[k]+1)+'.');
   const title=get(r,'title','name','scene_title');
   const action=get(r,'action','visual_action','visual','description');
   const camera=get(r,'camera','camera_angle','shot','camera_movement');
   const setting=get(r,'setting','location','background','environment');
   let image=get(r,'image_prompt','imagePrompt','image_description','prompt_image');
   let video=get(r,'video_prompt','videoPrompt','motion_prompt','motionPrompt','prompt_video');
   if(!title||!action||!camera||!setting)throw Error('AI belum melengkapi title/action/camera/setting pada scene '+(indices[k]+1)+'.');
   // Prompt derived exclusively from AI-authored shot guidance if the AI omitted a separate field.
   // We do NOT invent local footage or silently make a fake AI storyboard.
   if(!image)image=`${setting}. ${action}. First frame: ${camera}.`;
   if(!video)video=`${action}. Camera movement: ${camera}. Keep ${setting}. Natural motion, no text.`;
   if(action.length<12||camera.length<8||setting.length<5||image.length<22||video.length<22)throw Error('Deskripsi visual scene '+(indices[k]+1)+' terlalu pendek.');
   return {scene:indices[k]+1,title:title.slice(0,90),action:action.slice(0,1400),camera:camera.slice(0,420),setting:setting.slice(0,550),image_prompt:image.slice(0,1700),video_prompt:video.slice(0,2100)};
  });
 }
 function preferredList(chosen,status){
  const a=chosen==='openrouter'?'openrouter':'gemini',b=a==='gemini'?'openrouter':'gemini';
  return [a,b].filter(x=>!!status[x]);
 }
 function safeError(err){
  let message=String(err?.message||err||'Kesalahan tidak diketahui');
  message=message.replace(/sk-or-v1-[a-zA-Z0-9_-]+/g,'[API KEY]')
   .replace(/AIza[a-zA-Z0-9_-]{16,}/g,'[API KEY]');
  return message.slice(0,240);
 }
 async function attempt(available,request,onStage){
  if(!available.length)throw Error('Gemini dan OpenRouter belum punya API key. Buka Pengaturan AI (⚙).');
  const errors=[];
  for(const provider of available){
   try{if(onStage)onStage(provider,errors.length);
    const value=await request(provider);
    return {value,provider};
   }catch(err){errors.push(provider+': '+safeError(err).slice(0,90));}
  }
  throw Error('Semua provider gagal. '+errors.join(' | '));
 }
 function fingerprint(value){const str=JSON.stringify(value);let h=2166136261;for(let i=0;i<str.length;i++){h^=str.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(36)+':'+str.length;}
 return {parse,rows,preferredList,safeError,attempt,fingerprint};
});
