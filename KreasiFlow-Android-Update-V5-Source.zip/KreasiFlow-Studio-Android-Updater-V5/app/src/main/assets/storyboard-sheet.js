/* KreasiFlow v5.0.49 — Storyboard sheet: ONE Gemini image => independent frames per Flow clip.
 * The grid is an editor asset; Google Flow still requires separate Frames-to-Video generations.
 */
(function(root,factory){
 const api=factory();
 if(typeof module==='object'&&module.exports)module.exports=api;
 if(root)root.KFStoryboardSheet=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';
 const MAX_SCENES=16;
 function grid(count,columns){
  const n=Number(count);
  if(!Number.isSafeInteger(n)||n<1||n>MAX_SCENES)throw Error('Storyboard sheet mendukung 1–16 scene. Pecah proyek lebih besar menjadi beberapa sheet.');
  const chosen=Number(columns);
  const cols=Number.isSafeInteger(chosen)&&chosen>=1&&chosen<=4?Math.min(n,chosen):(n<=1?1:n<=4?2:n<=6?3:4);
  return {count:n,cols,rows:Math.ceil(n/cols),empty:cols*Math.ceil(n/cols)-n};
 }
 function shorten(v,max=34){return String(v||'').replace(/\s+/g,' ').trim().split(' ').filter(Boolean).slice(0,max).join(' ');}
 function prompt(input={}){
  const scenes=input.scenes||[],g=grid(scenes.length,input.columns),style=shorten(input.style||'2D Flat Vector Motion Graphic',25);
  const ratio=(String(input.ratio||'').match(/^(9:16|16:9|1:1|4:5|21:9)/)||['9:16'])[0];
  const cast=shorten(input.character,28);
  const continuity=shorten(input.styleRules,62);
  const layout=`${g.cols} COLUMNS x ${g.rows} ROWS`;
  const steps=scenes.map((s,i)=>{
   const visible=shorten(s.prompt||s.flowShot?.action||s.voice||s.name,46);
   const shot=shorten(s.flowShot?.camera||'',13);
   return `PANEL ${String(i+1).padStart(2,'0')} (reading order, left to right, row by row): ${visible}. ${shot?`View: ${shot}.`:''}`;
  }).join('\n');
  return `GOOGLE GEMINI IMAGE — CREATE EXACTLY ONE STORYBOARD CONTACT SHEET, NOT A VIDEO.\n`+
   `TITLE: ${shorten(input.title||'Storyboard',24)}\n`+
   `OUTPUT: ONE raster IMAGE divided into ${g.cols*g.rows} equal rectangular cells, layout ${layout}. `+
   `The first ${g.count} cells show exactly ${g.count} distinct numbered scenes in reading order; `+
   (g.empty?`leave the last ${g.empty} unused cell(s) as plain dark background. `:'')+
   `All cells must be the same size and each cell composed internally for ${ratio} video crop.\n`+
   `TILING REQUIREMENTS: Exact uniform rectangular grid spanning the image edge-to-edge, fixed grid boundaries at equal fractions. `+
   `NO gutters, NO borders, NO labels, NO captions, NO panel numbers printed inside the art, NO typography, NO overlays, NO watermark. `+
   `Do not create a single cinematic shot blending panels together. Do not draw one giant background crossing panels.\n`+
   `GLOBAL CONSISTENCY LOCK: ${style}. ${continuity}. `+
   (cast?`Recurring character identity: ${cast}. `:'')+
   `All panels share identical recurring character design, object geometry, palette, materials and environment continuity. `+
   `Vary scene actions, subject positions and camera angles. Do not repeat one panel with tiny changes.\n`+
   `PANEL SCENES:\n${steps}\n\n`+
   `QUALITY: each cell is one clear first-frame keyframe, readable if separately cropped for Image-to-Video. `+
   `Exactly ONE composite image and NO separate image files. Gemini is generating an image only; Google Flow will animate the cropped panels separately.`;
 }
 function tiles(width,height,count,ratio='9:16',columns){
  const g=grid(count,columns);
  if(!Number.isFinite(width)||!Number.isFinite(height)||width<g.cols*80||height<g.rows*120)throw Error('Resolusi gambar sheet terlalu kecil untuk auto-crop.');
  const [rw,rh]=((String(ratio).match(/^(9:16|16:9|1:1|4:5|21:9)/)||['9:16'])[0]).split(':').map(Number);
  const target=rw/rh;
  return Array.from({length:count},(_,i)=>{
   const col=i%g.cols,row=Math.floor(i/g.cols);
   const x0=Math.round(width*col/g.cols),x1=Math.round(width*(col+1)/g.cols);
   const y0=Math.round(height*row/g.rows),y1=Math.round(height*(row+1)/g.rows);
   const w=x1-x0,h=y1-y0;
   let cropW=w,cropH=h,cropX=x0,cropY=y0;
   if(w/h>target){cropW=h*target;cropX+=(w-cropW)/2;}
   else {cropH=w/target;cropY+=(h-cropH)/2;}
   return {index:i,x:cropX,y:cropY,width:cropW,height:cropH,cell:{x:x0,y:y0,width:w,height:h}};
  });
 }
 return Object.freeze({MAX_SCENES,grid,prompt,tiles});
});
