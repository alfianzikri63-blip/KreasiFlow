(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.KFStudioV6=api;})(globalThis,function(){
'use strict';
function readiness(p={}){
 const scenes=Array.isArray(p.scenes)?p.scenes:[];
 const ready=scenes.filter(s=>s&&(s.clip||s.image)).length;
 const rows=[{name:'Topik',ok:!!String(p.title||'').trim()},{name:'Naskah',ok:!!String(p.script||'').trim()},{name:'Voice-over',ok:!!p.audio},{name:'Storyboard',ok:scenes.length>0},{name:'Media scene',ok:scenes.length>0&&ready===scenes.length}];
 return {rows,ready,total:scenes.length,percent:Math.round(rows.filter(r=>r.ok).length/rows.length*100)};
}
function saveDraft(storage,snapshot){
 try{const raw=JSON.stringify(snapshot);storage.setItem('kreasiflow-current-v3',raw);return true;}catch(e){return false;}
}
function preferDraft(local,native){return !!(local&&native&&local.projectId===native.projectId&&Number(local.draftUpdatedAt)>Number(native.draftUpdatedAt||0));}
return {readiness,saveDraft,preferDraft};
});
