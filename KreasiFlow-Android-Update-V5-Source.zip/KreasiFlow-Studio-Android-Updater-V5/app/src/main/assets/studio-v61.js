(function(root){'use strict';const api={
 researchUrl(topic){return 'https://id.wikipedia.org/w/api.php?'+new URLSearchParams({action:'query',generator:'search',gsrsearch:String(topic).slice(0,180),gsrlimit:'5',prop:'extracts|info',exintro:'1',explaintext:'1',exchars:'1200',inprop:'url',format:'json',origin:'*'});},
 sources(data){return Object.values(data?.query?.pages||{}).sort((a,b)=>(a.index||0)-(b.index||0)).filter(p=>p.extract&&/^https:\/\/id\.wikipedia\.org\//.test(p.fullurl||'')).map(p=>({title:p.title,url:p.fullurl,text:p.extract}));},
 audit(cues){return (cues||[]).map((c,i)=>({index:i+1,cps:String(c.text||'').length/Math.max(.01,Number(c.end)-Number(c.start))})).filter(c=>c.cps>20);},
 estimate(seconds,rate){return Math.max(0,Number(seconds)||0)*Math.max(0,Number(rate)||0)/8/1000000;},
 camera(i){return ['wide establishing shot','medium action shot','close-up of relevant detail','over-the-shoulder or contextual angle'][i%4];},
 fade(t,d){return Math.max(0,Math.min(1,t/.25,(d-t)/.25));}
};if(typeof module==='object')module.exports=api;root.KFStudio61=api;})(globalThis);
