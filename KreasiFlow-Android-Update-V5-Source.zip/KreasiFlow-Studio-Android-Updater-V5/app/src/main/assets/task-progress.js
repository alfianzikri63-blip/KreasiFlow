/* KreasiFlow v5.0.37 — task progress model; no provider keys or uploaded media stored. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.KFTaskProgress=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
 function create(){
  const entries=new Map();let seq=0;
  const clamp=n=>Math.max(0,Math.min(100,Math.floor(Number(n)||0)));
  function start(label,detail='Menyiapkan proses...'){
   const id='op-'+(++seq);entries.set(id,{id,label:String(label||'Proses'),detail:String(detail),percent:0,state:'running'});return id;
  }
  function update(id,percent,detail){const x=entries.get(id);if(!x||x.state!=='running')return null;x.percent=Math.max(x.percent,Math.min(99,clamp(percent)));if(detail!==undefined)x.detail=String(detail);return {...x};}
  function steps(id,done,total,detail){if(!Number.isFinite(total)||total<=0)throw Error('Total langkah harus positif');return update(id,100*Math.max(0,done)/total,detail);}
  function finish(id,ok=true,detail){const x=entries.get(id);if(!x||x.state!=='running')return null;x.state=ok?'done':'error';if(ok)x.percent=100;if(detail!==undefined)x.detail=String(detail);return {...x};}
  function get(id){const v=entries.get(id);return v?{...v}:null;}
  function list(){return [...entries.values()].map(v=>({...v}));}
  function forget(id){entries.delete(id);}
  return {start,update,steps,finish,get,list,forget};
 }
 return {create};
});
