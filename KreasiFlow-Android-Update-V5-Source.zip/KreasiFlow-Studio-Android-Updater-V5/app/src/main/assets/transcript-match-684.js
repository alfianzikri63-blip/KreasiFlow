(function(root,factory){
 const api=factory();
 if(typeof module==='object'&&module.exports)module.exports=api;
 else root.KFTranscriptMatch=api;
})(globalThis,function(){
 'use strict';
 const aliases={ngetok:'mengetuk',ketok:'mengetuk',mengetok:'mengetuk',nengok:'menengok',tengok:'menengok',enggak:'tidak',nggak:'tidak',ngga:'tidak',gak:'tidak',ga:'tidak',tak:'tidak',udah:'sudah',dah:'sudah',aja:'saja',kalo:'kalau',gimana:'bagaimana',gini:'begini',gitu:'begitu',liat:'lihat',keliatan:'kelihatan',makasih:'terimakasih',pengen:'ingin',pingin:'ingin',sampe:'sampai',bentar:'sebentar'};
 const negative=new Set(['tidak','jangan','bukan','belum','tanpa','tak']);
 function clean(text){return String(text??'').replace(/\[[^\]\n]{1,100}\]|\((?:laugh(?:s|ing)?|crying|gasp|cough|tawa|tangisan|batuk|napas|isakan)[^)]{0,35}\)/gi,' ').replace(/\s+/g,' ').trim();}
 function tokens(text){return (clean(text).normalize('NFKC').toLocaleLowerCase('id').match(/[\p{L}\p{N}]+/gu)||[]).map(word=>aliases[word]||word);}
 function edits(a,b){
  let prev=Array.from({length:b.length+1},(_,i)=>i);
  for(let i=0;i<a.length;i++){
   const curr=[i+1];
   for(let j=0;j<b.length;j++)curr[j+1]=Math.min(prev[j+1]+1,curr[j]+1,prev[j]+(a[i]===b[j]?0:1));
   prev=curr;
  }
  return prev[b.length];
 }
 function score(a,b){
  const special=list=>list.filter(x=>negative.has(x)||/^\d+$/u.test(x)).join(' ');
  if(!a.length||!b.length||special(a)!==special(b))return 0;
  const collapse=list=>list.filter((word,i)=>i===0||word!==list[i-1]);
  if(a.join(' ')===b.join(' '))return 1;
  if(collapse(a).join(' ')===collapse(b).join(' '))return .94;
  let prev=Array.from({length:b.length+1},(_,i)=>i);
  for(let i=0;i<a.length;i++){
   const curr=[i+1];
   for(let j=0;j<b.length;j++){
    const x=a[i],y=b[j];
    const cost=x===y?0:x.length>=4&&y.length>=4&&Math.abs(x.length-y.length)<=1&&edits(x,y)===1?.32:1;
    curr[j+1]=Math.min(prev[j+1]+1,curr[j]+1,prev[j]+cost);
   }
   prev=curr;
  }
  return Math.max(0,1-prev[b.length]/Math.max(a.length,b.length));
 }
 function valid(cue,duration){
  return Number.isFinite(cue.start)&&Number.isFinite(cue.end)&&cue.start>=0&&cue.end>cue.start&&cue.end<=duration;
 }
 function analyze(lines,cues,duration,corrections={},extraReviewed=false,timingEstimated=false){
  const speech=(cues||[]).map((cue,index)=>({...cue,index,words:cue.type==='audio_event'?[]:tokens(cue.text)}))
   .filter(cue=>cue.words.length&&valid(cue,duration));
  const byFirst=new Map();
  speech.forEach((cue,index)=>{
   const key=cue.words[0];
   if(!byFirst.has(key))byFirst.set(key,[]);
   byFirst.get(key).push(index);
  });
  const fixed=lines.map((line,i)=>corrections[line.id??i]);
  let states=[{pos:0,cost:0,rows:[]}];
  lines.forEach((line,i)=>{
   const target=tokens(line.text??line),next=new Map();
   function offer(state,pos,cost,row){
    const total=state.cost+cost;
    if(!next.has(pos)||next.get(pos).cost>total)next.set(pos,{pos,cost:total,rows:[...state.rows,row]});
   }
   for(const state of states){
    const manual=fixed[i],before=state.rows.slice().reverse().find(row=>row.start!==undefined);
    if(manual&&valid(manual,duration)&&(!before||manual.start>=before.end)){
     let end=state.pos;
     while(end<speech.length&&speech[end].start<manual.end)end++;
     const indices=speech.slice(state.pos,end).filter(c=>c.end>manual.start).map(c=>c.index);
     offer(state,end,0,{...manual,indices,status:'corrected',score:score(target,tokens(manual.text))});
     continue;
    }
    offer(state,state.pos,1.2,{status:'missing',score:0,indices:[]});
    const upcoming=fixed.slice(i+1).find(cue=>cue&&valid(cue,duration));
    const candidates=[];
    const nearby=Array.from({length:Math.max(0,Math.min(29,speech.length-state.pos))},(_,offset)=>state.pos+offset);
    const farther=(byFirst.get(target[0])||[]).filter(pos=>pos>=state.pos+29);
    for(const start of nearby.concat(farther)){
     if(upcoming&&speech[start].start>=upcoming.start)break;
     if(before&&speech[start].start<before.end)continue;
     let words=[];
     for(let end=start;end<Math.min(speech.length,start+target.length+5);end++){
      if(upcoming&&speech[end].end>upcoming.start)break;
      words=words.concat(speech[end].words);
      if(words.length>target.length+4)break;
      if(words.length<Math.max(1,target.length-4))continue;
      const confidence=score(target,words);
      if(confidence<.64)continue;
      const slice=speech.slice(start,end+1);
      const status=confidence>=.88&&!timingEstimated?'matched':'review';
      const row={start:slice[0].start,end:slice.at(-1).end,text:slice.map(c=>c.text).join(' '),score:confidence,status,indices:slice.map(c=>c.index)};
      const internalGap=slice.slice(1).reduce((max,c,j)=>Math.max(max,c.start-slice[j].end),0);
      const skip=start-state.pos;
      candidates.push({pos:end+1,cost:(1-confidence)*2.2+Math.min(skip,12)*.06+Math.min(1,Math.max(0,internalGap-2))*.2,row});
     }
    }
    candidates.sort((a,b)=>a.cost-b.cost);
    for(const {pos,cost,row} of candidates.slice(0,12))offer(state,pos,cost,row);
   }
   states=[...next.values()].sort((a,b)=>a.cost-b.cost).slice(0,12);
  });
  const best=states.sort((a,b)=>(a.cost+Math.min(18,speech.length-a.pos)*.06)-(b.cost+Math.min(18,speech.length-b.pos)*.06))[0];
  const rows=best?.rows||[],used=new Set(rows.flatMap(row=>row.indices));
  const extra=speech.filter(c=>!used.has(c.index));
  // If a timed segment contains multiple dialogues, keep the segment in the review list.
  // Never infer internal word boundaries from a segment timestamp.
  return {rows,extra,ready:!!lines.length&&rows.every(r=>r.status==='matched'||r.status==='corrected')&&(!extra.length||extraReviewed)};
 }
 return {clean,tokens,score,valid,analyze};
});
