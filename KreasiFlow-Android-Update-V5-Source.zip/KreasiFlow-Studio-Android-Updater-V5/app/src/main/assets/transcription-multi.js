/* v5.0.39 — word-accurate STT adapter and bounded fallback policy.
 * API keys never enter this module. Provider output is untrusted and validated. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.KFMultiTranscription=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';
 const KNOWN=['elevenlabs','groq','gemini'];
 function order(preferred,available,allowFallback=true){
   const primary=KNOWN.includes(preferred)?preferred:'elevenlabs';
   const candidates=[primary,...KNOWN.filter(p=>p!==primary)];
   const list=candidates.filter(p=>!!available[p]);
   return allowFallback?list:list.slice(0,1).filter(p=>p===primary);
 }
 function shouldFallback(error){
   const message=String(error?.message||error||'');
   // Retryable capacity and billing issues; no cascade on invalid keys, invalid audio or timeouts
   // where the remote service may already have charged for the transcription.
   return /\bHTTP\s+(?:429|500|502|503|504)\b/i.test(message);
 }
 function cuesFromWords(words,duration,maxCues=250){
   if(!Array.isArray(words))throw Error('Data word-level timestamp tidak ada');
   const clean=words.filter(w=>w&&w.type!=='spacing'&&w.type!=='audio_event').map(w=>({
     start:Number(w.start),end:Number(w.end),text:String(w.text??w.word??'').trim()
   })).filter(w=>w.text&&Number.isFinite(w.start)&&Number.isFinite(w.end)&&w.start>=0&&w.end>w.start);
   if(!clean.length)throw Error('AI tidak mengembalikan kata bertimestamp');
   if(clean.some(w=>w.end>duration+0.3))throw Error('Timestamp melampaui durasi VO');
   const maxWords=Math.max(7,Math.ceil(clean.length/Math.max(1,maxCues-15)));
   const groups=[];let batch=[];
   function flush(){if(batch.length){groups.push({start:batch[0].start,end:batch[batch.length-1].end,text:batch.map(w=>w.text).join(' ').replace(/\s+([,.:;!?])/g,'$1').replace(/\s+/g,' ').trim()});batch=[];}}
   clean.forEach((w,i)=>{
     const previous=batch[batch.length-1];
     if(previous&&(w.start-previous.end)>0.85 && batch.length>=3)flush();
     batch.push(w);
     const next=clean[i+1];
     if(batch.length>=maxWords || (batch.length>=4 && /[.!?…]$/.test(w.text)) || (batch.length>=3 && next && next.start-w.end>0.72))flush();
   });flush();
   // Keep every recognized word while respecting renderer's 250-cue limit.
   while(groups.length>maxCues){
     let idx=0,least=Infinity;
     for(let i=0;i<groups.length-1;i++){
       const gap=Math.max(0,groups[i+1].start-groups[i].end);
       const cost=gap+Math.max(0,(groups[i].text.length+groups[i+1].text.length)-350)*0.03;
       if(cost<least){idx=i;least=cost;}
     }
     const a=groups[idx],b=groups[idx+1];
     groups.splice(idx,2,{start:a.start,end:b.end,text:a.text+' '+b.text});
   }
   const cues=groups.map(c=>({start:+c.start.toFixed(3),end:+c.end.toFixed(3),text:c.text}));
   if(cues.some(c=>c.text.length>400))throw Error('VO terlalu panjang untuk maksimum 250 subtitle. Pisahkan VO menjadi beberapa bagian.');
   return cues;
 }
 function normalize(response,duration){
   if(!response || typeof response!=='object')throw Error('Respons AI tidak valid');
   if(Array.isArray(response.words)&&response.words.length){
     try{return cuesFromWords(response.words,duration);}catch(e){if(!Array.isArray(response.segments)||!response.segments.length)throw e;}
   }
   if(!Array.isArray(response.segments)||!response.segments.length)throw Error('Provider tidak mengirim timestamp untuk subtitle');
   return response.segments.map(seg=>({start:Number(seg.start),end:Number(seg.end),text:String(seg.text||'').trim()}));
 }
 async function run({preferred='elevenlabs',available={},allowFallback=true,call,onStage=()=>{}}){
   const providers=order(preferred,available,allowFallback);
   if(!providers.length)throw Error('Tidak ada API key transkripsi untuk provider pilihan. Buka Pengaturan AI.');
   for(let i=0;i<providers.length;i++){
     const provider=providers[i];
     onStage({stage:'request',provider,attempt:i+1,total:providers.length,percent:55+Math.round(i/Math.max(1,providers.length)*25)});
     try{return {result:await call(provider),provider};}
     catch(err){
       if(!shouldFallback(err)||i===providers.length-1){throw err;}
       onStage({stage:'fallback',provider:providers[i+1],attempt:i+2,total:providers.length,percent:55+Math.round((i+1)/providers.length*25),reason:String(err.message||err).slice(0,130)});
     }
   }
   throw Error('Semua provider gagal');
 }
 return {order,shouldFallback,cuesFromWords,normalize,run};
});
