/* KreasiFlow v5.0.38 — controlled retry for audio transcription only.
 * Never retry 429, 401 or 403. A request may consume provider quota even
 * if the client sees an error: the user must confirm up to three calls.
 * No API keys/audio bytes enter this helper. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.KFTranscriptionRetry=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
 const PLAN=Object.freeze([
  Object.freeze({model:'gemini-3.6-flash',waitMs:0}),
  Object.freeze({model:'gemini-3.8-flash',waitMs:3000}),
  Object.freeze({model:'gemini-3.8-flash',waitMs:8000})
 ]);
 function errText(error){return String(error&&error.message||error||'');}
 function isOverloaded(error){return /\b(?:Gemini\s+)?HTTP\s+(?:503|502|504)\s*:/i.test(errText(error))||/\bMODEL_OVERLOADED\b/i.test(errText(error));}
 function isMissingModel(error){return /\b(?:Gemini\s+)?HTTP\s+404\s*:/i.test(errText(error));}
 function wait(ms){return new Promise(resolve=>setTimeout(resolve,ms));}
 async function run(call,onStage=()=>{},sleep=wait){
  if(typeof call!=='function')throw Error('Fungsi request transkrip tidak ada');
  let last=null;
  for(let i=0;i<PLAN.length;i++){
   const entry=PLAN[i],num=i+1;
   if(i){
    if(!isOverloaded(last)&&!(i===1&&isMissingModel(last)))throw last;
    onStage({stage:'wait',attempt:num,total:PLAN.length,model:entry.model,waitMs:entry.waitMs,percent:50+i*3});
    await sleep(entry.waitMs);
   }
   onStage({stage:'request',attempt:num,total:PLAN.length,model:entry.model,percent:50+i*3});
   try{return await call(entry.model,num);}catch(error){
    last=error;
    if(!isOverloaded(error)&&!isMissingModel(error))throw error;
    if(isMissingModel(error)&&i>=1)throw new Error('Model cadangan Gemini tidak tersedia untuk API key ini. Periksa model yang aktif di Google AI Studio atau gunakan impor SRT.');
   }
  }
  if(isOverloaded(last))throw new Error('Gemini sedang penuh (HTTP 503) setelah 3 percobaan. VO dan subtitle lama tetap aman. Coba lagi nanti atau gunakan Estimasi dari teks / Impor SRT.');
  throw last||new Error('Transkrip audio Gemini gagal');
 }
 return {PLAN,isOverloaded,isMissingModel,run};
});
