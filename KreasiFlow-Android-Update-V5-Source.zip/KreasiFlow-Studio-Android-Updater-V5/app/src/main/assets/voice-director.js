(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.KFVoiceDirector=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';
 const profiles={mystery:['Misterius & Horor','[low, steady voice, restrained suspense]','[quietly, with growing curiosity]','[serious, controlled delivery]'],documentary:['Dokumenter Sinematik','[calm, confident narration]','[thoughtfully, with measured emphasis]','[clear, steady delivery]'],science:['Edukasi & Sains','[curious, clear delivery]','[explaining with gentle emphasis]','[warm, confident narration]'],emotion:['Emosional','[warm, reflective tone]','[softly, with empathy]','[sincere, measured delivery]'],viral:['Enerjik & Viral','[energetic, clear delivery]','[excited, with controlled emphasis]','[confident, lively tone]'],casual:['Storytelling Santai','[warm, conversational tone]','[curious, natural delivery]','[relaxed, steady voice]']};
 const oneLine=v=>String(v??'').replace(/\s+/g,' ').trim();
 function pick(mode,context){if(profiles[mode])return mode;const t=String(context||'').toLowerCase();if(/misteri|horor|horror|thriller|mystery|crime|menegangkan|supranatural/.test(t))return 'mystery';if(/emosi|motivasi|inspirasi|drama|emotional/.test(t))return 'emotion';if(/sains|science|edukasi|cara kerja|teknologi|education/.test(t))return 'science';if(/viral|fakta cepat|ranking|enerjik/.test(t))return 'viral';if(/santai|komedi|dongeng|casual/.test(t))return 'casual';return 'documentary';}
 function direct(text,mode,context,loop){const clean=oneLine(text);if(!clean||mode==='plain')return clean;const p=profiles[pick(mode,context)];const parts=clean.split(/(?<=[.!?])\s+(?=[\p{L}\p{N}“"(])/u);const result=[];let current='';for(let i=0;i<parts.length;i++){let tag='';if(i===0)tag=p[1];else if(loop&&i===parts.length-1)tag=p[1];else if(i===Math.floor(parts.length/2)&&parts.length>=3)tag=p[2];else if(!loop&&i===parts.length-1&&parts.length>=4)tag=p[3];else if(i>0&&i<parts.length-1&&parts.length>=5&&/^(namun|tetapi|ternyata|tiba-tiba|however|but|suddenly)\b/i.test(parts[i]))tag=p[2];if(tag&&tag!==current){result.push(tag);current=tag;}result.push(parts[i]);}return result.join(' ');}
 const dialogueProfiles={
  auto:['Otomatis sesuai dialog',''],
  warm:['Hangat dan santai','[warm, conversational]'],
  worried:['Gugup dan pelan','[quietly, a little nervous]'],
  firm:['Tenang dan tegas','[calm, firm]'],
  bright:['Ceria dan ringan','[cheerfully]'],
 };
 function dialogue(text,mode='auto',emotion=''){
  const spoken=oneLine(text);
  if(!spoken)return '';
  const preset=dialogueProfiles[mode]?.[1];
  const mood=String(emotion||'').toLowerCase();
  const direction=/sedih|duka|sad/.test(mood)?'[softly, with sadness]':/panik|takut|fear|nervous/.test(mood)?'[quietly, a little nervous]':/marah|angry|geram/.test(mood)?'[firm, with controlled anger]':/gembira|ceria|happy/.test(mood)?'[cheerfully]':'';
  const tag=preset||direction||(/\?["”']?$/.test(spoken)?'[curiously]':/!["”']?$/.test(spoken)?'[with a quick burst of energy]':'[conversational]');
  return tag+' '+spoken;
 }
 const emotions={
  natural:['Natural',''],happy:['Bahagia','happy'],sad:['Sedih','sad'],afraid:['Takut','frightened'],panic:['Panik','panicked'],
  nervous:['Gugup','nervously'],angry:['Marah','angry'],whisper:['Berbisik','whispers'],surprised:['Terkejut','gasps'],
  crying:['Menangis','crying'],laughing:['Tertawa','laughs'],pleading:['Memohon','pleading'],firm:['Tegas','firmly'],
  relieved:['Lega','relieved'],confused:['Bingung','confused'],suspicious:['Curiga','suspicious'],disappointed:['Kecewa','disappointed'],
  excited:['Antusias','excited'],breath:['Menahan napas','breath held'],anxious:['Cemas','anxiously']
 };
 const keywords=[
  ['whisper',/bisik|whisper/],['crying',/menangis|isak|crying|sob/],['laughing',/tertawa|laugh/],
  ['breath',/tahan napas|menahan napas|breath held|holding.*breath/],['panic',/panik|panic/],
  ['afraid',/takut|fear|frighten|gemetar|scared/],['nervous',/gugup|nervous/],['angry',/marah|angry|geram|murka/],
  ['surprised',/terkejut|kaget|surpris|startled/],['pleading',/memohon|mohon|plead|begging/],
  ['relieved',/lega|relief|relieved/],['confused',/bingung|confused/],['suspicious',/curiga|suspicious|waspada/],
  ['disappointed',/kecewa|disappointed/],['anxious',/cemas|anxious|khawatir|worried/],['sad',/sedih|duka|sad/],
  ['firm',/tegas|firm/],['excited',/antusias|excited/],['happy',/bahagia|ceria|happy|cheerful|senang/]
 ];
 function moodOf(value){
  const text=String(value||'').toLowerCase();
  return emotions[text]?text:keywords.find(([,rule])=>rule.test(text))?.[0];
 }
 function deliveryFor(row,context={},mode='auto'){
  if(emotions[row.emotionOverride])return row.emotionOverride;
  if(dialogueProfiles[mode]&&mode!=='auto')return {warm:'natural',worried:'nervous',firm:'firm',bright:'happy'}[mode];
  const marked=moodOf(row.emotion);
  const delivery=moodOf(row.delivery);
  const surrounding=[row.expression,context.atmosphere,context.action,context.previous,context.next].join(' ').toLowerCase();
  const tense=/menegangkan|mencekam|ketakutan|bahaya|ketegangan|tense|terrified|threat|horror|terancam|tegang/.test(surrounding);
  if(delivery==='whisper')return 'whisper';
  if(marked&&marked!=='natural'&&!(tense&&marked==='happy'))return marked;
  if(delivery&&!(tense&&delivery==='happy'))return delivery;
  if(tense){
   if(/jangan.*(?:jauh|tinggal)|tolong|temani|please/i.test(row.text))return 'pleading';
   return /!["”']?$/u.test(row.text)?'afraid':'anxious';
  }
  return moodOf(row.expression)||moodOf(context.atmosphere)||'natural';
 }
 function supportsTags(model){return model==='v3'||model==='v4';}
 function contextualDialogue(row,context={},model,mode='auto'){
  const spoken=oneLine(row.text).replace(/\[[^\]\n]{1,100}\]/g,'').replace(/\s+/g,' ').trim();
  if(!spoken||!supportsTags(model))return spoken;
  const mood=deliveryFor(row,context,mode);
  const sentences=spoken.split(/(?<=[.!?…])\s+/u);
  const markers=new Map();
  if(!row.emotionOverride&&mode==='auto')for(const beat of row.beats||[]){
   const key=moodOf(beat.emotion);
   if(Number.isInteger(beat.sentence)&&beat.sentence>1&&beat.sentence<=sentences.length&&key)markers.set(beat.sentence-1,key);
  }
  let last='';
  return sentences.map((part,i)=>{
   const current=markers.get(i)||(i===0?mood:last),tag=emotions[current]?.[1];
   if(current===last||!tag)return part;
   last=current;
   const intense=i===0&&Number(row.intensity)>=4;
   const breath=intense&&(current==='panic'||current==='afraid')&&/!["”']?$/u.test(part)?'[gasps] ':'';
   return breath+'['+tag+'] '+part;
  }).join(' ');
 }
 return {oneLine,pick,direct,profiles,dialogueProfiles,dialogue,emotions,deliveryFor,contextualDialogue,supportsTags};
});
