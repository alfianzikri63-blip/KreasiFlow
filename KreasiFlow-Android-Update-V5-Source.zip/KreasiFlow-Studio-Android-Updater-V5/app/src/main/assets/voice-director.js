(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.KFVoiceDirector=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';
 const profiles={mystery:['Misterius & Horor','[low, steady voice, restrained suspense]','[quietly, with growing curiosity]','[serious, controlled delivery]'],documentary:['Dokumenter Sinematik','[calm, confident narration]','[thoughtfully, with measured emphasis]','[clear, steady delivery]'],science:['Edukasi & Sains','[curious, clear delivery]','[explaining with gentle emphasis]','[warm, confident narration]'],emotion:['Emosional','[warm, reflective tone]','[softly, with empathy]','[sincere, measured delivery]'],viral:['Enerjik & Viral','[energetic, clear delivery]','[excited, with controlled emphasis]','[confident, lively tone]'],casual:['Storytelling Santai','[warm, conversational tone]','[curious, natural delivery]','[relaxed, steady voice]']};
 const oneLine=v=>String(v??'').replace(/\s+/g,' ').trim();
 function pick(mode,context){if(profiles[mode])return mode;const t=String(context||'').toLowerCase();if(/misteri|horor|horror|thriller|mystery|crime|menegangkan|supranatural/.test(t))return 'mystery';if(/emosi|motivasi|inspirasi|drama|emotional/.test(t))return 'emotion';if(/sains|science|edukasi|cara kerja|teknologi|education/.test(t))return 'science';if(/viral|fakta cepat|ranking|enerjik/.test(t))return 'viral';if(/santai|komedi|dongeng|casual/.test(t))return 'casual';return 'documentary';}
 function direct(text,mode,context,loop){const clean=oneLine(text);if(!clean||mode==='plain')return clean;const p=profiles[pick(mode,context)];const parts=clean.split(/(?<=[.!?])\s+(?=[\p{L}\p{N}“"(])/u);const result=[];let current='';for(let i=0;i<parts.length;i++){let tag='';if(i===0)tag=p[1];else if(loop&&i===parts.length-1)tag=p[1];else if(i===Math.floor(parts.length/2)&&parts.length>=3)tag=p[2];else if(!loop&&i===parts.length-1&&parts.length>=4)tag=p[3];else if(i>0&&i<parts.length-1&&parts.length>=5&&/^(namun|tetapi|ternyata|tiba-tiba|however|but|suddenly)\b/i.test(parts[i]))tag=p[2];if(tag&&tag!==current){result.push(tag);current=tag;}result.push(parts[i]);}return result.join(' ');}
 const dialogueProfiles={
  auto:['Otomatis sesuai dialog',''],
  warm:['Hangat dan santai','[warm, conversational]'],
  worried:['Gugup dan pelan','[quietly, a little nervous]'],
  firm:['Tenang dan tegas','[calm, firm]'],
  bright:['Ceria dan ringan','[cheerfully]'],
 };
 function dialogue(text,mode='auto'){
  const spoken=oneLine(text);
  if(!spoken)return '';
  const preset=dialogueProfiles[mode]?.[1];
  const tag=preset||(/\?["”']?$/.test(spoken)?'[curiously]':/!["”']?$/.test(spoken)?'[with a quick burst of energy]':'[conversational]');
  return tag+' '+spoken;
 }
 return {oneLine,pick,direct,profiles,dialogueProfiles,dialogue};
});
