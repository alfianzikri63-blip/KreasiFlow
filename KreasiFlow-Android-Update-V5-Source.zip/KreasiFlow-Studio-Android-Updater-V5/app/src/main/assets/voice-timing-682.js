(function(root,factory){
 const api=factory();
 if(typeof module==='object'&&module.exports)module.exports=api;
 else root.KFVoiceTiming=api;
})(globalThis,function(){
 'use strict';
 function valid(cues,duration){
  return (cues||[]).map(c=>({...c,start:Number(c.start),end:Number(c.end)}))
   .filter(c=>c.start>=0&&c.start<duration&&c.end>c.start&&c.end<=duration+.025&&String(c.text||'').trim())
   .map(c=>({...c,end:Math.min(c.end,duration)}))
   .sort((a,b)=>a.start-b.start||a.end-b.end);
 }
 function gaps(cues){
  let end=cues[0]?.end||0;
  const cuts=[];
  for(const cue of cues.slice(1)){
   if(cue.start>=end)cuts.push((end+cue.start)/2);
   end=Math.max(end,cue.end);
  }
  return cuts;
 }
 function fromTranscript(cues,duration,target){
  const lines=valid(cues,duration),rows=[];
  if(!lines.length)return rows;
  let start=0,first=0,lastEnd=lines[0].end;
  function append(last,end){
   rows.push({voice:lines.slice(first,last).map(c=>c.text).join(' '),startSec:start,endSec:end,durationSec:end-start,estimated:false});
   start=end;first=last;
  }
  for(let i=1;i<lines.length&&rows.length<99;i++){
   const next=lines[i],previous=lines[i-1],silence=next.start-lastEnd;
   const sentence=/[.!?…]["”']?$/u.test(previous.text.trim());
   const span=lastEnd-start;
   const shouldSplit=target?span>=target*.65&&(sentence||silence>=.35)||span>=target*1.35&&silence>=.12:(sentence&&span>=1.6)||(silence>=.55&&span>=1.2);
   if(silence>=0&&shouldSplit)append(i,(lastEnd+next.start)/2);
   lastEnd=Math.max(lastEnd,next.end);
  }
  append(lines.length,duration);
  return rows;
 }
 function align(desired,cues,words,duration){
  const lines=valid(cues,duration);
  const primary=gaps(lines);
  const secondary=gaps(valid(words,duration));
  const useWords=primary.length<desired.length-2;
  const cuts=[...new Set(useWords?[...primary,...secondary]:primary)].filter(t=>t>0&&t<duration).sort((a,b)=>a-b);
  if(!lines.length||cuts.length<desired.length-2)return null;
  const starts=[0];
  let offset=0;
  for(let i=1;i<desired.length-1;i++){
   const max=cuts.length-(desired.length-i-1);
   let best=offset;
   for(let j=offset+1;j<=max;j++){
    if(Math.abs(cuts[j]-desired[i])<Math.abs(cuts[best]-desired[i]))best=j;
    if(cuts[j]>desired[i])break;
   }
   starts.push(cuts[best]);offset=best+1;
  }
  starts.push(duration);
  return starts;
 }
 function batch(scenes,segments,rate){
  const ascending=[...segments].sort((a,b)=>a.row.i-b.row.i||(a.row.j??0)-(b.row.j??0));
  if(!ascending.length)throw Error('Belum ada ucapan untuk disusun.');
  const track=[],starts=[0],cues=[];
  let cursor=0,index=0,previous=null;
  function gap(n){
   if(n<=0)return;
   if(cursor+n>600*rate)throw Error('Hasil sinkronisasi melebihi 600 detik.');
   track.push(new Float32Array(n));cursor+=n;
  }
  scenes.forEach((scene,i)=>{
   const sceneStart=cursor;
   while(ascending[index]?.row.i===i){
    const segment=ascending[index++];
    const pause=segment.packed?0:!previous?segment.start:
     previous.source===segment.source?Math.max(0,segment.start-previous.end):Math.round(.12*rate);
    gap(pause);
    const start=cursor/rate;
    cursor+=segment.samples.length;
    if(cursor>600*rate)throw Error('Hasil sinkronisasi melebihi 600 detik.');
    track.push(segment.samples);
    cues.push({start:start+(segment.speechStart||0)/rate,end:segment.speechEnd===undefined?cursor/rate:start+segment.speechEnd/rate,text:segment.row.text,...(segment.row.id?{dialogueId:segment.row.id}:{})});
    if(index===ascending.length&&!segment.packed)gap(segment.length-segment.end);
    previous=segment;
   }
   if(cursor===sceneStart)gap(Math.max(1,Math.round((scene.endSec-scene.startSec||1)*rate)));
   starts.push(cursor/rate);
  });
  return {clips:track,cues,starts};
 }
 function envelope(position,duration,fadeIn,fadeOut){
  return Math.max(0,Math.min(1,fadeIn>0?position/fadeIn:1,fadeOut>0?(duration-position)/fadeOut:1));
 }
 return {fromTranscript,align,batch,envelope};
});
