package id.kreasiflow.rebuild;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.os.Environment;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.view.View;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class MainActivity extends Activity {
    private static final int FILE_PICKER = 1401;
    private WebView web;
    private android.webkit.ValueCallback<Uri[]> pickerCallback;
    private final Map<String, FileOutputStream> activeStreams = new ConcurrentHashMap<>();
    private final Map<String, File> receivedFiles = new ConcurrentHashMap<>();
    private final Object fileLock = new Object();
    private File inbox;
    private VideoComposer composer;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(5,23,14));
        getWindow().setNavigationBarColor(Color.rgb(5,23,14));
        inbox = new File(getCacheDir(), "media-inbox"); inbox.mkdirs();
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(5,23,14));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setDatabaseEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new LocalBridge(), "KreasiAndroid");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest r) {
                if (!"file".equalsIgnoreCase(r.getUrl().getScheme())) {
                    openChrome(r.getUrl().toString());return true;
                }
                return false;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, android.webkit.ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pickerCallback != null) pickerCallback.onReceiveValue(null);
                pickerCallback = callback;
                try {
                    Intent i = params.createIntent();
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(i, FILE_PICKER);
                    return true;
                } catch (Exception ex) {
                    pickerCallback = null;
                    return false;
                }
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==FILE_PICKER && pickerCallback!=null){
            Uri[] result = null;
            if(resultCode==RESULT_OK && data!=null){
                if(data.getClipData()!=null){
                    int n=data.getClipData().getItemCount();result=new Uri[n];
                    for(int i=0;i<n;i++)result[i]=data.getClipData().getItemAt(i).getUri();
                }else if(data.getData()!=null)result=new Uri[]{data.getData()};
            }
            pickerCallback.onReceiveValue(result);pickerCallback=null;
        }
    }

    private void openChrome(String url) {
        runOnUiThread(()->{
            try {
                Uri u=Uri.parse(url);
                if(!"https".equalsIgnoreCase(u.getScheme()))throw new Exception("Hanya URL HTTPS diizinkan");
                Intent intent=new Intent(Intent.ACTION_VIEW,u);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                startActivity(intent);
            }catch(Exception e){Toast.makeText(this,"Tidak bisa membuka Chrome: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        });
    }

    private void callback(String message,boolean ok){
        runOnUiThread(()->{
            if(web!=null) web.evaluateJavascript("window.KreasiFlowRenderStatus("+JSONObject.quote(message)+","+ok+")",null);
            Toast.makeText(this,message,Toast.LENGTH_LONG).show();
        });
    }

    private boolean safeName(String name) {
        return name!=null && name.length()<100 && name.matches("[A-Za-z0-9._-]+") && !name.startsWith(".") && !name.contains("..");
    }

    private void saveDownload(String name,String type,InputStream input) throws IOException {
        if(!safeName(name))throw new IOException("Invalid filename");
        if(Build.VERSION.SDK_INT>=29){
            ContentValues values=new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME,name);
            values.put(MediaStore.Downloads.MIME_TYPE,type);
            values.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/KreasiFlow");
            values.put(MediaStore.Downloads.IS_PENDING,1);
            Uri item=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
            if(item==null)throw new IOException("Gagal menambahkan file ke Downloads");
            try(OutputStream output=getContentResolver().openOutputStream(item)){
                if(output==null)throw new IOException("Tidak bisa menulis file");
                byte[] block=new byte[65536];int n;
                while((n=input.read(block))>=0)output.write(block,0,n);
            }catch(Exception e){getContentResolver().delete(item,null,null);throw e;}
            values.clear();values.put(MediaStore.Downloads.IS_PENDING,0);
            getContentResolver().update(item,values,null,null);
        }else{
            File folder=new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"KreasiFlow");folder.mkdirs();
            try(OutputStream out=new FileOutputStream(new File(folder,name))){byte[] block=new byte[65536];int len;while((len=input.read(block))>=0)out.write(block,0,len);}
        }
    }

    public class LocalBridge {
        @JavascriptInterface public void openChrome(String url){MainActivity.this.openChrome(url);}
        @JavascriptInterface public void beginAsset(String name){
            if(!safeName(name))throw new IllegalArgumentException("Invalid asset name");
            synchronized(fileLock){try{
                FileOutputStream previous=activeStreams.remove(name);
                if(previous!=null)previous.close();
                File f=new File(inbox,name);
                activeStreams.put(name,new FileOutputStream(f,false));
                receivedFiles.put(name,f);
            }catch(IOException e){throw new RuntimeException(e);}}
        }
        @JavascriptInterface public void assetChunk(String name,String b64){
            synchronized(fileLock){
                try{
                    FileOutputStream out=activeStreams.get(name);
                    if(out==null)throw new IOException("Asset not begun: "+name);
                    if(b64.length()>100000)throw new IOException("Chunk too large");
                    out.write(android.util.Base64.decode(b64,android.util.Base64.DEFAULT));
                }catch(Exception e){throw new RuntimeException(e);}
            }
        }
        @JavascriptInterface public void endAsset(String name){
            synchronized(fileLock){try{FileOutputStream f=activeStreams.remove(name);if(f!=null)f.close();}catch(IOException e){throw new RuntimeException(e);}}
        }
        @JavascriptInterface public void saveText(String name,String text){
            new Thread(()->{
                try{saveDownload(name,"application/json",new ByteArrayInputStream(text.getBytes(StandardCharsets.UTF_8)));callback("Proyek JSON tersimpan di Downloads/KreasiFlow",true);}catch(Exception e){callback("Gagal simpan: "+e.getMessage(),false);}
            }).start();
        }
        @JavascriptInterface public void renderProject(String json){
            runOnUiThread(()->{
                if(composer!=null && composer.isRunning()){callback("Render masih berjalan; selesaikan terlebih dahulu.",false);return;}
                try{composer=new VideoComposer(MainActivity.this,inbox,receivedFiles,(file,error)->{
                    if(error!=null){callback("Render gagal: "+error,false);return;}
                    new Thread(()->{try(FileInputStream in=new FileInputStream(file)){
                        saveDownload("KreasiFlow-"+System.currentTimeMillis()+".mp4","video/mp4",in);
                        callback("MP4 berhasil disimpan di Downloads/KreasiFlow",true);
                    }catch(Exception e){callback("Video berhasil, tapi gagal menyimpan: "+e.getMessage(),false);}}).start();
                });composer.start(json);
                }catch(Exception e){callback("Render gagal dijalankan: "+e.getMessage(),false);}
            });
        }
    }
    @Override public void onBackPressed(){if(web!=null && web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){synchronized(fileLock){for(FileOutputStream f:activeStreams.values()){try{f.close();}catch(Exception ignored){}}activeStreams.clear();}if(web!=null){web.destroy();web=null;}super.onDestroy();}
}
