package id.kreasiflow.rebuild;

import android.content.Context;
import android.graphics.Matrix;
import android.net.Uri;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.audio.ChannelMixingAudioProcessor;
import androidx.media3.common.audio.ChannelMixingMatrix;
import androidx.media3.common.Effect;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.effect.MatrixTransformation;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.EditedMediaItemSequence;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.Transformer;
import androidx.media3.common.util.UnstableApi;
import java.io.File;
import java.util.*;
import org.json.JSONArray;
import org.json.JSONObject;

@UnstableApi
public final class VideoComposer {
    public interface ResultCallback{void finished(File mp4,String error);}
    private final Context context;
    private final File inbox;
    private final Map<String,File> received;
    private final ResultCallback callback;
    private boolean running=false;
    private Transformer transformer;
    public VideoComposer(Context context,File inbox,Map<String,File> received,ResultCallback callback){this.context=context;this.inbox=inbox;this.received=received;this.callback=callback;}
    public boolean isRunning(){return running;}
    private File require(String name) throws Exception {
        if(name==null||!name.matches("[A-Za-z0-9._-]+")||name.contains(".."))throw new Exception("Nama media tidak valid");
        File f=received.get(name);
        if(f==null||!f.isFile()||f.length()<20)throw new Exception("Media belum dikirim: "+name);
        if(!f.getCanonicalPath().startsWith(inbox.getCanonicalPath()+File.separator))throw new Exception("Lokasi media tidak valid");
        return f;
    }
    private ChannelMixingAudioProcessor stereo(float volume){
        float v=Math.min(1f,Math.max(0f,volume));
        ChannelMixingAudioProcessor p=new ChannelMixingAudioProcessor();
        p.putChannelMixingMatrix(new ChannelMixingMatrix(1,2,new float[]{v*.7071067f,v*.7071067f}));
        p.putChannelMixingMatrix(new ChannelMixingMatrix(2,2,new float[]{v,0f,0f,v}));
        return p;
    }
    private EditedMediaItem audioItem(String key,float volume) throws Exception {
        File f=require(key);
        List<AudioProcessor> audioEffects=new ArrayList<>();audioEffects.add(stereo(volume));
        return new EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(f)))
          .setEffects(new Effects(audioEffects,Collections.emptyList())).build();
    }
    public void start(String json) throws Exception {
        if(running)throw new IllegalStateException("Renderer sudah aktif");
        JSONObject job=new JSONObject(json);
        JSONArray names=job.getJSONArray("images"),durations=job.getJSONArray("durations");
        if(names.length()==0||names.length()>90||names.length()!=durations.length())throw new Exception("Jumlah scene tidak sesuai");
        boolean zoom=job.optBoolean("zoom",true);
        List<EditedMediaItem> images=new ArrayList<>();
        for(int i=0;i<names.length();i++){
            File f=require(names.getString(i));
            long duration=Math.max(1000,Math.min(60000,durations.getLong(i)));
            MediaItem media=new MediaItem.Builder().setUri(Uri.fromFile(f)).setImageDurationMs(duration).build();
            EditedMediaItem.Builder item=new EditedMediaItem.Builder(media).setFrameRate(30);
            if(zoom){
                final float direction=(i%2==0?1f:-1f);
                final long durUs=duration*1000;
                MatrixTransformation effect=presentationUs->{
                    float t=Math.min(1f,Math.max(0f,presentationUs/(float)durUs));
                    Matrix mat=new Matrix();
                    float z=direction>0?1.01f+0.07f*t:1.08f-0.07f*t;
                    mat.setScale(z,z);return mat;
                };
                List<Effect> fx=new ArrayList<>();fx.add(effect);
                item.setEffects(new Effects(Collections.emptyList(),fx));
            }
            images.add(item.build());
        }
        String voice=job.getString("voice");
        List<EditedMediaItemSequence> sequences=new ArrayList<>();
        sequences.add(EditedMediaItemSequence.withVideoFrom(images));
        sequences.add(EditedMediaItemSequence.withAudioFrom(Collections.singletonList(audioItem(voice,1f))));
        String music=job.optString("music","");
        if(!music.isEmpty()){
            EditedMediaItemSequence bg=EditedMediaItemSequence.withAudioFrom(
                Collections.singletonList(audioItem(music,(float)job.optDouble("musicVolume",.15))))
                .buildUpon().setIsLooping(true).build();
            sequences.add(bg);
        }
        Composition composition=new Composition.Builder(sequences).build();
        File out=new File(context.getCacheDir(),"kreasiflow-"+System.currentTimeMillis()+".mp4");
        transformer=new Transformer.Builder(context)
           .setVideoMimeType(MimeTypes.VIDEO_H264)
           .setAudioMimeType(MimeTypes.AUDIO_AAC)
           .addListener(new Transformer.Listener(){
               @Override public void onCompleted(Composition composition,ExportResult result){running=false;callback.finished(out,null);}
               @Override public void onError(Composition composition,ExportResult result,ExportException ex){running=false;callback.finished(null,ex.getMessage());}
           }).build();
        running=true;
        try{transformer.start(composition,out.getAbsolutePath());}catch(Exception ex){running=false;throw ex;}
    }
}
