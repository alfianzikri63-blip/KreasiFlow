package id.kreasiflow.studio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * v5.0.43: Native, user-initiated AI job runner. No dependency on WebView or Activity.
 * All API tokens are read from Android Keystore-backed ProviderSecrets, not job files.
 * A status snapshot and partial batch results survive Activity destruction; Android
 * process death/force-stop still interrupts a running job and is reported honestly.
 */
public final class AiForegroundService extends Service {
    private static final String TAG="KFAiBackground";
    private static final String CHANNEL="kf_ai_jobs_v1";
    private static final int NOTIFICATION_ID=8462;
    private static final String PREF="kf_ai_job_status";
    private static final String RUN="id.kreasiflow.studio.AI_RUN";
    private static final String CANCEL="id.kreasiflow.studio.AI_CANCEL";
    private static final AtomicBoolean ACTIVE=new AtomicBoolean(false);
    private volatile boolean cancelled=false;
    private volatile Thread worker;
    private volatile boolean timedOut=false;
    private PowerManager.WakeLock wakeLock;
    private String jobId="";
    private File jobFile;
    private long lastNotify=0;
    private int lastPercent=-1;

    static JSONObject performance(Context c){try{return new JSONObject(c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("performance","{}"));}catch(Exception e){return new JSONObject();}}
    private void measure(String provider,String kind,long since,boolean ok){try{
        JSONObject all=performance(this);String k=provider+":"+kind;JSONObject old=all.optJSONObject(k);
        JSONArray previous=old==null?null:old.optJSONArray("samples"),samples=new JSONArray();
        if(previous!=null)for(int i=Math.max(0,previous.length()-19);i<previous.length();i++)samples.put(previous.getJSONObject(i));
        samples.put(new JSONObject().put("ms",Math.max(1,android.os.SystemClock.elapsedRealtime()-since)).put("ok",ok));
        long total=0;int successes=0;for(int i=0;i<samples.length();i++){JSONObject item=samples.getJSONObject(i);total+=item.getLong("ms");if(item.getBoolean("ok"))successes++;}
        all.put(k,new JSONObject().put("n",samples.length()).put("ok",successes).put("ms",total/samples.length()).put("samples",samples));
        getSharedPreferences(PREF,MODE_PRIVATE).edit().putString("performance",all.toString()).apply();
    }catch(Exception ignored){}}
    private static File directory(Context context){return new File(context.getFilesDir(),"ai-jobs");}
    private static File resultFile(Context context,String id){return new File(directory(context),id+"-result.json");}
    private static void durable(File file,String text)throws IOException{
        File tmp=new File(file.getParentFile(),file.getName()+".tmp");
        try(FileOutputStream out=new FileOutputStream(tmp)){out.write(text.getBytes(StandardCharsets.UTF_8));out.getFD().sync();}
        if(!tmp.renameTo(file)){
            try(FileOutputStream out=new FileOutputStream(file)){out.write(text.getBytes(StandardCharsets.UTF_8));out.getFD().sync();}
            tmp.delete();
        }
    }
    static JSONObject status(Context c){
        String raw=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("status","");
        try{
            JSONObject status=raw.isEmpty()?new JSONObject():new JSONObject(raw);
            String state=status.optString("state","");
            if(("running".equals(state)||"queued".equals(state))&&!ACTIVE.get()){
                status.put("state","interrupted");
                status.put("message","Android menghentikan proses AI. Hasil batch sebelumnya masih tersimpan; coba ulang yang belum selesai.");
                c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString("status",status.toString()).commit();
            }
            return status;
        }catch(Exception e){return new JSONObject();}
    }
    static JSONObject result(Context c,String id){
        if(id==null||!id.matches("[a-f0-9-]{36}"))return new JSONObject();
        File file=resultFile(c,id);
        if(!file.isFile()||file.length()>2_000_000)return new JSONObject();
        try{return new JSONObject(new String(Files.readAllBytes(file.toPath()),StandardCharsets.UTF_8));}
        catch(Exception e){return new JSONObject();}
    }
    static void enqueue(Context c,JSONObject input,File audio)throws Exception{
        String kind=input.optString("kind","");
        if(!("title".equals(kind)||"script".equals(kind)||"storyboard".equals(kind)||"transcription".equals(kind)))
            throw new IOException("Jenis pekerjaan AI tidak dikenal");
        if(!ACTIVE.compareAndSet(false,true))throw new IOException("Satu pekerjaan AI masih berjalan. Lihat notifikasi untuk progres.");
        String id=UUID.randomUUID().toString();
        File folder=directory(c);File file=new File(folder,id+".json");
        try{
            if(!folder.exists()&&!folder.mkdirs())throw new IOException("Folder pekerjaan AI tidak dapat dibuat");
            if(input.toString().length()>650_000)throw new IOException("Storyboard terlalu besar. Kurangi jumlah scene atau panjang naskah.");
            JSONObject job=new JSONObject(input.toString());
            job.remove("audio_asset_id");job.remove("file");
            job.put("jobId",id);
            if("transcription".equals(kind)){
                if(audio==null||!audio.isFile()||audio.length()==0||audio.length()>12L*1024*1024)
                    throw new IOException("Berkas VO belum siap atau lebih dari 12 MB");
                File stored=new File(folder,id+"-audio.bin");
                try(FileInputStream in=new FileInputStream(audio);FileOutputStream out=new FileOutputStream(stored)){
                    byte[] block=new byte[32768];int n;while((n=in.read(block))>=0)out.write(block,0,n);
                    out.getFD().sync();
                }
                job.put("file",stored.getAbsolutePath());
            }
            durable(file,job.toString());
            JSONObject queued=new JSONObject().put("state","queued").put("jobId",id)
                .put("kind",kind).put("percent",0).put("message","Pekerjaan AI siap dijalankan di background")
                .put("updatedAt",System.currentTimeMillis());
            if(!c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString("status",queued.toString()).commit())
                throw new IOException("Tidak bisa menyimpan status pekerjaan AI");
            Intent intent=new Intent(c,AiForegroundService.class).setAction(RUN).putExtra("jobId",id);
            ContextCompat.startForegroundService(c,intent);
        }catch(Exception e){ACTIVE.set(false);throw e;}
    }
    @Override public IBinder onBind(Intent intent){return null;}
    @Override public void onCreate(){
        super.onCreate();
        NotificationChannel channel=new NotificationChannel(CHANNEL,"KreasiFlow — AI berjalan",NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null){stopSelf();return START_NOT_STICKY;}
        if(CANCEL.equals(intent.getAction())){
            if(intent.getStringExtra("jobId")!=null&&intent.getStringExtra("jobId").equals(jobId)){
                cancelled=true;Thread t=worker;if(t!=null)t.interrupt();
            }
            return START_NOT_STICKY;
        }
        if(!RUN.equals(intent.getAction())||worker!=null)return START_NOT_STICKY;
        jobId=intent.getStringExtra("jobId");
        if(jobId==null||!jobId.matches("[a-f0-9-]{36}")){ACTIVE.set(false);stopSelf();return START_NOT_STICKY;}
        jobFile=new File(directory(this),jobId+".json");
        try{
            if(Build.VERSION.SDK_INT>=29)startForeground(NOTIFICATION_ID,notification("Memulai pekerjaan AI",0,true),ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            else startForeground(NOTIFICATION_ID,notification("Memulai pekerjaan AI",0,true));
        }catch(Exception e){Log.e(TAG,"Foreground AI start rejected",e);record("error",0,"Android menolak foreground AI: "+e.getClass().getSimpleName(),status(this).optString("kind",""));ACTIVE.set(false);stopSelf();return START_NOT_STICKY;}
        worker=new Thread(()->runJob(startId),"kf-native-ai-worker");worker.start();
        return START_NOT_STICKY;
    }
    private Notification notification(String message,int percent,boolean ongoing){
        Intent open=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openAction=PendingIntent.getActivity(this,88,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder n=new NotificationCompat.Builder(this,CHANNEL)
            .setSmallIcon(R.drawable.ic_kreasiflow)
            .setContentTitle(ongoing?"KreasiFlow • AI "+percent+"%":"KreasiFlow • AI")
            .setContentText(message).setStyle(new NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_LOW).setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setOnlyAlertOnce(true).setOngoing(ongoing).setAutoCancel(!ongoing).setContentIntent(openAction);
        if(ongoing){
            n.setProgress(100,Math.max(0,Math.min(99,percent)),false);
            Intent cancel=new Intent(this,AiForegroundService.class).setAction(CANCEL).putExtra("jobId",jobId);
            PendingIntent cancelAction=PendingIntent.getService(this,89,cancel,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            n.addAction(android.R.drawable.ic_delete,"Batalkan",cancelAction);
        }
        return n.build();
    }
    private static String safeMessage(String message){String v=String.valueOf(message).replaceAll("[\\r\\n]+"," ");return v.substring(0,Math.min(600,v.length()));}
    private void record(String state,int percent,String message,String kind){
        try{
            JSONObject value=new JSONObject().put("state",state).put("percent",Math.max(0,Math.min(percent,100)))
              .put("message",safeMessage(message))
              .put("jobId",jobId).put("kind",kind).put("updatedAt",System.currentTimeMillis());
            getSharedPreferences(PREF,MODE_PRIVATE).edit().putString("status",value.toString()).commit();
        }catch(Exception e){Log.w(TAG,"Unable to store AI status",e);}
    }
    private void progress(int percent,String message,String kind){
        if(cancelled||Thread.currentThread().isInterrupted()||timedOut)throw new IllegalStateException("Pekerjaan AI dibatalkan atau mencapai batas waktu Android");
        int p=Math.max(0,Math.min(99,percent));long now=System.currentTimeMillis();
        record("running",p,message,kind);
        if(p!=lastPercent||now-lastNotify>1200){lastPercent=p;lastNotify=now;
            getSystemService(NotificationManager.class).notify(NOTIFICATION_ID,notification(message,p,true));}
    }
    private void finish(String state,int percent,String msg,String kind){
        record(state,percent,msg,kind);
        try{getSystemService(NotificationManager.class).notify(NOTIFICATION_ID,notification(msg,percent,false));}
        catch(SecurityException ignored){}
    }
    static void requestCancel(Context c){
        JSONObject state=status(c);String id=state.optString("jobId","");
        if(!id.isEmpty()&&("running".equals(state.optString("state"))||"queued".equals(state.optString("state"))))
            c.startService(new Intent(c,AiForegroundService.class).setAction(CANCEL).putExtra("jobId",id));
    }
    private String preferred(JSONObject job){String p=job.optString("provider");return java.util.Arrays.asList("groq","openrouter","gemini","cloudflare","nvidia").contains(p)?p:"gemini";}
    private static final java.util.Map<String,Long> providerCooldown=new java.util.concurrent.ConcurrentHashMap<>();
    private static String parseText(String provider,String raw)throws Exception{
        JSONObject doc=new JSONObject(raw);
        if("gemini".equals(provider)){
            String output=doc.optString("text","").trim();
            if(output.length()<3)throw new IOException("Gemini tidak mengirim teks storyboard");
            return output;
        }
        JSONArray choices=doc.optJSONArray("choices");
        if(choices==null||choices.length()==0){
            JSONObject error=doc.optJSONObject("error");
            if(error!=null)throw new IOException(provider+" HTTP "+error.optString("code","unknown")+": "+safeMessage(error.optString("message","Respons error")));
            throw new IOException(provider+" respons kosong: tidak mengembalikan pilihan model teks");
        }
        StringBuilder output=new StringBuilder();
        String finish="";
        for(int i=0;i<choices.length();i++){
            JSONObject choice=choices.optJSONObject(i);if(choice==null)continue;
            finish=choice.optString("finish_reason",finish);
            JSONObject message=choice.optJSONObject("message");if(message==null)continue;
            Object content=message.opt("content");
            if(content instanceof String)output.append((String)content);
            else if(content instanceof JSONArray){
                JSONArray parts=(JSONArray)content;
                for(int j=0;j<parts.length();j++){
                    JSONObject part=parts.optJSONObject(j);
                    if(part!=null)output.append(part.optString("text",part.optString("output_text","")));
                }
            }else if(content instanceof JSONObject){
                JSONObject part=(JSONObject)content;
                output.append(part.optString("text",part.optString("output_text","")));
            }
            if(output.length()<3)output.append(message.optString("output_text",""));
        }
        String value=output.toString().trim();
        if(value.length()<3){
            JSONObject usage=doc.optJSONObject("usage");
            JSONObject details=usage==null?null:usage.optJSONObject("completion_tokens_details");
            int thinking=details==null?0:details.optInt("reasoning_tokens",0);
            String why="length".equals(finish)?"batas token output habis":"model tidak menghasilkan teks";
            if(thinking>0)why+=" ("+thinking+" token penalaran)";
            throw new IOException(provider+" respons kosong: "+why+". Gunakan model teks bebas-penalaran.");
        }
        return value;
    }
    /** Verify the response for THIS batch before marking it completed. A malformed
     *  response must not be cached as a successful storyboard. */
    private static void validateStoryboardJson(String text,JSONArray indices)throws Exception {
        if(indices==null)throw new IOException("Daftar scene storyboard kosong");
        String cleaned=text.trim();
        if(cleaned.startsWith("```")){
            int firstNewline=cleaned.indexOf('\n');int lastFence=cleaned.lastIndexOf("```");
            if(firstNewline>=0&&lastFence>firstNewline)cleaned=cleaned.substring(firstNewline+1,lastFence).trim();
        }
        if(!cleaned.startsWith("{")){
            int p=cleaned.indexOf('{'),q=cleaned.lastIndexOf('}');
            if(p>=0&&q>p)cleaned=cleaned.substring(p,q+1);
        }
        JSONObject obj;
        try{obj=new JSONObject(cleaned);}catch(Exception e){throw new IOException("JSON storyboard tidak valid; beralih provider jika tersedia",e);}
        JSONArray scenes=obj.optJSONArray("scenes");
        if(scenes==null||scenes.length()!=indices.length())throw new IOException("Jumlah scene JSON tidak cocok; beralih provider jika tersedia");
        for(int i=0;i<indices.length();i++){
            JSONObject sc=scenes.optJSONObject(i);
            if(sc==null||sc.optInt("scene",-1)!=indices.optInt(i,-100)+1)
                throw new IOException("Urutan scene JSON tidak cocok; beralih provider jika tersedia");
            for(String field:new String[]{"title","action","camera","setting"})
                if(sc.optString(field,"").trim().length()<5)
                    throw new IOException("Field storyboard "+field+" tidak lengkap; beralih provider jika tersedia");
        }
    }
    private String text(JSONObject job,String prompt,String label,String kind)throws Exception{
        return text(job,prompt,label,kind,null);
    }
    private String text(JSONObject job,String prompt,String label,String kind,JSONArray indices)throws Exception{
        String primary=preferred(job); java.util.LinkedHashSet<String> order=new java.util.LinkedHashSet<>();order.add(primary);order.add("cloudflare");order.add("nvidia");order.add("groq");order.add("gemini");order.add("openrouter");
        ProviderSecrets secrets=new ProviderSecrets(this);Exception last=null;
        StringBuilder summary=new StringBuilder();
        for(String provider:order){
            if(providerCooldown.getOrDefault(provider,0L)>android.os.SystemClock.elapsedRealtime()){if(summary.length()>0)summary.append(" | ");summary.append(provider).append(": cooldown setelah 429/503");continue;}
            String key=secrets.get(provider);if(key==null||key.isEmpty())continue;
            String cfAccount="cloudflare".equals(provider)?secrets.get("cloudflare_account"):null;
            if("cloudflare".equals(provider)&&(cfAccount==null||!cfAccount.matches("(?i)[0-9a-f]{32}")))continue;
            boolean storyboard="storyboard".equals(kind);
            boolean script="script".equals(kind);
            String configured=job.optString("model","openrouter/free");
            // The random OpenRouter free router sometimes returns only reasoning;
            // for storyboard pick two explicit text+JSON capable free models.
            // Never override a specific user-selected model or silently choose paid alternatives.
            String[] models="openrouter".equals(provider)&&storyboard&&"openrouter/free".equals(configured)
                ?new String[]{"google/gemma-4-26b-a4b-it:free","inclusionai/ling-3.2-flash:free"}
                :"openrouter".equals(provider)&&script&&"openrouter/free".equals(configured)
                    ?new String[]{"google/gemma-4-26b-a4b-it:free","google/gemma-4-31b-it:free"}
                    :new String[]{"openrouter".equals(provider)?configured:"groq".equals(provider)?"openai/gpt-oss-20b":"cloudflare".equals(provider)?"@cf/meta/llama-3.3-70b-instruct-fp8-fast":"nvidia".equals(provider)?"google/gemma-4-31b-it":"gemini"};
            boolean leaveProvider=false;
            for(String route:models){
                int attempts=1; // one attempt per configured route; fallback remains available
                for(int attempt=1;attempt<=attempts;attempt++){
                    if(cancelled||Thread.currentThread().isInterrupted())throw new IOException("AI dibatalkan pengguna");
                    long attemptStart=android.os.SystemClock.elapsedRealtime();
                    try{
                        String detail="gemini".equals(provider)?(storyboard?"Gemini (batas baca 45 detik)":"Gemini"):route;
                        if(script)detail+=" (naskah cepat)";
                        if("title".equals(kind))detail+=" (mode cepat, batas baca 12 detik)";
                        progress(script?Math.max(lastPercent,provider.equals(primary)?10:35):Math.max(7,lastPercent),label+" • "+detail+" (percobaan "+attempt+")",kind);
                        JSONObject payload=new JSONObject().put("op","text").put("prompt",prompt)
                            .put("model",route).put("max_tokens",storyboard?6000:Math.max(128,Math.min(8192,job.optInt("max_tokens","title".equals(kind)?768:3500))))
                            .put("fast_text",!storyboard)
                            .put("title_fast","title".equals(kind))
                            .put("script_fast",script)
                            .put("storyboard_job",storyboard&&!"gemini".equals(provider))
                            .put("storyboard_fast",storyboard&&"openrouter".equals(provider)&&
                                (route.equals("google/gemma-4-26b-a4b-it:free")||route.equals("inclusionai/ling-3.2-flash:free")));
                        AtomicBoolean waiting=new AtomicBoolean(true);
                        Thread heartbeat=null;
                        if(storyboard||script){
                            final long since=System.currentTimeMillis();final String waitLabel=label+" • "+detail;
                            heartbeat=new Thread(()->{
                                while(waiting.get()){
                                    try{Thread.sleep(10000);}catch(InterruptedException interrupted){return;}
                                    if(!waiting.get()||cancelled||timedOut)return;
                                    long seconds=Math.max(1,(System.currentTimeMillis()-since)/1000L);
                                    try{progress(Math.max(7,lastPercent),waitLabel+" • menunggu "+seconds+" detik (server AI)...",kind);}
                                    catch(Exception ignored){return;}
                                }
                            },"kf-ai-storyboard-heartbeat");
                            heartbeat.setDaemon(true);heartbeat.start();
                        }
                        String raw;
                        try{
                            raw="gemini".equals(provider)
                                ?(storyboard?GeminiApi.fastStoryboard(payload,key):GeminiApi.execute(payload,key))
                                :MultiProviderApi.execute(provider,payload,key,cfAccount);
                        }finally{
                            waiting.set(false);
                            if(heartbeat!=null)heartbeat.interrupt();
                        }
                        if(cancelled||timedOut||Thread.currentThread().isInterrupted())throw new IOException("AI dibatalkan pengguna");
                        String body=parseText(provider,raw);
                        if(indices!=null)validateStoryboardJson(body,indices);
                        if(script&&body.trim().split("\\s+").length<12)throw new IOException("Naskah AI tidak lengkap (kurang dari 12 kata)");
                        measure(provider,kind,attemptStart,true);return body;
                    }catch(Exception ex){
                        if(!cancelled&&!timedOut)measure(provider,kind,attemptStart,false);
                        last=ex;String error=String.valueOf(ex.getMessage());
                        if(error.matches("(?is).*HTTP 429.*")){providerCooldown.put(provider,android.os.SystemClock.elapsedRealtime()+60000L);leaveProvider=true;}
                        else if(error.matches("(?is).*HTTP 503.*")){providerCooldown.put(provider,android.os.SystemClock.elapsedRealtime()+30000L);leaveProvider=true;}
                        if(summary.length()>0)summary.append(" | ");
                        summary.append(provider).append(" (").append("gemini".equals(provider)?"API":route)
                            .append("): ").append(safeMessage(error).substring(0,Math.min(80,safeMessage(error).length())));
                        if(cancelled||Thread.currentThread().isInterrupted())throw new IOException("AI dibatalkan pengguna",ex);
                        // Invalid requests and credentials must not repeatedly incur network calls.
                        if(error.matches("(?is).*(?:HTTP (?:400|413)|payload too large|prompt terlalu panjang).*")){
                            if(script&&models.length>1&&error.matches("(?is).*HTTP 400.*(?:model|reasoning|provider|parameter).*"))break;
                            leaveProvider=true;break;
                        }
                        if(error.matches("(?is).*(?:HTTP (?:401|402|403|429)|API key|invalid key|billing|saldo|kredit|insufficient|kuota).*")){
                            if(script&&models.length>1&&error.matches("(?is).*HTTP 429.*(?:upstream|provider rate|provider is|temporarily rate).*"))break;
                            leaveProvider=true;break;
                        }
                        boolean transientProblem=error.matches("(?is).*(?:HTTP (?:404|500|502|503|504)|timed out|timeout|melewati batas baca|temporar|overload|high demand|rate limit|kosong|empty|tidak valid|tidak cocok|tidak lengkap|connection reset|terpotong|batas token).*" );
                        if(!transientProblem){leaveProvider=true;break;}
                        if(attempt<attempts){progress(Math.max(7,lastPercent),label+" • server sibuk, mencoba ulang...",kind);Thread.sleep(2300);}
                    }
                }
                if(leaveProvider)break;
                // A different free text model may succeed after an empty/503 response.
                if(models.length>1&&!route.equals(models[models.length-1]))progress(script?Math.max(55,lastPercent):Math.max(7,lastPercent),label+" • mencoba model teks gratis cadangan...",kind);
            }
            if("title".equals(kind))break; // one network attempt, then local ideas in UI
            progress(Math.max(7,lastPercent),label+" • beralih ke AI cadangan jika tersedia...",kind);
        }
        if(last!=null)throw new IOException(("script".equals(kind)?"Naskah AI belum berhasil: ":"Storyboard/AI belum berhasil: ")+summary.toString().substring(0,Math.min(520,summary.length())),last);
        throw new IOException("Tidak ada provider teks siap, atau sedang cooldown. Periksa Pengaturan AI.");
    }
    private JSONObject transcribe(JSONObject job)throws Exception{
        String chosen=job.optString("provider","elevenlabs");
        boolean fallback=job.optBoolean("fallback",true);
        String[] order;
        switch(chosen){
            case "groq":order=fallback?new String[]{"groq","elevenlabs","gemini"}:new String[]{"groq"};break;
            case "gemini":order=fallback?new String[]{"gemini","elevenlabs","groq"}:new String[]{"gemini"};break;
            default:order=fallback?new String[]{"elevenlabs","groq","gemini"}:new String[]{"elevenlabs"};
        }
        ProviderSecrets secrets=new ProviderSecrets(this);
        File audio=new File(job.optString("file",""));
        if(!audio.getCanonicalFile().getParentFile().equals(directory(this).getCanonicalFile())||!audio.isFile())throw new IOException("Berkas VO background tidak ditemukan");
        String mime=job.optString("mime","audio/mpeg");double duration=job.optDouble("duration",0);
        IOException last=null;int i=0;
        for(String provider:order){
            i++;String key=secrets.get(provider);if(key==null||key.isEmpty())continue;
            progress(22+Math.round(60f*(i-1)/order.length),"Transkripsi VO • "+provider+" ("+i+"/"+order.length+")", "transcription");
            try{
                String raw="gemini".equals(provider)?GeminiApi.transcribe(audio,mime,duration,key,"gemini-3.6-flash")
                    :TranscriptionProviders.transcribe(provider,audio,mime,duration,key,"auto");
                return new JSONObject().put("provider",provider).put("payload",new JSONObject(raw));
            }catch(Exception e){
                String reason=String.valueOf(e.getMessage());last=new IOException(reason);
                if(!fallback||!reason.matches("(?is).*(?:HTTP (?:429|500|502|503|504)|timeout|temporar|overload|high demand|rate limit).*"))throw e;
            }
        }
        if(last!=null)throw last;
        throw new IOException("API key untuk transkripsi belum tersedia");
    }
    private void runJob(int startId){
        String kind="";
        try{
            PowerManager pm=getSystemService(PowerManager.class);
            wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"KreasiFlow:AiBackground");
            wakeLock.acquire(90*60*1000L); // Guard against forgotten locks; the system still enforces FGS time limits.
            JSONObject job=new JSONObject(new String(Files.readAllBytes(jobFile.toPath()),StandardCharsets.UTF_8));
            kind=job.optString("kind","");
            JSONObject saved=new JSONObject().put("jobId",jobId).put("kind",kind);
            progress(4,"Menyiapkan "+kind+"...",kind);
            if("title".equals(kind)||"script".equals(kind)){
                String generated=text(job,job.getString("prompt"),"AI membuat "+("title".equals(kind)?"judul":"naskah"),kind);
                saved.put("text",generated);
                progress(96,"Hasil AI diterima. Menyimpan proyek...",kind);
            }else if("transcription".equals(kind)){
                progress(12,"VO tersimpan di perangkat; menghubungi AI...",kind);
                saved.put("transcript",transcribe(job));
                progress(95,"Timestamp diterima; menyimpan transkrip...",kind);
            }else if("storyboard".equals(kind)){
                JSONArray batches=job.getJSONArray("batches");
                if(batches.length()==0||batches.length()>50)throw new IOException("Jumlah batch storyboard di luar batas");
                final int totalScenes=Math.max(1,job.optInt("sceneCount",batches.length()*3));
                int completedScenes=0;
                JSONArray results=new JSONArray();saved.put("batches",results);
                durable(resultFile(this,jobId),saved.toString());
                for(int i=0;i<batches.length();i++){
                    JSONObject batch=batches.getJSONObject(i);
                    JSONArray indices=batch.optJSONArray("indices");
                    int startScene=indices==null||indices.length()==0?completedScenes+1:indices.optInt(0)+1;
                    int endScene=indices==null||indices.length()==0?startScene:indices.optInt(indices.length()-1)+1;
                    String sceneLabel="Scene "+startScene+(startScene<endScene?"–"+endScene:"")+" dari "+totalScenes;
                    progress(5+(int)Math.floor(86.0*completedScenes/totalScenes),sceneLabel+" • menunggu AI (batch "+(i+1)+"/"+batches.length()+")",kind);
                    String prompt=batch.getString("prompt");
                    if(prompt.length()>85000)throw new IOException("Prompt storyboard terlalu panjang");
                    if(results.length()>0){
                        JSONObject prev=results.optJSONObject(results.length()-1);
                        if(prev!=null)prompt+="\nPREVIOUS_COMPLETED_SCENES (do not repeat action or camera): "+prev.optString("text","").substring(0,Math.min(2200,prev.optString("text","").length()));
                    }
                    String body=text(job,prompt,sceneLabel,kind,indices);
                    JSONObject answer=new JSONObject().put("indices",batch.optJSONArray("indices")).put("text",body);
                    results.put(answer);
                    // Durable checkpoint after every batch, not only at the end.
                    durable(resultFile(this,jobId),saved.toString());
                    completedScenes+=indices==null?0:indices.length();
                    progress(5+(int)Math.floor(86.0*completedScenes/totalScenes),"Storyboard "+completedScenes+"/"+totalScenes+" scene tersimpan",kind);
                }
                progress(95,"Semua batch tersimpan; siap diperiksa perbedaan footage",kind);
            }
            if(cancelled||timedOut)throw new IOException("Proses AI dihentikan");
            durable(resultFile(this,jobId),saved.toString());
            finish("done",100,"AI "+kind+" selesai. Buka KreasiFlow untuk menggunakan hasil.",kind);
        }catch(Exception e){
            Log.w(TAG,"Background AI failed (no credentials logged)",e);
            String msg=cancelled?"Dibatalkan oleh pengguna":timedOut?"Batas waktu foreground service Android tercapai":String.valueOf(e.getMessage());
            finish(cancelled?"cancelled":timedOut?"interrupted":"error",Math.max(0,lastPercent),"AI "+kind+" gagal: "+msg,kind);
        }finally{
            try{if(wakeLock!=null&&wakeLock.isHeld())wakeLock.release();}catch(Exception ignored){}
            if(jobFile!=null)jobFile.delete();
            ACTIVE.set(false);worker=null;stopSelf(startId);
        }
    }
    // Android 15 dataSync foreground services have a total six-hour per-day limit.
    @Override public void onTimeout(int startId,int type){timedOut=true;Thread t=worker;if(t!=null)t.interrupt();stopSelf(startId);}
    @Override public void onDestroy(){
        if(worker!=null){cancelled=true;worker.interrupt();}
        try{if(wakeLock!=null&&wakeLock.isHeld())wakeLock.release();}catch(Exception ignored){}
        ACTIVE.set(false);super.onDestroy();
    }
}
