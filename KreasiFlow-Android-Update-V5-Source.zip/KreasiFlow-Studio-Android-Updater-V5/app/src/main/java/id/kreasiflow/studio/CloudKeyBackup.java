package id.kreasiflow.studio;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Supabase Auth + end-to-end encrypted BYOK backup.
 * The Supabase server receives only AES-GCM ciphertext, never provider keys.
 * Cloud backup passphrase is supplied per operation and is NOT persisted.
 * Never use a service_role / sb_secret key in this Android application.
 */
final class CloudKeyBackup {
    private static final int ITERATIONS=250_000;
    private static final String SESSION_ALIAS="kreasiflow.cloud.session.v1";
    private static final String[] PROVIDERS={"gemini","openrouter","cloudflare","cloudflare_account","replicate","elevenlabs","groq"};
    private final SharedPreferences prefs;
    private final ProviderSecrets secrets;
    private final SecureRandom rng=new SecureRandom();

    // Only Supabase project URL and PUBLISHABLE (public) key are bundled.
    // Never embed service_role, sb_secret_, provider API keys, or backup passphrases.
    private static final String DEFAULT_SUPABASE_URL="https://ykmatipfszslrdmqqxib.supabase.co";
    private static final String DEFAULT_PUBLISHABLE_KEY="sb_publishable_3vr74QfX2dHHN15bA9EbKA_YcgUH2Eh";

    CloudKeyBackup(Context context,ProviderSecrets providerSecrets){
        prefs=context.getSharedPreferences("kreasiflow_cloud_auth",Context.MODE_PRIVATE);
        secrets=providerSecrets;
        // First-run defaults. Existing user configuration and sessions remain unchanged.
        if(prefs.getString("url","").isEmpty() && prefs.getString("publishable","").isEmpty()){
            prefs.edit().putString("url",DEFAULT_SUPABASE_URL)
                .putString("publishable",DEFAULT_PUBLISHABLE_KEY).apply();
        }
    }
    private String url(){return prefs.getString("url","");}
    private String publicKey(){return prefs.getString("publishable","");}
    private JSONObject session(){
        String raw=prefs.getString("session",null);
        if(raw==null)return null;
        try{return new JSONObject(decryptSession(raw));}
        catch(Exception e){return null;}
    }
    private void saveSession(JSONObject value)throws Exception{
        if(!prefs.edit().putString("session",encryptSession(value.toString())).commit())throw new Exception("Gagal menyimpan sesi aman di perangkat");
    }
    private void clearSession(){prefs.edit().remove("session").commit();}
    synchronized JSONObject status()throws Exception{
        JSONObject state=new JSONObject();JSONObject s=session();
        state.put("configured",!url().isEmpty()&&!publicKey().isEmpty());
        state.put("url",url());state.put("publishable",publicKey());
        state.put("loggedIn",s!=null&&!s.optString("refresh_token","").isEmpty());
        state.put("email",s==null?"":s.optString("email",""));
        int count=0;for(String p:PROVIDERS)if(secrets.get(p)!=null)count++;
        state.put("localKeyCount",count);
        return state;
    }
    synchronized JSONObject execute(JSONObject req)throws Exception{
        String operation=req.optString("op","");
        if("configure".equals(operation)){
            URI uri=new URI(req.optString("url","").trim());
            String host=uri.getHost();
            if(!"https".equalsIgnoreCase(uri.getScheme())||host==null||!host.matches("[a-zA-Z0-9-]+\\.supabase\\.co")||uri.getPort()!=-1||uri.getRawUserInfo()!=null||uri.getRawQuery()!=null||uri.getRawFragment()!=null||!(uri.getRawPath()==null||uri.getRawPath().isEmpty()||"/".equals(uri.getRawPath())))
                throw new Exception("URL Supabase harus https://PROJECT-REF.supabase.co");
            String key=req.optString("publishable","").trim();
            if(key.startsWith("sb_secret_")||key.length()<25||key.length()>1600||!(key.startsWith("sb_publishable_")||key.startsWith("eyJ")))
                throw new Exception("Masukkan publishable key (sb_publishable_) atau legacy anon key, BUKAN secret/service_role");
            if(key.startsWith("eyJ")){
                // Reject legacy service_role JWTs before storing them in a public client.
                try{
                    String[] parts=key.split("\\.");
                    if(parts.length!=3)throw new Exception();
                    JSONObject claims=new JSONObject(new String(Base64.decode(parts[1],Base64.URL_SAFE|Base64.NO_WRAP|Base64.NO_PADDING),StandardCharsets.UTF_8));
                    if(!"anon".equals(claims.optString("role")))throw new Exception();
                }catch(Exception e){throw new Exception("JWT legacy harus memiliki role anon, bukan service_role");}
            }
            String normalized=uri.getScheme()+"://"+host.toLowerCase(java.util.Locale.ROOT);
            if(!normalized.equals(url())||!key.equals(publicKey()))clearSession();
            if(!prefs.edit().putString("url",normalized).putString("publishable",key).commit())throw new Exception("Gagal menyimpan konfigurasi Supabase");
            return new JSONObject().put("message","Konfigurasi Supabase disimpan");
        }
        if("logout".equals(operation)){
            JSONObject s=session();
            clearSession();
            if(s!=null)try{http("POST","/auth/v1/logout",new JSONObject(),s.optString("access_token",""),null);}catch(Exception ignored){}
            return new JSONObject().put("message","Keluar dari akun. API key lokal tetap aman.");
        }
        if(url().isEmpty()||publicKey().isEmpty())throw new Exception("Atur URL dan publishable key Supabase dulu");
        if("signup".equals(operation)||"login".equals(operation)){
            String email=req.optString("email","").trim();String password=req.optString("password","");
            if(email.length()>254||!email.matches("[^\\s@]+@[^\\s@]+\\.[^\\s@]+")||password.length()<8||password.length()>256)
                throw new Exception("Isi email valid dan password 8–256 karakter");
            JSONObject body=new JSONObject().put("email",email).put("password",password);
            JSONObject response=http("POST","signup".equals(operation)?"/auth/v1/signup":"/auth/v1/token?grant_type=password",body,null,null);
            if(response.optString("access_token","").isEmpty()){
                if("signup".equals(operation))return new JSONObject().put("message","Akun dibuat. Periksa email konfirmasi Supabase, lalu Login.");
                throw new Exception("Login tidak mengembalikan sesi; periksa verifikasi email");
            }
            storeAuthResponse(response,email);
            return new JSONObject().put("message","Berhasil masuk ke akun Supabase").put("email",email);
        }
        if("backup".equals(operation)||"restore".equals(operation)||"delete_backup".equals(operation)){
            JSONObject s=refreshSession();
            String uid=s.optString("user_id","");
            if(!uid.matches("[0-9a-fA-F-]{36}"))throw new Exception("ID akun tidak valid");
            String endpoint="/rest/v1/kreasiflow_key_backups?user_id=eq."+uid;
            if("delete_backup".equals(operation)){
                http("DELETE",endpoint,null,s.optString("access_token"),null);
                return new JSONObject().put("message","Backup cloud akun ini dihapus; API key HP tetap ada.");
            }
            String pass=req.optString("passphrase","");
            if(pass.length()<12||pass.length()>512)throw new Exception("Gunakan passphrase backup terpisah, minimal 12 karakter");
            if("backup".equals(operation)){
                JSONObject providers=new JSONObject();
                for(String p:PROVIDERS){String key=secrets.get(p);if(key!=null)providers.put(p,key);}
                if(providers.length()==0)throw new Exception("Belum ada API key lokal untuk dicadangkan");
                byte[] salt=random(16),nonce=random(12);
                byte[] data=providers.toString().getBytes(StandardCharsets.UTF_8);
                byte[] cipher=crypt(Cipher.ENCRYPT_MODE,pass,salt,nonce,uid,data);
                Arrays.fill(data,(byte)0);
                JSONObject row=new JSONObject().put("user_id",uid).put("vault_version",1).put("kdf_iterations",ITERATIONS)
                    .put("salt_b64",b64(salt)).put("nonce_b64",b64(nonce)).put("ciphertext_b64",b64(cipher))
                    .put("updated_at",Instant.now().toString());
                http("POST","/rest/v1/kreasiflow_key_backups?on_conflict=user_id",new JSONArray().put(row),s.optString("access_token"),"resolution=merge-duplicates,return=minimal");
                return new JSONObject().put("message","Backup terenkripsi selesai. Simpan passphrase secara aman; Supabase tidak bisa memulihkannya.").put("count",providers.length());
            }
            JSONObject result=http("GET",endpoint+"&select=user_id,vault_version,kdf_iterations,salt_b64,nonce_b64,ciphertext_b64,updated_at",null,s.optString("access_token"),null);
            JSONArray rows=result.optJSONArray("rows");
            if(rows==null||rows.length()==0)throw new Exception("Backup akun ini belum ada. Jalankan Cadangkan di HP lama dahulu.");
            JSONObject row=rows.getJSONObject(0);
            if(row.optInt("vault_version")!=1||row.optInt("kdf_iterations")!=ITERATIONS)throw new Exception("Format backup tidak dikenali");
            byte[] plaintext;
            try{plaintext=crypt(Cipher.DECRYPT_MODE,pass,fromB64(row.getString("salt_b64")),fromB64(row.getString("nonce_b64")),uid,fromB64(row.getString("ciphertext_b64")));}
            catch(javax.crypto.AEADBadTagException wrong){throw new Exception("Passphrase salah atau data backup rusak");}
            JSONObject restored=new JSONObject(new String(plaintext,StandardCharsets.UTF_8));Arrays.fill(plaintext,(byte)0);
            int saved=0,skipped=0;
            for(String p:PROVIDERS){
                if(!restored.has(p))continue;
                if(secrets.get(p)!=null){skipped++;continue;}
                if(!secrets.save(p,restored.optString(p)))throw new Exception("Tidak bisa menyimpan "+p+" ke Keystore: "+secrets.lastSaveError());
                saved++;
            }
            return new JSONObject().put("message","Pemulihan selesai: "+saved+" key dipulihkan, "+skipped+" key lokal tidak ditimpa.").put("restored",saved).put("skipped",skipped);
        }
        throw new Exception("Perintah Supabase tidak dikenal");
    }
    private JSONObject refreshSession()throws Exception{
        JSONObject old=session();
        if(old==null||old.optString("refresh_token","").isEmpty())throw new Exception("Login Supabase terlebih dahulu");
        JSONObject fresh;
        try{fresh=http("POST","/auth/v1/token?grant_type=refresh_token",new JSONObject().put("refresh_token",old.optString("refresh_token")),null,null);}
        catch(Exception e){throw new Exception("Sesi gagal diperbarui. Login ulang jika sudah kedaluwarsa. "+e.getMessage());}
        storeAuthResponse(fresh,old.optString("email",""));
        return session();
    }
    private void storeAuthResponse(JSONObject auth,String fallbackEmail)throws Exception{
        String access=auth.optString("access_token","");String refresh=auth.optString("refresh_token","");
        JSONObject user=auth.optJSONObject("user");
        String userId=user!=null?user.optString("id",""):auth.optString("user_id","");
        if(userId.isEmpty()){JSONObject old=session();if(old!=null)userId=old.optString("user_id","");}
        String email=user!=null?user.optString("email",fallbackEmail):fallbackEmail;
        if(access.isEmpty()||refresh.isEmpty()||userId.isEmpty())throw new Exception("Respons autentikasi tidak lengkap");
        saveSession(new JSONObject().put("access_token",access).put("refresh_token",refresh).put("user_id",userId).put("email",email));
    }
    private JSONObject http(String method,String path,Object body,String accessToken,String prefer)throws Exception{
        HttpURLConnection c=null;
        try{
            c=(HttpURLConnection)new URL(url()+path).openConnection();
            c.setRequestMethod(method);c.setConnectTimeout(15000);c.setReadTimeout(25000);
            c.setRequestProperty("apikey",publicKey());c.setRequestProperty("Accept","application/json");
            if(accessToken!=null&&!accessToken.isEmpty())c.setRequestProperty("Authorization","Bearer "+accessToken);
            if(prefer!=null)c.setRequestProperty("Prefer",prefer);
            if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=UTF-8");
                byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);
                try(OutputStream output=c.getOutputStream()){output.write(bytes);}}
            int status=c.getResponseCode();
            String response="";
            InputStream input=status<400?c.getInputStream():c.getErrorStream();
            if(input!=null)try(InputStream stream=input;ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] buf=new byte[8192];int n;
                while((n=stream.read(buf))!=-1){if(out.size()+n>300000)throw new Exception("Respons Supabase terlalu besar");out.write(buf,0,n);}
                response=out.toString("UTF-8");
            }
            if(status>=400){
                String detail="HTTP "+status;
                try{JSONObject error=new JSONObject(response);String d=error.optString("msg",error.optString("message",error.optString("error_description",error.optString("error",""))));if(!d.isEmpty())detail+=": "+d.substring(0,Math.min(220,d.length()));}catch(Exception ignored){}
                throw new Exception("Supabase "+detail);
            }
            if(response.trim().startsWith("["))return new JSONObject().put("rows",new JSONArray(response));
            if(response.trim().isEmpty())return new JSONObject();
            return new JSONObject(response);
        }finally{if(c!=null)c.disconnect();}
    }
    private byte[] random(int size){byte[] bytes=new byte[size];rng.nextBytes(bytes);return bytes;}
    private String b64(byte[] data){return Base64.encodeToString(data,Base64.NO_WRAP);}
    private byte[] fromB64(String s){return Base64.decode(s,Base64.DEFAULT);}
    private byte[] crypt(int mode,String pass,byte[] salt,byte[] nonce,String userId,byte[] payload)throws Exception{
        if(salt.length!=16||nonce.length!=12)throw new Exception("Salt atau nonce tidak valid");
        char[] chars=pass.toCharArray();
        PBEKeySpec spec=new PBEKeySpec(chars,salt,ITERATIONS,256);
        byte[] key;
        try{key=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();}
        finally{spec.clearPassword();Arrays.fill(chars,'\0');}
        try{
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(mode,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,nonce));
            cipher.updateAAD(("kreasiflow-e2e-v1:"+userId).getBytes(StandardCharsets.UTF_8));
            return cipher.doFinal(payload);
        }finally{Arrays.fill(key,(byte)0);}
    }
    private String encryptSession(String value)throws Exception{
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,sessionKey());
        byte[] iv=c.getIV(), enc=c.doFinal(value.getBytes(StandardCharsets.UTF_8));
        byte[] all=new byte[iv.length+enc.length];System.arraycopy(iv,0,all,0,iv.length);System.arraycopy(enc,0,all,iv.length,enc.length);
        return b64(all);
    }
    private String decryptSession(String value)throws Exception{
        byte[] all=fromB64(value);if(all.length<29)throw new Exception("Sesi tidak valid");
        byte[] iv=Arrays.copyOfRange(all,0,12);
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,sessionKey(),new GCMParameterSpec(128,iv));
        return new String(c.doFinal(all,12,all.length-12),StandardCharsets.UTF_8);
    }
    private SecretKey sessionKey()throws Exception{
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        KeyStore.Entry previous=ks.getEntry(SESSION_ALIAS,null);
        if(previous instanceof KeyStore.SecretKeyEntry)return ((KeyStore.SecretKeyEntry)previous).getSecretKey();
        KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder(SESSION_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build());
        return gen.generateKey();
    }
}
