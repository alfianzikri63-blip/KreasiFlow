package id.kreasiflow.studio;

import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import java.util.ArrayList;
import java.util.List;

/** Bounded, optional forward frame cache. Caller owns each returned bitmap. */
final class FastFrameReader implements AutoCloseable {
    private final MediaMetadataRetriever reader;
    private final int width,height;
    private int count,batchSize,start=-1;
    private boolean enabled;
    private List<Bitmap> pending=new ArrayList<>();
    FastFrameReader(MediaMetadataRetriever reader,int fps,double seconds,int width,int height){
        this.reader=reader;this.width=width;this.height=height;
        try{
            count=meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT);
            int sw=meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH),sh=meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
            long bytes=(long)sw*sh*4;
            if(sw<=0||sh<=0||bytes<=0||count<2||seconds<=0||fps<=0)return;
            // Index path is intended for ordinary near-constant-FPS Flow MP4s only.
            if(Math.abs(count-seconds*fps)>Math.max(2,seconds*fps*.015))return;
            batchSize=(int)Math.min(8,24L*1024*1024/bytes);
            enabled=batchSize>=2;
        }catch(RuntimeException ignored){enabled=false;}
    }
    private int meta(int key){String v=reader.extractMetadata(key);return v==null?0:Integer.parseInt(v);}
    Bitmap take(int index){
        if(!enabled||index<0||index>=count)return null;
        try{
            int rel=index-start;
            if(start<0||rel<0||rel>=pending.size()||pending.get(rel)==null){
                clear();
                int n=Math.min(batchSize,count-index);
                if(n<2)return null;
                List<Bitmap> frames=reader.getFramesAtIndex(index,n);
                pending=new ArrayList<>(frames);start=index;rel=0;
                if(pending.isEmpty()||pending.get(0)==null){disable();return null;}
            }
            // Release skipped frames; never retain an entire source clip.
            for(int i=0;i<rel;i++){Bitmap b=pending.set(i,null);if(b!=null)b.recycle();}
            Bitmap raw=pending.set(rel,null);
            if(raw==null)return null;
            try{
                double scale=Math.min(1.0,Math.min(width/(double)raw.getWidth(),height/(double)raw.getHeight()));
                Bitmap result=scale<1?Bitmap.createScaledBitmap(raw,Math.max(2,(int)Math.round(raw.getWidth()*scale)),Math.max(2,(int)Math.round(raw.getHeight()*scale)),true):raw;
                if(result!=raw)raw.recycle();
                return result;
            }catch(RuntimeException ex){raw.recycle();disable();return null;}
        }catch(RuntimeException ex){disable();return null;}
    }
    private void clear(){for(Bitmap b:pending)if(b!=null&&!b.isRecycled())b.recycle();pending.clear();start=-1;}
    private void disable(){enabled=false;clear();}
    @Override public void close(){disable();}
}
