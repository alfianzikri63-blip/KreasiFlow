package id.kreasiflow.studio;

import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import org.json.JSONObject;
import java.io.File;
import java.io.IOException;

/** Verifies copied Flow videos before they are treated as ready for preview/render. */
final class FlowVideoInspector {
    private FlowVideoInspector() {}

    static JSONObject inspect(File file) throws IOException {
        if(file==null || !file.isFile() || file.length()<=0)
            throw new IOException("File video tidak ditemukan atau kosong");
        MediaExtractor extractor=new MediaExtractor();
        String codec="";long durationUs=0L;int width=0,height=0;
        try {
            extractor.setDataSource(file.getAbsolutePath());
            for(int i=0;i<extractor.getTrackCount();i++) {
                MediaFormat fmt=extractor.getTrackFormat(i);
                String mime=fmt.containsKey(MediaFormat.KEY_MIME)?fmt.getString(MediaFormat.KEY_MIME):"";
                if(mime!=null && mime.startsWith("video/")) {
                    codec=mime;
                    if(fmt.containsKey(MediaFormat.KEY_DURATION)) durationUs=Math.max(durationUs,fmt.getLong(MediaFormat.KEY_DURATION));
                    if(fmt.containsKey(MediaFormat.KEY_WIDTH))width=fmt.getInteger(MediaFormat.KEY_WIDTH);
                    if(fmt.containsKey(MediaFormat.KEY_HEIGHT))height=fmt.getInteger(MediaFormat.KEY_HEIGHT);
                    break;
                }
            }
        }catch(Exception e){throw new IOException("MP4 tidak dapat dibaca oleh Android: "+e.getMessage(),e);}
        finally{extractor.release();}
        if(codec.isEmpty())throw new IOException("MP4 tidak memiliki jalur video yang bisa dibaca");
        long durationMs=Math.max(0,durationUs/1000L);
        if(durationMs<=0){
            MediaMetadataRetriever retriever=new MediaMetadataRetriever();
            try{retriever.setDataSource(file.getAbsolutePath());
                String value=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                if(value!=null)durationMs=Long.parseLong(value);
            }catch(Exception ignored){}finally{retriever.release();}
        }
        if(durationMs<=0)throw new IOException("Durasi MP4 tidak terbaca (0:00). Coba unduh ulang dari Google Flow atau pilih file MP4 lain.");
        JSONObject result=new JSONObject();
        try{
            result.put("durationMs",durationMs).put("codec",codec).put("width",width).put("height",height).put("bytes",file.length());
        }catch(Exception e){throw new IOException("Gagal membaca metadata MP4",e);}
        return result;
    }
}
