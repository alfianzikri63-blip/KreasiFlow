package id.kreasiflow.studio;

import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.graphics.Bitmap;
import android.graphics.Color;
import org.json.JSONObject;
import java.io.File;
import java.io.IOException;

/** Verifies copied Flow videos before they are treated as ready for preview/render. */
final class FlowVideoInspector {
    private FlowVideoInspector() {}

    static JSONObject inspect(File file) throws IOException {
        if(file==null || !file.isFile() || file.length()<=0)
            throw new IOException("File video tidak ditemukan atau kosong");
        MediaExtractor extractor=new MediaExtractor();
        String codec="";long durationUs=0L;int width=0,height=0;
        try {
            extractor.setDataSource(file.getAbsolutePath());
            for(int i=0;i<extractor.getTrackCount();i++) {
                MediaFormat fmt=extractor.getTrackFormat(i);
                String mime=fmt.containsKey(MediaFormat.KEY_MIME)?fmt.getString(MediaFormat.KEY_MIME):"";
                if(mime!=null && mime.startsWith("video/")) {
                    codec=mime;
                    if(fmt.containsKey(MediaFormat.KEY_DURATION)) durationUs=Math.max(durationUs,fmt.getLong(MediaFormat.KEY_DURATION));
                    if(fmt.containsKey(MediaFormat.KEY_WIDTH))width=fmt.getInteger(MediaFormat.KEY_WIDTH);
                    if(fmt.containsKey(MediaFormat.KEY_HEIGHT))height=fmt.getInteger(MediaFormat.KEY_HEIGHT);
                    break;
                }
            }
        }catch(Exception e){throw new IOException("MP4 tidak dapat dibaca oleh Android: "+e.getMessage(),e);}
        finally{extractor.release();}
        if(codec.isEmpty())throw new IOException("MP4 tidak memiliki jalur video yang bisa dibaca");
        long durationMs=Math.max(0,durationUs/1000L);
        if(durationMs<=0){
            MediaMetadataRetriever retriever=new MediaMetadataRetriever();
            try{retriever.setDataSource(file.getAbsolutePath());
                String value=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                if(value!=null)durationMs=Long.parseLong(value);
            }catch(Exception ignored){}finally{retriever.release();}
        }
        if(durationMs<=0)throw new IOException("Durasi MP4 tidak terbaca (0:00). Coba unduh ulang dari Google Flow atau pilih file MP4 lain.");
        JSONObject result=new JSONObject();
        try{
            result.put("durationMs",durationMs).put("codec",codec).put("width",width).put("height",height).put("bytes",file.length());
        }catch(Exception e){throw new IOException("Gagal membaca metadata MP4",e);}
        return result;
    }

    static String coverFrame(File file) throws IOException {
        return exportFrame(file,0);
    }

    static String loopFrame(File file,boolean end) throws IOException {return exportFrame(file,end?2:1);}

    /** Small sampled sequence for a silent boundary preview (not a rendered MP4). */
    static org.json.JSONArray loopStrip(File file,boolean end) throws IOException {
        JSONObject info=inspect(file); MediaMetadataRetriever r=new MediaMetadataRetriever();
        try {
            r.setDataSource(file.getAbsolutePath());
            int w=Math.max(1,info.optInt("width",720)),h=Math.max(1,info.optInt("height",1280));
            String rotation=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
            if("90".equals(rotation)||"270".equals(rotation)){int tmp=w;w=h;h=tmp;}
            double scale=Math.min(1.0,480.0/Math.max(w,h));
            long last=Math.max(0L,info.optLong("durationMs")*1000L-1000L);
            long span=Math.min(last,833333L); org.json.JSONArray result=new org.json.JSONArray();
            for(int i=0;i<6;i++){
                long time=(end?last-span:0L)+Math.round(span*i/5.0);
                Bitmap frame=r.getScaledFrameAtTime(time,MediaMetadataRetriever.OPTION_CLOSEST,Math.max(1,(int)(w*scale)),Math.max(1,(int)(h*scale)));
                if(frame==null)throw new IOException("Frame preview tidak terbaca");
                try{java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();if(!frame.compress(Bitmap.CompressFormat.JPEG,70,out))throw new IOException("JPEG preview gagal");result.put(android.util.Base64.encodeToString(out.toByteArray(),android.util.Base64.NO_WRAP));}finally{frame.recycle();}
            }
            return result;
        }catch(Exception e){throw new IOException("Gagal mengambil sampel loop: "+e.getMessage(),e);}finally{r.release();}
    }

    private static String exportFrame(File file,int boundary) throws IOException {
        JSONObject info=inspect(file);
        MediaMetadataRetriever retriever=new MediaMetadataRetriever();
        Bitmap frame=null;
        try {
            retriever.setDataSource(file.getAbsolutePath());
            int width=Math.max(1,info.optInt("width",720)),height=Math.max(1,info.optInt("height",1280));
            String rotation=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
            if("90".equals(rotation)||"270".equals(rotation)){int swap=width;width=height;height=swap;}
            double scale=Math.min(1.0,(boundary==1||boundary==2?1920.0:960.0)/Math.max(width,height));
            long durationUs=info.optLong("durationMs")*1000L;
            long timeUs=boundary==1?0L:boundary==2?Math.max(0L,durationUs-1000L):Math.max(0L,durationUs/3);
            frame=retriever.getScaledFrameAtTime(timeUs,MediaMetadataRetriever.OPTION_CLOSEST,Math.max(1,(int)(width*scale)),Math.max(1,(int)(height*scale)));
            if(frame==null)throw new IOException("Frame MP4 tidak terbaca");
            java.io.ByteArrayOutputStream buffer=new java.io.ByteArrayOutputStream();
            if(!frame.compress(Bitmap.CompressFormat.JPEG,boundary==1||boundary==2?95:82,buffer))throw new IOException("Gagal membuat JPEG");
            return android.util.Base64.encodeToString(buffer.toByteArray(),android.util.Base64.NO_WRAP);
        }catch(Exception e){throw new IOException("Gagal mengambil cover: "+e.getMessage(),e);}
        finally{if(frame!=null)frame.recycle();retriever.release();}
    }

    /** Read real MP4 frames on Android, not a WebView URL. Each hash is 64-bit dHash. */
    static JSONObject fingerprint(File file) throws IOException {
        JSONObject info=inspect(file);
        long durationMs=info.optLong("durationMs",0L);
        MediaMetadataRetriever retriever=new MediaMetadataRetriever();
        try {
            retriever.setDataSource(file.getAbsolutePath());
            org.json.JSONArray hashes=new org.json.JSONArray();
            int lowDetailCount=0;
            for(double fraction:new double[]{0.28d,0.72d}){
                long sampleUs=Math.max(0L,Math.min(Math.max(0L,durationMs-40L),Math.round(durationMs*fraction)))*1000L;
                Bitmap frame=null;
                try {
                    // OPTION_CLOSEST decodes the intended point, even in short 4-second clips.
                    frame=retriever.getScaledFrameAtTime(sampleUs,MediaMetadataRetriever.OPTION_CLOSEST,144,128);
                    if(frame==null)frame=retriever.getScaledFrameAtTime(sampleUs,MediaMetadataRetriever.OPTION_CLOSEST_SYNC,144,128);
                    if(frame==null)throw new IOException("Decoder Android tidak mengembalikan frame pada "+(sampleUs/1000L)+" ms");
                    Bitmap tiny=Bitmap.createScaledBitmap(frame,9,8,true);
                    try {
                        Bitmap software=tiny.getConfig()==Bitmap.Config.HARDWARE?tiny.copy(Bitmap.Config.ARGB_8888,false):tiny;
                        if(software==null)throw new IOException("Bitmap frame tidak dapat dibaca");
                        try {
                            int[] pixels=new int[72];
                            software.getPixels(pixels,0,9,0,0,9,8);
                            int[] luma=new int[72];int min=255,max=0;
                            for(int i=0;i<72;i++){
                                int color=pixels[i];int value=(299*Color.red(color)+587*Color.green(color)+114*Color.blue(color))/1000;
                                luma[i]=value; min=Math.min(min,value);max=Math.max(max,value);
                            }
                            if(max-min<12)lowDetailCount++;
                            StringBuilder hash=new StringBuilder(64);
                            for(int y=0;y<8;y++)for(int x=0;x<8;x++)hash.append(luma[y*9+x]>luma[y*9+x+1]?'1':'0');
                            hashes.put(hash.toString());
                        }finally {if(software!=tiny)software.recycle();}
                    }finally {if(tiny!=frame)tiny.recycle();}
                }finally {if(frame!=null)frame.recycle();}
            }
            JSONObject result=new JSONObject();
            result.put("hashes",hashes);
            result.put("lowDetail",lowDetailCount==2);
            result.put("durationMs",durationMs);
            result.put("source","native-mp4");
            return result;
        }catch(IOException e){throw e;}
        catch(Exception e){throw new IOException("Gagal mengekstrak frame MP4: "+e.getMessage(),e);}
        finally {retriever.release();}
    }

}
