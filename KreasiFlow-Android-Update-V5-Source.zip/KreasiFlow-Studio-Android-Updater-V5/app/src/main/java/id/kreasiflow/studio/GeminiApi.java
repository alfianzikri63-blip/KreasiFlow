package id.kreasiflow.studio;

import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Gemini API calls. Credentials are passed only by native encrypted storage;
 *  they are never placed in HTML, localStorage, exported project JSON or GitHub.
 *  Endpoints and model names are allowlisted by the app, not supplied as URLs.
 */
final class GeminiApi {
    static final String BASE="https://generativelanguage.googleapis.com/v1beta";
    private static final int TEXT_LIMIT=2*1024*1024;
    private static final int MEDIA_LIMIT=27*1024*1024;

    static String execute(JSONObject input,String key)throws Exception {
        if(key==null||key.trim().length()<15)throw new IOException("Gemini API Key belum disimpan di Pengaturan AI");
        String op=input.optString("op","text");
        switch (op) {
            case "verify":return verify(key).toString();
            case "text":return text(input,key).toString();
            case "image":return image(input,key).toString();
            case "tts":return tts(input,key).toString();
            default:throw new IOException("Operasi Gemini tidak tersedia");
        }
    }
    private static JSONObject verify(String key)throws Exception {
        JSONObject res=request("GET", BASE+"/models?pageSize=1",key,null,TEXT_LIMIT);
        if(!res.has("models"))throw new IOException("Gemini API key belum terverifikasi");
        return new JSONObject().put("ok",true);
    }
    private static JSONObject text(JSONObject input,String key)throws Exception {
        String prompt=input.optString("prompt","").trim();
        if(prompt.isEmpty()||prompt.length()>82000)throw new IOException("Prompt Gemini terlalu panjang/kosong");
        JSONObject body=new JSONObject().put("contents",new JSONArray().put(
            new JSONObject().put("parts",new JSONArray().put(new JSONObject().put("text",prompt)))));
        // Gemini 2.5 Flash is unavailable to new projects. Prefer the current
        // supported Flash model; fall back only when Google reports HTTP 404
        // for a model, never on auth, quota or server errors.
        JSONObject res;
        try {
            res=request("POST",BASE+"/models/gemini-3.8-flash:generateContent",key,body,TEXT_LIMIT);
        } catch (IOException ex) {
            if (!ex.getMessage().startsWith("Gemini HTTP 404:")) throw ex;
            try {
                res=request("POST",BASE+"/models/gemini-3.5-flash-lite:generateContent",key,body,TEXT_LIMIT);
            } catch (IOException backupError) {
                if (backupError.getMessage().startsWith("Gemini HTTP 404:"))
                    throw new IOException("Model Gemini 3.8 Flash dan 3.5 Flash-Lite tidak tersedia untuk API key ini. Periksa akses model di Google AI Studio atau gunakan OpenRouter.", backupError);
                throw backupError;
            }
        }
        JSONArray candidates=res.optJSONArray("candidates");
        if(candidates==null||candidates.length()==0)throw new IOException("Gemini tidak mengembalikan jawaban teks; periksa safety/kuota");
        JSONObject content=candidates.optJSONObject(0).optJSONObject("content");
        JSONArray parts=content==null?null:content.optJSONArray("parts");
        StringBuilder text=new StringBuilder();
        if(parts!=null)for(int i=0;i<parts.length();i++){
            JSONObject p=parts.optJSONObject(i);
            if(p!=null&&!p.optBoolean("thought",false))text.append(p.optString("text",""));
        }
        if(text.length()==0)throw new IOException("Gemini mengembalikan teks kosong");
        return new JSONObject().put("text",text.toString());
    }
    private static JSONObject image(JSONObject input,String key)throws Exception {
        String prompt=input.optString("prompt","").trim();
        if(prompt.length()<3||prompt.length()>3000)throw new IOException("Prompt gambar Gemini tidak valid");
        // Current affordable text-to-image model. No caller-supplied model/URL.
        JSONObject req=new JSONObject().put("model","gemini-3.1-flash-lite-image")
                .put("input",new JSONArray().put(new JSONObject().put("type","text").put("text",prompt)));
        JSONObject res=request("POST",BASE+"/interactions",key,req,MEDIA_LIMIT);
        JSONObject media=findMedia(res,"image");
        if(media==null)throw new IOException("Gemini tidak mengembalikan gambar; periksa billing/kuota API");
        String b64=media.optString("data","");
        if(b64.length()<64||b64.length()>24*1024*1024)throw new IOException("Ukuran gambar Gemini tidak valid");
        String mime=media.optString("mime_type","image/png");
        if(!mime.equals("image/png")&&!mime.equals("image/jpeg")&&!mime.equals("image/webp"))
            throw new IOException("Format gambar Gemini tidak didukung");
        return new JSONObject().put("image_base64",b64).put("mime_type",mime);
    }
    private static JSONObject tts(JSONObject input,String key)throws Exception {
        String spoken=input.optString("text","").trim();
        if(spoken.length()<2||spoken.length()>9000)throw new IOException("Voice-over harus 2–9000 karakter");
        String style=input.optString("style","").replaceAll("[\\r\\n]+"," ");
        if(style.length()>200)style=style.substring(0,200);
        JSONObject textBlock=new JSONObject().put("type","text").put("text",spoken);
        if(!style.isEmpty())textBlock.put("annotations",new JSONArray().put(
            new JSONObject().put("type","speech_metadata").put("style",style)));
        JSONObject request=new JSONObject().put("model","gemini-3.8-flash-lite-tts")
            .put("input",new JSONArray().put(new JSONObject().put("type","user_input")
                .put("content",new JSONArray().put(textBlock))))
            .put("response_format",new JSONObject().put("type","audio"))
            .put("generation_config",new JSONObject().put("speech_config",new JSONArray().put(
                new JSONObject().put("voice","Kore"))));
        JSONObject res=request("POST",BASE+"/interactions",key,request,MEDIA_LIMIT);
        JSONObject media=findMedia(res,"audio");
        if(media==null)throw new IOException("Gemini TTS tidak mengembalikan audio; cek kuota dan model");
        String b64=media.optString("data","");
        if(b64.length()<100||b64.length()>26*1024*1024)throw new IOException("Ukuran audio Gemini tidak valid");
        String mime=media.optString("mime_type","audio/wav");
        if(!mime.startsWith("audio/"))throw new IOException("Respons suara Gemini bukan audio");
        return new JSONObject().put("audio_base64",b64).put("mime_type",mime);
    }
    static JSONObject findMedia(JSONObject root,String type){
        JSONArray steps=root.optJSONArray("steps");
        if(steps==null)return null;
        for(int i=steps.length()-1;i>=0;i--){
            JSONObject step=steps.optJSONObject(i);
            if(step==null||!"model_output".equals(step.optString("type")))continue;
            JSONArray contents=step.optJSONArray("content");
            if(contents==null)continue;
            for(int j=contents.length()-1;j>=0;j--){
                JSONObject item=contents.optJSONObject(j);
                if(item!=null&&type.equals(item.optString("type"))&&item.has("data"))return item;
            }
        }
        return null;
    }
    static JSONObject request(String method,String url,String key,JSONObject body,int limit)throws Exception {
        if(!url.startsWith(BASE+"/"))throw new IOException("URL Gemini tidak diizinkan");
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setRequestMethod(method);c.setConnectTimeout(25000);c.setReadTimeout(180000);c.setInstanceFollowRedirects(false);
        c.setRequestProperty("x-goog-api-key",key.trim());c.setRequestProperty("Accept","application/json");
        if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");
            try(OutputStream out=c.getOutputStream()){out.write(body.toString().getBytes(StandardCharsets.UTF_8));}}
        try{
            int status=c.getResponseCode();
            if(status<200||status>=300){
                String raw=readText(c.getErrorStream(),12000);
                String msg=raw;
                try{JSONObject err=new JSONObject(raw).optJSONObject("error");if(err!=null)msg=err.optString("message",raw);}catch(Exception ignored){}
                msg=msg.replaceAll("[\\r\\n]+"," ");
                throw new IOException("Gemini HTTP "+status+": "+msg.substring(0,Math.min(250,msg.length())));
            }
            byte[] raw=readBound(c.getInputStream(),limit);
            return new JSONObject(new String(raw,StandardCharsets.UTF_8));
        }finally{c.disconnect();}
    }
    static byte[] readBound(InputStream stream,int limit)throws IOException{
        if(stream==null)throw new IOException("Respons Gemini kosong");
        try(InputStream in=stream;ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buff=new byte[16384];int n;
            while((n=in.read(buff))!=-1){if(out.size()+n>limit)throw new IOException("Respons Gemini terlalu besar; coba klip lebih pendek");out.write(buff,0,n);}
            return out.toByteArray();
        }
    }
    static String readText(InputStream stream,int limit)throws IOException{
        if(stream==null)return "";
        return new String(readBound(stream,limit),StandardCharsets.UTF_8);
    }
}
