package id.kreasiflow.studio;

import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Gemini API calls. Credentials are passed only by native encrypted storage;
 *  they are never placed in HTML, localStorage, exported project JSON or GitHub.
 *  Endpoints and model names are allowlisted by the app, not supplied as URLs.
 */
final class GeminiApi {
    static final String BASE="https://generativelanguage.googleapis.com/v1beta";
    private static final int TEXT_LIMIT=2*1024*1024;
    private static final int MEDIA_LIMIT=27*1024*1024;

    static String execute(JSONObject input,String key)throws Exception {
        if(key==null||key.trim().length()<15)throw new IOException("Gemini API Key belum disimpan di Pengaturan AI");
        String op=input.optString("op","text");
        switch (op) {
            case "verify":return verify(key).toString();
            case "text":return input.optBoolean("fast_text",false)?fastText(input,key):text(input,key).toString();
            case "image":return image(input,key).toString();
            case "tts":return tts(input,key).toString();
            default:throw new IOException("Operasi Gemini tidak tersedia");
        }
    }
    /** Audio transcription with timecoded segments, sent ONLY by native app.
     *  Inputs never pass through JS base64 or project storage. This operation
     *  consumes Gemini API quota. Timing is model-estimated and user-editable.
     */
    static String transcribe(File audio,String mime,double durationSeconds,String key,String audioModel)throws Exception {
        // Only documented audio-capable models; never treat a caller value as an endpoint.
        if(!"gemini-3.6-flash".equals(audioModel) && !"gemini-3.8-flash".equals(audioModel))
            throw new IOException("Model Gemini untuk transkrip tidak diizinkan");
        if(key==null||key.trim().length()<15)throw new IOException("Simpan Gemini API Key dahulu di Pengaturan AI");
        if(audio==null||!audio.isFile())throw new IOException("File voice-over tidak ditemukan. Upload ulang suara terlebih dahulu.");
        if(audio.length()==0||audio.length()>12L*1024*1024)
            throw new IOException("Transkripsi AI menerima VO maksimal 12 MB untuk sementara. Kompres audio MP3 64 kbps lalu upload ulang.");
        if(durationSeconds<=0||durationSeconds>1800||!Double.isFinite(durationSeconds))
            throw new IOException("Durasi VO tidak valid (maksimal 30 menit).");
        if(!("audio/mpeg".equals(mime)||"audio/mp3".equals(mime)||"audio/wav".equals(mime)||
             "audio/x-wav".equals(mime)||"audio/mp4".equals(mime)||"audio/aac".equals(mime)||
             "audio/ogg".equals(mime)||"audio/flac".equals(mime)))
            throw new IOException("Format audio untuk Gemini harus MP3, WAV, M4A, AAC, OGG, atau FLAC.");
        String audio64=Base64.encodeToString(java.nio.file.Files.readAllBytes(audio.toPath()),Base64.NO_WRAP);
        String prompt="Dengarkan HANYA audio terlampir dan buat transkrip verbatim sesuai bahasa aslinya. " +
          "Jangan menciptakan kalimat, jangan terjemahkan, jangan menuliskan musik atau efek suara. " +
          "Bagi ke subtitle pendek 3 sampai 9 kata sesuai jeda asli ucapan. " +
          "Setiap segmen harus mempunyai waktu MULAI dan SELESAI dalam DETIK dari permulaan audio (angka desimal). " +
          "Jangan mengisi waktu saat tidak ada ucapan, jangan tumpang tindih, dan gunakan audio sebagai sumber kebenaran. " +
          "Kirim tepat objek JSON dengan key 'segments', berisi array objek {start: number, end: number, text: string}. " +
          "Batasi 250 segmen, tanpa label pembicara, tanpa komentar, tanpa markdown. " +
          "Durasi audio menurut metadata sekitar "+String.format(java.util.Locale.US,"%.2f",durationSeconds)+" detik.";
        JSONObject schema=new JSONObject().put("type","object")
          .put("properties",new JSONObject().put("segments",new JSONObject().put("type","array")
            .put("items",new JSONObject().put("type","object")
              .put("properties",new JSONObject().put("start",new JSONObject().put("type","number"))
                .put("end",new JSONObject().put("type","number"))
                .put("text",new JSONObject().put("type","string")))
              .put("required",new JSONArray().put("start").put("end").put("text")))))
          .put("required",new JSONArray().put("segments"));
        JSONObject request=new JSONObject().put("model",audioModel)
          .put("input",new JSONArray()
            .put(new JSONObject().put("type","text").put("text",prompt))
            .put(new JSONObject().put("type","audio").put("data",audio64).put("mime_type",mime)))
          .put("response_format",new JSONObject().put("type","text")
            .put("mime_type","application/json").put("schema",schema));
        // The audio is encoded once in native memory and sent directly to Google.
        audio64=null;
        JSONObject result=request("POST",BASE+"/interactions",key,request,TEXT_LIMIT);
        JSONArray steps=result.optJSONArray("steps");
        StringBuilder output=new StringBuilder();
        if(steps!=null)for(int i=0;i<steps.length();i++){
            JSONObject step=steps.optJSONObject(i);
            if(step==null||!"model_output".equals(step.optString("type")))continue;
            JSONArray contents=step.optJSONArray("content");
            if(contents!=null)for(int j=0;j<contents.length();j++){
                JSONObject item=contents.optJSONObject(j);
                if(item!=null&&"text".equals(item.optString("type")))output.append(item.optString("text",""));
            }
        }
        if(output.length()==0)throw new IOException("Gemini tidak mengembalikan teks transkrip");
        JSONObject parsed;
        try{parsed=new JSONObject(output.toString());}
        catch(Exception e){throw new IOException("Gemini mengembalikan format transkrip tidak sesuai. Coba ulang.",e);}
        JSONArray segments=parsed.optJSONArray("segments");
        if(segments==null||segments.length()==0)throw new IOException("Tidak ditemukan ucapan pada file suara atau Gemini mengembalikan transkrip kosong");
        if(segments.length()>250)throw new IOException("Terlalu banyak segmen subtitle (maksimal 250). Gunakan VO lebih pendek.");
        JSONArray safe=new JSONArray();double lastEnd=0;
        for(int i=0;i<segments.length();i++){
            JSONObject part=segments.optJSONObject(i);
            if(part==null)throw new IOException("Segmen AI "+(i+1)+" rusak");
            double start=part.optDouble("start",Double.NaN),end=part.optDouble("end",Double.NaN);
            String text=part.optString("text","").replaceAll("[\\r\\n\\t]+"," ").trim();
            if(!Double.isFinite(start)||!Double.isFinite(end)||start<0||end<=start||
               start<lastEnd-.02||end>durationSeconds+.3||text.isEmpty())
                throw new IOException("Timestamp Gemini pada segmen "+(i+1)+" tidak valid. Coba transkrip ulang atau impor SRT.");
            if(text.length()>400)text=text.substring(0,400);
            safe.put(new JSONObject().put("start",start).put("end",end).put("text",text));lastEnd=end;
        }
        return new JSONObject().put("segments",safe).put("model",audioModel).toString();
    }

    private static JSONObject verify(String key)throws Exception {
        JSONObject res=request("GET", BASE+"/models?pageSize=1",key,null,TEXT_LIMIT);
        if(!res.has("models"))throw new IOException("Gemini API key belum terverifikasi");
        return new JSONObject().put("ok",true);
    }
    private static JSONObject text(JSONObject input,String key)throws Exception {
        String prompt=input.optString("prompt","").trim();
        if(prompt.isEmpty()||prompt.length()>82000)throw new IOException("Prompt Gemini terlalu panjang/kosong");
        JSONObject body=new JSONObject().put("contents",new JSONArray().put(
            new JSONObject().put("parts",new JSONArray().put(new JSONObject().put("text",prompt)))));
        // A temporary HTTP 503 indicates Gemini capacity pressure, not a bad key.
        // Retry a few times with a short bounded backoff before trying a second,
        // lighter model. Do not retry or switch models for auth/quota errors.
        JSONObject res;
        try {
            res=requestTextWithRetry("gemini-3.8-flash",key,body,3);
        } catch (IOException ex) {
            if (!hasGeminiStatus(ex,404) && !hasGeminiStatus(ex,503)) throw ex;
            try {
                res=requestTextWithRetry("gemini-3.5-flash-lite",key,body,2);
            } catch (IOException backupError) {
                if (hasGeminiStatus(backupError,503))
                    throw new IOException("Gemini sedang sibuk (HTTP 503) pada kedua model setelah mencoba ulang. Simpan proyek, tunggu sebentar lalu coba lagi, atau pilih OpenRouter.", backupError);
                if (hasGeminiStatus(backupError,404))
                    throw new IOException("Gemini 3.8 Flash dan 3.5 Flash-Lite tidak tersedia untuk API key ini. Periksa akses model di Google AI Studio atau pilih OpenRouter.", backupError);
                throw backupError;
            }
        }
        JSONArray candidates=res.optJSONArray("candidates");
        if(candidates==null||candidates.length()==0)throw new IOException("Gemini tidak mengembalikan jawaban teks; periksa safety/kuota");
        JSONObject content=candidates.optJSONObject(0).optJSONObject("content");
        JSONArray parts=content==null?null:content.optJSONArray("parts");
        StringBuilder text=new StringBuilder();
        if(parts!=null)for(int i=0;i<parts.length();i++){
            JSONObject p=parts.optJSONObject(i);
            if(p!=null&&!p.optBoolean("thought",false))text.append(p.optString("text",""));
        }
        if(text.length()==0)throw new IOException("Gemini mengembalikan teks kosong");
        return new JSONObject().put("text",text.toString());
    }
    private static boolean hasGeminiStatus(IOException err,int status) {
        String msg=err.getMessage();
        return msg!=null && msg.startsWith("Gemini HTTP "+status+":");
    }

    /** Only safe, idempotent text generation attempts receive automatic retry.
     *  Do not use on image/video/TTS operations that may be billable per attempt.
     */
    private static JSONObject requestTextWithRetry(String model,String key,JSONObject body,int attempts)throws Exception {
        IOException last=null;
        for(int attempt=1;attempt<=attempts;attempt++) {
            try {
                return request("POST",BASE+"/models/"+model+":generateContent",key,body,TEXT_LIMIT);
            } catch(IOException e) {
                if (!hasGeminiStatus(e,503) || attempt>=attempts) throw e;
                last=e;
                // 1.2s then 2.4s, cap attempts so the UI remains responsive.
                long pause=1200L << Math.min(attempt-1,2);
                try { Thread.sleep(pause); }
                catch (InterruptedException interrupted) {
                    Thread.currentThread().interrupt();
                    throw new IOException("Permintaan Gemini dibatalkan saat mencoba ulang",interrupted);
                }
            }
        }
        throw last==null ? new IOException("Gemini gagal") : last;
    }

    /** Fast native storyboard path. The regular Gemini text API historically used a
     *  180-second read timeout plus nested retries, which could leave the first
     *  storyboard batch unchanged for many minutes. One short attempt here; the
     *  caller can switch to an already-configured OpenRouter provider on failure.
     *  Do not alter the longer timeout used for transcription and other operations.
     */
    static String fastStoryboard(JSONObject input,String key)throws Exception {
        if(key==null||key.trim().length()<15)throw new IOException("Gemini API Key belum tersedia");
        String prompt=input.optString("prompt","").trim();
        if(prompt.isEmpty()||prompt.length()>82000)throw new IOException("Prompt storyboard kosong atau terlalu panjang");
        JSONObject body=new JSONObject()
            .put("contents",new JSONArray().put(new JSONObject().put("parts",new JSONArray().put(new JSONObject().put("text",prompt)))))
            .put("generationConfig",new JSONObject().put("temperature",0.45)
                .put("maxOutputTokens",3500).put("responseMimeType","application/json"));
        JSONObject response;
        try {
            response=request("POST",BASE+"/models/gemini-3.5-flash-lite:generateContent",key,body,TEXT_LIMIT,12000,45000);
        } catch(IOException e) {
            // Model unavailable for this key: try the regular Flash once.
            // Busy/timeout/rate-limited: do not nest costly retries here.
            if(!hasGeminiStatus(e,404))throw e;
            response=request("POST",BASE+"/models/gemini-3.8-flash:generateContent",key,body,TEXT_LIMIT,12000,45000);
        }
        JSONArray candidates=response.optJSONArray("candidates");
        JSONObject candidate=candidates==null?null:candidates.optJSONObject(0);
        JSONObject content=candidate==null?null:candidate.optJSONObject("content");
        JSONArray parts=content==null?null:content.optJSONArray("parts");
        StringBuilder out=new StringBuilder();
        if(parts!=null)for(int i=0;i<parts.length();i++){
            JSONObject part=parts.optJSONObject(i);
            if(part!=null&&!part.optBoolean("thought",false))out.append(part.optString("text",""));
        }
        if(out.length()<3)throw new IOException("Gemini Lite tidak mengembalikan storyboard JSON");
        return new JSONObject().put("text",out.toString()).toString();
    }

    static String fastText(JSONObject input,String key)throws Exception {
        if(key==null||key.trim().length()<15)throw new IOException("Gemini API Key belum tersedia");
        String prompt=input.optString("prompt","").trim();
        if(prompt.isEmpty()||prompt.length()>82000)throw new IOException("Prompt teks kosong atau terlalu panjang");
        JSONObject body=new JSONObject()
            .put("contents",new JSONArray().put(new JSONObject().put("parts",new JSONArray().put(new JSONObject().put("text",prompt)))))
            .put("generationConfig",new JSONObject().put("temperature",0.45)
                .put("maxOutputTokens",Math.max(128,Math.min(8192,input.optInt("max_tokens",768)))));
        boolean titleFast=input.optBoolean("title_fast",false);
        boolean ideaFast=input.optBoolean("idea_fast",false);
        if(titleFast||ideaFast||input.optBoolean("structured",false))body.getJSONObject("generationConfig").put("responseMimeType","application/json");
        boolean scriptFast=input.optBoolean("script_fast",false);
        int scriptRead=input.optInt("max_tokens",1600)>4000?60000:input.optInt("max_tokens",1600)>2500?40000:25000;
        if(scriptFast||ideaFast)body.getJSONObject("generationConfig").put("thinkingConfig",new JSONObject().put("thinkingLevel","MINIMAL"));
        String model=StoryIdeaCancellation.managed()&&"gemini-3.5-flash".equals(input.optString("model"))
            ? "gemini-3.5-flash" : "gemini-3.5-flash-lite";
        JSONObject response;
        try {
            if(ideaFast)response=request("POST",BASE+"/models/"+model+":generateContent",key,body,TEXT_LIMIT,5000,18000);
            else response=request("POST",BASE+"/models/"+model+":generateContent",key,body,TEXT_LIMIT,titleFast?5000:12000,titleFast?12000:scriptFast?scriptRead:(input.optInt("max_tokens",768)>2000?120000:60000));
        } catch(IOException e) {
            // Model unavailable for this key: try the regular Flash once.
            // Busy/timeout/rate-limited: do not nest costly retries here.
            if(scriptFast||ideaFast||StoryIdeaCancellation.managed())throw e;
            if(titleFast||!hasGeminiStatus(e,404))throw e;
            response=request("POST",BASE+"/models/gemini-3.8-flash:generateContent",key,body,TEXT_LIMIT,12000,input.optInt("max_tokens",768)>2000?120000:60000);
        }
        JSONArray candidates=response.optJSONArray("candidates");
        JSONObject candidate=candidates==null?null:candidates.optJSONObject(0);
        JSONObject content=candidate==null?null:candidate.optJSONObject("content");
        JSONArray parts=content==null?null:content.optJSONArray("parts");
        StringBuilder out=new StringBuilder();
        if(parts!=null)for(int i=0;i<parts.length();i++){
            JSONObject part=parts.optJSONObject(i);
            if(part!=null&&!part.optBoolean("thought",false))out.append(part.optString("text",""));
        }
        if(ideaFast&&candidate!=null&&"MAX_TOKENS".equals(candidate.optString("finishReason")))throw new IOException("Respons ide Gemini terpotong. Coba lagi.");
        if((scriptFast||StoryIdeaCancellation.managed())&&candidate!=null&&"MAX_TOKENS".equals(candidate.optString("finishReason")))throw new IOException("Naskah Gemini terpotong karena batas token output");
        if(out.length()<3)throw new IOException("Gemini Lite tidak mengembalikan teks");
        return new JSONObject().put("text",out.toString()).toString();
    }

    static JSONObject creativePhoto(File photo,JSONObject input,String key,boolean transform)throws Exception {
        String mime=input.optString("mime_type",""), prompt=input.optString("prompt","").trim();
        if(photo==null||!photo.isFile()||photo.length()==0||photo.length()>12L*1024*1024)
            throw new IOException("Foto acuan tidak tersedia atau melebihi 12 MB");
        if(!"image/jpeg".equals(mime)&&!"image/png".equals(mime)&&!"image/webp".equals(mime))
            throw new IOException("Format foto tidak didukung");
        if(prompt.length()<3||prompt.length()>3000)throw new IOException("Prompt foto tidak valid");
        String data=Base64.encodeToString(java.nio.file.Files.readAllBytes(photo.toPath()),Base64.NO_WRAP);
        JSONArray parts=new JSONArray().put(new JSONObject().put("type","text").put("text",prompt))
                .put(new JSONObject().put("type","image").put("data",data).put("mime_type",mime));
        JSONObject body=new JSONObject().put("model",transform?"gemini-3.1-flash-lite-image":"gemini-3.5-flash-lite")
                .put("input",parts).put("store",false);
        JSONObject response=request("POST",BASE+"/interactions",key,body,transform?MEDIA_LIMIT:2*1024*1024);
        JSONObject result=findMedia(response,transform?"image":"text");
        if(result==null)throw new IOException("Gemini tidak mengembalikan hasil foto");
        if(!transform){
            String text=result.optString("text","").trim();
            if(text.isEmpty())throw new IOException("Analisis foto kosong");
            return new JSONObject().put("text",text);
        }
        String image=result.optString("data",""), outputMime=result.optString("mime_type","");
        if(image.length()<64||image.length()>24*1024*1024||
           !("image/png".equals(outputMime)||"image/jpeg".equals(outputMime)||"image/webp".equals(outputMime)))
            throw new IOException("Hasil gambar Gemini tidak valid");
        return new JSONObject().put("image_base64",image).put("mime_type",outputMime);
    }

    private static JSONObject image(JSONObject input,String key)throws Exception {
        String prompt=input.optString("prompt","").trim();
        if(prompt.length()<3||prompt.length()>3000)throw new IOException("Prompt gambar Gemini tidak valid");
        // Current affordable text-to-image model. No caller-supplied model/URL.
        JSONObject req=new JSONObject().put("model","gemini-3.1-flash-lite-image")
                .put("input",new JSONArray().put(new JSONObject().put("type","text").put("text",prompt)));
        JSONObject res=request("POST",BASE+"/interactions",key,req,MEDIA_LIMIT);
        JSONObject media=findMedia(res,"image");
        if(media==null)throw new IOException("Gemini tidak mengembalikan gambar; periksa billing/kuota API");
        String b64=media.optString("data","");
        if(b64.length()<64||b64.length()>24*1024*1024)throw new IOException("Ukuran gambar Gemini tidak valid");
        String mime=media.optString("mime_type","image/png");
        if(!mime.equals("image/png")&&!mime.equals("image/jpeg")&&!mime.equals("image/webp"))
            throw new IOException("Format gambar Gemini tidak didukung");
        return new JSONObject().put("image_base64",b64).put("mime_type",mime);
    }
    private static JSONObject tts(JSONObject input,String key)throws Exception {
        String spoken=input.optString("text","").trim();
        if(spoken.length()<2||spoken.length()>9000)throw new IOException("Voice-over harus 2–9000 karakter");
        String style=input.optString("style","").replaceAll("[\\r\\n]+"," ");
        if(style.length()>200)style=style.substring(0,200);
        JSONObject textBlock=new JSONObject().put("type","text").put("text",spoken);
        if(!style.isEmpty())textBlock.put("annotations",new JSONArray().put(
            new JSONObject().put("type","speech_metadata").put("style",style)));
        JSONObject request=new JSONObject().put("model","gemini-3.8-flash-lite-tts")
            .put("input",new JSONArray().put(new JSONObject().put("type","user_input")
                .put("content",new JSONArray().put(textBlock))))
            .put("response_format",new JSONObject().put("type","audio"))
            .put("generation_config",new JSONObject().put("speech_config",new JSONArray().put(
                new JSONObject().put("voice","Kore"))));
        JSONObject res=request("POST",BASE+"/interactions",key,request,MEDIA_LIMIT);
        JSONObject media=findMedia(res,"audio");
        if(media==null)throw new IOException("Gemini TTS tidak mengembalikan audio; cek kuota dan model");
        String b64=media.optString("data","");
        if(b64.length()<100||b64.length()>26*1024*1024)throw new IOException("Ukuran audio Gemini tidak valid");
        String mime=media.optString("mime_type","audio/wav");
        if(!mime.startsWith("audio/"))throw new IOException("Respons suara Gemini bukan audio");
        return new JSONObject().put("audio_base64",b64).put("mime_type",mime);
    }
    static JSONObject findMedia(JSONObject root,String type){
        JSONArray steps=root.optJSONArray("steps");
        if(steps==null)return null;
        for(int i=steps.length()-1;i>=0;i--){
            JSONObject step=steps.optJSONObject(i);
            if(step==null||!"model_output".equals(step.optString("type")))continue;
            JSONArray contents=step.optJSONArray("content");
            if(contents==null)continue;
            for(int j=contents.length()-1;j>=0;j--){
                JSONObject item=contents.optJSONObject(j);
                if(item!=null&&type.equals(item.optString("type"))&&(item.has("data")||("text".equals(type)&&item.has("text"))))return item;
            }
        }
        return null;
    }
    static JSONObject request(String method,String url,String key,JSONObject body,int limit)throws Exception {
        return request(method,url,key,body,limit,25000,180000);
    }
    static JSONObject request(String method,String url,String key,JSONObject body,int limit,int connectTimeout,int readTimeout)throws Exception {
        if(!url.startsWith(BASE+"/"))throw new IOException("URL Gemini tidak diizinkan");
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        StoryIdeaCancellation.track(c);
        c.setRequestMethod(method);c.setConnectTimeout(connectTimeout);c.setReadTimeout(readTimeout);c.setInstanceFollowRedirects(false);
        c.setRequestProperty("x-goog-api-key",key.trim());c.setRequestProperty("Accept","application/json");
        StoryIdeaCancellation.applyLimits(c);
        try{
            if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");
                try(OutputStream out=c.getOutputStream()){out.write(body.toString().getBytes(StandardCharsets.UTF_8));}}
            int status=c.getResponseCode();
            if(status<200||status>=300){
                String raw=readText(c.getErrorStream(),12000);
                String msg=raw;
                try{JSONObject err=new JSONObject(raw).optJSONObject("error");if(err!=null)msg=err.optString("message",raw);}catch(Exception ignored){}
                msg=msg.replaceAll("[\\r\\n]+"," ");
                throw new IOException("Gemini HTTP "+status+": "+msg.substring(0,Math.min(250,msg.length())));
            }
            byte[] raw=readBound(c.getInputStream(),limit);
            return new JSONObject(new String(raw,StandardCharsets.UTF_8));
        }finally{c.disconnect();}
    }
    static byte[] readBound(InputStream stream,int limit)throws IOException{
        if(stream==null)throw new IOException("Respons Gemini kosong");
        try(InputStream in=stream;ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buff=new byte[16384];int n;
            while((n=in.read(buff))!=-1){if(out.size()+n>limit)throw new IOException("Respons Gemini terlalu besar; coba klip lebih pendek");out.write(buff,0,n);}
            return out.toByteArray();
        }
    }
    static String readText(InputStream stream,int limit)throws IOException{
        if(stream==null)return "";
        return new String(readBound(stream,limit),StandardCharsets.UTF_8);
    }
}
