package id.kreasiflow.studio;

import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/** Gemini Omni Flash image-to-video with explicit user consent in the UI.
 *  Only a fixed Google endpoint/model is supported. 360p and a single scene
 *  keep memory and spend manageable during the debug stage.
 */
final class GeminiVideoApi {
    private static final String MODEL="gemini-omni-1.1-flash";
    private static final String API=GeminiApi.BASE+"/interactions";
    private static final String ID_RE="[a-zA-Z0-9_-]{5,140}";
    static JSONObject start(File image,JSONObject req,String key)throws Exception {
        if(key==null||key.trim().length()<15)throw new IOException("Gemini API Key belum disimpan");
        if(image==null||!image.isFile()||image.length()<100||image.length()>790_000)
            throw new IOException("Gambar scene harus JPG/PNG di bawah 790 KB");
        byte[] bytes=Files.readAllBytes(image.toPath());String mime;
        if((bytes[0]&255)==255&&(bytes[1]&255)==216)mime="image/jpeg";
        else if((bytes[0]&255)==137&&bytes[1]==80&&bytes[2]==78)mime="image/png";
        else throw new IOException("Gemini video membutuhkan gambar JPG/PNG");
        String prompt=req.optString("prompt","").trim();
        if(prompt.length()<6||prompt.length()>1800)throw new IOException("Prompt gerakan belum valid");
        String ratio=req.optString("ratio","9:16");if(!ratio.equals("16:9"))ratio="9:16";
        JSONObject body=new JSONObject()
            .put("model",MODEL)
            .put("input",new JSONArray()
                .put(new JSONObject().put("type","image").put("mime_type",mime)
                    .put("data",Base64.encodeToString(bytes,Base64.NO_WRAP)))
                .put(new JSONObject().put("type","text").put("text",prompt)))
            .put("response_format",new JSONObject().put("type","video").put("aspect_ratio",ratio).put("resolution","360p"))
            .put("background",true);
        JSONObject res=GeminiApi.request("POST",API,key,body,6*1024*1024);
        String id=res.optString("id","");
        if(!id.matches(ID_RE))throw new IOException("Gemini tidak mengembalikan interaction ID");
        return new JSONObject().put("prediction_id",id).put("status",res.optString("status","processing"));
    }
    static JSONObject poll(JSONObject request,String key,File destination)throws Exception {
        String id=request.optString("prediction_id","");
        if(!id.matches(ID_RE))throw new IOException("Gemini interaction ID tidak valid");
        JSONObject res=GeminiApi.request("GET",API+"/"+id,key,null,72*1024*1024);
        String state=res.optString("status","processing");
        if(state.equals("failed")||state.equals("cancelled")||state.equals("canceled")){
            JSONObject error=res.optJSONObject("error");
            throw new IOException("Gemini video gagal: "+(error!=null?error.optString("message","Coba prompt lain"):"Coba prompt lain"));
        }
        JSONObject r=new JSONObject().put("prediction_id",id).put("status",state.equals("completed")?"succeeded":"processing");
        if(!state.equals("completed"))return r;
        // Interactions API may include the clip in steps[].content[] OR
        // the top-level output_video. Support both official response shapes.
        JSONObject clip=locateVideo(res);
        if(clip==null)throw new IOException("Respons Gemini selesai tanpa data video MP4. Cek akses video model pada akun dan lihat log Google AI Studio.");
        if(!clip.optString("mime_type","video/mp4").equals("video/mp4"))
            throw new IOException("Format video Gemini tidak didukung (harus MP4)");
        String b64=clip.optString("data","");
        if(b64.length()<1000) {
            String uri=clip.optString("uri", "");
            if(!uri.isEmpty()) {
                // Only retrieve through verified Google Files IDs. Never send an
                // API key to an arbitrary URI supplied by a remote response.
                String fileId=extractGoogleFileId(uri);
                JSONObject file=GeminiApi.request("GET", GeminiApi.BASE+"/files/"+fileId,key,null,2*1024*1024);
                String fileState=file.optString("state", "");
                if("FAILED".equals(fileState))throw new IOException("Google gagal menyiapkan berkas MP4");
                if(!"ACTIVE".equals(fileState))return r.put("status","processing");
                downloadGoogleFile(fileId,key,destination);
                return r.put("downloaded",true).put("size",destination.length());
            }
            throw new IOException("Gemini tidak mengembalikan data MP4; coba ulang status dengan ID yang tersimpan");
        }
        if(b64.length()>68*1024*1024)throw new IOException("Video Gemini terlalu besar (>50 MB). Gunakan 360p dan klip singkat");
        byte[] mp4;
        try { mp4=Base64.decode(b64,Base64.DEFAULT); }
        catch(IllegalArgumentException badBase64) { throw new IOException("Data video Gemini tidak valid",badBase64); }
        if(mp4.length<4096||mp4.length>55*1024*1024||mp4[4]!='f'||mp4[5]!='t'||mp4[6]!='y'||mp4[7]!='p')
            throw new IOException("Output Gemini bukan MP4 yang valid");
        try(FileOutputStream out=new FileOutputStream(destination)){out.write(mp4);}
        return r.put("downloaded",true).put("size",destination.length());
    }
    private static final Pattern GOOGLE_FILE=Pattern.compile(
        "^(?:https://generativelanguage\\.googleapis\\.com/v1beta/)?files/([A-Za-z0-9_-]{3,160})(?::download(?:\\?.*)?)?$"
    );
    private static String extractGoogleFileId(String uri)throws IOException {
        Matcher matcher=GOOGLE_FILE.matcher(uri);
        if(!matcher.matches())throw new IOException("URI video dari API Google tidak dikenali; unduh manual dari Google AI Studio");
        return matcher.group(1);
    }
    private static boolean trustedDownloadHost(String host){
        return "generativelanguage.googleapis.com".equals(host)
            || "storage.googleapis.com".equals(host)
            || "googleusercontent.com".equals(host)
            || host.endsWith(".googleusercontent.com");
    }
    private static void downloadGoogleFile(String id,String key,File destination)throws Exception {
        URL url=new URL(GeminiApi.BASE+"/files/"+id+":download?alt=media");
        File temp=new File(destination.getParentFile(),destination.getName()+".part");
        try {
            for(int redirects=0;redirects<=3;redirects++){
                String host=url.getHost().toLowerCase(java.util.Locale.ROOT);
                if(!"https".equalsIgnoreCase(url.getProtocol())||!trustedDownloadHost(host))
                    throw new IOException("Lokasi unduh video Google ditolak demi keamanan");
                HttpURLConnection c=(HttpURLConnection)url.openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(25000);c.setReadTimeout(180000);
                c.setRequestProperty("Accept", "video/mp4,application/octet-stream");
                if("generativelanguage.googleapis.com".equals(host))c.setRequestProperty("x-goog-api-key",key.trim());
                try{
                    int http=c.getResponseCode();
                    if(http==301||http==302||http==303||http==307||http==308){
                        String location=c.getHeaderField("Location");
                        if(location==null||location.isEmpty())throw new IOException("Redirect unduh Google tidak valid");
                        url=new URL(url,location);continue;
                    }
                    if(http!=200){
                        String details=GeminiApi.readText(c.getErrorStream(),1000);
                        throw new IOException("Google Files download HTTP "+http+": "+details.substring(0,Math.min(180,details.length())));
                    }
                    long total=0;
                    try(InputStream in=c.getInputStream();FileOutputStream out=new FileOutputStream(temp)){
                        byte[] buffer=new byte[32768];int n;
                        while((n=in.read(buffer))!=-1){
                            total+=n;
                            if(total>55L*1024*1024)throw new IOException("Video lebih dari 55MB; pakai 360p/klip singkat");
                            out.write(buffer,0,n);
                        }
                    }
                    if(total<4096||!validMp4Header(temp))throw new IOException("Download Gemini bukan MP4 valid");
                    if(destination.exists()&&!destination.delete())throw new IOException("Gagal mengganti file video lama");
                    if(!temp.renameTo(destination))throw new IOException("Gagal menyimpan berkas video Gemini");
                    return;
                }finally{c.disconnect();}
            }
            throw new IOException("Google mengalihkan unduh terlalu banyak kali");
        }finally{if(temp.exists())temp.delete();}
    }
    private static boolean validMp4Header(File file)throws IOException {
        try(FileInputStream in=new FileInputStream(file)){
            byte[] header=new byte[8];
            if(in.read(header)!=8)return false;
            return header[4]=='f'&&header[5]=='t'&&header[6]=='y'&&header[7]=='p';
        }
    }
    private static JSONObject locateVideo(JSONObject response) {
        JSONObject media=GeminiApi.findMedia(response,"video");
        if(media!=null)return media;
        // The shared parser only returns media with inline `data`; video may
        // instead be a Google-hosted URI in steps[].content[].
        JSONArray steps=response.optJSONArray("steps");
        if(steps!=null)for(int i=steps.length()-1;i>=0;i--){
            JSONObject step=steps.optJSONObject(i);
            if(step==null||!"model_output".equals(step.optString("type","")))continue;
            JSONArray content=step.optJSONArray("content");
            if(content==null)continue;
            for(int j=content.length()-1;j>=0;j--){
                JSONObject item=content.optJSONObject(j);
                if(item!=null&&"video".equals(item.optString("type",""))&&
                   !item.optString("uri","").isEmpty())return item;
            }
        }
        media=response.optJSONObject("output_video");
        if(media!=null)return media;
        media=response.optJSONObject("outputVideo");
        if(media!=null)return media;
        JSONObject output=response.optJSONObject("output");
        if(output!=null){
            media=output.optJSONObject("video");
            if(media!=null)return media;
            media=output.optJSONObject("output_video");
        }
        return media;
    }
}
