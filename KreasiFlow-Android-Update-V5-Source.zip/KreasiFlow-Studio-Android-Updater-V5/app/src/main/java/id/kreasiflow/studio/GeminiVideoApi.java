package id.kreasiflow.studio;

import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/** Gemini Omni Flash image-to-video with explicit user consent in the UI.
 *  Only a fixed Google endpoint/model is supported. 360p and a single scene
 *  keep memory and spend manageable during the debug stage.
 */
final class GeminiVideoApi {
    private static final String MODEL="gemini-omni-1.2-flash";
    private static final String API=GeminiApi.BASE+"/interactions";
    private static final String ID_RE="[a-zA-Z0-9_-]{5,140}";
    static JSONObject start(File image,JSONObject req,String key)throws Exception {
        if(key==null||key.trim().length()<15)throw new IOException("Gemini API Key belum disimpan");
        if(image==null||!image.isFile()||image.length()<100||image.length()>790_000)
            throw new IOException("Gambar scene harus JPG/PNG di bawah 790 KB");
        byte[] bytes=Files.readAllBytes(image.toPath());String mime;
        if((bytes[0]&255)==255&&(bytes[1]&255)==216)mime="image/jpeg";
        else if((bytes[0]&255)==137&&bytes[1]==80&&bytes[2]==78)mime="image/png";
        else throw new IOException("Gemini video membutuhkan gambar JPG/PNG");
        String prompt=req.optString("prompt","").trim();
        if(prompt.length()<6||prompt.length()>1800)throw new IOException("Prompt gerakan belum valid");
        String ratio=req.optString("ratio","9:16");if(!ratio.equals("16:9"))ratio="9:16";
        JSONObject body=new JSONObject()
            .put("model",MODEL)
            .put("input",new JSONArray()
                .put(new JSONObject().put("type","image").put("mime_type",mime)
                    .put("data",Base64.encodeToString(bytes,Base64.NO_WRAP)))
                .put(new JSONObject().put("type","text").put("text",prompt)))
            .put("response_format",new JSONObject().put("type","video").put("aspect_ratio",ratio).put("resolution","360p"))
            .put("background",true);
        JSONObject res=GeminiApi.request("POST",API,key,body,6*1024*1024);
        String id=res.optString("id","");
        if(!id.matches(ID_RE))throw new IOException("Gemini tidak mengembalikan interaction ID");
        return new JSONObject().put("prediction_id",id).put("status",res.optString("status","processing"));
    }
    static JSONObject poll(JSONObject request,String key,File destination)throws Exception {
        String id=request.optString("prediction_id","");
        if(!id.matches(ID_RE))throw new IOException("Gemini interaction ID tidak valid");
        JSONObject res=GeminiApi.request("GET",API+"/"+id,key,null,72*1024*1024);
        String state=res.optString("status","processing");
        if(state.equals("failed")||state.equals("cancelled")||state.equals("canceled")){
            JSONObject error=res.optJSONObject("error");
            throw new IOException("Gemini video gagal: "+(error!=null?error.optString("message","Coba prompt lain"):"Coba prompt lain"));
        }
        JSONObject r=new JSONObject().put("prediction_id",id).put("status",state.equals("completed")?"succeeded":"processing");
        if(!state.equals("completed"))return r;
        JSONObject clip=GeminiApi.findMedia(res,"video");
        if(clip==null||!clip.optString("mime_type","video/mp4").equals("video/mp4"))throw new IOException("Gemini belum menghasilkan video MP4");
        String b64=clip.optString("data","");
        if(b64.length()<1000||b64.length()>68*1024*1024)throw new IOException("Video Gemini terlalu besar");
        byte[] mp4=Base64.decode(b64,Base64.DEFAULT);
        if(mp4.length<4096||mp4.length>55*1024*1024||mp4[4]!='f'||mp4[5]!='t'||mp4[6]!='y'||mp4[7]!='p')
            throw new IOException("Output Gemini bukan MP4 yang valid");
        try(FileOutputStream out=new FileOutputStream(destination)){out.write(mp4);}
        return r.put("downloaded",true).put("size",destination.length());
    }
}
