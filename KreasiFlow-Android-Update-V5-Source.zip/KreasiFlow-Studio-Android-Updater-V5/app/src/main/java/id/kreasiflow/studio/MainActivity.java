package id.kreasiflow.studio;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.ClipData;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicBoolean;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;


/**
 * KreasiFlow Studio — satu layar kerja. Browser eksternal dibuka saat pengguna
 * memilih AI Studio, Flow, Gemini, atau link AI dari halaman lokal.
 * Tidak ada panel split dan tidak ada login akun Google di WebView tertanam.
 * Identitas paket dan updater GitHub Releases tetap sama seperti versi 5.0.1.
 */
public final class MainActivity extends Activity {
    private static final String LOCAL = "https://appassets.androidplatform.net/assets/index.html";
    private static final String STUDIO = "https://aistudio.google.com/generate-speech";
    private static final String FLOW = "https://flow.google.com/";
    private static final String GEMINI = "https://gemini.google.com/app";
    private static final String API_KEYS = "https://aistudio.google.com/api-keys";
    private static final int PICK_FILE = 731;
    private static final int PICK_ALL_FLOW_CLIPS = 732;
    private static final int BG = Color.rgb(6, 20, 14);
    private static final int PANEL = Color.rgb(11, 37, 25);
    private static final int GREEN = Color.rgb(121, 235, 176);
    private static final int WHITE = Color.rgb(228, 249, 235);

    private UpdateController updater;
    private ProviderSecrets providerSecrets;
    private CloudKeyBackup cloudKeyBackup;
    private WebView topWeb;
    private ValueCallback<Uri[]> uploadCallback;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<String, SaveSession> transfers = new HashMap<>();
    private final AtomicLong nextTransfer = new AtomicLong(System.currentTimeMillis());
    private final ExecutorService apiPool = Executors.newFixedThreadPool(2);
    private final Map<String, AssetSession> renderTransfers = new HashMap<>();
    private final Map<String, File> renderAssets = new HashMap<>();
    // Native selection is retained only until the user confirms the scene mapping.
    private final Map<String, Uri> selectedFlowUris = new LinkedHashMap<>();
    private final Map<String, String> selectedFlowNames = new LinkedHashMap<>();
    private final AtomicBoolean flowClipImportBusy = new AtomicBoolean(false);
    private Uri lastRenderUri;
    private ProjectStore projectStore;
    private static final int REQUEST_PROJECT_BACKUP = 7353;
    private static final int REQUEST_PROJECT_RESTORE = 7354;
    private String pendingProjectBackupId;



    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        updater = new UpdateController(this);
        providerSecrets = new ProviderSecrets(this);
        cloudKeyBackup = new CloudKeyBackup(this,providerSecrets);
        try { projectStore = new ProjectStore(this); }
        catch (IOException ex) { Log.e("KreasiFlow", "Project store initialization failed", ex); }

        try {
            buildLayout();
            configureWebView();
            Bundle editorState=savedInstanceState == null ? null : savedInstanceState.getBundle("editor");
            if(editorState==null || topWeb.restoreState(editorState)==null) topWeb.loadUrl(LOCAL);
        } catch (RuntimeException | LinkageError ex) {
            Log.e("KreasiFlow","Unable to initialize editor",ex);
            showRecoveryScreen(ex);
            return;
        }
        try { if (!BuildConfig.DEBUG) updater.start(); }
        catch(RuntimeException ex) {
            Log.e("KreasiFlow","Updater startup failed; editor remains available",ex);
            getSharedPreferences("startup_diagnostics",MODE_PRIVATE).edit()
                .putString("last_update_error",ex.toString()).apply();
        }
        if (!BuildConfig.DEBUG && "id.kreasiflow.studio.SHOW_UPDATE".equals(getIntent().getAction()))
            updater.onNotificationTap();
    }

    private void buildLayout(){
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        setContentView(root);

        // v5.0.50: toolbar AI eksternal dan header ganda dihapus; navigasi satu layar ada di WebView.
        FrameLayout editor=new FrameLayout(this);
        editor.setBackgroundColor(BG);
        root.addView(editor,new LinearLayout.LayoutParams(-1,0,1));
        topWeb=new WebView(this);
        editor.addView(topWeb,new FrameLayout.LayoutParams(-1,-1));
    }

    private void configureWebView(){
        WebSettings s=topWeb.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSafeBrowsingEnabled(true);
        s.setSupportZoom(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        topWeb.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> cb,FileChooserParams params){
                if(uploadCallback!=null)uploadCallback.onReceiveValue(null);
                uploadCallback=cb;
                try{startActivityForResult(params.createIntent(),PICK_FILE);return true;}
                catch(Exception ex){cb.onReceiveValue(null);uploadCallback=null;return true;}
            }
        });
        // Bridge hanya dipasang pada editor aset lokal. Jangan menavigasikan
        // WebView ini ke situs eksternal, termasuk login Google.
        topWeb.addJavascriptInterface(new NativeBridge(),"KreasiFlowNative");
        WebViewAssetLoader assets=new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
        topWeb.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request){
                if(projectStore!=null && "appassets.androidplatform.net".equalsIgnoreCase(request.getUrl().getHost())
                    && request.getUrl().getPath().startsWith("/project-media/")) {
                    String range = null;
                    if(request.getRequestHeaders()!=null)for(Map.Entry<String,String> h:request.getRequestHeaders().entrySet()){
                        if("range".equalsIgnoreCase(h.getKey())){range=h.getValue();break;}
                    }
                    return projectStore.serveMedia(request.getUrl().getPath(),range);
                }
                return assets.shouldInterceptRequest(request.getUrl());
            }
            @Override public void onPageFinished(WebView view, String url){
                if(url!=null && url.startsWith(LOCAL))pushBackgroundRenderStatus();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){
                String url=request.getUrl().toString();
                if(url.startsWith("https://appassets.androidplatform.net/assets/"))return false;
                if(isHttps(url))runOnUiThread(()->openExternal(url));
                return true;
            }
        });
    }

    private boolean isHttps(String value){
        try{
            Uri uri=Uri.parse(value);
            return "https".equalsIgnoreCase(uri.getScheme())&&uri.getHost()!=null;
        }catch(Exception ex){return false;}
    }

    /** Preferred Chrome app, fallback to Android's default browser. */
    void openExternal(String url){
        if(!isHttps(url)){
            Toast.makeText(this,"Link AI harus HTTPS",Toast.LENGTH_SHORT).show();
            return;
        }
        Uri uri=Uri.parse(url);
        Intent chrome=new Intent(Intent.ACTION_VIEW,uri);
        chrome.addCategory(Intent.CATEGORY_BROWSABLE);
        chrome.setPackage("com.android.chrome");
        try{startActivity(chrome);return;}
        catch(ActivityNotFoundException ignored){/* Chrome not installed or disabled. */}
        catch(RuntimeException ex){Log.w("KreasiFlow","Chrome launch failed; trying default browser",ex);}
        try{
            Intent fallback=new Intent(Intent.ACTION_VIEW,uri);
            fallback.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(fallback);
        }catch(Exception ex){
            Toast.makeText(this,"Tidak ada browser untuk membuka tautan AI",Toast.LENGTH_LONG).show();
        }
    }

    private void showRecoveryScreen(Throwable cause){
        LinearLayout panel=new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20),dp(32),dp(20),dp(24));
        panel.setBackgroundColor(BG);
        panel.addView(label("KreasiFlow Studio • Mode Pemulihan",19,GREEN,true));
        TextView info=label("Editor tidak dapat dimuat. Perbarui Android System WebView atau Chrome. Detail: "+
                cause.getClass().getSimpleName()+" — "+String.valueOf(cause.getMessage()),13,WHITE,false);
        info.setPadding(0,dp(20),0,dp(20));
        panel.addView(info);
        panel.addView(button("Buka AI Studio",()->openExternal(STUDIO)));
        panel.addView(button("Buka Flow",()->openExternal(FLOW)));
        panel.addView(button("Rilis KreasiFlow",()->openExternal("https://github.com/alfianzikri63-blip/KreasiFlow/releases")));
        setContentView(panel);
    }

    private LinearLayout bar(int dpHeight){
        LinearLayout bar=new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(7),0,dp(7),0);
        bar.setMinimumHeight(dp(dpHeight));
        bar.setBackgroundColor(PANEL);
        return bar;
    }
    private TextView label(String value,int sp,int color,boolean bold){
        TextView label=new TextView(this);
        label.setText(value);label.setTextColor(color);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP,sp);
        label.setGravity(Gravity.CENTER_VERTICAL);
        if(bold)label.setTypeface(null,android.graphics.Typeface.BOLD);
        return label;
    }
    private TextView button(String value,Runnable onClick){
        TextView label=label(value,11,WHITE,true);
        label.setPadding(dp(12),0,dp(12),0);
        label.setGravity(Gravity.CENTER);
        label.setMinHeight(dp(40));
        label.setOnClickListener(v->onClick.run());
        label.setContentDescription(value);
        return label;
    }
    private int dp(float value){return (int)(value*getResources().getDisplayMetrics().density+.5f);}

    @Override protected void onResume(){
        super.onResume();
        if(!renderStatusPollActive){renderStatusPollActive=true;main.post(renderStatusPoll);}
        if(!BuildConfig.DEBUG && updater!=null)try{updater.onResume();}
        catch(RuntimeException ex){Log.e("KreasiFlow","Update resume issue",ex);}
    }
    @Override protected void onPause(){
        renderStatusPollActive=false;
        main.removeCallbacks(renderStatusPoll);
        super.onPause();
    }
    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        setIntent(intent);
        if(!BuildConfig.DEBUG && updater!=null && "id.kreasiflow.studio.SHOW_UPDATE".equals(intent.getAction()))
            updater.onNotificationTap();
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_ALL_FLOW_CLIPS){
            onFlowClipPickerResult(resultCode,data);
            return;
        }
        if(requestCode==PICK_FILE && uploadCallback!=null){
            // OEM photo pickers sometimes return ClipData but parseResult only yields one URI.
            Uri[] picked=extractPickedUris(resultCode,data);
            uploadCallback.onReceiveValue(picked.length==0?null:picked);
            uploadCallback=null;
        }else if(requestCode==REQUEST_PROJECT_BACKUP){
            final String id=pendingProjectBackupId;pendingProjectBackupId=null;
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null && id!=null && projectStore!=null){
                final Uri dest=data.getData();
                apiPool.execute(()->{
                    try(OutputStream out=getContentResolver().openOutputStream(dest,"w")){
                        if(out==null)throw new IOException("Lokasi penyimpanan tidak dapat ditulis");
                        projectStore.writeZip(id,out);
                        editorJs("window.__kfProjectBackupDone?.(true,'Backup ZIP berhasil disimpan');");
                    }catch(Exception ex){
                        editorJs("window.__kfProjectBackupDone?.(false,"+JSONObject.quote(String.valueOf(ex.getMessage()))+");");
                    }
                });
            }else editorJs("window.__kfProjectBackupDone?.(false,'Backup dibatalkan');");
        }else if(requestCode==REQUEST_PROJECT_RESTORE){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null && projectStore!=null){
                final Uri src=data.getData();
                apiPool.execute(()->{
                    try(InputStream in=getContentResolver().openInputStream(src)){
                        if(in==null)throw new IOException("Tidak dapat membuka ZIP");
                        String id=projectStore.readZip(in);
                        editorJs("window.__kfProjectArchiveImported?.("+JSONObject.quote(id)+",null);");
                    }catch(Exception ex){
                        editorJs("window.__kfProjectArchiveImported?.(null,"+JSONObject.quote(String.valueOf(ex.getMessage()))+");");
                    }
                });
            }else editorJs("window.__kfProjectArchiveImported?.(null,'Impor dibatalkan');");
        }
    }
    @Override protected void onSaveInstanceState(Bundle out){
        if(topWeb!=null){Bundle state=new Bundle();topWeb.saveState(state);out.putBundle("editor",state);}
        super.onSaveInstanceState(out);
    }
    @Override public void onBackPressed(){
        if(topWeb!=null && topWeb.canGoBack())topWeb.goBack();
        else new AlertDialog.Builder(this).setMessage("Tutup KreasiFlow Studio?")
                .setNegativeButton("Batal",(d,w)->{})
                .setPositiveButton("Keluar",(d,w)->finish()).show();
    }
    @Override protected void onDestroy(){
        main.removeCallbacks(renderStatusPoll);
        if(!BuildConfig.DEBUG && updater!=null)updater.stop();
        if(uploadCallback!=null){uploadCallback.onReceiveValue(null);uploadCallback=null;}
        synchronized(transfers){
            for(SaveSession session:transfers.values()){
                try{session.out.close();}catch(Exception ignored){}
                getContentResolver().delete(session.uri,null,null);
            }
            transfers.clear();
        }
        synchronized(renderTransfers){
            for(AssetSession session:renderTransfers.values()){
                try{session.out.close();}catch(Exception ignored){}
                session.file.delete();
            }
            renderTransfers.clear();
            // Asset files belong to queued foreground render tasks; do not delete on Activity destroy.
            renderAssets.clear();
        }
        apiPool.shutdownNow();
        if(topWeb!=null)topWeb.destroy();
        super.onDestroy();
    }
    private static final class SaveSession {
        final Uri uri;
        final OutputStream out;
        long size;
        SaveSession(Uri u,OutputStream o){uri=u;out=o;}
    }
    private void completeGemini(String requestId,String response,String error){
        main.post(()->{
            if(topWeb == null || topWeb.getUrl() == null || !topWeb.getUrl().startsWith(LOCAL))return;
            String id=JSONObject.quote(requestId);
            if(error!=null){
                topWeb.evaluateJavascript("window.__kreasiflowApiResolve("+id+",\"\","+JSONObject.quote(error)+");",null);
                return;
            }
            // Small chunks avoid oversized evaluateJavascript/Binder messages for images and WAV.
            topWeb.evaluateJavascript("window.__kreasiflowApiBegin("+id+");",null);
            String content=response==null?"":response;
            for(int offset=0;offset<content.length();offset+=16000){
                String part=content.substring(offset,Math.min(offset+16000,content.length()));
                topWeb.evaluateJavascript("window.__kreasiflowApiChunk("+id+","+JSONObject.quote(part)+");",null);
            }
            topWeb.evaluateJavascript("window.__kreasiflowApiEnd("+id+");",null);
        });
    }
    // Provider network calls run off the main/UI thread. Keys stay in encrypted
    // AndroidKeyStore-backed storage, never returned to WebView JavaScript.
    private void callProvider(String id, String provider, String json) {
        if (id == null || id.length() > 96 || !id.matches("[a-zA-Z0-9_-]+")) return;
        if (json == null || json.length() > 95000) {
            completeGemini(id, null, "Payload terlalu besar"); return;
        }
        if (!("openrouter".equals(provider) || "cloudflare".equals(provider) || "replicate".equals(provider) || "gemini".equals(provider) || "elevenlabs".equals(provider) || "groq".equals(provider) || "nvidia".equals(provider))) {
            completeGemini(id, null, "Provider tidak tersedia"); return;
        }
        apiPool.execute(() -> {
            try {
                String credential = providerSecrets.get(provider);
                String result;
                if("replicate".equals(provider)) {
                    JSONObject input=new JSONObject(json);
                    String operation=input.optString("op", "");
                    if("start".equals(operation)) {
                        File image=lookupAsset(input.optString("image_asset_id", ""));
                        if(image==null || !image.isFile())throw new IOException("Gambar scene belum dikirim ke Android");
                        result=ReplicateVideoApi.start(image,input,credential).toString();
                    } else if("status".equals(operation)) {
                        String clipId=String.valueOf(nextTransfer.getAndIncrement());
                        File out=new File(renderFolder(),"clip-"+clipId+".mp4");
                        JSONObject status=ReplicateVideoApi.poll(input,credential,out);
                        if(status.optBoolean("downloaded",false)) {
                            synchronized(renderTransfers){renderAssets.put(clipId,out);}
                            status.put("clip_id",clipId);
                        }
                        result=status.toString();
                    } else throw new IOException("Operasi Replicate tidak dikenal");
                } else if ("elevenlabs".equals(provider) || "groq".equals(provider)) {
                    JSONObject input = new JSONObject(json);
                    if ("transcribe_audio".equals(input.optString("op", ""))) {
                        File audio = lookupAsset(input.optString("audio_asset_id", ""));
                        result = TranscriptionProviders.transcribe(provider, audio,
                            input.optString("mime_type", "audio/mpeg"),
                            input.optDouble("duration_seconds", 0), credential,
                            input.optString("language_code", "auto"));
                    } else if ("groq".equals(provider)&&"text".equals(input.optString("op"))) {
                        result=MultiProviderApi.execute(provider,input,credential,null);
                    } else throw new IOException("Operasi audio tidak didukung");
                } else if ("gemini".equals(provider)) {
                    JSONObject input = new JSONObject(json);
                    String op=input.optString("op", "text");
                    if("transcribe_audio".equals(op)) {
                        File audioFile=lookupAsset(input.optString("audio_asset_id",""));
                        String mime=input.optString("mime_type","audio/mpeg");
                        double seconds=input.optDouble("duration_seconds",0);
                        String audioModel=input.optString("audio_model","gemini-3.6-flash");
                        result=GeminiApi.transcribe(audioFile,mime,seconds,credential,audioModel);
                    } else if("video_start".equals(op)) {
                        File image=lookupAsset(input.optString("image_asset_id", ""));
                        if(image==null||!image.isFile())throw new IOException("Gambar scene belum ditransfer ke Android");
                        result=GeminiVideoApi.start(image,input,credential).toString();
                    } else if("video_status".equals(op)) {
                        String clipId=String.valueOf(nextTransfer.getAndIncrement());
                        File dest=new File(renderFolder(),"gemini-clip-"+clipId+".mp4");
                        JSONObject status=GeminiVideoApi.poll(input,credential,dest);
                        if(status.optBoolean("downloaded",false)) {
                            synchronized(renderTransfers){renderAssets.put(clipId,dest);}
                            status.put("clip_id",clipId);
                        }
                        result=status.toString();
                    } else result=GeminiApi.execute(input,credential);
                } else {
                    result=MultiProviderApi.execute(provider, new JSONObject(json), credential, "cloudflare".equals(provider) ? providerSecrets.get("cloudflare_account") : null);
                }
                completeGemini(id, result, null);
            } catch (Exception ex) {
                Log.w("KreasiFlow", "Provider request failed: " + provider + " (no credentials logged)");
                completeGemini(id, null, ex.getMessage() == null ? "Layanan AI gagal" : ex.getMessage());
            }
        });
    }
    // v5.0.57: Native multi-video import avoids the WebView file chooser and massive
    // Base64 File transfers. ContentResolver streams files into the existing render
    // asset registry; Javascript only receives safe names, sizes, and asset IDs.
    private static Uri[] extractPickedUris(int resultCode, Intent data) {
        if(resultCode!=RESULT_OK || data==null)return new Uri[0];
        LinkedHashSet<Uri> seen=new LinkedHashSet<>();
        ClipData group=data.getClipData();
        if(group!=null){
            for(int i=0;i<group.getItemCount() && i<120;i++){
                Uri u=group.getItemAt(i).getUri();if(u!=null)seen.add(u);
            }
        }
        if(data.getData()!=null)seen.add(data.getData());
        return seen.toArray(new Uri[0]);
    }
    private void pickAllFlowClips(String source) {
        main.post(()->{
            if(flowClipImportBusy.get()){
                editorJs("window.__kfNativeFlowPickerError('Impor sebelumnya masih berjalan');");return;
            }
            try {
                Intent picker=new Intent("files".equals(source)?Intent.ACTION_OPEN_DOCUMENT:Intent.ACTION_GET_CONTENT);
                picker.addCategory(Intent.CATEGORY_OPENABLE);
                picker.setType("video/*");
                picker.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
                picker.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivityForResult(Intent.createChooser(picker,"Pilih semua video MP4"),PICK_ALL_FLOW_CLIPS);
            }catch(Exception ex){
                editorJs("window.__kfNativeFlowPickerError("+JSONObject.quote("Tidak dapat membuka pemilih video: "+String.valueOf(ex.getMessage()))+");");
            }
        });
    }
    private void onFlowClipPickerResult(int resultCode, Intent data) {
        synchronized(selectedFlowUris){selectedFlowUris.clear();selectedFlowNames.clear();}
        Uri[] uris=extractPickedUris(resultCode,data);
        if(uris.length==0){editorJs("window.__kfNativeFlowPickerError('Tidak ada video dipilih.');");return;}
        if(uris.length>36){editorJs("window.__kfNativeFlowPickerError('Maksimal 36 video per impor. Pilih sebagian dulu.');");return;}
        JSONArray picked=new JSONArray();
        int failures=0;
        for(Uri uri:uris){
            try{
                String name=null;long size=-1;
                try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},null,null,null)){
                    if(c!=null&&c.moveToFirst()){
                        int ni=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        int si=c.getColumnIndex(OpenableColumns.SIZE);
                        if(ni>=0)name=c.getString(ni);
                        if(si>=0&&!c.isNull(si))size=c.getLong(si);
                    }
                }
                String mime=getContentResolver().getType(uri);
                if(name==null||name.trim().isEmpty())name="Flow-"+(picked.length()+1)+".mp4";
                if(!name.toLowerCase(java.util.Locale.ROOT).endsWith(".mp4") && "video/mp4".equalsIgnoreCase(mime))name+=".mp4";
                if(!name.toLowerCase(java.util.Locale.ROOT).endsWith(".mp4")){failures++;continue;}
                if(size>250L*1024*1024){failures++;continue;}
                String token="flow-"+nextTransfer.getAndIncrement();
                synchronized(selectedFlowUris){selectedFlowUris.put(token,uri);selectedFlowNames.put(token,name);}
                JSONObject item=new JSONObject();
                item.put("token",token).put("name",name).put("type","video/mp4").put("size",size>0?size:1);
                picked.put(item);
            }catch(Exception ex){failures++;}
        }
        if(picked.length()==0){editorJs("window.__kfNativeFlowPickerError('Tidak ada MP4 yang dapat dibaca dari galeri. Coba lewat File Manager.');");return;}
        editorJs("window.__kfNativeFlowFilesSelected("+picked.toString()+","+failures+");");
    }
    private void clearFlowSelection() {
        if(flowClipImportBusy.get())return;
        synchronized(selectedFlowUris){selectedFlowUris.clear();selectedFlowNames.clear();}
    }
    private boolean importSelectedFlowClips(String json) {
        if(json==null || json.length()>25000 || !flowClipImportBusy.compareAndSet(false,true))return false;
        final ArrayList<JSONObject> jobs=new ArrayList<>();
        final Map<String,Uri> uris=new LinkedHashMap<>();
        try{
            JSONArray list=new JSONArray(json);
            if(list.length()<1||list.length()>36)throw new IOException("Jumlah MP4 tidak valid");
            Set<String> tokens=new HashSet<>();Set<Integer> scenes=new HashSet<>();
            synchronized(selectedFlowUris){
                for(int i=0;i<list.length();i++){
                    JSONObject j=list.getJSONObject(i);
                    String token=j.optString("token","");int index=j.getInt("index");
                    if(index<0||index>=36||!tokens.add(token)||!scenes.add(index) || !selectedFlowUris.containsKey(token))
                        throw new IOException("Pemilihan video atau nomor scene tidak valid");
                    jobs.add(j);uris.put(token,selectedFlowUris.get(token));
                }
                selectedFlowUris.clear();selectedFlowNames.clear();
            }
        }catch(Exception ex){
            flowClipImportBusy.set(false);
            editorJs("window.__kfNativeFlowPickerError("+JSONObject.quote("Gagal memulai impor: "+String.valueOf(ex.getMessage()))+");");
            return false;
        }
        apiPool.execute(()->{
            JSONArray failures=new JSONArray();int imported=0;
            for(int n=0;n<jobs.size();n++){
                JSONObject job=jobs.get(n);
                String token=job.optString("token","");
                int index=job.optInt("index",-1);
                String name=job.optString("name","Scene-"+(index+1)+".mp4");
                String id=String.valueOf(nextTransfer.getAndIncrement());
                File output=new File(renderFolder(),"asset-"+id+".mp4");
                long sent=0,limit=250L*1024*1024;
                try(InputStream input=getContentResolver().openInputStream(uris.get(token));
                    OutputStream stream=new FileOutputStream(output)){
                    if(input==null)throw new IOException("File tidak dapat dibaca oleh Android");
                    byte[] block=new byte[131072];int read;long lastTick=0;
                    while((read=input.read(block))!=-1){
                        sent+=read;
                        if(sent>limit)throw new IOException("MP4 melebihi 250 MB");
                        stream.write(block,0,read);
                        long now=android.os.SystemClock.uptimeMillis();
                        if(now-lastTick>=350){
                            lastTick=now;
                            editorJs("window.__kfNativeFlowTransferProgress("+n+","+jobs.size()+","+sent+","+job.optLong("size",0)+");");
                        }
                    }
                    stream.flush();
                    if(sent==0)throw new IOException("File MP4 kosong");
                    // A completed byte copy is not yet a usable video. Validate container,
                    // video track and duration BEFORE marking any clip as imported.
                    JSONObject videoInfo=FlowVideoInspector.inspect(output);
                    synchronized(renderTransfers){renderAssets.put(id,output);}
                    JSONObject success=new JSONObject();
                    success.put("id",id).put("index",index).put("name",name)
                        .put("size",sent).put("position",n+1).put("total",jobs.size());
                    success.put("durationMs",videoInfo.optLong("durationMs"));
                    success.put("codec",videoInfo.optString("codec"));
                    editorJs("window.__kfNativeFlowClipImported("+success.toString()+");");
                    imported++;
                }catch(Exception ex){
                    output.delete();
                    try{failures.put("Scene "+(index+1)+" ("+name+"): "+String.valueOf(ex.getMessage()));}catch(Exception ignored){}
                }
            }
            JSONObject done=new JSONObject();
            try{done.put("imported",imported).put("total",jobs.size()).put("failures",failures);}catch(Exception ignored){}
            flowClipImportBusy.set(false);
            editorJs("window.__kfNativeFlowImportFinished("+done.toString()+");");
        });
        return true;
    }

    private static final class AssetSession {
        final File file;
        final OutputStream out;
        long size;
        final long max;
        AssetSession(File f, OutputStream o, long max){file=f;out=o;this.max=max;}
    }
    private File renderFolder(){
        File folder=new File(getCacheDir(),"render-assets");
        if(!folder.exists())folder.mkdirs();
        return folder;
    }
    private void previewClip(String id){
        if(id==null||!id.matches("[0-9]{1,18}"))return;
        File file=lookupAsset(id);
        if(file==null||!file.isFile()||!file.getName().endsWith(".mp4")){
            Toast.makeText(this,"Klip sudah tidak tersedia. Generate ulang.",Toast.LENGTH_LONG).show();return;
        }
        try {
            Uri uri=androidx.core.content.FileProvider.getUriForFile(this,
                getPackageName()+".fileprovider",file);
            Intent play=new Intent(this,VideoPreviewActivity.class)
                .setDataAndType(uri,"video/mp4")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            play.putExtra("videoName",file.getName());
            startActivity(play);
        }catch(Exception e){
            Toast.makeText(this,"Pemutar video Android tidak dapat dibuka",Toast.LENGTH_LONG).show();
        }
    }
    private void editorJs(String javascript){
        main.post(()->{
            if(topWeb!=null&&topWeb.getUrl()!=null&&topWeb.getUrl().startsWith(LOCAL))
                topWeb.evaluateJavascript(javascript,null);
        });
    }
    private void reportRender(int pct,String msg){
        editorJs("window.__kreasiflowRenderProgress("+pct+","+JSONObject.quote(msg)+");");
    }
    private Uri publishMp4(File video) throws IOException {
        Uri uri=null;
        try{
            ContentValues values=new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME,"KreasiFlow-"+System.currentTimeMillis()+".mp4");
            values.put(MediaStore.MediaColumns.MIME_TYPE,"video/mp4");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/KreasiFlow");
            values.put(MediaStore.MediaColumns.IS_PENDING,1);
            uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
            if(uri==null)throw new IOException("Android tidak memberi lokasi unduhan");
            try(InputStream input=new FileInputStream(video);OutputStream output=getContentResolver().openOutputStream(uri,"w")){
                if(output==null)throw new IOException("Folder unduhan tidak dapat ditulis");
                byte[] block=new byte[65536];int n;
                while((n=input.read(block))!=-1){
                    if(Thread.currentThread().isInterrupted())throw new IOException("Render dibatalkan");
                    output.write(block,0,n);
                }
            }
            ContentValues ready=new ContentValues();ready.put(MediaStore.MediaColumns.IS_PENDING,0);
            getContentResolver().update(uri,ready,null,null);
            return uri;
        }catch(Exception e){
            if(uri!=null)getContentResolver().delete(uri,null,null);
            if(e instanceof IOException)throw (IOException)e;
            throw new IOException("Gagal menyimpan MP4: "+e.getMessage(),e);
        }
    }
    private void openLastRender(){
        Uri finalUri=lastRenderUri;
        if(finalUri==null){
            String uriString=RenderForegroundService.status(this).optString("uri","");
            if(!uriString.isEmpty())finalUri=Uri.parse(uriString);
        }
        if(finalUri==null){Toast.makeText(this,"Belum ada MP4 selesai",Toast.LENGTH_SHORT).show();return;}
        Intent intent=new Intent(Intent.ACTION_VIEW).setDataAndType(finalUri,"video/mp4");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try{startActivity(intent);}catch(Exception e){
            Toast.makeText(this,"Video tersimpan di Download/KreasiFlow. Buka lewat File Manager.",Toast.LENGTH_LONG).show();
        }
    }
    private File lookupAsset(String id){
        if(id==null||!id.matches("[0-9]{1,18}"))return null;
        synchronized(renderTransfers){return renderAssets.get(id);}
    }
    private String queuedRenderMode;
    private String queuedRenderJson;
    private static final int REQUEST_RENDER_NOTIFICATIONS = 8361;
    private void startForegroundRender(String mode, String payload){
        main.post(() -> {
            // Request the drawer notification permission while still in the visible Activity.
            // Foreground rendering remains possible if user denies it, but won't appear in the drawer.
            if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                  != android.content.pm.PackageManager.PERMISSION_GRANTED &&
                !getPreferences(MODE_PRIVATE).getBoolean("render_notifications_asked",false)) {
                queuedRenderMode=mode;queuedRenderJson=payload;
                getPreferences(MODE_PRIVATE).edit().putBoolean("render_notifications_asked",true).apply();
                requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},REQUEST_RENDER_NOTIFICATIONS);
                return;
            }
            enqueueForegroundRender(mode,payload);
        });
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==REQUEST_RENDER_NOTIFICATIONS && queuedRenderMode!=null){
            String mode=queuedRenderMode, json=queuedRenderJson;
            queuedRenderMode=null;queuedRenderJson=null;
            if(grantResults.length==0 || grantResults[0]!=android.content.pm.PackageManager.PERMISSION_GRANTED)
                Toast.makeText(this,"Notifikasi belum diizinkan. Render tetap berjalan, tetapi status tidak muncul di bilah notifikasi.",Toast.LENGTH_LONG).show();
            enqueueForegroundRender(mode,json);
        }
    }
    private void enqueueForegroundRender(String mode,String payload){
        try {
            JSONObject input=new JSONObject(payload);
            JSONObject assets=new JSONObject();
            synchronized(renderTransfers){
                if(!renderTransfers.isEmpty())throw new IOException("Transfer media belum selesai; tunggu sebelum render.");
                for(Map.Entry<String,File> entry:renderAssets.entrySet()){
                    File file=entry.getValue();
                    if(file!=null && file.isFile())assets.put(entry.getKey(),file.getCanonicalPath());
                }
            }
            RenderForegroundService.enqueue(this,mode,input,assets);
            reportRender(0,"Render berjalan di latar belakang. Lihat progress pada notifikasi Android.");
        }catch(Exception ex){
            String error=ex.getMessage()==null?"Tidak bisa memulai render di latar":ex.getMessage();
            editorJs("window.__kreasiflowRenderDone(false,"+JSONObject.quote(error)+");");
        }
    }
    private final Runnable renderStatusPoll=new Runnable(){
        @Override public void run(){
            pushBackgroundRenderStatus();
            main.postDelayed(this,1500);
        }
    };
    private boolean renderStatusPollActive=false;
    private void pushBackgroundRenderStatus(){
        JSONObject status=RenderForegroundService.status(this);
        if(status.optString("state","").isEmpty())return;
        editorJs("window.__kreasiflowBackgroundRenderSync && window.__kreasiflowBackgroundRenderSync("+status.toString()+");");
    }
    private void cloudAction(String requestId,String payload){
        if(requestId==null||!requestId.matches("[A-Za-z0-9_-]{1,80}")||payload==null||payload.length()>5000)return;
        apiPool.execute(()->{
            JSONObject reply;
            try{reply=cloudKeyBackup.execute(new JSONObject(payload));reply.put("ok",true);}
            catch(Exception e){
                String msg=e.getMessage()==null?"Koneksi atau penyimpanan Supabase gagal":e.getMessage();
                // Do not log passwords, provider keys, session tokens or payloads.
                try{reply=new JSONObject().put("ok",false).put("message",msg.substring(0,Math.min(280,msg.length())));}catch(Exception ignored){return;}
            }
            editorJs("window.__kreasiflowCloudResolve("+JSONObject.quote(requestId)+","+JSONObject.quote(reply.toString())+");");
        });
    }
    private void openProjectZipExport(String id) {
        if(projectStore==null)return;
        main.post(()->{
            try {
                if(!ProjectStore.validId(id))throw new IOException("ID proyek tidak valid");
                pendingProjectBackupId=id;
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/zip");
                intent.putExtra(Intent.EXTRA_TITLE,"KreasiFlow-Project-"+id+".zip");
                startActivityForResult(intent,REQUEST_PROJECT_BACKUP);
            }catch(Exception ex){
                editorJs("window.__kfProjectBackupDone?.(false,"+JSONObject.quote(String.valueOf(ex.getMessage()))+");");
            }
        });
    }
    private void openProjectZipImport() {
        if(projectStore==null)return;
        main.post(()->{
            try {
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/zip");
                intent.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/zip","application/x-zip-compressed","application/octet-stream"});
                startActivityForResult(intent,REQUEST_PROJECT_RESTORE);
            }catch(Exception ex){
                editorJs("window.__kfProjectArchiveImported?.(null,"+JSONObject.quote(String.valueOf(ex.getMessage()))+");");
            }
        });
    }

    private final class NativeBridge {
        @JavascriptInterface public String restoreSavedFlowClip(String projectId,int sceneIndex){
            try{
                if(projectStore==null)return "";
                File saved=projectStore.findSavedClip(projectId,sceneIndex);
                if(saved==null)return "";
                String assetId=String.valueOf(nextTransfer.getAndIncrement());
                synchronized(renderTransfers){renderAssets.put(assetId,saved);}
                return assetId;
            }catch(Exception ex){return "";}
        }
        @JavascriptInterface public void pickAllFlowVideos(String source){pickAllFlowClips(source);}
        @JavascriptInterface public boolean importSelectedFlowVideos(String items){return importSelectedFlowClips(items);}
        @JavascriptInterface public void cancelFlowSelection(){clearFlowSelection();}

        /** Manual updater stays available from Settings, not a permanent toolbar. */
        @JavascriptInterface public void checkAppUpdate(){
            main.post(()->{
                if(BuildConfig.DEBUG){
                    Toast.makeText(MainActivity.this,"Update otomatis hanya tersedia pada APK release.",Toast.LENGTH_LONG).show();
                } else updater.checkManually();
            });
        }

        @JavascriptInterface public boolean saveProjectSnapshot(String id,String json){
            if(projectStore==null)return false;
            try {projectStore.saveProject(id,json);return true;}
            catch(Exception e){Log.w("KreasiFlow","Project autosave failed",e);return false;}
        }
        @JavascriptInterface public String listSavedProjects(){
            if(projectStore==null)return "[]";
            return projectStore.listProjects().toString();
        }
        @JavascriptInterface public String openSavedProject(String id){
            try {
                if(projectStore==null)throw new IOException("Penyimpanan proyek belum tersedia");
                JSONObject value=projectStore.loadProject(id);
                JSONObject media=value.getJSONObject("assets");
                java.util.Iterator<String> names=media.keys();
                synchronized(renderTransfers){
                    while(names.hasNext()){
                        String key=names.next();JSONObject entry=media.getJSONObject(key);
                        String uri=entry.optString("url");
                        String fname=uri.substring(uri.lastIndexOf('/')+1);
                        File f=projectStore.mediaFile(id,fname);
                        if(f==null)continue;
                        String assetId=String.valueOf(nextTransfer.getAndIncrement());
                        renderAssets.put(assetId,f);
                        entry.put("nativeId",assetId);
                    }
                }
                return value.toString();
            }catch(Exception ex){return new JSONObject(java.util.Collections.singletonMap("error",String.valueOf(ex.getMessage()))).toString();}
        }
        @JavascriptInterface public String saveProjectMedia(String id,String key,String sourceId,String mime,String filename){
            try{
                if(projectStore==null)throw new IOException("Penyimpanan proyek tidak tersedia");
                File source=lookupAsset(sourceId);
                if(source==null)throw new IOException("Media belum ada di penyimpanan Android");
                return projectStore.saveAsset(id,key,source,mime,filename).toString();
            }catch(Exception ex){return new JSONObject(java.util.Collections.singletonMap("error",String.valueOf(ex.getMessage()))).toString();}
        }
        @JavascriptInterface public boolean removeProjectMedia(String id,String key){
            try{if(projectStore==null)return false;projectStore.removeAsset(id,key);return true;}
            catch(Exception e){return false;}
        }
        @JavascriptInterface public String duplicateSavedProject(String fromId,String toId){
            try{if(projectStore==null)throw new IOException("Penyimpanan proyek tidak tersedia");return projectStore.duplicate(fromId,toId);}
            catch(Exception e){return "error:"+String.valueOf(e.getMessage());}
        }
        @JavascriptInterface public boolean deleteSavedProject(String id){
            try{if(projectStore==null)return false;projectStore.deleteProject(id);return true;}
            catch(Exception e){return false;}
        }
        @JavascriptInterface public void backupSavedProject(String id){openProjectZipExport(id);}
        @JavascriptInterface public void importSavedProjectZip(){openProjectZipImport();}
        @JavascriptInterface public String cloudAccountStatus(){
            try{return cloudKeyBackup.status().toString();}
            catch(Exception e){return "{}";}
        }
        @JavascriptInterface public void requestCloud(String requestId,String json){
            MainActivity.this.cloudAction(requestId,json);
        }
        @JavascriptInterface public String beginRenderAsset(String kind){
            long max="audio".equals(kind)?150L*1024*1024:"clip".equals(kind)?250L*1024*1024:18L*1024*1024;
            if(!("audio".equals(kind)||"image".equals(kind)||"clip".equals(kind)))return "error";
            try{
                String id=String.valueOf(nextTransfer.getAndIncrement());
                File f=new File(renderFolder(),"asset-"+id+("audio".equals(kind)?".mp3":"clip".equals(kind)?".mp4":".jpg"));
                synchronized(renderTransfers){renderTransfers.put(id,new AssetSession(f,new FileOutputStream(f),max));}
                return id;
            }catch(Exception e){return "error";}
        }
        @JavascriptInterface public boolean appendRenderAsset(String id,String base64){
            if(base64==null||base64.length()>180000)return false;
            synchronized(renderTransfers){
                AssetSession s=renderTransfers.get(id);
                if(s==null)return false;
                try{
                    byte[] bytes=Base64.decode(base64,Base64.DEFAULT);
                    if(s.size+bytes.length>s.max)return false;
                    s.out.write(bytes);s.size+=bytes.length;return true;
                }catch(Exception e){return false;}
            }
        }
        @JavascriptInterface public boolean finishRenderAsset(String id,boolean ok){
            synchronized(renderTransfers){
                AssetSession s=renderTransfers.remove(id);if(s==null)return false;
                try{s.out.close();}catch(Exception e){ok=false;}
                if(ok&&s.size>0){renderAssets.put(id,s.file);return true;}
                s.file.delete();return false;
            }
        }
        @JavascriptInterface public void startMovingMp4Render(String config) {
            if(config==null||config.length()>12000){reportRender(-1,"Data video AI terlalu besar");return;}
            MainActivity.this.startForegroundRender("moving",config);
        }
        @JavascriptInterface public void startMp4Render(String config){
            if(config==null||config.length()>120_000){reportRender(-1,"Data render terlalu besar");return;}
            MainActivity.this.startForegroundRender("slideshow",config);
        }
        @JavascriptInterface public String getBackgroundRenderStatus(){return RenderForegroundService.status(MainActivity.this).toString();}

        // Starts user-initiated native AI work before WebView may be suspended by Android.
        @JavascriptInterface public String startBackgroundAi(String payload){
            try {
                if(payload==null||payload.length()>650000)throw new IOException("Permintaan AI terlalu besar");
                JSONObject cfg=new JSONObject(payload);
                File audio=null;
                if("transcription".equals(cfg.optString("kind",""))){
                    audio=lookupAsset(cfg.optString("audio_asset_id",""));
                    if(audio==null||!audio.isFile())throw new IOException("VO belum berhasil dikirim ke perangkat");
                }
                AiForegroundService.enqueue(MainActivity.this,cfg,audio);
                if(android.os.Build.VERSION.SDK_INT>=33 &&
                    checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED){
                    main.post(()->{
                        try{requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},8462);}
                        catch(Exception ignored){}
                    });
                }
                return new JSONObject().put("ok",true).put("status",AiForegroundService.status(MainActivity.this)).toString();
            }catch(Exception e){
                String message=String.valueOf(e.getMessage());
                return "{\"ok\":false,\"error\":" + JSONObject.quote(message.substring(0,Math.min(220,message.length()))) + "}";
            }
        }
        @JavascriptInterface public String getAiPerformance(){return AiForegroundService.performance(MainActivity.this).toString();}
        @JavascriptInterface public void cancelBackgroundAi(){AiForegroundService.requestCancel(MainActivity.this);}
        @JavascriptInterface public String getBackgroundAiStatus(){return AiForegroundService.status(MainActivity.this).toString();}
        @JavascriptInterface public String getBackgroundAiResult(String jobId){return AiForegroundService.result(MainActivity.this,jobId).toString();}

        @JavascriptInterface public void openRenderedMp4(){main.post(()->MainActivity.this.openLastRender());}
        @JavascriptInterface public void previewGeneratedClip(String id){main.post(()->MainActivity.this.previewClip(id));}
        // Asynchronous native visual check: WebView has no playable URL for imported MP4.
        @JavascriptInterface public void requestFlowClipFingerprint(String requestId,String clipId){
            if(requestId==null||!requestId.matches("fp[0-9]{1,10}"))return;
            try {
                apiPool.execute(()->{
                    JSONObject payload;
                    try{
                        File video=lookupAsset(clipId);
                        if(video==null||!video.isFile())throw new IOException("MP4 tersimpan tidak ditemukan; buka ulang proyek atau impor ulang scene");
                        payload=FlowVideoInspector.fingerprint(video);
                    }catch(Exception e){
                        payload=new JSONObject(java.util.Collections.singletonMap("error",String.valueOf(e.getMessage())));
                    }
                    editorJs("window.__kfNativeFlowFingerprintResult?.("+JSONObject.quote(requestId)+","+payload.toString()+");");
                });
            }catch(Exception rejected){
                JSONObject error=new JSONObject(java.util.Collections.singletonMap("error","Layanan pemeriksa frame tidak tersedia"));
                editorJs("window.__kfNativeFlowFingerprintResult?.("+JSONObject.quote(requestId)+","+error.toString()+");");
            }
        }
        // Optional cover editor: extract one bounded-size JPEG frame, no renderer changes.
        @JavascriptInterface public void requestCoverFrame(String requestId,String clipId){
            if(requestId==null||!requestId.matches("cv[0-9]{1,10}"))return;
            try {apiPool.execute(()->{
                JSONObject result;
                try {
                    File file=lookupAsset(clipId);
                    if(file==null||!file.isFile())throw new IOException("MP4 tidak tersedia");
                    result=new JSONObject().put("data",FlowVideoInspector.coverFrame(file));
                }catch(Exception e){result=new JSONObject(java.util.Collections.singletonMap("error",String.valueOf(e.getMessage())));}
                editorJs("window.__kfCoverFrame?.("+JSONObject.quote(requestId)+","+result.toString()+");");
            });}catch(Exception e){JSONObject err=new JSONObject(java.util.Collections.singletonMap("error","Layanan frame tidak tersedia"));editorJs("window.__kfCoverFrame?.("+JSONObject.quote(requestId)+","+err.toString()+");");}
        }
        @JavascriptInterface public void requestLoopFrame(String requestId,String clipId,boolean end){
            if(requestId==null||!requestId.matches("cv[0-9]{1,10}"))return;
            try {apiPool.execute(()->{
                JSONObject result;
                try {
                    File file=lookupAsset(clipId);
                    if(file==null||!file.isFile())throw new IOException("MP4 tidak tersedia");
                    result=new JSONObject().put("data",FlowVideoInspector.loopFrame(file,end));
                }catch(Exception e){result=new JSONObject(java.util.Collections.singletonMap("error",String.valueOf(e.getMessage())));}
                editorJs("window.__kfCoverFrame?.("+JSONObject.quote(requestId)+","+result.toString()+");");
            });}catch(Exception e){JSONObject err=new JSONObject(java.util.Collections.singletonMap("error","Layanan frame tidak tersedia"));editorJs("window.__kfCoverFrame?.("+JSONObject.quote(requestId)+","+err.toString()+");");}
        }
        @JavascriptInterface public void requestLoopStrip(String requestId,String clipId,boolean end){
            if(requestId==null||!requestId.matches("cv[0-9]{1,10}"))return;
            try{apiPool.execute(()->{JSONObject result;try{File file=lookupAsset(clipId);if(file==null||!file.isFile())throw new IOException("MP4 tidak tersedia");result=new JSONObject().put("data",FlowVideoInspector.loopStrip(file,end));}catch(Exception e){result=new JSONObject(java.util.Collections.singletonMap("error",String.valueOf(e.getMessage())));}editorJs("window.__kfCoverFrame?.("+JSONObject.quote(requestId)+","+result.toString()+");");});}catch(Exception e){JSONObject err=new JSONObject(java.util.Collections.singletonMap("error","Layanan preview tidak tersedia"));editorJs("window.__kfCoverFrame?.("+JSONObject.quote(requestId)+","+err.toString()+");");}
        }
        @JavascriptInterface public String inspectFlowClip(String id){
            try{File f=lookupAsset(id);if(f==null)throw new IOException("Klip belum tersedia; buka ulang proyek dari Riwayat");
                return FlowVideoInspector.inspect(f).toString();}
            catch(Exception e){return new JSONObject(java.util.Collections.singletonMap("error",String.valueOf(e.getMessage()))).toString();}
        }
        @JavascriptInterface public void requestProvider(String id, String provider, String json) {
            MainActivity.this.callProvider(id, provider, json);
        }
        @JavascriptInterface public boolean setProviderKey(String provider, String value) {
            
            return providerSecrets.save(provider, value);
        }
        // Returns only a generic failure reason; no API key is echoed to JavaScript.
        @JavascriptInterface public String providerSaveError() {
            return providerSecrets.lastSaveError();
        }
        @JavascriptInterface public void removeProviderKey(String provider) {
            providerSecrets.delete(provider);
        }
        @JavascriptInterface public String providerStatus() {
            JSONObject status = new JSONObject();
            for (String p : new String[]{"openrouter", "cloudflare", "cloudflare_account", "replicate", "gemini", "elevenlabs", "groq", "nvidia"}) {
                try { status.put(p, providerSecrets.get(p) != null); }
                catch (Exception ignored) { }
            }
            return status.toString();
        }
        // Flow handoff: clipboard + browser launch on a user-initiated tap.
        // No automated controls, cookies, hidden WebView login or accessibility permission.
        @JavascriptInterface public void launchFlowWithPrompt(String prompt){
            if(prompt==null||prompt.length()>5000)return;
            main.post(()->{
                ClipboardManager clipboard=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                if(clipboard!=null)clipboard.setPrimaryClip(ClipData.newPlainText("KreasiFlow Flow Prompt",prompt));
                MainActivity.this.openExternal(FLOW);
            });
        }
        // Copies ONLY verified spoken words before opening the speech editor in Chrome.
        // Never controls Google login, generates speech automatically, or reads browser data.
        @JavascriptInterface public void launchAiStudioWithNarration(String narration){
            if(narration==null || narration.trim().isEmpty() || narration.length()>10000)return;
            main.post(()->{
                ClipboardManager cb=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                if(cb!=null)cb.setPrimaryClip(ClipData.newPlainText("KreasiFlow – Narasi Bersih", narration));
                MainActivity.this.openExternal(STUDIO);
            });
        }
        @JavascriptInterface public void openAi(String url){
            if(isHttps(url))main.post(()->MainActivity.this.openExternal(url));
        }
        @JavascriptInterface public String beginSave(String name,String mime){
            String safe=name==null?"file":name.replaceAll("[^a-zA-Z0-9._-]","_");
            if(safe.length()>100)safe=safe.substring(safe.length()-100);
            if(safe.isEmpty())safe="kreasiflow-file";
            String type=mime==null||mime.length()>120?"application/octet-stream":mime;
            Uri uri=null;
            try{
                ContentValues v=new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME,safe);
                v.put(MediaStore.MediaColumns.MIME_TYPE,type);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/KreasiFlow");
                v.put(MediaStore.MediaColumns.IS_PENDING,1);
                uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
                if(uri==null)return "error";
                OutputStream out=getContentResolver().openOutputStream(uri,"w");
                if(out==null){getContentResolver().delete(uri,null,null);return "error";}
                String id=String.valueOf(nextTransfer.getAndIncrement());
                synchronized(transfers){transfers.put(id,new SaveSession(uri,out));}
                return id;
            }catch(Exception ex){
                if(uri!=null)getContentResolver().delete(uri,null,null);
                return "error";
            }
        }
        @JavascriptInterface public boolean appendSave(String id,String base64){
            if(base64==null||base64.length()>180000)return false;
            synchronized(transfers){
                SaveSession s=transfers.get(id);
                if(s==null)return false;
                try{
                    byte[] chunk=Base64.decode(base64,Base64.DEFAULT);
                    if(s.size+chunk.length>512L*1024*1024)return false;
                    s.out.write(chunk);
                    s.size+=chunk.length;
                    return true;
                }catch(Exception ex){return false;}
            }
        }
        @JavascriptInterface public void finishSave(String id,boolean ok){
            SaveSession s;
            synchronized(transfers){s=transfers.remove(id);}
            if(s==null)return;
            try{s.out.flush();s.out.close();}catch(IOException ex){ok=false;}
            try{
                if(ok){
                    ContentValues v=new ContentValues();v.put(MediaStore.MediaColumns.IS_PENDING,0);
                    getContentResolver().update(s.uri,v,null,null);
                    main.post(()->Toast.makeText(MainActivity.this,"Tersimpan ke Download/KreasiFlow",Toast.LENGTH_LONG).show());
                }else{
                    getContentResolver().delete(s.uri,null,null);
                    main.post(()->Toast.makeText(MainActivity.this,"Gagal menyimpan file",Toast.LENGTH_LONG).show());
                }
            }catch(Exception ignored){}
        }
    }
}
