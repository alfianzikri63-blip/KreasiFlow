package id.kreasiflow.studio;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicBoolean;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;


/**
 * KreasiFlow Studio — satu layar kerja. Browser eksternal dibuka saat pengguna
 * memilih AI Studio, Flow, Gemini, atau link AI dari halaman lokal.
 * Tidak ada panel split dan tidak ada login akun Google di WebView tertanam.
 * Identitas paket dan updater GitHub Releases tetap sama seperti versi 5.0.1.
 */
public final class MainActivity extends Activity {
    private static final String LOCAL = "https://appassets.androidplatform.net/assets/index.html";
    private static final String STUDIO = "https://aistudio.google.com/generate-speech";
    private static final String FLOW = "https://flow.google.com/";
    private static final String GEMINI = "https://gemini.google.com/app";
    private static final String API_KEYS = "https://aistudio.google.com/api-keys";
    private static final int PICK_FILE = 731;
    private static final int BG = Color.rgb(6, 20, 14);
    private static final int PANEL = Color.rgb(11, 37, 25);
    private static final int GREEN = Color.rgb(121, 235, 176);
    private static final int WHITE = Color.rgb(228, 249, 235);

    private UpdateController updater;
    private ProviderSecrets providerSecrets;
    private WebView topWeb;
    private ValueCallback<Uri[]> uploadCallback;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<String, SaveSession> transfers = new HashMap<>();
    private final AtomicLong nextTransfer = new AtomicLong(1);
    private final ExecutorService apiPool = Executors.newFixedThreadPool(2);
    private final ExecutorService renderPool = Executors.newSingleThreadExecutor();
    private final AtomicBoolean renderBusy = new AtomicBoolean(false);
    private final Map<String, AssetSession> renderTransfers = new HashMap<>();
    private final Map<String, File> renderAssets = new HashMap<>();
    private Uri lastRenderUri;


    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        updater = new UpdateController(this);
        providerSecrets = new ProviderSecrets(this);
        try {
            buildLayout();
            configureWebView();
            Bundle editorState=savedInstanceState == null ? null : savedInstanceState.getBundle("editor");
            if(editorState==null || topWeb.restoreState(editorState)==null) topWeb.loadUrl(LOCAL);
        } catch (RuntimeException | LinkageError ex) {
            Log.e("KreasiFlow","Unable to initialize editor",ex);
            showRecoveryScreen(ex);
            return;
        }
        try { updater.start(); }
        catch(RuntimeException ex) {
            Log.e("KreasiFlow","Updater startup failed; editor remains available",ex);
            getSharedPreferences("startup_diagnostics",MODE_PRIVATE).edit()
                .putString("last_update_error",ex.toString()).apply();
        }
        if("id.kreasiflow.studio.SHOW_UPDATE".equals(getIntent().getAction()))
            updater.onNotificationTap();
    }

    private void buildLayout(){
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        setContentView(root);

        LinearLayout toolbar = bar(45);
        TextView title = label("✦  KREASIFLOW",15,GREEN,true);
        toolbar.addView(title,new LinearLayout.LayoutParams(0,-1,1));
        toolbar.addView(button("↻ Update",()->updater.checkManually()));
        root.addView(toolbar,new LinearLayout.LayoutParams(-1,dp(45)));

        HorizontalScrollView shortcuts=new HorizontalScrollView(this);
        shortcuts.setHorizontalScrollBarEnabled(false);
        shortcuts.setFillViewport(true);
        shortcuts.setBackgroundColor(PANEL);
        LinearLayout links=new LinearLayout(this);
        links.setGravity(Gravity.CENTER_VERTICAL);
        links.addView(button("✍ OpenRouter",()->openExternal("https://openrouter.ai/")));
        links.addView(button("🖼 fal.ai",()->openExternal("https://fal.ai/")));
        links.addView(button("🎙 ElevenLabs",()->openExternal("https://elevenlabs.io/")));
        links.addView(button("🎬 Flow",()->openExternal(FLOW)));
        links.addView(button("🔑 API Keys",()->{
            if (topWeb != null) topWeb.evaluateJavascript(
                "document.querySelector('[data-action=\"settings\"]')?.click();", null);
        }));
        shortcuts.addView(links);
        root.addView(shortcuts,new LinearLayout.LayoutParams(-1,dp(42)));

        FrameLayout editor=new FrameLayout(this);
        editor.setBackgroundColor(BG);
        root.addView(editor,new LinearLayout.LayoutParams(-1,0,1));
        topWeb=new WebView(this);
        editor.addView(topWeb,new FrameLayout.LayoutParams(-1,-1));
    }

    private void configureWebView(){
        WebSettings s=topWeb.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSafeBrowsingEnabled(true);
        s.setSupportZoom(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        topWeb.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> cb,FileChooserParams params){
                if(uploadCallback!=null)uploadCallback.onReceiveValue(null);
                uploadCallback=cb;
                try{startActivityForResult(params.createIntent(),PICK_FILE);return true;}
                catch(Exception ex){cb.onReceiveValue(null);uploadCallback=null;return true;}
            }
        });
        // Bridge hanya dipasang pada editor aset lokal. Jangan menavigasikan
        // WebView ini ke situs eksternal, termasuk login Google.
        topWeb.addJavascriptInterface(new NativeBridge(),"KreasiFlowNative");
        WebViewAssetLoader assets=new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
        topWeb.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request){
                return assets.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){
                String url=request.getUrl().toString();
                if(url.startsWith("https://appassets.androidplatform.net/assets/"))return false;
                if(isHttps(url))runOnUiThread(()->openExternal(url));
                return true;
            }
        });
    }

    private boolean isHttps(String value){
        try{
            Uri uri=Uri.parse(value);
            return "https".equalsIgnoreCase(uri.getScheme())&&uri.getHost()!=null;
        }catch(Exception ex){return false;}
    }

    /** Preferred Chrome app, fallback to Android's default browser. */
    void openExternal(String url){
        if(!isHttps(url)){
            Toast.makeText(this,"Link AI harus HTTPS",Toast.LENGTH_SHORT).show();
            return;
        }
        Uri uri=Uri.parse(url);
        Intent chrome=new Intent(Intent.ACTION_VIEW,uri);
        chrome.addCategory(Intent.CATEGORY_BROWSABLE);
        chrome.setPackage("com.android.chrome");
        try{startActivity(chrome);return;}
        catch(ActivityNotFoundException ignored){/* Chrome not installed or disabled. */}
        catch(RuntimeException ex){Log.w("KreasiFlow","Chrome launch failed; trying default browser",ex);}
        try{
            Intent fallback=new Intent(Intent.ACTION_VIEW,uri);
            fallback.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(fallback);
        }catch(Exception ex){
            Toast.makeText(this,"Tidak ada browser untuk membuka tautan AI",Toast.LENGTH_LONG).show();
        }
    }

    private void showRecoveryScreen(Throwable cause){
        LinearLayout panel=new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(20),dp(32),dp(20),dp(24));
        panel.setBackgroundColor(BG);
        panel.addView(label("KreasiFlow Studio • Mode Pemulihan",19,GREEN,true));
        TextView info=label("Editor tidak dapat dimuat. Perbarui Android System WebView atau Chrome. Detail: "+
                cause.getClass().getSimpleName()+" — "+String.valueOf(cause.getMessage()),13,WHITE,false);
        info.setPadding(0,dp(20),0,dp(20));
        panel.addView(info);
        panel.addView(button("Buka AI Studio",()->openExternal(STUDIO)));
        panel.addView(button("Buka Flow",()->openExternal(FLOW)));
        panel.addView(button("Rilis KreasiFlow",()->openExternal("https://github.com/alfianzikri63-blip/KreasiFlow/releases")));
        setContentView(panel);
    }

    private LinearLayout bar(int dpHeight){
        LinearLayout bar=new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(7),0,dp(7),0);
        bar.setMinimumHeight(dp(dpHeight));
        bar.setBackgroundColor(PANEL);
        return bar;
    }
    private TextView label(String value,int sp,int color,boolean bold){
        TextView label=new TextView(this);
        label.setText(value);label.setTextColor(color);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP,sp);
        label.setGravity(Gravity.CENTER_VERTICAL);
        if(bold)label.setTypeface(null,android.graphics.Typeface.BOLD);
        return label;
    }
    private TextView button(String value,Runnable onClick){
        TextView label=label(value,11,WHITE,true);
        label.setPadding(dp(12),0,dp(12),0);
        label.setGravity(Gravity.CENTER);
        label.setMinHeight(dp(40));
        label.setOnClickListener(v->onClick.run());
        label.setContentDescription(value);
        return label;
    }
    private int dp(float value){return (int)(value*getResources().getDisplayMetrics().density+.5f);}

    @Override protected void onResume(){
        super.onResume();
        if(updater!=null)try{updater.onResume();}
        catch(RuntimeException ex){Log.e("KreasiFlow","Update resume issue",ex);}
    }
    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        setIntent(intent);
        if(updater!=null && "id.kreasiflow.studio.SHOW_UPDATE".equals(intent.getAction()))
            updater.onNotificationTap();
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_FILE && uploadCallback!=null){
            uploadCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode,data));
            uploadCallback=null;
        }
    }
    @Override protected void onSaveInstanceState(Bundle out){
        if(topWeb!=null){Bundle state=new Bundle();topWeb.saveState(state);out.putBundle("editor",state);}
        super.onSaveInstanceState(out);
    }
    @Override public void onBackPressed(){
        if(topWeb!=null && topWeb.canGoBack())topWeb.goBack();
        else new AlertDialog.Builder(this).setMessage("Tutup KreasiFlow Studio?")
                .setNegativeButton("Batal",(d,w)->{})
                .setPositiveButton("Keluar",(d,w)->finish()).show();
    }
    @Override protected void onDestroy(){
        if(updater!=null)updater.stop();
        if(uploadCallback!=null){uploadCallback.onReceiveValue(null);uploadCallback=null;}
        synchronized(transfers){
            for(SaveSession session:transfers.values()){
                try{session.out.close();}catch(Exception ignored){}
                getContentResolver().delete(session.uri,null,null);
            }
            transfers.clear();
        }
        synchronized(renderTransfers){
            for(AssetSession session:renderTransfers.values()){
                try{session.out.close();}catch(Exception ignored){}
                session.file.delete();
            }
            renderTransfers.clear();
            for(File f:renderAssets.values())f.delete();
            renderAssets.clear();
        }
        renderPool.shutdownNow();
        apiPool.shutdownNow();
        if(topWeb!=null)topWeb.destroy();
        super.onDestroy();
    }
    private static final class SaveSession {
        final Uri uri;
        final OutputStream out;
        long size;
        SaveSession(Uri u,OutputStream o){uri=u;out=o;}
    }
    private void completeGemini(String requestId,String response,String error){
        main.post(()->{
            if(topWeb == null || topWeb.getUrl() == null || !topWeb.getUrl().startsWith(LOCAL))return;
            String id=JSONObject.quote(requestId);
            if(error!=null){
                topWeb.evaluateJavascript("window.__kreasiflowApiResolve("+id+",\"\","+JSONObject.quote(error)+");",null);
                return;
            }
            // Small chunks avoid oversized evaluateJavascript/Binder messages for images and WAV.
            topWeb.evaluateJavascript("window.__kreasiflowApiBegin("+id+");",null);
            String content=response==null?"":response;
            for(int offset=0;offset<content.length();offset+=16000){
                String part=content.substring(offset,Math.min(offset+16000,content.length()));
                topWeb.evaluateJavascript("window.__kreasiflowApiChunk("+id+","+JSONObject.quote(part)+");",null);
            }
            topWeb.evaluateJavascript("window.__kreasiflowApiEnd("+id+");",null);
        });
    }
    // Provider network calls run off the main/UI thread. Keys stay in encrypted
    // AndroidKeyStore-backed storage, never returned to WebView JavaScript.
    private void callProvider(String id, String provider, String json) {
        if (id == null || id.length() > 96 || !id.matches("[a-zA-Z0-9_-]+")) return;
        if (json == null || json.length() > 95000) {
            completeGemini(id, null, "Payload terlalu besar"); return;
        }
        if (!("openrouter".equals(provider) || "fal".equals(provider) || "elevenlabs".equals(provider))) {
            completeGemini(id, null, "Provider tidak tersedia"); return;
        }
        apiPool.execute(() -> {
            try {
                String credential = providerSecrets.get(provider);
                String result = MultiProviderApi.execute(provider, new JSONObject(json), credential);
                completeGemini(id, result, null);
            } catch (Exception ex) {
                Log.w("KreasiFlow", "Provider request failed: " + provider + " (no credentials logged)");
                completeGemini(id, null, ex.getMessage() == null ? "Layanan AI gagal" : ex.getMessage());
            }
        });
    }
    private static final class AssetSession {
        final File file;
        final OutputStream out;
        long size;
        final long max;
        AssetSession(File f, OutputStream o, long max){file=f;out=o;this.max=max;}
    }
    private File renderFolder(){
        File folder=new File(getCacheDir(),"render-assets");
        if(!folder.exists())folder.mkdirs();
        return folder;
    }
    private void editorJs(String javascript){
        main.post(()->{
            if(topWeb!=null&&topWeb.getUrl()!=null&&topWeb.getUrl().startsWith(LOCAL))
                topWeb.evaluateJavascript(javascript,null);
        });
    }
    private void reportRender(int pct,String msg){
        editorJs("window.__kreasiflowRenderProgress("+pct+","+JSONObject.quote(msg)+");");
    }
    private Uri publishMp4(File video) throws IOException {
        Uri uri=null;
        try{
            ContentValues values=new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME,"KreasiFlow-"+System.currentTimeMillis()+".mp4");
            values.put(MediaStore.MediaColumns.MIME_TYPE,"video/mp4");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/KreasiFlow");
            values.put(MediaStore.MediaColumns.IS_PENDING,1);
            uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
            if(uri==null)throw new IOException("Android tidak memberi lokasi unduhan");
            try(InputStream input=new FileInputStream(video);OutputStream output=getContentResolver().openOutputStream(uri,"w")){
                if(output==null)throw new IOException("Folder unduhan tidak dapat ditulis");
                byte[] block=new byte[65536];int n;
                while((n=input.read(block))!=-1){
                    if(Thread.currentThread().isInterrupted())throw new IOException("Render dibatalkan");
                    output.write(block,0,n);
                }
            }
            ContentValues ready=new ContentValues();ready.put(MediaStore.MediaColumns.IS_PENDING,0);
            getContentResolver().update(uri,ready,null,null);
            return uri;
        }catch(Exception e){
            if(uri!=null)getContentResolver().delete(uri,null,null);
            if(e instanceof IOException)throw (IOException)e;
            throw new IOException("Gagal menyimpan MP4: "+e.getMessage(),e);
        }
    }
    private void openLastRender(){
        if(lastRenderUri==null){Toast.makeText(this,"Belum ada MP4 selesai",Toast.LENGTH_SHORT).show();return;}
        Intent intent=new Intent(Intent.ACTION_VIEW).setDataAndType(lastRenderUri,"video/mp4");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try{startActivity(intent);}catch(Exception e){
            Toast.makeText(this,"Video tersimpan di Download/KreasiFlow. Buka lewat File Manager.",Toast.LENGTH_LONG).show();
        }
    }
    private File lookupAsset(String id){
        if(id==null||!id.matches("[0-9]{1,12}"))return null;
        synchronized(renderTransfers){return renderAssets.get(id);}
    }
    private void runNativeRender(String json){
        if(!renderBusy.compareAndSet(false,true)){
            reportRender(-1,"Render sebelumnya masih berjalan");return;
        }
        renderPool.execute(()->{
            File work=new File(getCacheDir(),"native-mp4-"+System.nanoTime());
            File finished=new File(work,"final.mp4");
            List<File> used=new ArrayList<>();
            try{
                if(!work.mkdirs())throw new IOException("Tidak bisa menyiapkan ruang sementara");
                JSONObject args=new JSONObject(json);
                NativeVideoRenderer.Config cfg=new NativeVideoRenderer.Config();
                int size=Math.max(360,Math.min(720,args.optInt("resolution",540)));
                boolean landscape=args.optString("ratio","9:16").startsWith("16:9");
                cfg.width=landscape?(int)Math.round(size*16.0/9):size;
                cfg.height=landscape?size:(int)Math.round(size*16.0/9);
                // Hardware encoders accept even dimensions. Sizes used here are multiples of 2.
                cfg.width-=cfg.width%2;cfg.height-=cfg.height%2;
                cfg.fps=Math.max(12,Math.min(30,args.optInt("fps",24)));
                cfg.seconds=Math.max(2,Math.min(600,args.optDouble("duration",60)));
                cfg.captions=args.optBoolean("captions",true);cfg.fade=args.optBoolean("fade",true);
                cfg.subtitlePosition=args.optString("subtitlePosition","Bawah");
                cfg.watermark=args.optString("watermark","").substring(0,Math.min(80,args.optString("watermark","").length()));
                cfg.effect=args.optString("effect","Smooth zoom");
                try{cfg.subtitleColor=Color.parseColor(args.optString("captionColor","#ffffff"));}
                catch(Exception e){cfg.subtitleColor=Color.WHITE;}
                cfg.narration=lookupAsset(args.optString("audioId",""));
                if(cfg.narration!=null)used.add(cfg.narration);
                cfg.scenes=new ArrayList<>();
                org.json.JSONArray scenes=args.optJSONArray("scenes");
                if(scenes==null||scenes.length()==0)throw new IOException("Scene kosong; buat storyboard dulu");
                if(scenes.length()>36)throw new IOException("Maksimal 36 scene");
                for(int i=0;i<scenes.length();i++){
                    JSONObject sc=scenes.getJSONObject(i);
                    File asset=lookupAsset(sc.optString("imageId",""));
                    if(asset!=null)used.add(asset);
                    cfg.scenes.add(new NativeVideoRenderer.Scene(asset,sc.optString("voice",""),sc.optString("name","Adegan "+(i+1))));
                }
                NativeVideoRenderer.render(cfg,finished,work,(pct,msg)->reportRender(pct,msg));
                Uri uri=publishMp4(finished);lastRenderUri=uri;
                editorJs("window.__kreasiflowRenderDone(true,"+JSONObject.quote("MP4 tersimpan di Download/KreasiFlow")+");");
            }catch(Exception e){
                Log.e("KreasiFlowRender","Native MP4 export failed",e);
                String msg=e.getMessage()==null?"Render gagal; coba resolusi 360p":e.getMessage();
                editorJs("window.__kreasiflowRenderDone(false,"+JSONObject.quote(msg)+");");
            }finally{
                for(File f:used){
                    synchronized(renderTransfers){renderAssets.values().remove(f);}
                    f.delete();
                }
                File[] tmp=work.listFiles();if(tmp!=null)for(File f:tmp)f.delete();work.delete();
                renderBusy.set(false);
            }
        });
    }
    private final class NativeBridge {
        @JavascriptInterface public String beginRenderAsset(String kind){
            long max="audio".equals(kind)?80L*1024*1024:18L*1024*1024;
            if(!("audio".equals(kind)||"image".equals(kind)))return "error";
            try{
                String id=String.valueOf(nextTransfer.getAndIncrement());
                File f=new File(renderFolder(),"asset-"+id+("audio".equals(kind)?".mp3":".jpg"));
                synchronized(renderTransfers){renderTransfers.put(id,new AssetSession(f,new FileOutputStream(f),max));}
                return id;
            }catch(Exception e){return "error";}
        }
        @JavascriptInterface public boolean appendRenderAsset(String id,String base64){
            if(base64==null||base64.length()>180000)return false;
            synchronized(renderTransfers){
                AssetSession s=renderTransfers.get(id);
                if(s==null)return false;
                try{
                    byte[] bytes=Base64.decode(base64,Base64.DEFAULT);
                    if(s.size+bytes.length>s.max)return false;
                    s.out.write(bytes);s.size+=bytes.length;return true;
                }catch(Exception e){return false;}
            }
        }
        @JavascriptInterface public boolean finishRenderAsset(String id,boolean ok){
            synchronized(renderTransfers){
                AssetSession s=renderTransfers.remove(id);if(s==null)return false;
                try{s.out.close();}catch(Exception e){ok=false;}
                if(ok&&s.size>0){renderAssets.put(id,s.file);return true;}
                s.file.delete();return false;
            }
        }
        @JavascriptInterface public void startMp4Render(String config){
            if(config==null||config.length()>120_000){reportRender(-1,"Data render terlalu besar");return;}
            MainActivity.this.runNativeRender(config);
        }
        @JavascriptInterface public void openRenderedMp4(){main.post(()->MainActivity.this.openLastRender());}
        @JavascriptInterface public void requestProvider(String id, String provider, String json) {
            MainActivity.this.callProvider(id, provider, json);
        }
        @JavascriptInterface public boolean setProviderKey(String provider, String value) {
            return providerSecrets.save(provider, value);
        }
        // Returns only a generic failure reason; no API key is echoed to JavaScript.
        @JavascriptInterface public String providerSaveError() {
            return providerSecrets.lastSaveError();
        }
        @JavascriptInterface public void removeProviderKey(String provider) {
            providerSecrets.delete(provider);
        }
        @JavascriptInterface public String providerStatus() {
            JSONObject status = new JSONObject();
            for (String p : new String[]{"openrouter", "fal", "elevenlabs"}) {
                try { status.put(p, providerSecrets.get(p) != null); }
                catch (Exception ignored) { }
            }
            return status.toString();
        }
        @JavascriptInterface public void openAi(String url){
            if(isHttps(url))main.post(()->MainActivity.this.openExternal(url));
        }
        @JavascriptInterface public String beginSave(String name,String mime){
            String safe=name==null?"file":name.replaceAll("[^a-zA-Z0-9._-]","_");
            if(safe.length()>100)safe=safe.substring(safe.length()-100);
            if(safe.isEmpty())safe="kreasiflow-file";
            String type=mime==null||mime.length()>120?"application/octet-stream":mime;
            Uri uri=null;
            try{
                ContentValues v=new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME,safe);
                v.put(MediaStore.MediaColumns.MIME_TYPE,type);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/KreasiFlow");
                v.put(MediaStore.MediaColumns.IS_PENDING,1);
                uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
                if(uri==null)return "error";
                OutputStream out=getContentResolver().openOutputStream(uri,"w");
                if(out==null){getContentResolver().delete(uri,null,null);return "error";}
                String id=String.valueOf(nextTransfer.getAndIncrement());
                synchronized(transfers){transfers.put(id,new SaveSession(uri,out));}
                return id;
            }catch(Exception ex){
                if(uri!=null)getContentResolver().delete(uri,null,null);
                return "error";
            }
        }
        @JavascriptInterface public boolean appendSave(String id,String base64){
            if(base64==null||base64.length()>180000)return false;
            synchronized(transfers){
                SaveSession s=transfers.get(id);
                if(s==null)return false;
                try{
                    byte[] chunk=Base64.decode(base64,Base64.DEFAULT);
                    if(s.size+chunk.length>512L*1024*1024)return false;
                    s.out.write(chunk);
                    s.size+=chunk.length;
                    return true;
                }catch(Exception ex){return false;}
            }
        }
        @JavascriptInterface public void finishSave(String id,boolean ok){
            SaveSession s;
            synchronized(transfers){s=transfers.remove(id);}
            if(s==null)return;
            try{s.out.flush();s.out.close();}catch(IOException ex){ok=false;}
            try{
                if(ok){
                    ContentValues v=new ContentValues();v.put(MediaStore.MediaColumns.IS_PENDING,0);
                    getContentResolver().update(s.uri,v,null,null);
                    main.post(()->Toast.makeText(MainActivity.this,"Tersimpan ke Download/KreasiFlow",Toast.LENGTH_LONG).show());
                }else{
                    getContentResolver().delete(s.uri,null,null);
                    main.post(()->Toast.makeText(MainActivity.this,"Gagal menyimpan file",Toast.LENGTH_LONG).show());
                }
            }catch(Exception ignored){}
        }
    }
}
