package id.kreasiflow.studio;

import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Allowlisted AI endpoints only; never allow arbitrary request URL from the WebView. */
final class MultiProviderApi {
    private static final int MAX_IMAGE = 14 * 1024 * 1024;
    private static final int MAX_JSON = 2 * 1024 * 1024;
    private static final int MAX_IMAGE_JSON = 20 * 1024 * 1024;

    static String execute(String provider, JSONObject input, String key, String cloudflareAccountId) throws Exception {
        if (key == null || key.isEmpty()) throw new IOException("API key untuk " + provider + " belum diatur. Buka Pengaturan AI.");
        switch (provider) {
            case "openrouter": return text(input, key);
            case "groq": return groqText(input,key);
            case "cloudflare": return cloudflareImage(input, key, cloudflareAccountId);
            default: throw new IOException("Provider tidak didukung");
        }
    }

    private static String groqText(JSONObject input,String key)throws Exception {
        String prompt=input.optString("prompt", "");
        if(prompt.isEmpty()||prompt.length()>85000)throw new IOException("Prompt Groq tidak valid");
        int max=Math.max(128,Math.min(8192,input.optInt("max_tokens",3500)));
        // GPT-OSS supports low, not none; allow room for reasoning as well as visible output.
        JSONObject body=new JSONObject().put("model","openai/gpt-oss-20b")
            .put("stream",false).put("reasoning_effort","low")
            .put("max_completion_tokens",Math.min(12288,max+1024))
            .put("messages",new JSONArray().put(new JSONObject().put("role","user").put("content",prompt)));
        if(input.optBoolean("storyboard_job",false)||input.optBoolean("title_fast",false))body.put("response_format",new JSONObject().put("type","json_object"));
        HttpURLConnection c=connect("https://api.groq.com/openai/v1/chat/completions","Bearer "+key,"Authorization");
        c.setConnectTimeout(7000);c.setReadTimeout(input.optBoolean("title_fast",false)?12000:max>4000?60000:30000);
        String raw=new String(send(c,body.toString(),MAX_JSON),StandardCharsets.UTF_8);
        JSONArray choices=new JSONObject(raw).optJSONArray("choices");JSONObject choice=choices==null?null:choices.optJSONObject(0);
        if(choice==null||"length".equals(choice.optString("finish_reason")))throw new IOException("Groq respons kosong atau terpotong: batas token");
        return raw;
    }
    private static String text(JSONObject input, String key) throws Exception {
        // Free diagnostic: validates the same stored credential without a
        // model call. The token never crosses into JavaScript.
        if (input.optBoolean("verify_key", false)) return verifyOpenRouterKey(key);
        String model = input.optString("model", "openrouter/free");
        boolean scriptFast=input.optBoolean("script_fast",false);
        if(scriptFast&&model.equals("openrouter/free"))model="google/gemma-4-26b-a4b-it:free";
        if (!model.matches("[a-zA-Z0-9_./:-]{2,120}")) throw new IOException("Model OpenRouter tidak valid");
        String prompt = input.optString("prompt", "");
        if (prompt.isEmpty() || prompt.length() > 85000) throw new IOException("Prompt naskah tidak valid/terlalu panjang");
        JSONObject body = new JSONObject();
        body.put("model", model);
        body.put("stream", false);
        int maxTokens = input.optInt("max_tokens", 0);
        if (maxTokens >= 128 && maxTokens <= 8192) body.put("max_completion_tokens", maxTokens);
        if (input.optBoolean("storyboard_fast",false) && (model.equals("google/gemma-4-26b-a4b-it:free") || model.equals("inclusionai/ling-3.2-flash:free"))) {
            // Supported by Gemma 4 / Ling 3.2 Flash free text models.
            // Avoid spending the whole response token budget on invisible reasoning.
            body.put("reasoning",new JSONObject().put("effort","none"));
            body.put("response_format",new JSONObject().put("type","json_object"));
            body.put("temperature",0.35);
        }
        if(scriptFast){
            body.put("temperature",0.65);
            if(model.equals("google/gemma-4-26b-a4b-it:free")||model.equals("google/gemma-4-31b-it:free")||model.equals("inclusionai/ling-3.2-flash:free"))
                body.put("reasoning",new JSONObject().put("effort","none"));
        }
        body.put("messages", new JSONArray().put(new JSONObject().put("role", "user").put("content", prompt)));
        HttpURLConnection connection = connect("https://openrouter.ai/api/v1/chat/completions", "Bearer " + key, "Authorization");
        connection.setRequestProperty("X-Title", "KreasiFlow Studio");
        if (input.optBoolean("title_fast",false)) { connection.setConnectTimeout(5000); connection.setReadTimeout(12000); }
        else if(scriptFast){connection.setConnectTimeout(7000);connection.setReadTimeout(maxTokens>4000?60000:maxTokens>2500?40000:25000);}
        else if (input.optBoolean("storyboard_job",false)) connection.setReadTimeout(60000);
        else if(input.optBoolean("fast_text",false))connection.setReadTimeout(input.optInt("max_tokens",768)>2000?120000:60000);
        try {
            String response=new String(send(connection, body.toString(), MAX_JSON), StandardCharsets.UTF_8);
            if(scriptFast){
                JSONArray choices=new JSONObject(response).optJSONArray("choices");
                JSONObject choice=choices==null?null:choices.optJSONObject(0);
                if(choice!=null&&"length".equals(choice.optString("finish_reason")))throw new IOException("Naskah OpenRouter terpotong atau kosong: batas token output habis. Coba model teks non-reasoning.");
            }
            return response;
        } catch (java.net.SocketTimeoutException timeout) {
            throw new IOException(scriptFast?"OpenRouter naskah melewati batas baca mode cepat.":input.optBoolean("title_fast",false)?"OpenRouter judul melewati batas baca 12 detik.":input.optBoolean("storyboard_job",false)
                ?"OpenRouter storyboard tidak merespons dalam batas baca 60 detik; model cadangan akan dicoba jika tersedia."
                :"OpenRouter timeout jaringan (batas baca 180 detik). Pilih model yang responsif atau beralih ke Gemini.", timeout);
        }
    }

    private static String verifyOpenRouterKey(String key) throws Exception {
        HttpURLConnection connection = (HttpURLConnection)
                new URL("https://openrouter.ai/api/v1/key").openConnection();
        connection.setInstanceFollowRedirects(false);
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(20000);
        connection.setReadTimeout(25000);
        connection.setRequestProperty("Authorization", "Bearer " + key.trim());
        connection.setRequestProperty("Accept", "application/json");
        try {
            int status = connection.getResponseCode();
            if (status != 200) {
                if (status == 401) throw new IOException(
                        "OpenRouter menolak autentikasi (401). Salin ulang hanya nilai API key sk-or- dari dashboard.");
                throw new IOException("Uji koneksi OpenRouter gagal (HTTP " + status + ")");
            }
            // Read just enough to validate the API response, never echo key
            // details or billing data into WebView JavaScript.
            JSONObject response = new JSONObject(new String(
                    readLimited(connection.getInputStream(), 16000), StandardCharsets.UTF_8));
            if (response.optJSONObject("data") == null) throw new IOException("Respons uji API key tidak dikenal");
            return new JSONObject().put("ok", true).toString();
        } finally { connection.disconnect(); }
    }

    /** Workers AI FLUX.1 Schnell free-tier-capable text-to-image REST endpoint.
     *  Cloudflare returns result.image as base64 JPEG (not a fal.ai media URL).
     *  The model does not promise native portrait generation; renderer covers/crops.
     */
    private static String cloudflareImage(JSONObject input, String key, String accountId) throws Exception {
        if (accountId == null || !accountId.matches("(?i)[0-9a-f]{32}"))
            throw new IOException("Cloudflare Account ID belum diisi atau tidak valid (32 karakter). Buka pengaturan AI.");
        String prompt = input.optString("prompt", "").trim();
        if (prompt.isEmpty()) throw new IOException("Prompt gambar belum diisi");
        // Cloudflare FLUX Schnell accepts up to 2048 characters, no arbitrary URLs.
        if (prompt.length() > 2048) prompt = prompt.substring(0, 2048);
        int steps = input.optInt("steps", 4);
        if (steps < 1 || steps > 8) steps = 4;
        JSONObject body = new JSONObject().put("prompt", prompt).put("steps", steps);
        String url = "https://api.cloudflare.com/client/v4/accounts/" + accountId.toLowerCase(java.util.Locale.ROOT)
                + "/ai/run/@cf/black-forest-labs/flux-1-schnell";
        HttpURLConnection c = connect(url, "Bearer " + key.trim(), "Authorization");
        JSONObject envelope = new JSONObject(new String(send(c, body.toString(), MAX_IMAGE_JSON), StandardCharsets.UTF_8));
        if (!envelope.optBoolean("success", false)) {
            JSONArray errs = envelope.optJSONArray("errors");
            String reason = errs != null && errs.length() > 0 ? errs.optJSONObject(0).optString("message", "") : "API belum mengembalikan hasil";
            throw new IOException("Cloudflare Workers AI: " + shorten(reason));
        }
        JSONObject result = envelope.optJSONObject("result");
        String image64 = result == null ? "" : result.optString("image", "");
        if (image64.isEmpty()) throw new IOException("Cloudflare tidak mengembalikan gambar. Periksa kuota dan izin Workers AI.");
        byte[] bytes;
        try { bytes = Base64.decode(image64, Base64.DEFAULT); }
        catch (IllegalArgumentException e) { throw new IOException("Data gambar Cloudflare tidak valid", e); }
        if (bytes.length < 128 || bytes.length > MAX_IMAGE) throw new IOException("Ukuran gambar Cloudflare tidak valid");
        // Check image magic bytes before trusting the provider response MIME.
        String mime;
        if ((bytes[0] & 255) == 0xFF && (bytes[1] & 255) == 0xD8) mime = "image/jpeg";
        else if ((bytes[0] & 255) == 0x89 && bytes[1] == 0x50 && bytes[2] == 0x4E && bytes[3] == 0x47) mime = "image/png";
        else if (bytes[0]=='R' && bytes[1]=='I' && bytes[2]=='F' && bytes[3]=='F' &&
                 bytes[8]=='W' && bytes[9]=='E' && bytes[10]=='B' && bytes[11]=='P') mime = "image/webp";
        else throw new IOException("Format gambar Cloudflare tidak dikenal");
        return new JSONObject().put("mime_type", mime)
                .put("image_base64", Base64.encodeToString(bytes, Base64.NO_WRAP)).toString();
    }

    private static HttpURLConnection connect(String url, String key, String header) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setInstanceFollowRedirects(false);
        c.setConnectTimeout(20000);
        c.setReadTimeout(180000);
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setRequestProperty(header, key);
        c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        c.setRequestProperty("Accept", "application/json, audio/mpeg, image/png, image/jpeg");
        return c;
    }

    private static byte[] send(HttpURLConnection c, String payload, int limit) throws IOException {
        try {
            byte[] body = payload.getBytes(StandardCharsets.UTF_8);
            try (OutputStream out = c.getOutputStream()) { out.write(body); }
            int status = c.getResponseCode();
            if (status >= 300 && status < 400) throw new IOException("Provider mengalihkan URL API. Permintaan dibatalkan demi keamanan.");
            if (status < 200 || status >= 300) {
                InputStream error = c.getErrorStream();
                String message = error == null ? "" : new String(readLimited(error, 20000), StandardCharsets.UTF_8);
                try {
                    JSONObject j = new JSONObject(message);
                    JSONObject e = j.optJSONObject("error");
                    if (e != null) message = e.optString("message", message);
                    else if (j.optString("detail", "").length() > 0) message = j.optString("detail");
                } catch (JSONException ignored) { }
                throw new IOException("HTTP " + status + " (" + (status == 401 ? "Autentikasi ditolak; " : status == 402 ? "saldo/kredit kurang; " : status == 429 ? "kuota habis; " : "") + shorten(message) + ")");
            }
            InputStream stream = c.getInputStream();
            if (stream == null) throw new IOException("Respons kosong dari provider");
            return readLimited(stream, limit);
        } finally { c.disconnect(); }
    }

    private static byte[] readLimited(InputStream input, int limit) throws IOException {
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) != -1) {
                if (out.size() + n > limit) throw new IOException("Respons provider lebih besar dari batas keamanan");
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        }
    }

    private static String shorten(String message) {
        if (message == null) return "error";
        String cleaned = message.replaceAll("[\r\n]+", " ");
        return cleaned.substring(0, Math.min(240, cleaned.length()));
    }
}
