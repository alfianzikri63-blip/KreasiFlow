package id.kreasiflow.studio;

import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Exactly three explicit API endpoints; never allow arbitrary URL from WebView. */
final class MultiProviderApi {
    private static final int MAX_IMAGE = 14 * 1024 * 1024;
    private static final int MAX_AUDIO = 18 * 1024 * 1024;
    private static final int MAX_JSON = 2 * 1024 * 1024;

    static String execute(String provider, JSONObject input, String key) throws Exception {
        if (key == null || key.isEmpty()) throw new IOException("API key untuk " + provider + " belum diatur. Buka Pengaturan AI.");
        switch (provider) {
            case "openrouter": return text(input, key);
            case "fal": return image(input, key);
            case "elevenlabs": return speech(input, key);
            default: throw new IOException("Provider tidak didukung");
        }
    }

    private static String text(JSONObject input, String key) throws Exception {
        // Free diagnostic: validates the same stored credential without a
        // model call. The token never crosses into JavaScript.
        if (input.optBoolean("verify_key", false)) return verifyOpenRouterKey(key);
        String model = input.optString("model", "openrouter/free");
        if (!model.matches("[a-zA-Z0-9_./:-]{2,120}")) throw new IOException("Model OpenRouter tidak valid");
        String prompt = input.optString("prompt", "");
        if (prompt.isEmpty() || prompt.length() > 85000) throw new IOException("Prompt naskah tidak valid/terlalu panjang");
        JSONObject body = new JSONObject();
        body.put("model", model);
        body.put("stream", false);
        body.put("messages", new JSONArray().put(new JSONObject().put("role", "user").put("content", prompt)));
        HttpURLConnection connection = connect("https://openrouter.ai/api/v1/chat/completions", "Bearer " + key, "Authorization");
        connection.setRequestProperty("X-Title", "KreasiFlow Studio");
        return new String(send(connection, body.toString(), MAX_JSON), StandardCharsets.UTF_8);
    }

    private static String verifyOpenRouterKey(String key) throws Exception {
        HttpURLConnection connection = (HttpURLConnection)
                new URL("https://openrouter.ai/api/v1/key").openConnection();
        connection.setInstanceFollowRedirects(false);
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(20000);
        connection.setReadTimeout(25000);
        connection.setRequestProperty("Authorization", "Bearer " + key.trim());
        connection.setRequestProperty("Accept", "application/json");
        try {
            int status = connection.getResponseCode();
            if (status != 200) {
                if (status == 401) throw new IOException(
                        "OpenRouter menolak autentikasi (401). Salin ulang hanya nilai API key sk-or- dari dashboard.");
                throw new IOException("Uji koneksi OpenRouter gagal (HTTP " + status + ")");
            }
            // Read just enough to validate the API response, never echo key
            // details or billing data into WebView JavaScript.
            JSONObject response = new JSONObject(new String(
                    readLimited(connection.getInputStream(), 16000), StandardCharsets.UTF_8));
            if (response.optJSONObject("data") == null) throw new IOException("Respons uji API key tidak dikenal");
            return new JSONObject().put("ok", true).toString();
        } finally { connection.disconnect(); }
    }

    private static String image(JSONObject input, String key) throws Exception {
        String prompt = input.optString("prompt", "");
        if (prompt.isEmpty() || prompt.length() > 12000) throw new IOException("Prompt gambar terlalu panjang/kosong");
        String ratio = input.optString("ratio", "9:16");
        JSONObject body = new JSONObject()
                .put("prompt", prompt)
                .put("image_size", "16:9".equals(ratio) ? "landscape_16_9" : "portrait_16_9")
                .put("num_images", 1)
                .put("num_inference_steps", 4);
        HttpURLConnection connection = connect("https://fal.run/fal-ai/flux/schnell", "Key " + key, "Authorization");
        JSONObject response = new JSONObject(new String(send(connection, body.toString(), MAX_JSON), StandardCharsets.UTF_8));
        JSONArray images = response.optJSONArray("images");
        if (images == null || images.length() == 0) throw new IOException("fal.ai tidak mengembalikan gambar; periksa kredit akun");
        String imageUrl = images.getJSONObject(0).optString("url", "");
        URL url = new URL(imageUrl);
        String host = url.getHost().toLowerCase(java.util.Locale.ROOT);
        if (!"https".equalsIgnoreCase(url.getProtocol()) || !(host.equals("fal.media") || host.endsWith(".fal.media")))
            throw new IOException("Alamat file gambar dari fal tidak dikenal: " + host);
        HttpURLConnection media = (HttpURLConnection) url.openConnection();
        media.setConnectTimeout(20000);
        media.setReadTimeout(50000);
        media.setInstanceFollowRedirects(false);
        try {
            if (media.getResponseCode() != 200) throw new IOException("Unduhan gambar fal gagal (HTTP " + media.getResponseCode() + ")");
            String mime = media.getContentType();
            if (mime == null || !mime.toLowerCase(java.util.Locale.ROOT).startsWith("image/"))
                throw new IOException("Respons fal bukan file gambar");
            byte[] bytes = readLimited(media.getInputStream(), MAX_IMAGE);
            return new JSONObject().put("mime_type", mime.split(";")[0])
                    .put("image_base64", Base64.encodeToString(bytes, Base64.NO_WRAP)).toString();
        } finally { media.disconnect(); }
    }

    private static String speech(JSONObject input, String key) throws Exception {
        String text = input.optString("text", "").trim();
        String voice = input.optString("voice_id", "JBFqnCBsd6RMkjVDRZzb");
        if (text.length() < 2 || text.length() > 10000) throw new IOException("ElevenLabs: panjang narasi harus 2–10.000 karakter");
        if (!voice.matches("[A-Za-z0-9]{10,48}")) throw new IOException("Voice ID ElevenLabs tidak valid");
        JSONObject body = new JSONObject().put("text", text).put("model_id", "eleven_multilingual_v2");
        String url = "https://api.elevenlabs.io/v1/text-to-speech/" + voice + "?output_format=mp3_44100_128";
        HttpURLConnection connection = connect(url, key, "xi-api-key");
        byte[] audio = send(connection, body.toString(), MAX_AUDIO);
        return new JSONObject().put("mime_type", "audio/mpeg")
                .put("audio_base64", Base64.encodeToString(audio, Base64.NO_WRAP)).toString();
    }

    private static HttpURLConnection connect(String url, String key, String header) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setInstanceFollowRedirects(false);
        c.setConnectTimeout(20000);
        c.setReadTimeout(180000);
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setRequestProperty(header, key);
        c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        c.setRequestProperty("Accept", "application/json, audio/mpeg, image/png, image/jpeg");
        return c;
    }

    private static byte[] send(HttpURLConnection c, String payload, int limit) throws IOException {
        try {
            byte[] body = payload.getBytes(StandardCharsets.UTF_8);
            try (OutputStream out = c.getOutputStream()) { out.write(body); }
            int status = c.getResponseCode();
            if (status >= 300 && status < 400) throw new IOException("Provider mengalihkan URL API. Permintaan dibatalkan demi keamanan.");
            if (status < 200 || status >= 300) {
                InputStream error = c.getErrorStream();
                String message = error == null ? "" : new String(readLimited(error, 20000), StandardCharsets.UTF_8);
                try {
                    JSONObject j = new JSONObject(message);
                    JSONObject e = j.optJSONObject("error");
                    if (e != null) message = e.optString("message", message);
                    else if (j.optString("detail", "").length() > 0) message = j.optString("detail");
                } catch (JSONException ignored) { }
                throw new IOException("HTTP " + status + " (" + (status == 401 ? "Autentikasi ditolak; " : status == 402 ? "saldo/kredit kurang; " : status == 429 ? "kuota habis; " : "") + shorten(message) + ")");
            }
            InputStream stream = c.getInputStream();
            if (stream == null) throw new IOException("Respons kosong dari provider");
            return readLimited(stream, limit);
        } finally { c.disconnect(); }
    }

    private static byte[] readLimited(InputStream input, int limit) throws IOException {
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) != -1) {
                if (out.size() + n > limit) throw new IOException("Respons provider lebih besar dari batas keamanan");
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        }
    }

    private static String shorten(String message) {
        if (message == null) return "error";
        String cleaned = message.replaceAll("[\r\n]+", " ");
        return cleaned.substring(0, Math.min(240, cleaned.length()));
    }
}
