package id.kreasiflow.studio;

import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;

/** Pure Android 16-bit PCM mixing; VO remains the master clock. No FFmpeg dependency.
 *  Flow audio is optionally ducked beneath VO; it is NEVER speech-separated.
 */
final class NativeAudioMixer {
    private static final int RATE=44100;
    private static void checkCancel685(int i)throws InterruptedException{
        if((i&8191)==0&&Thread.currentThread().isInterrupted())throw new InterruptedException("Render dibatalkan");
    }
    private static void ensure(boolean test,String message)throws IOException{if(!test)throw new IOException(message);}
    private static final class Pcm {
        final short[][] blocks;
        final int count,sampleRate,channels;
        Pcm(short[][] blocks,int count,int sampleRate,int channels){
            this.blocks=blocks;this.count=count;this.sampleRate=sampleRate;this.channels=channels;
        }
        int frames(){return count/channels;}
        long bytes(){return 2L*blocks.length*PcmSamples685.CHUNK;}
        private short sample(int index){
            return blocks[index/PcmSamples685.CHUNK][index%PcmSamples685.CHUNK];
        }
        float at(double seconds){
            if(seconds<0||frames()==0)return 0;
            double position=seconds*sampleRate;int index=(int)position;
            if(index>=frames())return 0;
            float left=mono(index),right=mono(Math.min(index+1,frames()-1));
            return left+(right-left)*(float)(position-index);
        }
        private float mono(int frame){long sum=0;for(int c=0;c<channels;c++)sum+=sample(frame*channels+c);return sum/(float)channels;}
    }
    private static final class PcmSamples685 {
        private static final int CHUNK=32768;
        private final java.util.ArrayList<short[]> blocks=new java.util.ArrayList<>();
        private int count;
        void append(ByteBuffer data,int size)throws IOException{
            ensure(size%2==0,"PCM audio rusak");
            int newSamples=size/2;
            ensure((long)(count+newSamples)*2<125L*1024*1024,"Audio terlalu panjang untuk pencampuran di HP");
            java.nio.ShortBuffer input=data.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer();
            while(newSamples>0){
                int block=count/CHUNK,offset=count%CHUNK;
                if(offset==0)blocks.add(new short[CHUNK]);
                int n=Math.min(CHUNK-offset,newSamples);
                input.get(blocks.get(block),offset,n);count+=n;newSamples-=n;
            }
        }
        Pcm finish(int rate,int channels){
            return new Pcm(blocks.toArray(new short[0][]),count,rate,channels);
        }
    }
    private static Pcm decode(File file)throws Exception{
        MediaExtractor ex=new MediaExtractor();MediaCodec decoder=null;
        try{
            ex.setDataSource(file.getAbsolutePath());
            int track=-1;
            for(int i=0;i<ex.getTrackCount();i++){
                String mime=ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
                if(mime!=null&&mime.startsWith("audio/")){track=i;break;}
            }
            if(track<0)return null;
            MediaFormat input=ex.getTrackFormat(track);ex.selectTrack(track);
            decoder=MediaCodec.createDecoderByType(input.getString(MediaFormat.KEY_MIME));
            decoder.configure(input,null,null,0);decoder.start();
            int rate=input.containsKey(MediaFormat.KEY_SAMPLE_RATE)?input.getInteger(MediaFormat.KEY_SAMPLE_RATE):RATE;
            int channels=input.containsKey(MediaFormat.KEY_CHANNEL_COUNT)?input.getInteger(MediaFormat.KEY_CHANNEL_COUNT):1;
            PcmSamples685 raw=new PcmSamples685();
            boolean inputEnd=false,outputEnd=false;int stall=0;
            MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
            while(!outputEnd){
                if(Thread.currentThread().isInterrupted())throw new InterruptedException("Render dibatalkan");
                boolean progress=false;
                if(!inputEnd){
                    int n=decoder.dequeueInputBuffer(10000);
                    if(n>=0){
                        ByteBuffer b=decoder.getInputBuffer(n);ensure(b!=null,"Input decoder audio tidak ada");b.clear();
                        int len=ex.readSampleData(b,0);
                        if(len<0){decoder.queueInputBuffer(n,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputEnd=true;}
                        else{decoder.queueInputBuffer(n,0,len,Math.max(0,ex.getSampleTime()),0);ex.advance();}
                        progress=true;
                    }
                }
                int out=decoder.dequeueOutputBuffer(info,10000);
                if(out==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){
                    MediaFormat f=decoder.getOutputFormat();
                    rate=f.getInteger(MediaFormat.KEY_SAMPLE_RATE);channels=f.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    int encoding=f.containsKey(MediaFormat.KEY_PCM_ENCODING)?f.getInteger(MediaFormat.KEY_PCM_ENCODING):AudioFormat.ENCODING_PCM_16BIT;
                    ensure(encoding==AudioFormat.ENCODING_PCM_16BIT,"PCM audio harus 16-bit; konversi sumber audio sebelum render");
                    progress=true;
                }else if(out>=0){
                    ByteBuffer data=decoder.getOutputBuffer(out);
                    if(info.size>0){
                        ensure(data!=null,"Decoder audio tidak mengembalikan PCM");
                        data.position(info.offset);data.limit(info.offset+info.size);
                        raw.append(data,info.size);
                    }
                    outputEnd=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
                    decoder.releaseOutputBuffer(out,false);progress=true;
                }
                stall=progress?0:stall+1;ensure(stall<300,"Decoder audio tidak merespons");
            }
            ensure(channels>=1&&channels<=2&&rate>=8000&&rate<=192000,"Format audio tidak didukung");
            return raw.finish(rate,channels);
        }finally{
            ex.release();if(decoder!=null){try{decoder.stop();}catch(Exception ignored){}decoder.release();}
        }
    }
    static void mixToMp4(File narration,List<File> clips,double[] starts,float voiceGain,float sfxGain,
                         File target,long durationUs,NativeVideoRenderer.Progress progress)throws Exception{
        mixToMp4(narration,clips,starts,voiceGain,sfxGain,null,0,false,target,durationUs,progress);
    }
    static void mixToMp4(File narration,List<File> clips,double[] starts,float voiceGain,float sfxGain,
                         File music,float musicGain,boolean duck,File target,long durationUs,NativeVideoRenderer.Progress progress)throws Exception{
        mixToMp4(narration,clips,starts,voiceGain,sfxGain,music,musicGain,duck,null,durationUs/1_000_000.0,target,durationUs,progress);
    }
    static void mixToMp4(File narration,List<File> clips,double[] starts,float voiceGain,float sfxGain,
                         File music,float musicGain,boolean duck,File outroVoice,double mainSeconds,File target,long durationUs,NativeVideoRenderer.Progress progress)throws Exception{
        mixToMp4(narration,clips,starts,voiceGain,sfxGain,music,musicGain,duck,outroVoice,mainSeconds,target,durationUs,progress,false,true,null,0f,0,null,null);
    }
    static void mixToMp4(File narration,List<File> clips,double[] starts,float voiceGain,float sfxGain,
                         File music,float musicGain,boolean duck,File outroVoice,double mainSeconds,File target,long durationUs,NativeVideoRenderer.Progress progress,boolean smartLoop,boolean musicLoop, File separateSfx,float separateGain,double separateStart,double[] trimStarts,double[][] clipParts)throws Exception{
        ensure(durationUs>0&&durationUs<=600_000_000L,"Durasi audio harus 0–600 detik");
        int frames=(int)Math.ceil(durationUs*RATE/1_000_000.0);
        short[] mix=new short[frames];boolean hasAudio=false; Pcm voice=null;
        if(narration!=null&&narration.length()>0){
            progress.onProgress(81,"Mendekode VO sesuai waktu asli...");
            Pcm vo=decode(narration);voice=vo;ensure(vo!=null&&vo.frames()>0,"Voice-over tidak mengandung audio");
            for(int i=0;i<frames&&i/(double)RATE<mainSeconds;i++){checkCancel685(i);float x=vo.at(i/(double)RATE)*voiceGain;mix[i]=clip(x);}
            hasAudio=true;
        }
        if(sfxGain>0&&clips!=null){
            java.util.Map<File,Integer> uses=new java.util.HashMap<>();
            for(File file:clips)if(file!=null)uses.merge(file,1,Integer::sum);
            java.util.Map<File,Pcm> decodedClips=new java.util.HashMap<>();
            long cacheBytes=0;
            for(int scene=0;scene<clips.size();scene++){
                File f=clips.get(scene);if(f==null)continue;
                progress.onProgress(83+Math.min(6,(int)(6.0*scene/clips.size())),"Mix SFX Flow scene "+(scene+1));
                Pcm sound=decodedClips.get(f);
                if(sound==null){
                    sound=decode(f);
                    if(sound!=null&&uses.get(f)>1 && cacheBytes+sound.bytes()<=12L*1024*1024){
                        decodedClips.put(f,sound);cacheBytes+=sound.bytes();
                    }
                }
                int remaining=uses.merge(f,-1,Integer::sum);
                if(remaining==0){Pcm released=decodedClips.remove(f);if(released!=null)cacheBytes-=released.bytes();}
                if(sound==null)continue;hasAudio=true;
                double duration=starts[scene+1]-starts[scene],sourceDuration=sound.frames()/(double)sound.sampleRate;
                // For short adjustment, track original visuals by mapping evenly.
                // For long scenes, keep audio at original speed and let final image hold.
                double speed=duration<=sourceDuration?sourceDuration/duration:1.0;
                int first=(int)Math.ceil(starts[scene]*RATE),end=Math.min(frames,(int)Math.ceil(starts[scene+1]*RATE));
                for(int i=first;i<end;i++){
                    checkCancel685(i);
                    double trim=trimStarts==null?0:trimStarts[scene];
                    double local=NativeVideoRenderer.clipSourceTime(i/(double)RATE-starts[scene],speed,trim,clipParts==null?null:clipParts[scene]);
                    float effect=sound.at(local)*sfxGain;
                    // Last 0.12 seconds fade to avoid abrupt audio at scene cut.
                    double remain=starts[scene+1]-i/(double)RATE;
                    if(remain<.12)effect*=Math.max(0,remain/.12);
                    mix[i]=clip(mix[i]+effect);
                }
            }
        }
        if(separateSfx!=null&&separateGain>0){
            Pcm effects=decode(separateSfx);
            ensure(effects!=null&&effects.frames()>0,"Trek SFX tidak memiliki audio");
            int first=Math.min(frames,(int)Math.ceil(separateStart*RATE));
            int end=Math.min(frames,first+(int)Math.ceil(effects.frames()*RATE/(double)effects.sampleRate));
            for(int i=first;i<end;i++)mix[i]=clip(mix[i]+effects.at((i-first)/(double)RATE)*separateGain);
            hasAudio=true;
        }
        Pcm ending=null;
        if(outroVoice!=null){
            ending=decode(outroVoice);ensure(ending!=null&&ending.frames()>0,"VO outro tidak memiliki audio");
            for(int i=Math.max(0,(int)Math.ceil(mainSeconds*RATE));i<frames;i++)mix[i]=clip(mix[i]+ending.at(i/(double)RATE-mainSeconds)*voiceGain);
            hasAudio=true;
        }
        if(music!=null&&musicGain>0){
            progress.onProgress(89,"Mix musik latar dengan ducking...");
            Pcm bed=decode(music);ensure(bed!=null&&bed.frames()>0,"Musik tidak memiliki audio");
            double length=bed.frames()/(double)bed.sampleRate;float envelope=0;
            for(int i=0;i<frames;i++){
                if((i&8191)==0&&Thread.currentThread().isInterrupted())throw new InterruptedException("Render dibatalkan");
                double t=i/(double)RATE;
                if(!musicLoop&&t>=length)break;
                double local=t%length;
                float level=t>=mainSeconds?(ending==null?0:Math.abs(ending.at(t-mainSeconds))/32768f):(voice==null?0:Math.abs(voice.at(t))/32768f);
                envelope+=(level-envelope)*(level>envelope?.001f:.00005f);
                float gain=musicGain*(duck&&(voice!=null||ending!=null)?1f-.72f*Math.min(1f,envelope/.035f):1f);
                float fade=(float)Math.min(1,Math.min(local/.025,(length-local)/.025));
                fade*=Math.min(1,Math.max(0,(frames-i)/(RATE*.15f)));
                fade*=Math.min(1,i/(RATE*.25f));
                mix[i]=clip(mix[i]+bed.at(local)*gain*fade);
            }hasAudio=true;
        }
        ensure(hasAudio,"Tidak ada track VO, musik atau efek suara di klip Flow");
        progress.onProgress(90,"Encoding campuran audio AAC...");
        encode(mix,target);
    }
    private static short clip(float x){return (short)Math.max(Short.MIN_VALUE,Math.min(Short.MAX_VALUE,Math.round(x)));}
    private static void encode(short[] pcm,File file)throws Exception{
        MediaCodec enc=null;MediaMuxer mux=null;boolean started=false;
        try{
            MediaFormat fmt=MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC,RATE,1);
            fmt.setInteger(MediaFormat.KEY_AAC_PROFILE,MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            fmt.setInteger(MediaFormat.KEY_BIT_RATE,96000);fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE,16384);
            enc=MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
            enc.configure(fmt,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE);enc.start();
            mux=new MediaMuxer(file.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            boolean inputEnd=false,outputEnd=false;int index=0,track=-1,idle=0;
            MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
            while(!outputEnd){
                if(Thread.currentThread().isInterrupted())throw new InterruptedException("Render dibatalkan");
                boolean progress=false;
                if(!inputEnd){
                    int in=enc.dequeueInputBuffer(10000);
                    if(in>=0){
                        ByteBuffer b=enc.getInputBuffer(in);ensure(b!=null,"Encoder AAC input tidak tersedia");
                        b.clear();b.order(ByteOrder.LITTLE_ENDIAN);
                        int available=Math.min(pcm.length-index,b.remaining()/2);
                        for(int i=0;i<available;i++)b.putShort(pcm[index+i]);
                        long pts=(long)(index*1_000_000.0/RATE);
                        index+=available;
                        boolean last=index>=pcm.length;
                        enc.queueInputBuffer(in,0,available*2,pts,last?MediaCodec.BUFFER_FLAG_END_OF_STREAM:0);
                        inputEnd=last;progress=true;
                    }
                }
                int out=enc.dequeueOutputBuffer(info,10000);
                if(out==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){
                    ensure(!started,"Format AAC berubah dua kali");track=mux.addTrack(enc.getOutputFormat());mux.start();started=true;progress=true;
                }else if(out>=0){
                    ByteBuffer b=enc.getOutputBuffer(out);ensure(b!=null,"Output AAC tidak tersedia");
                    if((info.flags&MediaCodec.BUFFER_FLAG_CODEC_CONFIG)!=0)info.size=0;
                    if(info.size>0){ensure(started,"Muxer audio belum mulai");b.position(info.offset);b.limit(info.offset+info.size);mux.writeSampleData(track,b,info);}
                    outputEnd=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
                    enc.releaseOutputBuffer(out,false);progress=true;
                }
                idle=progress?0:idle+1;ensure(idle<300,"Encoder AAC tidak merespons");
            }
            ensure(started,"Encoder AAC tidak menghasilkan track");
        }finally{
            if(enc!=null){try{enc.stop();}catch(Exception ignored){}enc.release();}
            if(mux!=null){if(started)try{mux.stop();}catch(Exception ignored){}mux.release();}
        }
    }
}
