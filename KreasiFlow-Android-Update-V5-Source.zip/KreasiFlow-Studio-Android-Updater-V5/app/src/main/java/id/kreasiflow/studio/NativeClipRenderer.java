package id.kreasiflow.studio;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.List;

/** Join downloaded moving H264 clips, then mux optional ElevenLabs narration.
 *  Requires compatible clips generated with one selected model and aspect ratio.
 *  If narration is longer than the clips, the sequence loops to avoid cutting narration.
 *  Subtitle/watermark overlay is not available for native clip passthrough.
 */
final class NativeClipRenderer {
    private static void ensure(boolean ok,String message)throws IOException{if(!ok)throw new IOException(message);}
    static void render(List<File> clips,File narration,double duration,boolean preserveClipAudio,File output,File tmp,NativeVideoRenderer.Progress progress)throws Exception {
        ensure(clips!=null&&!clips.isEmpty(),"Klip AI belum tersedia");
        ensure(clips.size()<=36,"Maksimal 36 klip AI");
        ensure(duration>=0&&duration<=600,"Durasi maksimal 10 menit");
        File silent=new File(tmp,"ai-video-only.mp4");
        File audio=new File(tmp,"ai-narration.mp4");
        try{
            progress.onProgress(4,"Menggabungkan klip AI bergerak...");
            long durationUs=preserveClipAudio?concatenateWithAudio(clips,silent,progress):concatenate(clips,silent,duration>1?(long)(duration*1_000_000):0,progress);
            if(preserveClipAudio&&narration!=null&&narration.length()>0)throw new IOException("Pilih audio Flow ATAU suara narator, bukan keduanya sekaligus");
            if(!preserveClipAudio&&narration!=null&&narration.length()>0){
                progress.onProgress(81,"Konversi suara narator ke AAC...");
                NativeVideoRenderer.transcodeAudio(narration,audio,durationUs);
                progress.onProgress(92,"Menggabungkan suara dan gambar bergerak...");
                NativeVideoRenderer.mergeMp4(silent,audio,output,durationUs);
            }else if(!silent.renameTo(output)) {
                java.nio.file.Files.copy(silent.toPath(),output.toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
            ensure(output.exists()&&output.length()>2048,"Hasil video AI MP4 kosong");
            progress.onProgress(100,"Video AI bergerak selesai");
        }finally {silent.delete();audio.delete();}
    }
    private static long concatenate(List<File> videos,File out,long targetUs,NativeVideoRenderer.Progress progress)throws Exception {
        MediaExtractor first=new MediaExtractor();MediaMuxer muxer=null;boolean muxStarted=false;
        int width=0,height=0;String codec=null;long pts=0;long totalPts=0;
        try{
            first.setDataSource(videos.get(0).getAbsolutePath());
            int idx=findVideo(first);ensure(idx>=0,"Klip pertama tidak berisi video");
            MediaFormat base=first.getTrackFormat(idx);
            width=base.getInteger(MediaFormat.KEY_WIDTH);height=base.getInteger(MediaFormat.KEY_HEIGHT);
            codec=base.getString(MediaFormat.KEY_MIME);
            ensure(MediaFormat.MIMETYPE_VIDEO_AVC.equals(codec),"Klip AI harus memakai H264/AVC untuk penggabungan cepat");
            muxer=new MediaMuxer(out.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int track=muxer.addTrack(base);muxer.start();muxStarted=true;
            // Without narration, concatenate one pass. With narration, repeat in order to
            // fill audio duration, avoiding an abrupt truncation of the spoken text.
            int rounds=targetUs==0?1:120;
            ByteBuffer buffer=ByteBuffer.allocateDirect(8*1024*1024);
            MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
            outer:for(int round=0;round<rounds;round++){
                for(int index=0;index<videos.size();index++){
                    if(Thread.currentThread().isInterrupted())throw new InterruptedException("Render dibatalkan");
                    MediaExtractor ex=new MediaExtractor();
                    try{
                        ex.setDataSource(videos.get(index).getAbsolutePath());
                        int t=findVideo(ex);ensure(t>=0,"Klip "+(index+1)+" tidak memiliki video");
                        MediaFormat fmt=ex.getTrackFormat(t);
                        ensure(codec.equals(fmt.getString(MediaFormat.KEY_MIME))
                            && width==fmt.getInteger(MediaFormat.KEY_WIDTH)
                            && height==fmt.getInteger(MediaFormat.KEY_HEIGHT),
                            "Ukuran/codec klip berbeda; gunakan 480p dan rasio sama untuk semua scene");
                        ex.selectTrack(t);
                        long firstPts=-1,lastPts=-1,lastGap=62500;
                        while(true){
                            if(Thread.currentThread().isInterrupted())throw new InterruptedException("Render dibatalkan");
                            buffer.clear();int size=ex.readSampleData(buffer,0);long tUs=ex.getSampleTime();
                            if(size<0||tUs<0)break;
                            if(firstPts<0)firstPts=tUs;
                            long rel=tUs-firstPts;
                            if(rel<0)rel=0;
                            long position=pts+rel;
                            if(targetUs>0&&position>=targetUs)break outer;
                            ensure(size<=buffer.capacity(),"Frame klip melebihi buffer renderer");
                            info.set(0,size,position,ex.getSampleFlags());
                            buffer.position(0);buffer.limit(size);
                            muxer.writeSampleData(track,buffer,info);
                            if(lastPts>=0&&rel>lastPts)lastGap=Math.max(1,rel-lastPts);
                            lastPts=rel;totalPts=position;
                            if(!ex.advance())break;
                        }
                        pts+=Math.max(0,lastPts)+lastGap;
                    }finally {ex.release();}
                    if(targetUs>0){
                        int pct=Math.min(100,(int)(pts*100/targetUs));
                        progress.onProgress(5+(int)(pct*.74),"Menyusun klip gerak "+pct+"%");
                    }
                }
                if(targetUs==0)break;
                if(pts>=targetUs)break;
            }
            ensure(totalPts>100000,"Tidak ada frame video yang bisa digabung");
            return targetUs>0?Math.min(targetUs,totalPts+62500):totalPts+62500;
        }finally{
            first.release();
            if(muxer!=null){if(muxStarted)try{muxer.stop();}catch(Exception ignored){}muxer.release();}
        }
    }
    /**
     * Preserve existing Flow-generated AAC audio during fast MP4 concatenation.
     * Do not transcode or silently drop a missing/incompatible audio track.
     * This path is selected only for Edu3D mode when Flow narration is enabled.
     * Per-word subtitles are exported as a separate editable SRT, not burned in.
     */
    private static long concatenateWithAudio(List<File> clips,File out,NativeVideoRenderer.Progress progress)throws Exception {
        MediaMuxer muxer=null;boolean started=false;
        int baseWidth=-1,baseHeight=-1,baseRate=-1,baseChannels=-1;
        String baseVideo=null,baseAudio=null;
        long offsetUs=0;
        try{
            // Add both tracks BEFORE starting MediaMuxer. The first Flow MP4
            // must contain an AVC video track and an AAC audio track.
            MediaExtractor first=new MediaExtractor();
            try{
                first.setDataSource(clips.get(0).getAbsolutePath());
                int video=findVideo(first),audio=findAudio(first);
                ensure(video>=0&&audio>=0,"Klip 1 tidak mempunyai video DAN audio. Pilih MP4 Flow dengan suara asli.");
                MediaFormat v=first.getTrackFormat(video),a=first.getTrackFormat(audio);
                baseVideo=v.getString(MediaFormat.KEY_MIME);
                baseAudio=a.getString(MediaFormat.KEY_MIME);
                ensure(MediaFormat.MIMETYPE_VIDEO_AVC.equals(baseVideo),"Gabung cepat membutuhkan MP4 H.264/AVC. Konversi klip terlebih dahulu.");
                ensure(MediaFormat.MIMETYPE_AUDIO_AAC.equals(baseAudio),"Audio Flow harus AAC untuk digabung tanpa konversi.");
                baseWidth=v.getInteger(MediaFormat.KEY_WIDTH);baseHeight=v.getInteger(MediaFormat.KEY_HEIGHT);
                baseRate=a.getInteger(MediaFormat.KEY_SAMPLE_RATE);baseChannels=a.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                muxer=new MediaMuxer(out.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                int videoOut=muxer.addTrack(v),audioOut=muxer.addTrack(a);muxer.start();started=true;
                ByteBuffer buffer=ByteBuffer.allocateDirect(8*1024*1024);
                MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
                for(int n=0;n<clips.size();n++){
                    if(Thread.currentThread().isInterrupted())throw new InterruptedException("Render dibatalkan");
                    MediaExtractor ex=new MediaExtractor();
                    try{
                        ex.setDataSource(clips.get(n).getAbsolutePath());
                        int vi=findVideo(ex),ai=findAudio(ex);
                        ensure(vi>=0&&ai>=0,"Klip "+(n+1)+" tidak mempunyai track video dan audio. Jangan kehilangan narasi Flow.");
                        MediaFormat vf=ex.getTrackFormat(vi),af=ex.getTrackFormat(ai);
                        ensure(baseVideo.equals(vf.getString(MediaFormat.KEY_MIME))
                            &&vf.getInteger(MediaFormat.KEY_WIDTH)==baseWidth
                            &&vf.getInteger(MediaFormat.KEY_HEIGHT)==baseHeight,
                            "Format/resolusi video klip "+(n+1)+" berbeda. Gunakan resolusi dan rasio Flow yang sama.");
                        ensure(baseAudio.equals(af.getString(MediaFormat.KEY_MIME))
                            &&af.getInteger(MediaFormat.KEY_SAMPLE_RATE)==baseRate
                            &&af.getInteger(MediaFormat.KEY_CHANNEL_COUNT)==baseChannels,
                            "Format/sample-rate/channel audio klip "+(n+1)+" berbeda. Samakan AAC sebelum gabung.");
                        // Each extractor sees one selected track, so timestamp
                        // normalization doesn't confuse the first-video and first-audio sample.
                        long vDuration=copyTrackSamples(clips.get(n),vi,muxer,videoOut,offsetUs,buffer,info);
                        long aDuration=copyTrackSamples(clips.get(n),ai,muxer,audioOut,offsetUs,buffer,info);
                        long clipDuration=Math.max(vDuration,aDuration);
                        ensure(clipDuration>100000,"Klip "+(n+1)+" tidak mengandung sampel audio/video yang cukup");
                        offsetUs+=clipDuration;
                        ensure(offsetUs<600_000_000L,"Durasi gabungan melebihi 10 menit");
                        progress.onProgress(5+(int)(76.0*(n+1)/clips.size()),"Klip "+(n+1)+"/"+clips.size()+" beserta audio siap");
                    }finally{ex.release();}
                }
            }finally{first.release();}
            ensure(offsetUs>100000,"Tidak ada data MP4 yang bisa digabung");
            return offsetUs;
        }finally{if(muxer!=null){if(started)try{muxer.stop();}catch(Exception ignore){}muxer.release();}}
    }
    private static long copyTrackSamples(File file,int trackIndex,MediaMuxer muxer,int outputTrack,
        long offsetUs,ByteBuffer buffer,MediaCodec.BufferInfo info)throws Exception {
        MediaExtractor extractor=new MediaExtractor();
        try{
            extractor.setDataSource(file.getAbsolutePath());
            extractor.selectTrack(trackIndex);
            long firstPts=-1,lastRel=-1,lastGap=0,prevRel=-1;
            while(true){
                buffer.clear();int size=extractor.readSampleData(buffer,0);long pts=extractor.getSampleTime();
                if(size<0||pts<0)break;
                ensure(size<=buffer.capacity(),"Sampel MP4 melebihi ukuran buffer");
                if(firstPts<0)firstPts=pts;
                long rel=Math.max(0,pts-firstPts);
                if(prevRel>=0&&rel>prevRel)lastGap=rel-prevRel;
                info.set(0,size,offsetUs+rel,extractor.getSampleFlags());
                buffer.position(0);buffer.limit(size);
                muxer.writeSampleData(outputTrack,buffer,info);
                prevRel=rel;lastRel=rel;
                if(!extractor.advance())break;
            }
            return lastRel<0?0:lastRel+(lastGap>0?lastGap:33000);
        }finally{extractor.release();}
    }
    private static int findAudio(MediaExtractor ex){
        for(int i=0;i<ex.getTrackCount();i++){
            String mime=ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
            if(mime!=null&&mime.startsWith("audio/"))return i;
        }
        return -1;
    }
    private static int findVideo(MediaExtractor ex){
        for(int i=0;i<ex.getTrackCount();i++){
            String mime=ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
            if(mime!=null&&mime.startsWith("video/"))return i;
        }
        return -1;
    }
}
