package id.kreasiflow.studio;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.List;

/** Join downloaded moving H264 clips, then mux optional ElevenLabs narration.
 *  Requires compatible clips generated with one selected model and aspect ratio.
 *  If narration is longer than the clips, the sequence loops to avoid cutting narration.
 *  Subtitle/watermark overlay is not available for native clip passthrough.
 */
final class NativeClipRenderer {
    private static void ensure(boolean ok,String message)throws IOException{if(!ok)throw new IOException(message);}
    static void render(List<File> clips,File narration,double duration,File output,File tmp,NativeVideoRenderer.Progress progress)throws Exception {
        ensure(clips!=null&&!clips.isEmpty(),"Klip AI belum tersedia");
        ensure(clips.size()<=36,"Maksimal 36 klip AI");
        ensure(duration>=0&&duration<=600,"Durasi maksimal 10 menit");
        File silent=new File(tmp,"ai-video-only.mp4");
        File audio=new File(tmp,"ai-narration.mp4");
        try{
            progress.onProgress(4,"Menggabungkan klip AI bergerak...");
            long durationUs=concatenate(clips,silent,duration>1?(long)(duration*1_000_000):0,progress);
            if(narration!=null&&narration.length()>0){
                progress.onProgress(81,"Konversi suara narator ke AAC...");
                NativeVideoRenderer.transcodeAudio(narration,audio,durationUs);
                progress.onProgress(92,"Menggabungkan suara dan gambar bergerak...");
                NativeVideoRenderer.mergeMp4(silent,audio,output,durationUs);
            }else if(!silent.renameTo(output)) {
                java.nio.file.Files.copy(silent.toPath(),output.toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
            ensure(output.exists()&&output.length()>2048,"Hasil video AI MP4 kosong");
            progress.onProgress(100,"Video AI bergerak selesai");
        }finally {silent.delete();audio.delete();}
    }
    private static long concatenate(List<File> videos,File out,long targetUs,NativeVideoRenderer.Progress progress)throws Exception {
        MediaExtractor first=new MediaExtractor();MediaMuxer muxer=null;boolean muxStarted=false;
        int width=0,height=0;String codec=null;long pts=0;long totalPts=0;
        try{
            first.setDataSource(videos.get(0).getAbsolutePath());
            int idx=findVideo(first);ensure(idx>=0,"Klip pertama tidak berisi video");
            MediaFormat base=first.getTrackFormat(idx);
            width=base.getInteger(MediaFormat.KEY_WIDTH);height=base.getInteger(MediaFormat.KEY_HEIGHT);
            codec=base.getString(MediaFormat.KEY_MIME);
            ensure(MediaFormat.MIMETYPE_VIDEO_AVC.equals(codec),"Klip AI harus memakai H264/AVC untuk penggabungan cepat");
            muxer=new MediaMuxer(out.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int track=muxer.addTrack(base);muxer.start();muxStarted=true;
            // Without narration, concatenate one pass. With narration, repeat in order to
            // fill audio duration, avoiding an abrupt truncation of the spoken text.
            int rounds=targetUs==0?1:120;
            ByteBuffer buffer=ByteBuffer.allocateDirect(8*1024*1024);
            MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
            outer:for(int round=0;round<rounds;round++){
                for(int index=0;index<videos.size();index++){
                    if(Thread.currentThread().isInterrupted())throw new InterruptedException("Render dibatalkan");
                    MediaExtractor ex=new MediaExtractor();
                    try{
                        ex.setDataSource(videos.get(index).getAbsolutePath());
                        int t=findVideo(ex);ensure(t>=0,"Klip "+(index+1)+" tidak memiliki video");
                        MediaFormat fmt=ex.getTrackFormat(t);
                        ensure(codec.equals(fmt.getString(MediaFormat.KEY_MIME))
                            && width==fmt.getInteger(MediaFormat.KEY_WIDTH)
                            && height==fmt.getInteger(MediaFormat.KEY_HEIGHT),
                            "Ukuran/codec klip berbeda; gunakan 480p dan rasio sama untuk semua scene");
                        ex.selectTrack(t);
                        long firstPts=-1,lastPts=-1,lastGap=62500;
                        while(true){
                            if(Thread.currentThread().isInterrupted())throw new InterruptedException("Render dibatalkan");
                            buffer.clear();int size=ex.readSampleData(buffer,0);long tUs=ex.getSampleTime();
                            if(size<0||tUs<0)break;
                            if(firstPts<0)firstPts=tUs;
                            long rel=tUs-firstPts;
                            if(rel<0)rel=0;
                            long position=pts+rel;
                            if(targetUs>0&&position>=targetUs)break outer;
                            ensure(size<=buffer.capacity(),"Frame klip melebihi buffer renderer");
                            info.set(0,size,position,ex.getSampleFlags());
                            buffer.position(0);buffer.limit(size);
                            muxer.writeSampleData(track,buffer,info);
                            if(lastPts>=0&&rel>lastPts)lastGap=Math.max(1,rel-lastPts);
                            lastPts=rel;totalPts=position;
                            if(!ex.advance())break;
                        }
                        pts+=Math.max(0,lastPts)+lastGap;
                    }finally {ex.release();}
                    if(targetUs>0){
                        int pct=Math.min(100,(int)(pts*100/targetUs));
                        progress.onProgress(5+(int)(pct*.74),"Menyusun klip gerak "+pct+"%");
                    }
                }
                if(targetUs==0)break;
                if(pts>=targetUs)break;
            }
            ensure(totalPts>100000,"Tidak ada frame video yang bisa digabung");
            return targetUs>0?Math.min(targetUs,totalPts+62500):totalPts+62500;
        }finally{
            first.release();
            if(muxer!=null){if(muxStarted)try{muxer.stop();}catch(Exception ignored){}muxer.release();}
        }
    }
    private static int findVideo(MediaExtractor ex){
        for(int i=0;i<ex.getTrackCount();i++){
            String mime=ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
            if(mime!=null&&mime.startsWith("video/"))return i;
        }
        return -1;
    }
}
