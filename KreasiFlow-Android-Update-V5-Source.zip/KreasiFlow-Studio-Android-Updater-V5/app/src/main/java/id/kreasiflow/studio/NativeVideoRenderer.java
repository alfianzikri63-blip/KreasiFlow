package id.kreasiflow.studio;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.media.Image;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaMetadataRetriever;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Offline MP4 slideshow writer. Images are still images, not AI-generated motion.
 * Generates H.264 frames with Android MediaCodec and transcodes narration to AAC.
 * No FFmpeg executable, hidden screen capture or third-party streaming service.
 */
final class NativeVideoRenderer {
    interface Progress { void onProgress(int percent, String message); }
    private static final long WAIT = 10_000L;

    static final class Scene {
        File image;
        String voice;
        String name;
        Scene(File image, String voice, String name) {this.image=image;this.voice=voice;this.name=name;}
    }
    static final class Config {
        int width, height, fps;
        double seconds, mainSeconds;
        ThemeOutro outro; File outroVoice;
        boolean captions, fade, frameBlend;
        boolean fastRender=true;
        String sceneTransition="off";
        String subtitlePosition, watermark, effect;
        int subtitleColor;
        File narration,music;
        boolean musicDuck=true,smartRemux=false,smartLoop=false;
        float musicGain=.15f,subtitleSize=.05f;
        String subtitlePreset="classic";
        List<Scene> scenes;
        List<File> motionClips; // one entry per scene, null = fallback still image
        double[] sceneStarts;  // exactly scenes.size()+1 boundaries, seconds
        float voiceGain=0.95f, flowAudioGain=0f;
        List<CaptionCue> subtitleCues = new ArrayList<>();
    }
    static final class CaptionCue {
        final double start, end; final String text;
        CaptionCue(double start, double end, String text){this.start=start;this.end=end;this.text=text;}
    }
    private static void ensure(boolean ok, String message) throws IOException {
        if (!ok) throw new IOException(message);
    }
    private static void cancelIfInterrupted() throws InterruptedException {
        if (Thread.currentThread().isInterrupted()) throw new InterruptedException("Render dibatalkan");
    }
    static void render(Config config, File output, File temporary, Progress progress) throws Exception {
        ensure(config.scenes != null && !config.scenes.isEmpty(), "Scene belum dibuat");
        ensure(config.width >= 320 && config.width <= 1280 && config.height >= 320 && config.height <= 1280,
            "Resolusi tidak didukung");
        ensure(config.seconds > 1 && config.seconds <= 600, "Durasi video maksimal 10 menit untuk ekspor ini");
        config.mainSeconds=config.seconds;
        if(config.outro!=null){config.seconds+=config.outro.seconds;config.smartRemux=false;}
        ensure(config.seconds<=600,"Durasi termasuk outro maksimal 10 menit");
        if (!temporary.exists() && !temporary.mkdirs()) throw new IOException("Tidak bisa membuat folder render");
        File silent = new File(temporary, "video-raw.mp4");
        File audio = new File(temporary, "narration-aac.mp4");
        try {
            progress.onProgress(1,"Membuat frame gambar...");
            boolean remuxed=false;
            if(config.smartRemux)try{remuxed=SmartRemux.tryJoin(config,silent,progress);}catch(InterruptedException e){throw e;}catch(Exception e){silent.delete();progress.onProgress(2,"Klip tidak kompatibel; kembali ke encoding normal");}
            if(!remuxed){if(config.smartRemux)progress.onProgress(2,"Smart Render tidak cocok; encoding normal tanpa mengubah pengaturan");encodeFrames(config, silent, (pct, msg)->progress.onProgress(2+(int)(pct*0.78),msg));}
            cancelIfInterrupted();
            if(config.outro!=null&&(config.outroVoice!=null||config.narration!=null||(config.music!=null&&config.musicGain>0)||(config.motionClips!=null&&config.flowAudioGain>0))){
                NativeAudioMixer.mixToMp4(config.narration,config.motionClips,config.sceneStarts,config.voiceGain,config.flowAudioGain,config.music,config.musicGain,config.musicDuck,config.outroVoice,config.outro.combinedVoice?config.seconds:config.mainSeconds,audio,(long)(config.seconds*1_000_000L),progress);
                progress.onProgress(92,"Menggabungkan video dan audio outro...");
                mergeMp4(silent,audio,output,(long)(config.seconds*1_000_000L));
            } else if(config.music!=null&&config.musicGain>0){
                NativeAudioMixer.mixToMp4(config.narration,config.motionClips,config.sceneStarts,config.voiceGain,config.flowAudioGain,config.music,config.musicGain,config.musicDuck,null,config.seconds,audio,(long)(config.seconds*1_000_000L),progress,config.smartLoop);
                progress.onProgress(92,"Menggabungkan video dan campuran audio...");
                mergeMp4(silent,audio,output,(long)(config.seconds*1_000_000L));
            } else if (config.narration != null && config.narration.length() > 0) {
                progress.onProgress(81,"Mengonversi voice-over menjadi audio AAC...");
                if (config.motionClips!=null) NativeAudioMixer.mixToMp4(config.narration,config.motionClips,config.sceneStarts,config.voiceGain,config.flowAudioGain,audio,(long)(config.seconds*1_000_000L),progress);
                else transcodeAudio(config.narration, audio, (long)(config.seconds*1_000_000L));
                progress.onProgress(92,"Menggabungkan video dan suara...");
                mergeMp4(silent,audio,output,(long)(config.seconds*1_000_000L));
            } else if(config.motionClips!=null&&config.flowAudioGain>0){
                NativeAudioMixer.mixToMp4(null,config.motionClips,config.sceneStarts,0,config.flowAudioGain,audio,(long)(config.seconds*1_000_000L),progress);
                progress.onProgress(92,"Menggabungkan video dengan audio Flow...");
                mergeMp4(silent,audio,output,(long)(config.seconds*1_000_000L));
            } else {
                // A silent MP4 is valid when no narration has been supplied.
                if (!silent.renameTo(output)) {
                    java.nio.file.Files.copy(silent.toPath(),output.toPath(),
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                }
            }
            ensure(output.exists() && output.length()>1024,"Hasil MP4 kosong");
            progress.onProgress(100,"MP4 selesai dibuat");
        } finally {
            silent.delete();audio.delete();
        }
    }
    private static void encodeFrames(Config c, File file, Progress progress) throws Exception {
        final int w=c.width,h=c.height,fps=c.fps;
        final int frames=(int)Math.ceil(c.seconds*fps);
        MediaCodec encoder=null;
        MediaMuxer muxer=null;
        Bitmap frame=null;
        Bitmap sceneBitmap=null, motionBitmap=null, motionNext=null, previousVisual=null, loopOpening=null;
        int previousVisualScene=-1;
        float blendWeight=0f;
        int sourceFps=30;
        MediaMetadataRetriever retriever=null;
        FastFrameReader batch=null;
        double motionSeconds=0;int lastSampleIndex=-1;
        int lastScene=-1,track=-1,lastPct=-1;
        boolean muxStarted=false;
        try {
            encoder=MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            MediaCodecInfo.CodecCapabilities caps=encoder.getCodecInfo().getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_AVC);
            int format=chooseColorFormat(caps.colorFormats);
            ensure(format!=0,"Encoder H.264 tidak mendukung format YUV420");
            if(fps==60 && caps.getVideoCapabilities()!=null &&
                !caps.getVideoCapabilities().areSizeAndRateSupported(w,h,60.0))
                throw new IOException("Encoder HP tidak mendukung "+w+"×"+h+" pada 60 FPS. Coba 540p atau 30 FPS.");
            MediaFormat fmt=MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC,w,h);
            fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT,format);
            fmt.setInteger(MediaFormat.KEY_BIT_RATE,Math.min(8_000_000,Math.max(1_000_000,w*h*fps/7)));
            fmt.setInteger(MediaFormat.KEY_FRAME_RATE,fps);
            fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL,2);
            encoder.configure(fmt,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE);
            encoder.start();
            muxer=new MediaMuxer(file.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            frame=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
            Canvas canvas=new Canvas(frame);
            int[] pixels=new int[w*h];
            byte[] yuv = new byte[w*h*3/2];
            byte[] yRow=new byte[w],uRow=new byte[w/2],vRow=new byte[w/2];
            MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
            for (int f=0;f<=frames;f++) {
                cancelIfInterrupted();
                boolean eos=f==frames;
                if (!eos) {
                    double t=f/(double)fps;
                    if(c.outro!=null&&t>=c.mainSeconds){
                        c.outro.draw(canvas,w,h,t-c.mainSeconds);
                    }else{
                    int index=sceneAt(c,t);
                    if(index!=lastScene){
                        if(sceneBitmap!=null){sceneBitmap.recycle();sceneBitmap=null;}
                        if(motionBitmap!=null){motionBitmap.recycle();motionBitmap=null;}
                        if(motionNext!=null){motionNext.recycle();motionNext=null;}
                        blendWeight=0f;
                        if(batch!=null){batch.close();batch=null;}
                        if(retriever!=null){retriever.release();retriever=null;}
                        sceneBitmap=decode(c.scenes.get(index).image,Math.max(w,h)*2);
                        lastScene=index;lastSampleIndex=-1;motionSeconds=0;
                        File clip=c.motionClips==null||index>=c.motionClips.size()?null:c.motionClips.get(index);
                        if(clip!=null){
                            retriever=new MediaMetadataRetriever();
                            retriever.setDataSource(clip.getAbsolutePath());
                            String duration=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                            motionSeconds=duration==null?0:Math.max(.1,Long.parseLong(duration)/1000.0);
                            sourceFps=sourceFrameRate(clip);
                            if(c.fastRender)batch=new FastFrameReader(retriever,sourceFps,motionSeconds,w,h);
                        }
                    }
                    blendWeight=0f;
                    if(retriever!=null){
                        double local=t-sceneStart(c,index),slot=sceneEnd(c,index)-sceneStart(c,index);
                        double speed=slot<=motionSeconds*1.35?motionSeconds/slot:1.0;
                        double sourceTime=Math.min(Math.max(0,motionSeconds-.005),Math.max(0,local*speed));
                        // Follow source frame rate: old 12 FPS sampling made even 30 FPS look choppy.
                        int sampleIndex=(int)Math.floor(sourceTime*sourceFps+1e-6);
                        if(sampleIndex!=lastSampleIndex||motionBitmap==null){
                            if(motionNext!=null && sampleIndex==lastSampleIndex+1){
                                if(motionBitmap!=null)motionBitmap.recycle();
                                motionBitmap=motionNext;motionNext=null;
                            } else {
                                if(motionBitmap!=null)motionBitmap.recycle();
                                if(motionNext!=null)motionNext.recycle();
                                motionNext=null;
                                motionBitmap=readVideoFrame(retriever,batch,sampleIndex,sourceFps,w,h,index);
                            }
                            lastSampleIndex=sampleIndex;
                        }
                        // Light temporal frame blending is opt-in. It can ghost on fast motion.
                        // Never describe it as new AI-generated intermediate motion.
                        boolean canBlend=c.frameBlend && fps==60 && sourceFps<fps &&
                            (sampleIndex+1)/(double)sourceFps <= motionSeconds-.005;
                        if(canBlend){
                            if(motionNext==null)motionNext=readVideoFrame(retriever,batch,sampleIndex+1,sourceFps,w,h,index);
                            blendWeight=(float)Math.max(0,Math.min(1,sourceTime*sourceFps-sampleIndex));
                        }
                    }
                    if(c.smartLoop&&f==0)loopOpening=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
                    boolean capture="dissolve".equals(c.sceneTransition) && index<c.scenes.size()-1 &&
                        (f+1)/(double)fps>=sceneEnd(c,index);
                    if(capture && previousVisual==null)previousVisual=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
                    // Keep the outgoing visual without captions. A one-frame scene may skip its incoming dissolve.
                    drawScene(canvas,c,motionBitmap!=null?motionBitmap:sceneBitmap,
                        blendWeight>0f?motionNext:null,blendWeight,index,t,
                        previousVisualScene==index-1&&!capture?previousVisual:null,capture?previousVisual:null,frame,loopOpening,f,frames);
                    if(capture)previousVisualScene=index;
                    }
                    frame.getPixels(pixels,0,w,0,0,w,h);
                }
                int input=encoder.dequeueInputBuffer(WAIT);
                if (input<0) {
                    DrainResult d=drainVideo(encoder,muxer,track,muxStarted,info,false);
                    track=d.track; muxStarted=d.started;
                    input=encoder.dequeueInputBuffer(WAIT);
                }
                if (input<0) throw new IOException("Encoder video tidak menerima frame; coba resolusi 360p");
                if (eos) encoder.queueInputBuffer(input,0,0,(long)(c.seconds*1_000_000L),MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                else {
                    Image image=null;
                    try {image=encoder.getInputImage(input);}catch(RuntimeException ignored){}
                    if(image!=null){
                        try {packImage(pixels,w,h,image,yRow,uRow,vRow);}finally{image.close();}
                    } else {
                        if (format==MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
                            throw new IOException("Encoder tidak menyediakan input YUV. Coba gunakan perangkat lain.");
                        packBytes(pixels,w,h,yuv,format);
                        ByteBuffer buffer=encoder.getInputBuffer(input);
                        ensure(buffer!=null && buffer.capacity()>=yuv.length,"Buffer encoder terlalu kecil");
                        buffer.clear();buffer.put(yuv);
                    }
                    encoder.queueInputBuffer(input,0,yuv.length,(long)f*1_000_000L/fps,0);
                }
                DrainResult d=drainVideo(encoder,muxer,track,muxStarted,info,eos);
                track=d.track;muxStarted=d.started;
                int pct=(int)(f*100L/frames);
                if(pct!=lastPct && pct%4==0){lastPct=pct;progress.onProgress(pct,"Encoding video "+pct+"%");}
            }
            ensure(muxStarted,"Encoder tidak menghasilkan stream MP4");
        } finally {
            if(previousVisual!=null)previousVisual.recycle();
            if(loopOpening!=null)loopOpening.recycle();
            if(sceneBitmap!=null)sceneBitmap.recycle();
            if(motionBitmap!=null)motionBitmap.recycle();
            if(motionNext!=null)motionNext.recycle();
            if(batch!=null)batch.close();
            if(retriever!=null)retriever.release();
            if(frame!=null)frame.recycle();
            if(encoder!=null){try{encoder.stop();}catch(Exception ignored){}encoder.release();}
            if(muxer!=null){if(muxStarted)try{muxer.stop();}catch(Exception ignored){}muxer.release();}
        }
    }
    static final class DrainResult {
        final int track;final boolean started;
        DrainResult(int track,boolean started){this.track=track;this.started=started;}
    }
    private static DrainResult drainVideo(MediaCodec enc,MediaMuxer mux,int track,boolean started,
                                          MediaCodec.BufferInfo info,boolean finish) throws Exception {
        int idle=0;boolean gotEnd=false;
        while(true){
            int out=enc.dequeueOutputBuffer(info,finish?WAIT:0);
            if(out==MediaCodec.INFO_TRY_AGAIN_LATER){if(!finish||++idle>150)break;continue;}
            if(out==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){
                ensure(!started,"Format video berubah setelah muxer dimulai");
                track=mux.addTrack(enc.getOutputFormat());mux.start();started=true;continue;
            }
            if(out>=0){
                ByteBuffer data=enc.getOutputBuffer(out);
                ensure(data!=null,"Frame video gagal dibaca");
                if((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG)!=0)info.size=0;
                if(info.size>0){ensure(started,"Video muxer belum dimulai");data.position(info.offset);data.limit(info.offset+info.size);mux.writeSampleData(track,data,info);}
                gotEnd=(info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
                enc.releaseOutputBuffer(out,false);
                if(gotEnd)break;
            }
        }
        if(finish)ensure(gotEnd,"Timeout saat menyelesaikan video H.264");
        return new DrainResult(track,started);
    }
    private static int chooseColorFormat(int[] all){
        for(int color:new int[]{MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar})
            for(int available:all)if(color==available)return color;
        return 0;
    }
    private static int y(int r,int g,int b){return clamp((66*r+129*g+25*b+128)/256+16);}
    private static int u(int r,int g,int b){return clamp((-38*r-74*g+112*b+128)/256+128);}
    private static int v(int r,int g,int b){return clamp((112*r-94*g-18*b+128)/256+128);}
    private static int clamp(int val){return Math.min(255,Math.max(0,val));}
    // Cache plane metadata once per frame, then bulk-copy contiguous rows.
    // Preserve the existing BT.601 conversion and 2x2 chroma averaging.
    private static void packImage(int[] p,int w,int h,Image img,byte[] yr,byte[] ur,byte[] vr){
        Image.Plane[] planes=img.getPlanes();
        ByteBuffer yb=planes[0].getBuffer(),ub=planes[1].getBuffer(),vb=planes[2].getBuffer();
        int ys=planes[0].getRowStride(),us=planes[1].getRowStride(),vs=planes[2].getRowStride();
        int yp=planes[0].getPixelStride(),up=planes[1].getPixelStride(),vp=planes[2].getPixelStride();
        int yo=yb.position(),uo=ub.position(),vo=vb.position();
        for(int row=0;row<h;row++){
            int base=row*w;
            for(int col=0;col<w;col++){
                int px=p[base+col];yr[col]=(byte)y((px>>>16)&255,(px>>>8)&255,px&255);
            }
            putRow(yb,yo+row*ys,yp,yr);
        }
        for(int row=0;row<h/2;row++){
            int base=row*2*w;
            for(int col=0;col<w/2;col++){
                int a=p[base+col*2],b=p[base+col*2+1],c=p[base+w+col*2],d=p[base+w+col*2+1];
                int r=((a>>>16)&255)+((b>>>16)&255)+((c>>>16)&255)+((d>>>16)&255);
                int g=((a>>>8)&255)+((b>>>8)&255)+((c>>>8)&255)+((d>>>8)&255);
                int blue=(a&255)+(b&255)+(c&255)+(d&255);
                ur[col]=(byte)u(r/4,g/4,blue/4);vr[col]=(byte)v(r/4,g/4,blue/4);
            }
            putRow(ub,uo+row*us,up,ur);putRow(vb,vo+row*vs,vp,vr);
        }
    }
    private static void putRow(ByteBuffer dst,int offset,int stride,byte[] row){
        if(stride==1){dst.position(offset);dst.put(row);}
        else for(int col=0;col<row.length;col++)dst.put(offset+col*stride,row[col]);
    }
    private static void packBytes(int[] p,int w,int h,byte[] out,int color){
        int luma=w*h,planarU=luma,planarV=luma+luma/4;
        for(int row=0;row<h;row++)for(int col=0;col<w;col++){
            int px=p[row*w+col];out[row*w+col]=(byte)y((px>>>16)&255,(px>>>8)&255,px&255);
        }
        for(int row=0;row<h/2;row++)for(int col=0;col<w/2;col++){
            int r=0,g=0,b=0;for(int yy=0;yy<2;yy++)for(int xx=0;xx<2;xx++){
                int px=p[(row*2+yy)*w+(col*2+xx)];r+=(px>>>16)&255;g+=(px>>>8)&255;b+=px&255;
            }
            int U=u(r/4,g/4,b/4),V=v(r/4,g/4,b/4),pos=row*(w/2)+col;
            if(color==MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar){out[planarU+pos]=(byte)U;out[planarV+pos]=(byte)V;}
            else {out[luma+pos*2]=(byte)U;out[luma+pos*2+1]=(byte)V;}
        }
    }
    private static Bitmap decode(File file,int maxDim){
        if(file==null || !file.isFile())return null;
        BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;
        BitmapFactory.decodeFile(file.getAbsolutePath(),bounds);
        int sample=1;while(Math.max(bounds.outWidth,bounds.outHeight)/sample>maxDim)sample*=2;
        BitmapFactory.Options opts=new BitmapFactory.Options();opts.inSampleSize=sample;
        return BitmapFactory.decodeFile(file.getAbsolutePath(),opts);
    }
    private static int sourceFrameRate(File video){
        MediaExtractor extractor=new MediaExtractor();
        try{
            extractor.setDataSource(video.getAbsolutePath());
            for(int i=0;i<extractor.getTrackCount();i++){
                MediaFormat fmt=extractor.getTrackFormat(i);
                String mime=fmt.getString(MediaFormat.KEY_MIME);
                if(mime!=null && mime.startsWith("video/")){
                    if(fmt.containsKey(MediaFormat.KEY_FRAME_RATE)){
                        int rate=fmt.getInteger(MediaFormat.KEY_FRAME_RATE);
                        if(rate>=12 && rate<=120)return Math.min(60,rate);
                    }
                    break;
                }
            }
        }catch(Exception ignored){/* Some variable frame-rate files omit metadata. */}
        finally{try{extractor.release();}catch(Exception ignored){}}
        return 30;
    }
    private static Bitmap readVideoFrame(MediaMetadataRetriever reader,FastFrameReader batch,int idx,int sourceFps,int w,int h,int scene) throws IOException{
        Bitmap cached=batch==null?null:batch.take(idx);
        if(cached!=null)return cached;
        long micros=(long)(idx*1_000_000.0/sourceFps);
        Bitmap next=reader.getScaledFrameAtTime(micros,MediaMetadataRetriever.OPTION_CLOSEST,
            Math.max(2,w),Math.max(2,h));
        ensure(next!=null,"Frame MP4 scene "+(scene+1)+" gagal dibaca. Gunakan MP4 H.264 standar atau 30 FPS.");
        return next;
    }
    private static double sceneStart(Config c,int index){return c.sceneStarts==null?c.mainSeconds*index/c.scenes.size():c.sceneStarts[index];}
    private static double sceneEnd(Config c,int index){return c.sceneStarts==null?c.mainSeconds*(index+1)/c.scenes.size():c.sceneStarts[index+1];}
    private static int sceneAt(Config c,double time){
        if(c.sceneStarts==null)return Math.min(c.scenes.size()-1,(int)(time*c.scenes.size()/c.mainSeconds));
        for(int i=1;i<c.sceneStarts.length-1;i++)if(time<c.sceneStarts[i])return i-1;
        return c.scenes.size()-1;
    }
    private static void drawScene(Canvas c,Config config,Bitmap img,Bitmap next,float blend,int index,double time, Bitmap previousVisual, Bitmap capture, Bitmap frame, Bitmap loopOpening,int frameIndex,int frameCount){
        final int w=config.width,h=config.height;
        final double slice=Math.max(.01,sceneEnd(config,index)-sceneStart(config,index));
        double offset=time-sceneStart(config,index);
        Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        paint.setShader(new LinearGradient(0,0,w,h,0xff10412c,0xff0a0c17,Shader.TileMode.CLAMP));
        c.drawRect(0,0,w,h,paint);paint.setShader(null);
        if(img!=null){
            double scale=Math.max(w/(double)img.getWidth(),h/(double)img.getHeight());
            double zoom="Smooth zoom".equals(config.effect)?1.0+0.07*offset/slice:1;
            float dw=(float)(img.getWidth()*scale*zoom),dh=(float)(img.getHeight()*scale*zoom);
            float shift="Slide pelan".equals(config.effect)?(float)((offset/slice-.5)*w*.05):0f;
            RectF dest=new RectF((w-dw)/2+shift,(h-dh)/2,(w+dw)/2+shift,(h+dh)/2);
            c.drawBitmap(img,null,dest,paint);
            if(next!=null && blend>0f){
                paint.setAlpha(Math.max(0,Math.min(255,Math.round(255*blend))));
                c.drawBitmap(next,null,dest,paint);
                paint.setAlpha(255);
            }
        }else{
            paint.setColor(0xffddfff0);paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            paint.setTextSize(w*.065f);paint.setTextAlign(Paint.Align.CENTER);
            drawLines(c,config.scenes.get(index).name,w/2f,h*.44f,w*.85f,3,paint,w*.09f);
        }
        paint.setShader(new LinearGradient(0,h*.35f,0,h,0x00000000,0xbb000000,Shader.TileMode.CLAMP));
        c.drawRect(0,h*.35f,w,h,paint);paint.setShader(null);
        if(config.fade){
            double edge=Math.min(offset,slice-offset);
            if(edge<.25){paint.setColor(Color.BLACK);paint.setAlpha((int)(110*(1-edge/.25)));c.drawRect(0,0,w,h,paint);paint.setAlpha(255);}
        }
        // Apply transition beneath subtitles and watermark; never touch narration or timestamps.
        if(capture!=null){Canvas snapshot=new Canvas(capture);snapshot.drawBitmap(frame,0,0,null);}
        float transitionAlpha=SceneTransition.alpha(config.sceneTransition,index,config.scenes.size(),offset,slice,
            index>0?sceneStart(config,index)-sceneStart(config,index-1):0);
        if(transitionAlpha>0f){
            paint.setAlpha(255);
            if("dissolve".equals(config.sceneTransition)){
                if(previousVisual!=null){paint.setAlpha(Math.round(255*transitionAlpha));c.drawBitmap(previousVisual,0,0,paint);}
            }else{
                paint.setColor("flash".equals(config.sceneTransition)?Color.WHITE:Color.BLACK);
                paint.setAlpha(Math.round(255*transitionAlpha));c.drawRect(0,0,w,h,paint);
            }
            paint.setAlpha(255);
        }
        if(config.smartLoop&&loopOpening!=null){
            if(frameIndex==0){new Canvas(loopOpening).drawBitmap(frame,0,0,null);}
            else if(index==config.scenes.size()-1){
                int seam=Math.max(2,(int)Math.round(Math.min(.30,slice*.35)*config.fps));
                float a=Math.max(0f,Math.min(1f,1f-(frameCount-1-frameIndex)/(float)(seam-1)));
                if(a>0){paint.setAlpha(Math.round(255*a));c.drawBitmap(loopOpening,0,0,paint);paint.setAlpha(255);}
            }
        }
        if(config.captions){
            String caption="";
            if(config.subtitleCues!=null){
                for(CaptionCue cue:config.subtitleCues){
                    if(time>=cue.start && time<cue.end){caption=cue.text;break;}
                }
            }
            if(caption!=null&&!caption.trim().isEmpty()){
                float base="Atas".equals(config.subtitlePosition)?h*.19f:
                      "Tengah".equals(config.subtitlePosition)?h*.53f:h*.80f;
                paint.setTypeface(android.graphics.Typeface.create("sans-serif-black",android.graphics.Typeface.BOLD));
                paint.setTextSize(w*config.subtitleSize*("bold".equals(config.subtitlePreset)?1.15f:1f));paint.setTextAlign(Paint.Align.CENTER);
                String[] lines=wrap(caption,paint,w*.82f,3);
                float step=paint.getTextSize()*1.36f;float begin=base-(lines.length-1)*step/2;
                for(int j=0;j<lines.length;j++){
                    if("documentary".equals(config.subtitlePreset)){float tw=paint.measureText(lines[j]);paint.setStyle(Paint.Style.FILL);paint.setColor(0xcc000000);c.drawRoundRect(w/2f-tw/2-w*.022f,begin+j*step-paint.getTextSize(),w/2f+tw/2+w*.022f,begin+j*step+w*.018f,w*.012f,w*.012f,paint);}
                    paint.setColor(0xff000000);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(w*.012f);paint.setStrokeJoin(Paint.Join.ROUND);
                    c.drawText(lines[j],w/2f,begin+j*step,paint);
                    paint.setStyle(Paint.Style.FILL);paint.setColor("karaoke".equals(config.subtitlePreset)?0xffffd54f:config.subtitleColor);
                    c.drawText(lines[j],w/2f,begin+j*step,paint);
                    if("highlight".equals(config.subtitlePreset)){String line=lines[j],word="";int pos=0;java.util.regex.Matcher m=java.util.regex.Pattern.compile("\\S+").matcher(line);while(m.find())if(m.group().length()>word.length()){word=m.group();pos=m.start();}if(!word.isEmpty()){float left=w/2f-paint.measureText(line)/2+paint.measureText(line.substring(0,pos));paint.setTextAlign(Paint.Align.LEFT);paint.setColor(0xffffd54f);c.drawText(word,left,begin+j*step,paint);paint.setTextAlign(Paint.Align.CENTER);}}
                }
            }
        }
        if(config.watermark!=null&&!config.watermark.trim().isEmpty()){
            paint.setTextSize(w*.028f);paint.setTextAlign(Paint.Align.CENTER);paint.setColor(0xccffffff);
            paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            c.drawText(config.watermark,w/2f,h*.065f,paint);
        }
    }
    private static void drawLines(Canvas canvas,String text,float x,float y,float width,int max,Paint paint,float gap){
        String[] lines=wrap(text,paint,width,max);
        for(int j=0;j<lines.length;j++)canvas.drawText(lines[j],x,y+j*gap,paint);
    }
    private static String[] wrap(String text,Paint paint,float width,int max){
        String[] words=(text==null?"":text).split("\\s+");
        List<String> lines=new ArrayList<>();String line="";
        for(String word:words){String next=line.isEmpty()?word:line+" "+word;
            if(!line.isEmpty() && paint.measureText(next)>width){lines.add(line);line=word; if(lines.size()==max-1)break;}
            else line=next;
        }
        if(!line.isEmpty())lines.add(line);
        return lines.toArray(new String[0]);
    }
    static void transcodeAudio(File src,File target,long durationUs) throws Exception {
        MediaExtractor extractor=new MediaExtractor();MediaCodec decoder=null,encoder=null;MediaMuxer muxer=null;
        boolean muxStarted=false;
        try {
            extractor.setDataSource(src.getAbsolutePath());
            int track=-1;MediaFormat source=null;
            for(int i=0;i<extractor.getTrackCount();i++){
                MediaFormat f=extractor.getTrackFormat(i);String mime=f.getString(MediaFormat.KEY_MIME);
                if(mime!=null&&mime.startsWith("audio/")){track=i;source=f;break;}
            }
            ensure(track>=0,"File voice-over tidak memiliki trek audio");
            extractor.selectTrack(track);
            int sampleRate=source.containsKey(MediaFormat.KEY_SAMPLE_RATE)?source.getInteger(MediaFormat.KEY_SAMPLE_RATE):44100;
            int channels=source.containsKey(MediaFormat.KEY_CHANNEL_COUNT)?source.getInteger(MediaFormat.KEY_CHANNEL_COUNT):1;
            ensure(channels>=1&&channels<=2,"Audio voice-over harus mono atau stereo");
            decoder=MediaCodec.createDecoderByType(source.getString(MediaFormat.KEY_MIME));
            decoder.configure(source,null,null,0);decoder.start();
            MediaFormat aac=MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC,sampleRate,channels);
            aac.setInteger(MediaFormat.KEY_AAC_PROFILE,MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            aac.setInteger(MediaFormat.KEY_BIT_RATE,channels==1?96000:128000);
            aac.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE,16384);
            encoder=MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
            encoder.configure(aac,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE);encoder.start();
            muxer=new MediaMuxer(target.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int outTrack=-1;boolean readEnd=false,decEnd=false,encEnd=false,encoderSignaled=false;
            long written=0,limitBytes=(long)(durationUs*sampleRate/1_000_000L)*channels*2L;
            int heldDecoder=-1;
            ByteBuffer pcm=null;
            MediaCodec.BufferInfo decInfo=new MediaCodec.BufferInfo();MediaCodec.BufferInfo encInfo=new MediaCodec.BufferInfo();
            long stale=System.currentTimeMillis();
            while(!encEnd){
                cancelIfInterrupted();boolean advanced=false;
                if(!readEnd&&!encoderSignaled){
                    int in=decoder.dequeueInputBuffer(0);
                    if(in>=0){
                        ByteBuffer b=decoder.getInputBuffer(in);ensure(b!=null,"Decoder audio buffer tidak tersedia");b.clear();
                        int n=extractor.readSampleData(b,0);
                        if(n<0){decoder.queueInputBuffer(in,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);readEnd=true;}
                        else {decoder.queueInputBuffer(in,0,n,extractor.getSampleTime(),0);extractor.advance();}
                        advanced=true;
                    }
                }
                if(heldDecoder<0&&!decEnd&&!encoderSignaled){
                    int out=decoder.dequeueOutputBuffer(decInfo,1000);
                    if(out==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){
                        MediaFormat d=decoder.getOutputFormat();
                        int actualRate=d.getInteger(MediaFormat.KEY_SAMPLE_RATE),actualChannels=d.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                        int encoding=d.containsKey(MediaFormat.KEY_PCM_ENCODING)?d.getInteger(MediaFormat.KEY_PCM_ENCODING):2;
                        ensure(actualRate==sampleRate&&actualChannels==channels&&encoding==2,"Format PCM audio tidak didukung; gunakan MP3 standar 44.1kHz/48kHz");
                        advanced=true;
                    } else if(out>=0){
                        heldDecoder=out;ByteBuffer b=decoder.getOutputBuffer(out);
                        ensure(b!=null,"Output decoder audio kosong");
                        b.position(decInfo.offset);b.limit(decInfo.offset+decInfo.size);pcm=b;
                        if((decInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0)decEnd=true;
                        advanced=true;
                    }
                }
                if(heldDecoder>=0&&!encoderSignaled){
                    int in=encoder.dequeueInputBuffer(1000);
                    if(in>=0){
                        ByteBuffer b=encoder.getInputBuffer(in);ensure(b!=null,"Encoder audio input kosong");b.clear();
                        int frameSize=channels*2;
                        int size=(int)Math.min(Math.min(b.remaining(),pcm.remaining()),Math.max(0,limitBytes-written));
                        size-=size%frameSize;
                        if(size>0){
                            int end=pcm.limit();pcm.limit(pcm.position()+size);b.put(pcm);pcm.limit(end);
                            long pts=(written/frameSize)*1_000_000L/sampleRate;
                            encoder.queueInputBuffer(in,0,size,pts,0);written+=size;
                        }else if(decEnd||written>=limitBytes){
                            encoder.queueInputBuffer(in,0,0,(written/frameSize)*1_000_000L/sampleRate,MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            encoderSignaled=true;
                        } else {
                            // Empty decoder buffer, release it and try again.
                            encoder.queueInputBuffer(in,0,0,(written/frameSize)*1_000_000L/sampleRate,0);
                        }
                        if(!pcm.hasRemaining()||written>=limitBytes){decoder.releaseOutputBuffer(heldDecoder,false);heldDecoder=-1;pcm=null;}
                        advanced=true;
                    }
                }else if(decEnd&&!encoderSignaled){
                    int in=encoder.dequeueInputBuffer(1000);
                    if(in>=0){encoder.queueInputBuffer(in,0,0,(written/(channels*2))*1_000_000L/sampleRate,MediaCodec.BUFFER_FLAG_END_OF_STREAM);encoderSignaled=true;advanced=true;}
                }
                int out=encoder.dequeueOutputBuffer(encInfo,1000);
                if(out==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){
                    ensure(!muxStarted,"Format audio berubah dua kali");outTrack=muxer.addTrack(encoder.getOutputFormat());muxer.start();muxStarted=true;advanced=true;
                }else if(out>=0){
                    ByteBuffer data=encoder.getOutputBuffer(out);
                    ensure(data!=null,"Data audio encoder kosong");
                    if((encInfo.flags&MediaCodec.BUFFER_FLAG_CODEC_CONFIG)!=0)encInfo.size=0;
                    if(encInfo.size>0){ensure(muxStarted,"Audio muxer belum mulai");data.position(encInfo.offset);data.limit(encInfo.offset+encInfo.size);muxer.writeSampleData(outTrack,data,encInfo);}
                    encEnd=(encInfo.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
                    encoder.releaseOutputBuffer(out,false);advanced=true;
                }
                if(advanced)stale=System.currentTimeMillis();
                ensure(System.currentTimeMillis()-stale<20_000,"Timeout saat konversi audio");
            }
            ensure(muxStarted,"Encoder AAC gagal dimulai");
        }finally{
            extractor.release();
            if(decoder!=null){try{decoder.stop();}catch(Exception ignored){}decoder.release();}
            if(encoder!=null){try{encoder.stop();}catch(Exception ignored){}encoder.release();}
            if(muxer!=null){if(muxStarted)try{muxer.stop();}catch(Exception ignored){}muxer.release();}
        }
    }
    static void mergeMp4(File vFile,File aFile,File output,long durationUs) throws Exception {
        MediaExtractor video=new MediaExtractor(),audio=new MediaExtractor();MediaMuxer muxer=null;boolean started=false;
        try{
            video.setDataSource(vFile.getAbsolutePath());audio.setDataSource(aFile.getAbsolutePath());
            int videoIdx=findTrack(video,"video/"),audioIdx=findTrack(audio,"audio/");
            ensure(videoIdx>=0&&audioIdx>=0,"Gagal membaca salah satu trek audio/video");
            video.selectTrack(videoIdx);audio.selectTrack(audioIdx);
            muxer=new MediaMuxer(output.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int v=muxer.addTrack(video.getTrackFormat(videoIdx));int a=muxer.addTrack(audio.getTrackFormat(audioIdx));
            muxer.start();started=true;
            copyTrack(video,muxer,v,durationUs);
            copyTrack(audio,muxer,a,durationUs);
        }finally{
            video.release();audio.release();
            if(muxer!=null){if(started)try{muxer.stop();}catch(Exception ignored){}muxer.release();}
        }
    }
    private static int findTrack(MediaExtractor ex,String prefix){
        for(int i=0;i<ex.getTrackCount();i++){
            String mime=ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
            if(mime!=null&&mime.startsWith(prefix))return i;
        }
        return -1;
    }
    private static void copyTrack(MediaExtractor ex,MediaMuxer out,int track,long maxUs) throws Exception {
        ByteBuffer buf=ByteBuffer.allocateDirect(4*1024*1024);
        MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
        while(true){
            cancelIfInterrupted();buf.clear();int len=ex.readSampleData(buf,0);
            long pts=ex.getSampleTime();if(len<0||pts<0||pts>maxUs)break;
            ensure(len<=buf.capacity(),"Sample media terlalu besar");
            info.set(0,len,pts,ex.getSampleFlags());
            buf.position(0);buf.limit(len);out.writeSampleData(track,buf,info);
            if(!ex.advance())break;
        }
    }
}
