package id.kreasiflow.studio;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import org.json.JSONArray;
import org.json.JSONObject;

final class OpenRouterStream {
    static String read(Reader source, int limit) throws Exception {
        try (BufferedReader stream = new BufferedReader(source)) {
            StringBuilder output = new StringBuilder();
            StringBuilder line = new StringBuilder();
            boolean complete = false;
            int total = 0;
            for (int c; (c = stream.read()) != -1;) {
                if (++total > limit) throw new IOException("Respons streaming terlalu besar");
                if (c != '\n') {
                    if (c != '\r') line.append((char)c);
                    continue;
                }
                String event = line.toString();
                line.setLength(0);
                if (!event.startsWith("data:")) continue;
                String payload = event.substring(5).trim();
                if ("[DONE]".equals(payload)) { complete = true; break; }
                if (payload.isEmpty()) continue;
                JSONObject chunk = new JSONObject(payload);
                JSONObject error = chunk.optJSONObject("error");
                if (error != null) {
                    int status = error.optInt("code",0);
                    throw new IOException(status >= 400 && status <= 599 ? "HTTP " + status : "Respons streaming ditolak provider");
                }
                JSONArray choices = chunk.optJSONArray("choices");
                JSONObject choice = choices == null ? null : choices.optJSONObject(0);
                if (choice == null) continue;
                String reason = choice.optString("finish_reason","");
                if ("length".equals(reason) || "error".equals(reason) || "content_filter".equals(reason)) {
                    throw new IOException("Naskah streaming tidak lengkap");
                }
                JSONObject delta = choice.optJSONObject("delta");
                if (delta != null && delta.opt("content") instanceof String) output.append(delta.optString("content"));
            }
            if (!complete || output.toString().trim().isEmpty()) throw new IOException("Naskah streaming terpotong");
            return new JSONObject().put("choices",new JSONArray().put(new JSONObject()
                .put("message",new JSONObject().put("content",output.toString())))).toString();
        }
    }
}
