package id.kreasiflow.studio;

import android.content.Context;
import android.net.Uri;
import android.webkit.WebResourceResponse;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.*;
import java.util.zip.*;

/** Private, persistent project store. Nothing here contains provider credentials. */
final class ProjectStore {
    static final String BASE = "https://appassets.androidplatform.net/project-media/";
    static final long MAX_ASSET = 250L * 1024 * 1024;
    static final long MAX_ARCHIVE_UNPACKED = 2L * 1024 * 1024 * 1024;
    private static final int MAX_FILES = 160;
    private final File root;
    ProjectStore(Context context) throws IOException {
        root = new File(context.getFilesDir(),"saved-projects-v1");
        if(!root.isDirectory() && !root.mkdirs()) throw new IOException("Tidak dapat membuat folder proyek");
    }
    static boolean validId(String id){return id!=null && id.matches("[a-z0-9-]{12,72}");}
    static boolean validKey(String key){return key!=null && key.matches("(?:audio|music|storyboard_sheet|scene_image_[0-9]{1,3}|scene_clip_[0-9]{1,3}|edu_(?:character|object|setting)|toon_[a-z0-9-]{1,56})");}
    private static String extension(String mime) {
        if("video/mp4".equals(mime))return "mp4";
        if("image/png".equals(mime))return "png";
        if("image/webp".equals(mime))return "webp";
        if("image/jpeg".equals(mime))return "jpg";
        if("audio/wav".equals(mime)||"audio/x-wav".equals(mime))return "wav";
        if("audio/mp4".equals(mime)||"audio/x-m4a".equals(mime))return "m4a";
        if("audio/ogg".equals(mime))return "ogg";
        if("audio/mpeg".equals(mime)||"audio/mp3".equals(mime))return "mp3";
        throw new IllegalArgumentException("Jenis media tidak didukung: "+mime);
    }
    static String mimeOf(File file){
        String n=file.getName().toLowerCase(Locale.US);
        if(n.endsWith(".mp4"))return "video/mp4";
        if(n.endsWith(".png"))return "image/png";
        if(n.endsWith(".webp"))return "image/webp";
        if(n.endsWith(".jpg"))return "image/jpeg";
        if(n.endsWith(".wav"))return "audio/wav";
        if(n.endsWith(".m4a"))return "audio/mp4";
        if(n.endsWith(".ogg"))return "audio/ogg";
        if(n.endsWith(".mp3"))return "audio/mpeg";
        return "application/octet-stream";
    }
    private File dir(String id) throws IOException {
        if(!validId(id))throw new IOException("ID proyek tidak valid");
        return new File(root,id);
    }
    private static void mkdir(File target) throws IOException {
        if(!target.isDirectory() && !target.mkdirs())throw new IOException("Gagal membuat direktori media proyek");
    }
    private static void copyBounded(InputStream in,OutputStream out,long max) throws IOException {
        byte[] buffer=new byte[65536];long size=0;int n;
        while((n=in.read(buffer))!=-1){size+=n;if(size>max)throw new IOException("Berkas melebihi batas ukuran proyek");out.write(buffer,0,n);}
    }
    private static void copyFile(File src,File dest,long limit) throws IOException {
        if(!src.isFile()||src.length()<1||src.length()>limit)throw new IOException("Berkas media tidak ditemukan / terlalu besar");
        File tmp=new File(dest.getParentFile(),dest.getName()+".writing");
        try(InputStream in=new FileInputStream(src);OutputStream out=new FileOutputStream(tmp)) {copyBounded(in,out,limit);}
        try { Files.move(tmp.toPath(),dest.toPath(),StandardCopyOption.REPLACE_EXISTING); }
        finally {tmp.delete();}
    }
    private static String cleanName(String name){
        if(name==null)return "media";
        return name.replaceAll("[\\r\\n\\t\\u0000-\\u001f]", " ").trim().substring(0,Math.min(100,name.trim().length()));
    }
    // Saved MP4 can be re-registered as an existing native render asset after app restart.
    synchronized File findSavedClip(String id,int index) throws IOException {
        if(index<0||index>=36)throw new IOException("Nomor scene tidak valid");
        File file=new File(new File(dir(id),"media"),"scene_clip_"+index+".mp4");
        return file.isFile() && file.length()>0 && file.length()<=MAX_ASSET ? file : null;
    }
    synchronized JSONObject saveAsset(String id,String key,File source,String mime,String original) throws IOException {
        if(!validKey(key))throw new IOException("Jenis aset proyek tidak dikenal");
        String ext;
        try { ext=extension(mime); }catch(IllegalArgumentException e){throw new IOException(e.getMessage());}
        if(key.startsWith("scene_clip_") && !"mp4".equals(ext))throw new IOException("Klip scene harus MP4");
        if((key.equals("storyboard_sheet")||key.startsWith("scene_image_")||key.startsWith("edu_")||key.startsWith("toon_"))&&!Arrays.asList("png","webp","jpg").contains(ext))throw new IOException("Referensi harus gambar");
        if(("audio".equals(key)||"music".equals(key))&&!Arrays.asList("mp3","wav","m4a","ogg").contains(ext))throw new IOException("VO / musik harus audio");
        File targetDir=new File(dir(id),"media");mkdir(targetDir);
        File target=new File(targetDir,key+"."+ext);
        copyFile(source,target,MAX_ASSET);
        for(File old:Objects.requireNonNull(targetDir.listFiles()))if(old.isFile()&&old.getName().startsWith(key+".")&&!old.equals(target))old.delete();
        JSONObject data=new JSONObject();
        try {data.put("url",BASE+id+"/"+target.getName());data.put("name",cleanName(original));data.put("mime",mime);data.put("size",target.length());}
        catch(Exception e){throw new IOException("Gagal menyimpan informasi media",e);}
        return data;
    }
    synchronized void removeAsset(String id,String key) throws IOException {
        if(!validKey(key))throw new IOException("ID media tidak valid");
        File media=new File(dir(id),"media");
        File[] files=media.listFiles();if(files==null)return;
        for(File f:files)if(f.getName().startsWith(key+"."))f.delete();
    }
    synchronized void saveProject(String id,String rawJson) throws IOException {
        if(rawJson==null||rawJson.length()>2_000_000)throw new IOException("Proyek terlalu besar (maks. 2 MB metadata)");
        JSONObject obj;
        try {obj=new JSONObject(rawJson);obj.put("projectId",id);}
        catch(Exception e){throw new IOException("Data proyek JSON tidak valid",e);}
        File folder=dir(id);mkdir(folder);
        File dest=new File(folder,"project.json");File tmp=new File(folder,"project.json.writing");
        try(OutputStream out=new FileOutputStream(tmp)){out.write(obj.toString().getBytes(StandardCharsets.UTF_8));}
        try{Files.move(tmp.toPath(),dest.toPath(),StandardCopyOption.REPLACE_EXISTING);}
        finally{tmp.delete();}
    }
    synchronized JSONObject loadProject(String id) throws IOException {
        File metadata=new File(dir(id),"project.json");
        if(!metadata.isFile()||metadata.length()>2_000_000)throw new IOException("Proyek tidak ditemukan / rusak");
        try {
            byte[] b=Files.readAllBytes(metadata.toPath());
            JSONObject result=new JSONObject();result.put("project",new JSONObject(new String(b,StandardCharsets.UTF_8)));
            JSONObject media=new JSONObject();
            File folder=new File(dir(id),"media");File[] files=folder.listFiles();
            if(files!=null)for(File f:files) {
                if(!f.isFile()||!f.getName().matches("[a-z0-9_-]{1,80}\\.(?:mp4|mp3|wav|m4a|ogg|png|jpg|webp)"))continue;
                String key=f.getName().substring(0,f.getName().lastIndexOf('.'));
                if(!validKey(key))continue;
                media.put(key,new JSONObject().put("url",BASE+id+"/"+f.getName()).put("mime",mimeOf(f)).put("size",f.length()));
            }
            result.put("assets",media);return result;
        }catch(Exception e){throw new IOException("Gagal membaca proyek: "+e.getMessage(),e);}
    }
    synchronized JSONArray listProjects() {
        JSONArray arr=new JSONArray();
        File[] files=root.listFiles();if(files==null)return arr;
        Arrays.sort(files,(a,b)->Long.compare(new File(b,"project.json").lastModified(),new File(a,"project.json").lastModified()));
        for(File d:files){if(!d.isDirectory()||!validId(d.getName()))continue;
            File meta=new File(d,"project.json");if(!meta.isFile()||meta.length()>2_000_000)continue;
            try{
                JSONObject p=new JSONObject(new String(Files.readAllBytes(meta.toPath()),StandardCharsets.UTF_8));
                File m=new File(d,"media");int count=0;long size=0;File[] media=m.listFiles();if(media!=null)for(File f:media)if(f.isFile()&&!f.getName().endsWith(".writing")){count++;size+=f.length();}
                String name=p.optString("projectName",p.optString("selected",p.optString("title","Proyek")));
                if("Project baru".equals(name))name=p.optString("selected",p.optString("title","Project baru"));
                if(name.length()>100)name=name.substring(0,100);
                arr.put(new JSONObject().put("id",d.getName()).put("name",name)
                        .put("updatedAt",meta.lastModified()).put("mediaCount",count).put("mediaBytes",size));
            }catch(Exception ignored){}
        }
        return arr;
    }
    synchronized String duplicate(String id,String newId) throws IOException {
        JSONObject src=loadProject(id);if(new File(dir(newId),"project.json").exists())throw new IOException("ID proyek sudah ada");
        File sourceMedia=new File(dir(id),"media");File destination=new File(dir(newId),"media");
        try {
            if(sourceMedia.isDirectory()){mkdir(destination);File[] files=sourceMedia.listFiles();if(files!=null)for(File f:files)if(f.isFile()&&!f.getName().endsWith(".writing"))copyFile(f,new File(destination,f.getName()),MAX_ASSET);}
            JSONObject copy=src.getJSONObject("project");copy.put("projectId",newId);
            String base=copy.optString("projectName",copy.optString("selected","Proyek"));
            copy.put("projectName",base.substring(0,Math.min(85,base.length()))+" (salinan)");
            saveProject(newId,copy.toString());return newId;
        }catch(Exception e){deleteRecursive(new File(root,newId));throw new IOException("Gagal menggandakan proyek",e);}
    }
    synchronized void deleteProject(String id) throws IOException {
        File folder=dir(id);if(!folder.isDirectory())throw new IOException("Proyek tidak ditemukan");deleteRecursive(folder);
    }
    private static void deleteRecursive(File f){File[] list=f.listFiles();if(list!=null)for(File c:list)deleteRecursive(c);f.delete();}
    synchronized File mediaFile(String id,String fileName){
        if(!validId(id)||fileName==null||!fileName.matches("[a-z0-9_-]{1,80}\\.(?:mp4|mp3|wav|m4a|ogg|png|jpg|webp)"))return null;
        String key=fileName.substring(0,fileName.lastIndexOf('.'));if(!validKey(key))return null;
        File f=new File(new File(new File(root,id),"media"),fileName);
        return f.isFile()?f:null;
    }
    synchronized WebResourceResponse serveMedia(String urlPath,String rangeHeader) {
        if(urlPath==null||!urlPath.startsWith("/project-media/"))return null;
        String suffix=urlPath.substring("/project-media/".length());String[] parts=suffix.split("/",-1);
        if(parts.length!=2)return errorResponse(404,"Not found");
        File f=mediaFile(parts[0],parts[1]);if(f==null)return errorResponse(404,"Not found");
        try {
            long total=f.length();long start=0,end=total-1;boolean partial=false;
            if(rangeHeader!=null&&rangeHeader.startsWith("bytes=")){
                java.util.regex.Matcher m=java.util.regex.Pattern.compile("bytes=(\\d*)-(\\d*)").matcher(rangeHeader.trim());
                if(!m.matches() || (m.group(1).isEmpty()&&m.group(2).isEmpty()))return errorResponse(416,"Invalid range");
                if(m.group(1).isEmpty()){
                    long tailBytes=Long.parseLong(m.group(2));if(tailBytes<=0)return errorResponse(416,"Invalid range");
                    start=Math.max(0,total-tailBytes);
                }else{
                    start=Long.parseLong(m.group(1));end=m.group(2).isEmpty()?end:Math.min(end,Long.parseLong(m.group(2)));
                }
                if(start>=total||end<start)return errorResponse(416,"Invalid range");
                partial=true;
            }
            InputStream src=new FileInputStream(f);long skipped=0;
            while(skipped<start){long delta=src.skip(start-skipped);if(delta<=0){src.close();return errorResponse(416,"Invalid range");}skipped+=delta;}
            final long allowed=end-start+1;
            InputStream bounded=new FilterInputStream(src){long remaining=allowed;
                @Override public int read()throws IOException{if(remaining<=0)return -1;int b=super.read();if(b!=-1)remaining--;return b;}
                @Override public int read(byte[] b,int off,int len)throws IOException{if(remaining<=0)return -1;int n=super.read(b,off,(int)Math.min(len,remaining));if(n>0)remaining-=n;return n;}
            };
            Map<String,String> headers=new HashMap<>();headers.put("Accept-Ranges","bytes");headers.put("Content-Length",String.valueOf(allowed));headers.put("Cache-Control","private, max-age=3600");
            if(partial)headers.put("Content-Range","bytes "+start+"-"+end+"/"+total);
            return new WebResourceResponse(mimeOf(f),null,partial?206:200,partial?"Partial Content":"OK",headers,bounded);
        }catch(Exception e){return errorResponse(500,"Media read failed");}
    }
    private static WebResourceResponse errorResponse(int code,String message){return new WebResourceResponse("text/plain","UTF-8",code,message,Collections.singletonMap("Cache-Control","no-store"),new ByteArrayInputStream(new byte[0]));}

    synchronized void writeZip(String id,OutputStream out) throws IOException {
        JSONObject loaded=loadProject(id);
        try(ZipOutputStream zip=new ZipOutputStream(new BufferedOutputStream(out))){zip.setLevel(1);
            byte[] metadata=loaded.getJSONObject("project").toString().getBytes(StandardCharsets.UTF_8);
            zip.putNextEntry(new ZipEntry("project.json"));zip.write(metadata);zip.closeEntry();
            File media=new File(dir(id),"media");File[] files=media.listFiles();
            if(files!=null){int count=0;long total=0;for(File f:files){if(!f.isFile()||f.getName().endsWith(".writing"))continue;
                if(++count>MAX_FILES||f.length()>MAX_ASSET||(total+=f.length())>MAX_ARCHIVE_UNPACKED)throw new IOException("Backup terlalu besar");
                zip.putNextEntry(new ZipEntry("media/"+f.getName()));try(InputStream in=new FileInputStream(f)){copyBounded(in,zip,MAX_ASSET);}zip.closeEntry();
            }}
            zip.finish();
        }catch(Exception e){if(e instanceof IOException)throw (IOException)e;throw new IOException("Gagal menulis backup",e);}
    }
    synchronized String readZip(InputStream input) throws IOException {
        String id="p-"+UUID.randomUUID().toString();File folder=dir(id);mkdir(folder);
        File media=new File(folder,"media");JSONObject project=null;long total=0;int count=0;
        Set<String> names=new HashSet<>();
        try(ZipInputStream zip=new ZipInputStream(new BufferedInputStream(input))){
            ZipEntry entry;
            while((entry=zip.getNextEntry())!=null){String path=entry.getName();
                if(++count>MAX_FILES+8||!names.add(path))throw new IOException("Terlalu banyak / duplikat berkas pada ZIP");
                if(entry.isDirectory()){
                    if(!"media/".equals(path))throw new IOException("Folder ZIP tidak dikenal");
                    zip.closeEntry();continue;
                }
                if(!"project.json".equals(path)&&!path.matches("media/[a-z0-9_-]{1,80}\\.(?:mp4|mp3|wav|m4a|ogg|png|jpg|webp)"))throw new IOException("ZIP berisi lokasi file tidak aman");
                if(path.startsWith("media/")){
                    String filename=path.substring(6);
                    String key=filename.substring(0,filename.lastIndexOf('.'));
                    if(!validKey(key))throw new IOException("Media ZIP tidak sesuai skema proyek");
                }
                long limit="project.json".equals(path)?2_000_000:MAX_ASSET;
                File dest="project.json".equals(path)?new File(folder,"project.json"):new File(media,path.substring(6));
                if(dest.getParentFile().equals(media))mkdir(media);
                long written=0;byte[] buf=new byte[65536];int n;
                try(OutputStream out=new FileOutputStream(dest)){
                    while((n=zip.read(buf))!=-1){written+=n;total+=n;
                        if(written>limit||total>MAX_ARCHIVE_UNPACKED)throw new IOException("Ukuran backup melewati batas");out.write(buf,0,n);
                    }
                }
                zip.closeEntry();
            }
            File meta=new File(folder,"project.json");if(!meta.isFile()||meta.length()>2_000_000)throw new IOException("Manifest proyek tidak ditemukan");
            try{project=new JSONObject(new String(Files.readAllBytes(meta.toPath()),StandardCharsets.UTF_8));project.put("projectId",id);}
            catch(Exception e){throw new IOException("Manifest proyek tidak valid",e);}
            saveProject(id,project.toString());return id;
        }catch(Exception e){deleteRecursive(folder);if(e instanceof IOException)throw (IOException)e;throw new IOException("Impor ZIP gagal",e);}
    }
}
