package id.kreasiflow.studio;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.util.Log;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Per-device BYOK storage. API keys are not committed, exported into projects,
 * sent back into JavaScript, nor stored in cleartext SharedPreferences.
 * Device compromise can still compromise locally held secrets: for a shared
 * application, replace this with an authenticated server-side proxy.
 */
final class ProviderSecrets {
    private static final String ALIAS = "kreasiflow.ai.provider-keys.v1";
    private final SharedPreferences store;

    ProviderSecrets(Context context) {
        store = context.getSharedPreferences("kreasiflow_provider_keys", Context.MODE_PRIVATE);
    }

    private static boolean allowed(String provider) {
        return "openrouter".equals(provider) || "fal".equals(provider) || "elevenlabs".equals(provider);
    }

    synchronized boolean save(String provider, String key) {
        if (!allowed(provider) || key == null || key.trim().length() < 8 || key.length() > 512) return false;
        try {
            byte[] nonce = new byte[12];
            new SecureRandom().nextBytes(nonce);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, aesKey(), new GCMParameterSpec(128, nonce));
            byte[] encrypted = c.doFinal(key.trim().getBytes(StandardCharsets.UTF_8));
            byte[] out = new byte[nonce.length + encrypted.length];
            System.arraycopy(nonce, 0, out, 0, nonce.length);
            System.arraycopy(encrypted, 0, out, nonce.length, encrypted.length);
            return store.edit().putString(provider, Base64.encodeToString(out, Base64.NO_WRAP)).commit();
        } catch (Exception e) {
            Log.e("KreasiFlow", "Unable to encrypt provider credential", e);
            return false;
        }
    }

    synchronized String get(String provider) {
        if (!allowed(provider)) return null;
        String encoded = store.getString(provider, null);
        if (encoded == null) return null;
        try {
            byte[] bytes = Base64.decode(encoded, Base64.NO_WRAP);
            if (bytes.length < 29) return null;
            byte[] nonce = new byte[12];
            System.arraycopy(bytes, 0, nonce, 0, nonce.length);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, aesKey(), new GCMParameterSpec(128, nonce));
            return new String(c.doFinal(bytes, nonce.length, bytes.length - nonce.length), StandardCharsets.UTF_8);
        } catch (Exception e) {
            Log.w("KreasiFlow", "Credential unavailable (device key changed?)", e);
            return null;
        }
    }

    synchronized void delete(String provider) {
        if (allowed(provider)) store.edit().remove(provider).apply();
    }

    private SecretKey aesKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        KeyStore.Entry existing = ks.getEntry(ALIAS, null);
        if (existing instanceof KeyStore.SecretKeyEntry) return ((KeyStore.SecretKeyEntry) existing).getSecretKey();
        KeyGenerator gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build());
        return gen.generateKey();
    }
}
