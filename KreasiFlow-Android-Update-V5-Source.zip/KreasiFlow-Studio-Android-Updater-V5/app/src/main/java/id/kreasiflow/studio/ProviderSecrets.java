package id.kreasiflow.studio;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.util.Log;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Per-device BYOK storage. API keys are not committed, exported into projects,
 * sent back into JavaScript, nor stored in cleartext SharedPreferences.
 * Device compromise can still compromise locally held secrets: for a shared
 * application, replace this with an authenticated server-side proxy.
 */
final class ProviderSecrets {
    private static final String ALIAS = "kreasiflow.ai.provider-keys.v1";
    private final SharedPreferences store;
    private String lastSaveError = "";

    synchronized String lastSaveError() {
        return lastSaveError;
    }

    ProviderSecrets(Context context) {
        store = context.getSharedPreferences("kreasiflow_provider_keys", Context.MODE_PRIVATE);
    }

    private static boolean allowed(String provider) {
        return "openrouter".equals(provider) || "cloudflare".equals(provider) || "cloudflare_account".equals(provider) || "elevenlabs".equals(provider) || "groq".equals(provider) || "replicate".equals(provider) || "gemini".equals(provider);
    }

    synchronized boolean save(String provider, String key) {
        if (!allowed(provider) || key == null || key.trim().length() < 8 || key.trim().length() > 512) {
            lastSaveError = "API key tidak valid (8–512 karakter)";
            return false;
        }
        // The OpenRouter dashboard supplies a bare sk-or-... token. If a user
        // accidentally pastes the whole "Bearer <token>" form, normalize it
        // before encrypting; never place two Bearer prefixes on the wire.
        String normalized = key.trim();
        if ("cloudflare_account".equals(provider)) {
            if (!normalized.matches("(?i)[0-9a-f]{32}")) {
                lastSaveError = "Account ID Cloudflare harus 32 karakter hexadecimal";
                return false;
            }
        }
        if ("openrouter".equals(provider)) {
            if (normalized.regionMatches(true, 0, "Bearer ", 0, 7)) {
                normalized = normalized.substring(7).trim();
            }
            if (!normalized.startsWith("sk-or-") || !normalized.matches("[A-Za-z0-9._-]+")) {
                lastSaveError = "OpenRouter: masukkan hanya nilai API key yang diawali sk-or- (tanpa Bearer, kutip, atau spasi)";
                return false;
            }
        }
        try {
            // AndroidKeyStore rejects caller-supplied IVs when randomized encryption
            // is required (the secure default). Let the Cipher generate its own IV.
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, aesKey());
            byte[] nonce = c.getIV();
            if (nonce == null || nonce.length != 12) {
                throw new IllegalStateException("AndroidKeystore did not produce a 96-bit GCM IV");
            }
            byte[] encrypted = c.doFinal(normalized.getBytes(StandardCharsets.UTF_8));
            byte[] out = new byte[nonce.length + encrypted.length];
            System.arraycopy(nonce, 0, out, 0, nonce.length);
            System.arraycopy(encrypted, 0, out, nonce.length, encrypted.length);
            boolean saved = store.edit().putString(provider, Base64.encodeToString(out, Base64.NO_WRAP)).commit();
            lastSaveError = saved ? "" : "Penyimpanan perangkat tidak dapat ditulis";
            return saved;
        } catch (Exception e) {
            // Only the exception class is surfaced to the UI, never a credential.
            lastSaveError = "Penyimpanan terenkripsi gagal (" + e.getClass().getSimpleName() + ")";
            Log.e("KreasiFlow", "Unable to encrypt provider credential", e);
            return false;
        }
    }

    synchronized String get(String provider) {
        if (!allowed(provider)) return null;
        String encoded = store.getString(provider, null);
        if (encoded == null) return null;
        try {
            byte[] bytes = Base64.decode(encoded, Base64.NO_WRAP);
            if (bytes.length < 29) return null;
            byte[] nonce = new byte[12];
            System.arraycopy(bytes, 0, nonce, 0, nonce.length);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, aesKey(), new GCMParameterSpec(128, nonce));
            return new String(c.doFinal(bytes, nonce.length, bytes.length - nonce.length), StandardCharsets.UTF_8);
        } catch (Exception e) {
            Log.w("KreasiFlow", "Credential unavailable (device key changed?)", e);
            return null;
        }
    }

    synchronized void delete(String provider) {
        if (allowed(provider)) store.edit().remove(provider).apply();
    }

    private SecretKey aesKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        KeyStore.Entry existing = ks.getEntry(ALIAS, null);
        if (existing instanceof KeyStore.SecretKeyEntry) return ((KeyStore.SecretKeyEntry) existing).getSecretKey();
        KeyGenerator gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build());
        return gen.generateKey();
    }
}
