package id.kreasiflow.studio;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Query rilis stabil publik dari repository yang disematkan saat build APK. */
final class ReleaseApi {
    static final String APK_ASSET = "KreasiFlow-Studio.apk";

    static final class Release {
        final String version;
        final String tag;
        final String notes;
        final String pageUrl;
        final String apkUrl;
        final String sha256;
        Release(String v, String t, String n, String page, String apk, String hash) {
            version=v;tag=t;notes=n;pageUrl=page;apkUrl=apk;sha256=hash;
        }
        boolean isNewer() { return compare(version, BuildConfig.VERSION_NAME) > 0; }
        boolean canInstallInsideApp() { return apkUrl!=null && sha256!=null; }
    }

    static boolean isConfigured() {
        return !"SET_OWNER".equals(BuildConfig.GITHUB_OWNER) && !BuildConfig.GITHUB_OWNER.isEmpty();
    }

    static Release latest() throws Exception {
        if (!isConfigured()) throw new IOException("Repo GitHub belum disetel saat build APK.");
        String base = "https://github.com/" + BuildConfig.GITHUB_OWNER + "/" + BuildConfig.GITHUB_REPOSITORY;
        URL url = new URL("https://api.github.com/repos/" + BuildConfig.GITHUB_OWNER + "/" + BuildConfig.GITHUB_REPOSITORY + "/releases/latest");
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        con.setRequestProperty("Accept", "application/vnd.github+json");
        con.setRequestProperty("User-Agent", "KreasiFlow-Studio-Android/" + BuildConfig.VERSION_NAME);
        con.setConnectTimeout(12000);
        con.setReadTimeout(12000);
        try {
            int code=con.getResponseCode();
            if (code==404) return null; // Belum ada release stabil (atau repo privat).
            if (code!=200) throw new IOException("GitHub HTTP " + code);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try(BufferedInputStream in = new BufferedInputStream(con.getInputStream())) {
                byte[] buf=new byte[8192]; int len;
                while((len=in.read(buf))!=-1){
                    if(out.size()+len>1024*1024) throw new IOException("Metadata rilis terlalu besar");
                    out.write(buf,0,len);
                }
            }
            JSONObject json = new JSONObject(new String(out.toByteArray(), StandardCharsets.UTF_8));
            if(json.optBoolean("draft")||json.optBoolean("prerelease")) return null;
            String tag=json.optString("tag_name", "");
            String ver=cleanVersion(tag);
            if(ver==null) throw new IOException("Tag release harus vMAJOR.MINOR.PATCH");
            String page=json.optString("html_url", "");
            if(!page.startsWith(base + "/releases/tag/")) page=base+"/releases/latest";
            String apkUrl=null,sha=null;
            JSONArray assets=json.optJSONArray("assets");
            if(assets!=null){
                for(int i=0;i<assets.length();i++){
                    JSONObject asset=assets.optJSONObject(i);
                    if(asset!=null && APK_ASSET.equals(asset.optString("name"))){
                        String candidate=asset.optString("browser_download_url", "");
                        String digest=asset.optString("digest", "");
                        if(candidate.startsWith(base+"/releases/download/") && candidate.endsWith("/"+APK_ASSET)) apkUrl=candidate;
                        if(digest.matches("sha256:[0-9a-fA-F]{64}"))sha=digest.substring(7).toLowerCase(Locale.US);
                        break;
                    }
                }
            }
            String notes=json.optString("body", "");
            if(notes.length()>1000)notes=notes.substring(0,1000)+"…";
            return new Release(ver,tag,notes,page,apkUrl,sha);
        } finally { con.disconnect(); }
    }

    static String cleanVersion(String tag){
        String s=tag.startsWith("v")||tag.startsWith("V")?tag.substring(1):tag;
        if(!s.matches("(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)\\.(0|[1-9][0-9]*)"))return null;
        return s;
    }
    static int compare(String one, String two){
        String a=cleanVersion(one), b=cleanVersion(two);
        if(a==null||b==null)return 0;
        String[] aa=a.split("\\."),bb=b.split("\\.");
        for(int i=0;i<3;i++){
            // Avoid integer overflow from unexpected gigantic tag components.
            String left=aa[i].replaceFirst("^0+(?!$)", "");
            String right=bb[i].replaceFirst("^0+(?!$)", "");
            if(left.length()!=right.length())return Integer.compare(left.length(),right.length());
            int c=left.compareTo(right); if(c!=0)return c;
        }
        return 0;
    }
}
