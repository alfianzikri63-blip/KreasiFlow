package id.kreasiflow.studio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Android-owned foreground render job. No WebView, Activity or UI handler reference:
 * encoding can continue while the Activity is paused/destroyed.
 * Android can still terminate processes (force-stop, vendor battery manager, low memory).
 */
public final class RenderForegroundService extends Service {
    private static final String TAG="KFBackgroundRender";
    private static final String CHANNEL="kf_render_ongoing_v1";
    private static final int NOTIFICATION_ID=8451;
    private static final String PREF="kf_render_service_status";
    private static final String ACTION_RUN="id.kreasiflow.studio.RUN_RENDER";
    private static final String ACTION_CANCEL="id.kreasiflow.studio.CANCEL_RENDER";
    private static final String EXTRA_JOB="job";
    private static final AtomicBoolean ACTIVE=new AtomicBoolean(false);
    private volatile Thread worker;
    private volatile boolean cancelled=false;
    private volatile boolean timedOut=false;
    private JSONObject assetPaths;
    private String jobId="";
    private File jobFile;
    private long lastUiUpdate=0;
    private int lastPercent=-1;
    private PowerManager.WakeLock wakeLock;
    private RenderStats685 stats;
    private long jobStartedAt;
    private int progressColor=0xff8b5cf6;
    private static final java.util.concurrent.atomic.AtomicReference<String> CANCELLED_JOB=new java.util.concurrent.atomic.AtomicReference<>();


    public static JSONObject status(Context c){
        String raw=c.getSharedPreferences(PREF,MODE_PRIVATE).getString("status","");
        if(raw.isEmpty())return new JSONObject();
        try{
            JSONObject o=new JSONObject(raw);
            // If the process was killed, START_NOT_STICKY cannot preserve a job.
            if(("running".equals(o.optString("state")) || "queued".equals(o.optString("state"))) && !ACTIVE.get()){
                o.put("state","interrupted");
                o.put("message","Render terhenti karena proses Android dihentikan. Jalankan ulang dari aplikasi.");
                c.getSharedPreferences(PREF,MODE_PRIVATE).edit().putString("status",o.toString()).apply();
            }
            return o;
        }catch(Exception e){return new JSONObject();}
    }
    private void record(String state,int percent,String message,Uri uri){
        try{
            JSONObject data=new JSONObject().put("state",state).put("percent",percent)
                .put("message",message).put("jobId",jobId).put("startedAt",jobStartedAt).put("updatedAt",System.currentTimeMillis());
            if(stats!=null)data.put("telemetry",stats.json());
            if(uri!=null)data.put("uri",uri.toString());
            getSharedPreferences(PREF,MODE_PRIVATE).edit().putString("status",data.toString()).apply();
        }catch(Exception ex){Log.w(TAG,"Tidak bisa menyimpan status render",ex);}
    }
    static void enqueue(Context context,String mode,JSONObject config,JSONObject assets)throws Exception{
        if(!("moving".equals(mode)||"slideshow".equals(mode)))throw new IOException("Mode render tidak dikenal");
        if(!ACTIVE.compareAndSet(false,true))throw new IOException("Render lain masih berjalan di latar. Lihat notifikasi.");
        File dir=new File(context.getFilesDir(),"render-jobs");
        try{
            if(!dir.exists()&&!dir.mkdirs())throw new IOException("Folder antrian render tidak dapat dibuat");
            String id=java.util.UUID.randomUUID().toString();
            JSONObject job=new JSONObject().put("jobId",id).put("mode",mode)
                .put("config",config).put("assets",assets);
            File file=new File(dir,id+".json");
            try(FileOutputStream out=new FileOutputStream(file)){
                out.write(job.toString().getBytes(StandardCharsets.UTF_8));out.getFD().sync();
            }
            JSONObject queued=new JSONObject().put("state","queued").put("percent",0)
                .put("message","Render masuk antrian layanan Android...")
                .put("jobId",id).put("startedAt",System.currentTimeMillis()).put("updatedAt",System.currentTimeMillis());
            if(!context.getSharedPreferences(PREF,MODE_PRIVATE).edit()
                .putString("status",queued.toString()).commit())
                throw new IOException("Status render tidak dapat disimpan");
            Intent intent=new Intent(context,RenderForegroundService.class).setAction(ACTION_RUN)
                .putExtra(EXTRA_JOB,id);
            ContextCompat.startForegroundService(context,intent);
        }catch(Exception ex){
            ACTIVE.set(false);
            JSONObject failed=new JSONObject().put("state","error").put("percent",0)
                .put("message","Layanan render tidak dapat dimulai: "+ex.getMessage())
                .put("jobId","").put("updatedAt",System.currentTimeMillis());
            context.getSharedPreferences(PREF,MODE_PRIVATE).edit().putString("status",failed.toString()).apply();
            throw ex;
        }
    }
    static boolean isActive685(){return ACTIVE.get();}
    static boolean cancel(Context context,String id){
        if(id==null||!id.matches("[a-f0-9-]{36}")||!ACTIVE.get())return false;
        JSONObject current=status(context);
        if(!id.equals(current.optString("jobId"))||!("queued".equals(current.optString("state"))||"running".equals(current.optString("state"))))return false;
        CANCELLED_JOB.set(id);
        try { context.startService(new Intent(context,RenderForegroundService.class).setAction(ACTION_CANCEL).putExtra(EXTRA_JOB,id));return true; }
        catch(RuntimeException failure){CANCELLED_JOB.compareAndSet(id,null);return false;}
    }
    @Override public IBinder onBind(Intent intent){return null;}
    @Override public void onCreate(){
        super.onCreate();
        NotificationManager nm=getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL,"KreasiFlow — Proses render",NotificationManager.IMPORTANCE_LOW));
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null){stopSelf();return START_NOT_STICKY;}
        if(ACTION_CANCEL.equals(intent.getAction())){
            String requested=intent.getStringExtra(EXTRA_JOB);
            if(requested!=null&&requested.equals(jobId)){
                cancelled=true;
                Thread t=worker;if(t!=null)t.interrupt();
            }
            return START_NOT_STICKY;
        }
        if(!ACTION_RUN.equals(intent.getAction())||worker!=null){return START_NOT_STICKY;}
        jobId=intent.getStringExtra(EXTRA_JOB);
        if(jobId==null||!jobId.matches("[a-f0-9-]{36}")){
            ACTIVE.set(false);stopSelf();return START_NOT_STICKY;
        }
        jobStartedAt=System.currentTimeMillis();
        jobFile=new File(new File(getFilesDir(),"render-jobs"),jobId+".json");
        try{
            Notification notification=notification("Mempersiapkan render MP4...",0,true);
            if(Build.VERSION.SDK_INT>=35)startForeground(NOTIFICATION_ID,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING);
            else startForeground(NOTIFICATION_ID,notification);
        }catch(Exception e){
            Log.e(TAG,"Foreground start failed",e);
            record("error",0,"Android menolak layanan render: "+e.getMessage(),null);
            ACTIVE.set(false);stopSelf();return START_NOT_STICKY;
        }
        record("running",0,"Menyiapkan render MP4 di latar belakang...",null);
        worker=new Thread(()->runJob(startId),"kf-native-foreground-encoder");
        worker.start();
        return START_NOT_STICKY;
    }
    private Notification notification(String message,int progress,boolean ongoing){
        Intent app=new Intent(this,MainActivity.class)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent open=PendingIntent.getActivity(this,0,app,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder builder=new NotificationCompat.Builder(this,CHANNEL)
            .setSmallIcon(R.drawable.ic_kreasiflow).setColor(progressColor).setContentTitle("KreasiFlow • Render MP4")
            .setContentText(message).setStyle(new NotificationCompat.BigTextStyle().bigText(message))
            .setOnlyAlertOnce(true).setOngoing(ongoing).setAutoCancel(!ongoing)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setPriority(NotificationCompat.PRIORITY_LOW).setContentIntent(open);
        if(ongoing){
            boolean measured=stats!=null&&"video".equals(stats.phase)&&stats.frameTotal>0;
            builder.setProgress(measured?stats.frameTotal:0,measured?Math.min(stats.frames,stats.frameTotal):0,!measured);
            Intent cancel=new Intent(this,RenderForegroundService.class).setAction(ACTION_CANCEL)
                .putExtra(EXTRA_JOB,jobId);
            PendingIntent stop=PendingIntent.getService(this,1,cancel,
                PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            builder.addAction(android.R.drawable.ic_delete,"Batalkan",stop);
        }
        return builder.build();
    }
    private void updateProgress(int percent,String message){
        if(cancelled||jobId.equals(CANCELLED_JOB.get())||Thread.currentThread().isInterrupted()){cancelled=true;throw new RuntimeException("Render dibatalkan");}
        int pct=Math.max(0,Math.min(98,percent));
        long now=System.currentTimeMillis();
        if(pct==lastPercent&&now-lastUiUpdate<550)return;
        lastPercent=pct;lastUiUpdate=now;
        record("running",pct,message,null);
        try{getSystemService(NotificationManager.class).notify(NOTIFICATION_ID,notification(message,pct,true));}
        catch(SecurityException ex){Log.w(TAG,"Notifikasi dibatasi pengguna",ex);}
    }
    private void reportRender(int percent,String message){updateProgress(percent,message);}
    private void finishJob(String state,int percent,String message,Uri uri){
        record(state,percent,message,uri);
        stopForeground(STOP_FOREGROUND_REMOVE);
        try{getSystemService(NotificationManager.class).notify(NOTIFICATION_ID,notification(message,percent,false));}
        catch(SecurityException ex){Log.w(TAG,"Notifikasi selesai tidak diizinkan",ex);}
    }
    private File lookupAsset(String id){
        if(id==null||!id.matches("[0-9]{1,18}"))return null;
        String path=assetPaths.optString(id,"");
        if(path.isEmpty())return null;
        try{
            File base=new File(getCacheDir(),"render-assets").getCanonicalFile();
            File result=new File(path).getCanonicalFile();
            if(!result.getPath().startsWith(base.getPath()+File.separator)||!result.isFile())return null;
            return result;
        }catch(IOException ex){return null;}
    }
    private void runJob(int startId){
        try{
            PowerManager pm=(PowerManager)getSystemService(Context.POWER_SERVICE);
            wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"KreasiFlow:RenderMP4");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire(2*60*60*1000L); // bounded; released in finally
            if(jobFile==null||!jobFile.isFile()||jobFile.length()>1_000_000)
                throw new IOException("Berkas antrian render hilang atau tidak valid");
            String serialized=new String(Files.readAllBytes(jobFile.toPath()),StandardCharsets.UTF_8);
            JSONObject job=new JSONObject(serialized);
            assetPaths=job.getJSONObject("assets");
            String mode=job.getString("mode");
            JSONObject args=job.getJSONObject("config");
            String color=args.optString("progressColor","");
            if(color.matches("#[0-9a-fA-F]{6}"))progressColor=android.graphics.Color.parseColor(color);
            String config=args.toString();
            if(jobId.equals(CANCELLED_JOB.get())){cancelled=true;throw new InterruptedException("Render dibatalkan");}
            if("moving".equals(mode))renderMoving(config);
            else if("slideshow".equals(mode))renderSlideshow(config);
            else throw new IOException("Mode render tidak dikenal");
        }catch(Throwable ex){
            String message=timedOut?"Batas waktu Android tercapai. Render perlu diulang.":
                (cancelled||Thread.currentThread().isInterrupted()?"Render dibatalkan pengguna":
                ex.getMessage()==null?"Render gagal — periksa log Android":ex.getMessage());
            Log.e(TAG,"Foreground render failed",ex);
            finishJob(timedOut?"interrupted":cancelled?"cancelled":"error",Math.max(0,lastPercent),message,null);
        }finally{
            if(wakeLock!=null && wakeLock.isHeld())wakeLock.release();
            if(jobFile!=null)jobFile.delete();
            CANCELLED_JOB.updateAndGet(value->jobId.equals(value)?null:value);
            ACTIVE.set(false);
            stopSelf(startId);
        }
    }
    @Override public void onTimeout(int startId,int fgsType){
        timedOut=true;cancelled=true;
        Thread t=worker;if(t!=null)t.interrupt();
        record("interrupted",Math.max(0,lastPercent),"Batas waktu layanan Android tercapai; render dihentikan.",null);
        stopSelf(startId);
    }
    @Override public void onDestroy(){
        Thread t=worker;
        if(t!=null && t.isAlive())t.interrupt();
        if(wakeLock!=null && wakeLock.isHeld())wakeLock.release();
        ACTIVE.set(false);
        super.onDestroy();
    }
    private void applyThemeOutro(JSONObject args,NativeVideoRenderer.Config cfg)throws Exception{
        if(cfg.smartLoop)return;
        JSONObject o=args.optJSONObject("themeOutro");
        if(o==null||!o.optBoolean("enabled",false))return;
        cfg.outro=ThemeOutro.fromJson(o);
        if(cfg.outro.combinedVoice&&cfg.narration==null)throw new IOException("VO gabungan belum tersedia");
        String voiceId=o.optString("voiceId","");
        cfg.outroVoice=lookupAsset(voiceId);
        if(!voiceId.isEmpty()&&cfg.outroVoice==null)throw new IOException("VO outro hilang. Upload ulang.");
        if(cfg.seconds+cfg.outro.seconds>600)throw new IOException("Durasi termasuk outro maksimal 10 menit.");
    }
    private void renderMoving(String json) throws Exception {
        File work=new File(getCacheDir(),"native-ai-video-"+System.nanoTime());
        File output=new File(work,"moving-final.mp4");
        try {
                if(!work.mkdirs())throw new IOException("Folder render video AI tidak tersedia");
                JSONObject args=new JSONObject(json);
                org.json.JSONArray scenes=args.optJSONArray("scenes");
                if(scenes==null||scenes.length()<1||scenes.length()>100)
                    throw new IOException("Render membutuhkan 1–100 scene storyboard berurutan");
                double seconds=args.optDouble("duration",Double.NaN);
                if(!Double.isFinite(seconds)||seconds<1||seconds>600)
                    throw new IOException("Durasi audio VO tidak valid (1–600 detik)");
                org.json.JSONArray boundaries=args.optJSONArray("sceneStarts");
                if(boundaries==null||boundaries.length()!=scenes.length()+1)
                    throw new IOException("Timeline scene harus berisi N+1 batas waktu dari VO");
                NativeVideoRenderer.Config cfg=new NativeVideoRenderer.Config();
                stats=cfg.stats;stats.uiPrepareMs=args.optLong("uiPrepareMs",0);stats.engine=args.optString("renderEngine687",args.optBoolean("fastRender",true)?"Render Cepat V2":"Render Go");
                cfg.sceneStarts=new double[boundaries.length()];
                double previous=-1;
                for(int i=0;i<boundaries.length();i++){
                    double t=boundaries.optDouble(i,Double.NaN);
                    if(!Double.isFinite(t)||t<0||t>seconds+.01||t<=previous)
                        throw new IOException("Timeline scene #"+(i+1)+" tidak urut/valid");
                    cfg.sceneStarts[i]=t;previous=t;
                }
                if(Math.abs(cfg.sceneStarts[0])>.02||Math.abs(previous-seconds)>.05)
                    throw new IOException("Timeline harus dimulai 0 dan berakhir tepat pada durasi VO");
                applyProductionSize(args,cfg);
                cfg.fps=Math.max(12,Math.min(60,args.optInt("fps",30)));
                stats.width=cfg.width;stats.height=cfg.height;stats.outputFps=cfg.fps;
                cfg.fastRender=args.optBoolean("fastRender",true);
                cfg.frameBlend=cfg.fps==60 && args.optBoolean("frameBlend",false);
                cfg.seconds=seconds;cfg.fade=args.optBoolean("fade",true);
                cfg.captions=args.optBoolean("captions",true);
                cfg.subtitlePosition=args.optString("subtitlePosition","Bawah");
                cfg.subtitlePreset=args.optString("subtitlePreset","classic");
                cfg.subtitleSize=(float)Math.max(.04,Math.min(.07,args.optDouble("subtitleSize",5)/100.0));
                cfg.music=lookupAsset(args.optString("musicId",""));
                if(!args.optString("musicId","").isEmpty()&&cfg.music==null)throw new IOException("Musik hilang. Upload ulang.");
                cfg.musicGain=(float)Math.max(0,Math.min(.7,args.optDouble("musicVolume",15)/100.0));
                cfg.musicDuck=args.optBoolean("musicDuck",true);
                cfg.smartRemux=args.optBoolean("smartRemux",false);
                cfg.voiceGain=(float)Math.max(0,Math.min(1,args.optDouble("voiceVolume",95)/100.0));
                cfg.effect=args.optString("effect","Smooth zoom");
                cfg.sceneTransition=SceneTransition.normalize(args.optString("sceneTransition","off"));
                if(!"off".equals(cfg.sceneTransition))cfg.fade=false;
                cfg.smartLoop=args.optBoolean("smartLoop",false);
                cfg.directLoop=cfg.smartLoop&&args.optBoolean("directLoop",false);
                if(cfg.smartLoop){cfg.fade=false;cfg.smartRemux=false;}
                String watermark=args.optString("watermark","");
                cfg.watermark=watermark.substring(0,Math.min(watermark.length(),80));
                try{cfg.subtitleColor=Color.parseColor(args.optString("captionColor","#ffffff"));}
                catch(Exception e){cfg.subtitleColor=Color.WHITE;}
                cfg.narration=lookupAsset(args.optString("audioId",""));
                if(!args.optString("audioId","").isEmpty()&&cfg.narration==null)
                    throw new IOException("VO tidak ditemukan di cache render. Upload ulang.");
                cfg.voiceGain=(float)Math.max(0,Math.min(1,args.optDouble("voiceVolume",95)/100.0));
                cfg.flowAudioGain=(float)Math.max(0,Math.min(1,args.optDouble("sfxVolume",0)/100.0));
                cfg.scenes=new ArrayList<>();cfg.motionClips=new ArrayList<>();
                int suppliedClips=0;
                cfg.trimStarts=new double[scenes.length()];
                cfg.clipParts=new double[scenes.length()][];
                for(int i=0;i<scenes.length();i++){
                    JSONObject item=scenes.getJSONObject(i);
                    String clipId=item.optString("clipId","");
                    File clip=lookupAsset(clipId);
                    if(!clipId.isEmpty()&&(clip==null||!clip.isFile()))
                        throw new IOException("MP4 scene "+(i+1)+" hilang. Impor ulang sesuai nomor scene.");
                    if(clip!=null){suppliedClips++;}
                    File still=lookupAsset(item.optString("imageId",""));
                    cfg.motionClips.add(clip);
                    cfg.trimStarts[i]=Math.max(0,Math.min(600,item.optDouble("trimStart",0)));
                    if(cfg.trimStarts[i]>0)cfg.smartRemux=false;
                    org.json.JSONArray parts=item.optJSONArray("parts");
                    if(parts!=null&&parts.length()>0){
                        if(parts.length()>40)throw new IOException("Terlalu banyak potongan klip");
                        cfg.clipParts[i]=new double[parts.length()*2];
                        double last=0,slot=cfg.sceneStarts[i+1]-cfg.sceneStarts[i];
                        for(int j=0;j<parts.length();j++){
                            JSONObject part=parts.getJSONObject(j);
                            double after=part.optDouble("after",Double.NaN),source=part.optDouble("source",Double.NaN);
                            if(!Double.isFinite(after)||!Double.isFinite(source)||after<=last||after>=slot||source<0||source>600)
                                throw new IOException("Potongan klip tidak valid pada scene "+(i+1));
                            cfg.clipParts[i][j*2]=after;cfg.clipParts[i][j*2+1]=source;last=after;
                        }
                        cfg.smartRemux=false;
                    }
                    cfg.scenes.add(new NativeVideoRenderer.Scene(still,item.optString("voice",""),
                        item.optString("name","Scene "+(i+1))));
                }
                if(suppliedClips==0)throw new IOException("Belum ada MP4 bergerak yang terpasang pada scene");
                org.json.JSONArray captions=args.optJSONArray("subtitles");
                if(cfg.captions){
                    if(captions==null||captions.length()==0)
                        throw new IOException("Subtitle aktif: buat AI transkrip atau impor SRT dulu");
                    if(captions.length()>("karaoke".equals(cfg.subtitlePreset)?2000:250))throw new IOException("Terlalu banyak baris subtitle");
                    double prevEnd=0;
                    for(int i=0;i<captions.length();i++){
                        JSONObject cue=captions.getJSONObject(i);
                        double start=cue.optDouble("start",Double.NaN),end=cue.optDouble("end",Double.NaN);
                        String caption=cue.optString("text","").trim();
                        if(!Double.isFinite(start)||!Double.isFinite(end)||start<0||end<=start
                            ||start<prevEnd-.01||end>seconds+.2||caption.isEmpty())
                            throw new IOException("Subtitle #"+(i+1)+" waktunya tidak valid");
                        cfg.subtitleCues.add(new NativeVideoRenderer.CaptionCue(start,end,
                            caption.substring(0,Math.min(caption.length(),400))));prevEnd=end;
                    }
                }
                reportRender(1,"Sinkronisasi "+suppliedClips+" MP4 ke "+cfg.scenes.size()+" scene sesuai timeline VO...");
                applyThemeOutro(args,cfg);
                NativeVideoRenderer.render(cfg,output,work,(p,message)->reportRender(p,message));
                stats.phase="publish";
                updateProgress(99,"Menyimpan MP4 ke Download/KreasiFlow...");
                long savingStarted=System.nanoTime();
                Uri uri=publishMp4(output);
                stats.outputBytes=output.length();
                stats.publishNs=System.nanoTime()-savingStarted;stats.phase="done";
                finishJob("done",100,"Video AI bergerak tersimpan di Download/KreasiFlow",uri);
        } finally {
            File[] files=work.listFiles();if(files!=null)for(File f:files)f.delete();work.delete();
        }
    }
    private void applyProductionSize(JSONObject args, NativeVideoRenderer.Config cfg)throws IOException{
        int size=Math.max(360,Math.min(2160,args.optInt("resolution",540)));
        String ratio=args.optString("ratio","9:16");
        int x=9,y=16;
        if(ratio.startsWith("16:9")){x=16;y=9;}
        else if(ratio.startsWith("1:1")){x=1;y=1;}
        else if(ratio.startsWith("4:5")){x=4;y=5;}
        else if(ratio.startsWith("21:9")){x=21;y=9;}
        cfg.width=x>=y?(int)Math.round(size*x/(2.0*y))*2:size;
        cfg.height=x>=y?size:(int)Math.round(size*y/(2.0*x))*2;
        cfg.width-=cfg.width%2;cfg.height-=cfg.height%2;
        cfg.fit="fit".equals(args.optString("frameFit","crop"));
        cfg.musicLoop=args.optBoolean("musicLoop",true);
        String sfxId=args.optString("separateSfxId","");
        cfg.separateSfx=lookupAsset(sfxId);
        if(!sfxId.isEmpty()&&cfg.separateSfx==null)throw new IOException("Trek SFX tidak tersedia");
        cfg.separateSfxGain=(float)(Math.max(0,Math.min(100,args.optDouble("separateSfxVolume",30)))/100);
        cfg.separateSfxStart=Math.max(0,Math.min(600,args.optDouble("separateSfxStart",0)));
    }

    private void renderSlideshow(String json) throws Exception {
        File work=new File(getCacheDir(),"native-mp4-"+System.nanoTime());
        File finished=new File(work,"final.mp4");
        List<File> used=new ArrayList<>();
        try {
                if(!work.mkdirs())throw new IOException("Tidak bisa menyiapkan ruang sementara");
                JSONObject args=new JSONObject(json);
                NativeVideoRenderer.Config cfg=new NativeVideoRenderer.Config();
                stats=cfg.stats;stats.uiPrepareMs=args.optLong("uiPrepareMs",0);stats.engine=args.optString("renderEngine687",args.optBoolean("fastRender",true)?"Render Cepat V2":"Render Go");
                applyProductionSize(args,cfg);
                cfg.fps=Math.max(12,Math.min(60,args.optInt("fps",30)));
                stats.width=cfg.width;stats.height=cfg.height;stats.outputFps=cfg.fps;
                cfg.fastRender=args.optBoolean("fastRender",true);
                cfg.seconds=Math.max(2,Math.min(600,args.optDouble("duration",60)));
                org.json.JSONArray starts=args.optJSONArray("sceneStarts");
                if(starts!=null){
                    org.json.JSONArray items=args.getJSONArray("scenes");
                    if(starts.length()!=items.length()+1)throw new IOException("Jumlah batas scene tidak cocok");
                    cfg.sceneStarts=new double[starts.length()];
                    for(int i=0;i<starts.length();i++){
                        double value=starts.optDouble(i,Double.NaN);
                        if(!Double.isFinite(value)|| (i==0&&Math.abs(value)>.02)||
                           (i>0&&(value<=cfg.sceneStarts[i-1])))
                            throw new IOException("Timeline render gambar tidak valid pada scene "+i);
                        cfg.sceneStarts[i]=value;
                    }
                    if(Math.abs(cfg.sceneStarts[starts.length()-1]-cfg.seconds)>.05)throw new IOException("Durasi timeline tidak cocok");
                }
                cfg.captions=args.optBoolean("captions",true);cfg.fade=args.optBoolean("fade",true);
                cfg.subtitlePosition=args.optString("subtitlePosition","Bawah");
                cfg.subtitlePreset=args.optString("subtitlePreset","classic");
                cfg.subtitleSize=(float)Math.max(.04,Math.min(.07,args.optDouble("subtitleSize",5)/100.0));
                cfg.music=lookupAsset(args.optString("musicId",""));
                if(!args.optString("musicId","").isEmpty()&&cfg.music==null)throw new IOException("Musik hilang. Upload ulang.");
                cfg.musicGain=(float)Math.max(0,Math.min(.7,args.optDouble("musicVolume",15)/100.0));
                cfg.musicDuck=args.optBoolean("musicDuck",true);
                cfg.smartRemux=args.optBoolean("smartRemux",false);
                cfg.voiceGain=(float)Math.max(0,Math.min(1,args.optDouble("voiceVolume",95)/100.0));
                cfg.watermark=args.optString("watermark","").substring(0,Math.min(80,args.optString("watermark","").length()));
                cfg.effect=args.optString("effect","Smooth zoom");
                cfg.sceneTransition=SceneTransition.normalize(args.optString("sceneTransition","off"));
                if(!"off".equals(cfg.sceneTransition))cfg.fade=false;
                cfg.smartLoop=args.optBoolean("smartLoop",false);
                cfg.directLoop=cfg.smartLoop&&args.optBoolean("directLoop",false);
                if(cfg.smartLoop){cfg.fade=false;cfg.smartRemux=false;}
                try{cfg.subtitleColor=Color.parseColor(args.optString("captionColor","#ffffff"));}
                catch(Exception e){cfg.subtitleColor=Color.WHITE;}
                org.json.JSONArray cues=args.optJSONArray("subtitles");
                if(cfg.captions){
                    if(cues==null||cues.length()==0)throw new IOException("Subtitle aktif, tetapi data timestamp belum dibuat. Buka Proses → Subtitle.");
                    if(cues.length()>("karaoke".equals(cfg.subtitlePreset)?2000:250))throw new IOException("Maksimal 250 baris subtitle");
                    double lastEnd=0;
                    for(int i=0;i<cues.length();i++){
                        JSONObject cue=cues.getJSONObject(i);
                        double start=cue.optDouble("start",-1),end=cue.optDouble("end",-1);
                        String text=cue.optString("text","").trim();
                        if(!Double.isFinite(start)||!Double.isFinite(end)||start<0||end<=start
                            ||start<lastEnd-0.01||end>cfg.seconds+0.2||text.isEmpty())
                            throw new IOException("Timestamp subtitle #"+(i+1)+" tidak valid atau melewati durasi");
                        cfg.subtitleCues.add(new NativeVideoRenderer.CaptionCue(start,end,text.substring(0,Math.min(400,text.length()))));
                        lastEnd=end;
                    }
                }
                cfg.narration=lookupAsset(args.optString("audioId",""));
                if(cfg.narration!=null)used.add(cfg.narration);
                cfg.scenes=new ArrayList<>();
                org.json.JSONArray scenes=args.optJSONArray("scenes");
                if(scenes==null||scenes.length()==0)throw new IOException("Scene kosong; buat storyboard dulu");
                if(scenes.length()>100)throw new IOException("Maksimal 100 scene");
                for(int i=0;i<scenes.length();i++){
                    JSONObject sc=scenes.getJSONObject(i);
                    File asset=lookupAsset(sc.optString("imageId",""));
                    if(asset!=null)used.add(asset);
                    cfg.scenes.add(new NativeVideoRenderer.Scene(asset,sc.optString("voice",""),sc.optString("name","Adegan "+(i+1))));
                }
                applyThemeOutro(args,cfg);
                NativeVideoRenderer.render(cfg,finished,work,(pct,msg)->reportRender(pct,msg));
                stats.phase="publish";
                updateProgress(99,"Menyimpan MP4 ke Download/KreasiFlow...");
                long savingStarted=System.nanoTime();
                Uri uri=publishMp4(finished);
                stats.outputBytes=finished.length();
                stats.publishNs=System.nanoTime()-savingStarted;stats.phase="done";
                finishJob("done",100,"MP4 tersimpan di Download/KreasiFlow",uri);
        } finally {
            // Keep media assets for the user and other pending exports. A cache janitor may
            // remove files only after they are no longer referenced by an active render.
            File[] tmp=work.listFiles();if(tmp!=null)for(File f:tmp)f.delete();work.delete();
        }
    }
    private Uri publishMp4(File video) throws IOException {
        Uri uri=null;
        try{
            ContentValues values=new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME,"KreasiFlow-"+System.currentTimeMillis()+".mp4");
            values.put(MediaStore.MediaColumns.MIME_TYPE,"video/mp4");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/KreasiFlow");
            values.put(MediaStore.MediaColumns.IS_PENDING,1);
            uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
            if(uri==null)throw new IOException("Android tidak memberi lokasi unduhan");
            try(InputStream input=new FileInputStream(video);OutputStream output=getContentResolver().openOutputStream(uri,"w")){
                if(output==null)throw new IOException("Folder unduhan tidak dapat ditulis");
                byte[] block=new byte[65536];int n;
                while((n=input.read(block))!=-1){
                    if(cancelled||jobId.equals(CANCELLED_JOB.get())||Thread.currentThread().isInterrupted()){cancelled=true;throw new IOException("Render dibatalkan");}
                    output.write(block,0,n);
                }
            }
            if(cancelled||jobId.equals(CANCELLED_JOB.get())||Thread.currentThread().isInterrupted()){cancelled=true;throw new IOException("Render dibatalkan");}
            ContentValues ready=new ContentValues();ready.put(MediaStore.MediaColumns.IS_PENDING,0);
            getContentResolver().update(uri,ready,null,null);
            return uri;
        }catch(Exception e){
            if(uri!=null)getContentResolver().delete(uri,null,null);
            if(e instanceof IOException)throw (IOException)e;
            throw new IOException("Gagal menyimpan MP4: "+e.getMessage(),e);
        }
    }
}
