package id.kreasiflow.studio;

/** Time arithmetic shared by the byte-buffer and surface paths. */
final class RenderFrameClock686 {
    private RenderFrameClock686() {}

    static int sourceIndex(double local, double slot, double duration, int sourceFps,
                           boolean bridge, double trim, double[] parts,
                           boolean directEnd, int frame, int firstFrame, int frameCount) {
        if (directEnd) {
            int last = Math.max(0, (int)Math.ceil(duration * sourceFps - 1e-7) - 1);
            double progress = (frame - firstFrame) / (double)Math.max(1, frameCount - 1 - firstFrame);
            return (int)Math.round(Math.max(0, Math.min(1, progress)) * last);
        }
        return (int)Math.floor(sourceTime(local,slot,duration,bridge,trim,parts) * sourceFps + 1e-6);
    }

    static long ptsUs(int frame, int fps) {
        return frame * 1_000_000L / fps;
    }

    static double sourceTime(double local,double slot,double duration,boolean bridge,double trim,double[] parts) {
        if (parts != null) {
            for (int i = parts.length - 2; i >= 0; i -= 2) {
                if (local >= parts[i]) return clamp(parts[i + 1] + local - parts[i], duration);
            }
        }
        double speed = bridge || slot <= duration ? duration / slot : 1;
        return clamp(trim + local * (trim > 0 || (parts != null && parts.length > 0) ? 1 : speed), duration);
    }

    private static double clamp(double time,double duration) {
        return Math.min(Math.max(0, duration - .005), Math.max(0, time));
    }

    static boolean takeNext(long wanted, long current, long next) {
        return current < 0 || next <= wanted || next - wanted < wanted - current;
    }
}
