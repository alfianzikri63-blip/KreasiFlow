package id.kreasiflow.studio;

/** BT.601 limited range conversion. Same integer rounding and 2x2 chroma averaging as KF684. */
final class RenderPixel685 {
    private RenderPixel685(){}
    private static final int[] YR=new int[256], YG=new int[256], YB=new int[256];
    static {
        for(int i=0;i<256;i++){YR[i]=66*i;YG[i]=129*i;YB[i]=25*i;}
    }
    private static int luma(int p){
        return ((YR[(p>>>16)&255]+YG[(p>>>8)&255]+YB[p&255]+128)>>8)+16;
    }
    static void pack(int[] pixels,int width,int height,byte[] out,boolean planar){
        int lumaSize=width*height,chroma=lumaSize,vPlane=chroma+lumaSize/4;
        for(int row=0;row<height;row+=2){
            int first=row*width,second=first+width;
            for(int col=0;col<width;col+=2){
                int a=pixels[first+col], b=pixels[first+col+1], c=pixels[second+col], d=pixels[second+col+1];
                out[first+col]=(byte)luma(a);out[first+col+1]=(byte)luma(b);
                out[second+col]=(byte)luma(c);out[second+col+1]=(byte)luma(d);
                int r=(((a>>>16)&255)+((b>>>16)&255)+((c>>>16)&255)+((d>>>16)&255))>>2;
                int g=(((a>>>8)&255)+((b>>>8)&255)+((c>>>8)&255)+((d>>>8)&255))>>2;
                int blue=((a&255)+(b&255)+(c&255)+(d&255))>>2;
                byte u=(byte)((-38*r-74*g+112*blue+128)/256+128);
                byte v=(byte)((112*r-94*g-18*blue+128)/256+128);
                out[chroma++]=u;
                if(planar)out[vPlane++]=v;
                else out[chroma++]=v;
            }
        }
    }
}
