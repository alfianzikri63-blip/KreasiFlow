package id.kreasiflow.studio;

import org.json.JSONObject;

/** Written and snapshotted by the render worker. Times are monotonic and stage-local. */
final class RenderStats685 {
    final long openingNs=System.nanoTime();
    String phase="prepare", engine="", encoder="";
    Boolean hardware=null;
    boolean remux=false;
    String path="", fallbackReason="";
    final java.util.Set<String> decoders=new java.util.LinkedHashSet<>();
    int decodedFrames,latchedFrames,subtitleUploads,retrieverCalls;
    long frameSetupNs, stillUploadNs, textureLatchNs, glSubmitNs, surfaceSwapNs, subtitleNs, bitmapAllocationNs,
        canvasCompositionNs, bitmapReadbackNs, colorPackNs, encoderInputNs, encoderOutputNs,
        muxWriteNs, videoSetupNs, videoFinalizeNs, validationNs, abandonedSurfaceNs;
    private final long gcCountAtStart=runtimeStat("art.gc.gc-count");
    private final long gcTimeAtStart=runtimeStat("art.gc.gc-time");

    private static long runtimeStat(String key) {
        try {return Long.parseLong(android.os.Debug.getRuntimeStat(key));}
        catch (RuntimeException unavailable) {return -1;}
    }

    void resetVideo686() {
        frames=0;scenes=0;videoNs=0;videoEndNs=0;encoder="";hardware=null;
        decoders.clear();decodedFrames=0;latchedFrames=0;subtitleUploads=0;
        frameSetupNs=0;stillUploadNs=0;decodeNs=0;textureLatchNs=0;glSubmitNs=0;surfaceSwapNs=0;
        subtitleNs=0;encoderInputNs=0;encoderOutputNs=0;muxWriteNs=0;videoSetupNs=0;videoFinalizeNs=0;
    }
    int frames, frameTotal, scenes, sceneTotal, width, height, outputFps;
    long peakJavaHeapBytes, outputBytes, uiPrepareMs;
    long videoNs, videoEndNs, decodeNs, encodeNs, audioNs, prepareNs, sheetEndNs, publishNs;
    void sampleJavaHeap() {
        Runtime runtime=Runtime.getRuntime();
        peakJavaHeapBytes=Math.max(peakJavaHeapBytes,runtime.totalMemory()-runtime.freeMemory());
    }
    JSONObject json() throws Exception {
        sampleJavaHeap();
        long now=System.nanoTime();
        JSONObject data=new JSONObject().put("phase",phase).put("engine",engine)
            .put("width",width).put("height",height).put("outputFps",outputFps).put("frames",frames).put("frameTotal",frameTotal).put("scenes",scenes).put("sceneTotal",sceneTotal)
            .put("encoder",encoder).put("hardware",hardware==null?JSONObject.NULL:hardware)
            .put("elapsedMs",(now-openingNs)/1_000_000).put("decodeMs",decodeNs/1_000_000)
            .put("encodeMs",encodeNs/1_000_000).put("audioMs",audioNs/1_000_000).put("prepareMs",prepareNs/1_000_000)
            .put("uiPrepareMs",uiPrepareMs).put("peakJavaHeapBytes",peakJavaHeapBytes).put("outputBytes",outputBytes)
            .put("muxMs",sheetEndNs/1_000_000).put("publishMs",publishNs/1_000_000).put("remux",remux);
        data.put("path",path).put("fallbackReason",fallbackReason)
            .put("decoders",new org.json.JSONArray(decoders)).put("decodedFrames",decodedFrames)
            .put("latchedFrames",latchedFrames).put("retrieverCalls",retrieverCalls).put("subtitleUploads",subtitleUploads)
            .put("videoSetupMs",videoSetupNs/1_000_000).put("frameSetupMs",frameSetupNs/1_000_000)
            .put("stillUploadMs",stillUploadNs/1_000_000).put("textureLatchMs",textureLatchNs/1_000_000).put("glSubmitMs",glSubmitNs/1_000_000)
            .put("surfaceSwapMs",surfaceSwapNs/1_000_000).put("subtitleMs",subtitleNs/1_000_000)
            .put("bitmapAllocationMs",bitmapAllocationNs/1_000_000)
            .put("canvasCompositionMs",canvasCompositionNs/1_000_000).put("bitmapReadbackMs",bitmapReadbackNs/1_000_000)
            .put("colorPackMs",colorPackNs/1_000_000).put("encoderInputMs",encoderInputNs/1_000_000)
            .put("encoderOutputMs",encoderOutputNs/1_000_000).put("muxWriteMs",muxWriteNs/1_000_000)
            .put("videoFinalizeMs",videoFinalizeNs/1_000_000).put("validationMs",validationNs/1_000_000)
            .put("abandonedSurfaceMs",abandonedSurfaceNs/1_000_000);
        long gcCount=runtimeStat("art.gc.gc-count"),gcTime=runtimeStat("art.gc.gc-time");
        if(gcCountAtStart>=0&&gcCount>=gcCountAtStart)data.put("processGcCount",gcCount-gcCountAtStart);
        if(gcTimeAtStart>=0&&gcTime>=gcTimeAtStart)data.put("processGcMs",gcTime-gcTimeAtStart);
        if(videoNs>0&&frames>0){
            double seconds=((videoEndNs==0?now:videoEndNs)-videoNs)/1e9;
            if(seconds>=1){double fps=frames/seconds;data.put("throughput",fps);
                if(frames<frameTotal&&frames>=12&&"video".equals(phase))data.put("etaVideoSeconds",(frameTotal-frames)/fps);
            }
        }
        return data;
    }
}
