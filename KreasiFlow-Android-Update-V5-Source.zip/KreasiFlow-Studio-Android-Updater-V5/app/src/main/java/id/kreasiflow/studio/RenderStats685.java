package id.kreasiflow.studio;

import org.json.JSONObject;

/** Written and snapshotted by the render worker. Times are monotonic and stage-local. */
final class RenderStats685 {
    final long openingNs=System.nanoTime();
    String phase="prepare", engine="", encoder="";
    Boolean hardware=null;
    boolean remux=false;
    int frames, frameTotal, scenes, sceneTotal;
    long peakJavaHeapBytes, outputBytes;
    long videoNs, videoEndNs, decodeNs, encodeNs, audioNs, prepareNs, sheetEndNs, publishNs;
    void sampleJavaHeap() {
        Runtime runtime=Runtime.getRuntime();
        peakJavaHeapBytes=Math.max(peakJavaHeapBytes,runtime.totalMemory()-runtime.freeMemory());
    }
    JSONObject json() throws Exception {
        sampleJavaHeap();
        long now=System.nanoTime();
        JSONObject data=new JSONObject().put("phase",phase).put("engine",engine)
            .put("frames",frames).put("frameTotal",frameTotal).put("scenes",scenes).put("sceneTotal",sceneTotal)
            .put("encoder",encoder).put("hardware",hardware==null?JSONObject.NULL:hardware)
            .put("elapsedMs",(now-openingNs)/1_000_000).put("decodeMs",decodeNs/1_000_000)
            .put("encodeMs",encodeNs/1_000_000).put("audioMs",audioNs/1_000_000).put("prepareMs",prepareNs/1_000_000)
            .put("peakJavaHeapBytes",peakJavaHeapBytes).put("outputBytes",outputBytes)
            .put("muxMs",sheetEndNs/1_000_000).put("publishMs",publishNs/1_000_000).put("remux",remux);
        if(videoNs>0&&frames>0){
            double seconds=((videoEndNs==0?now:videoEndNs)-videoNs)/1e9;
            if(seconds>=1){double fps=frames/seconds;data.put("throughput",fps);
                if(frames<frameTotal&&frames>=12&&"video".equals(phase))data.put("etaVideoSeconds",(frameTotal-frames)/fps);
            }
        }
        return data;
    }
}
