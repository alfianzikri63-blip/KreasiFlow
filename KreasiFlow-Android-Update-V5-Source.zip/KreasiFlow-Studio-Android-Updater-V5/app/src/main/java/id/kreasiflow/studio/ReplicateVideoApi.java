package id.kreasiflow.studio;

import android.util.Base64;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Locale;

/** Explicit opt-in image-to-video. Only a fixed official Replicate model can be called.
 *  API credential stays in Android KeyStore. No arbitrary URL or model from WebView.
 */
final class ReplicateVideoApi {
    private static final int MAX_RESPONSE=100_000;
    private static final int MAX_VIDEO=100*1024*1024;
    private static final String ENDPOINT="https://api.replicate.com/v1/models/wan-video/wan-2.2-5b-fast/predictions";
    private static final String API="https://api.replicate.com/v1/predictions/";
    private static final String ID_RE="[a-z0-9]{12,70}";

    static JSONObject start(File image,JSONObject request,String token) throws Exception {
        checkToken(token);
        if(!image.isFile()||image.length()<100||image.length()>790_000)
            throw new IOException("Gambar untuk video AI harus JPEG/PNG di bawah 790 KB");
        byte[] data=Files.readAllBytes(image.toPath());
        String mime;
        if(data.length>4&&(data[0]&255)==255&&(data[1]&255)==216)mime="image/jpeg";
        else if(data.length>8&&(data[0]&255)==137&&data[1]==80&&data[2]==78&&data[3]==71)mime="image/png";
        else throw new IOException("Untuk video AI gunakan gambar JPEG atau PNG");
        String prompt=request.optString("prompt", "").trim();
        if(prompt.length()<6||prompt.length()>1800)throw new IOException("Prompt gerakan harus 6–1800 karakter");
        String ratio=request.optString("ratio", "9:16");
        if(!ratio.equals("9:16")&&!ratio.equals("16:9"))ratio="9:16";
        JSONObject input=new JSONObject().put("image","data:"+mime+";base64,"+Base64.encodeToString(data,Base64.NO_WRAP))
            .put("prompt",prompt).put("resolution","480p").put("aspect_ratio",ratio)
            .put("go_fast",true).put("num_frames",81).put("frames_per_second",16)
            .put("optimize_prompt",false).put("disable_safety_checker",false);
        JSONObject body=new JSONObject().put("input",input);
        JSONObject prediction=new JSONObject(new String(send("POST",ENDPOINT,token,body.toString()),StandardCharsets.UTF_8));
        String id=prediction.optString("id", "");
        if(!id.matches(ID_RE))throw new IOException("Replicate tidak mengembalikan ID pekerjaan video");
        return new JSONObject().put("prediction_id",id).put("status",prediction.optString("status","starting"));
    }

    static JSONObject poll(JSONObject req,String token,File destination) throws Exception {
        checkToken(token);
        String id=req.optString("prediction_id", "");
        if(!id.matches(ID_RE))throw new IOException("ID video AI tidak valid");
        JSONObject result=new JSONObject(new String(send("GET",API+id,token,null),StandardCharsets.UTF_8));
        String status=result.optString("status", "unknown");
        if("failed".equals(status)||"canceled".equals(status)) {
            String e=result.optString("error","Model video tidak berhasil");
            throw new IOException("Replicate video "+status+": "+safe(e));
        }
        JSONObject statusJson=new JSONObject().put("status",status).put("prediction_id",id);
        if(!"succeeded".equals(status))return statusJson;
        Object raw=result.opt("output");
        String url=raw instanceof String?(String)raw:raw instanceof org.json.JSONArray?((org.json.JSONArray)raw).optString(0,""):"";
        download(url,destination);
        return statusJson.put("downloaded",true).put("size",destination.length()).put("preview_url",url);
    }

    private static void checkToken(String key)throws IOException {
        if(key==null||key.trim().length()<15||key.trim().length()>512)throw new IOException("Replicate API Token belum diisi di Pengaturan AI");
    }
    private static byte[] send(String method,String url,String token,String payload)throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setInstanceFollowRedirects(false);c.setConnectTimeout(25000);c.setReadTimeout(120000);
        c.setRequestMethod(method);
        c.setRequestProperty("Authorization","Bearer "+token.trim());
        c.setRequestProperty("Accept","application/json");
        if(payload!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");
            byte[] b=payload.getBytes(StandardCharsets.UTF_8);
            try(OutputStream o=c.getOutputStream()){o.write(b);} }
        try{
            int status=c.getResponseCode();
            if(status<200||status>=300){
                String err=readString(c.getErrorStream(),10000);
                try{JSONObject o=new JSONObject(err);err=o.optString("detail",o.optString("error",err));}catch(Exception ignored){}
                throw new IOException("Replicate HTTP "+status+": "+safe(err));
            }
            try(InputStream in=c.getInputStream();ByteArrayOutputStream bytes=new ByteArrayOutputStream()){
                byte[] buf=new byte[8192];int n;
                while((n=in.read(buf))!=-1){if(bytes.size()+n>MAX_RESPONSE)throw new IOException("Respons API Replicate terlalu besar");bytes.write(buf,0,n);}
                return bytes.toByteArray();
            }
        }finally{c.disconnect();}
    }
    private static String readString(InputStream stream,int max)throws IOException{
        if(stream==null)return "";
        try(InputStream in=stream;ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1){if(out.size()+n>max)break;out.write(b,0,n);}return out.toString("UTF-8");
        }
    }
    private static String safe(String s){String cleaned=String.valueOf(s).replaceAll("[\r\n]+"," ");return cleaned.substring(0,Math.min(cleaned.length(),200));}
    private static void download(String path,File output)throws IOException{
        URL url;
        try{url=new URL(path);}catch(Exception e){throw new IOException("URL video tidak valid");}
        String host=url.getHost().toLowerCase(Locale.ROOT);
        if(!"https".equals(url.getProtocol())||!(host.equals("replicate.delivery")||host.endsWith(".replicate.delivery")))
            throw new IOException("Host output video tidak didukung");
        HttpURLConnection c=(HttpURLConnection)url.openConnection();
        c.setInstanceFollowRedirects(false);c.setConnectTimeout(30000);c.setReadTimeout(90000);
        try {
            if(c.getResponseCode()!=200)throw new IOException("Unduhan klip gagal HTTP "+c.getResponseCode());
            if(c.getContentLengthLong()>MAX_VIDEO)throw new IOException("Klip lebih besar dari 100 MB");
            try(InputStream in=c.getInputStream();OutputStream out=new FileOutputStream(output)){
                byte[] buf=new byte[8192];long n=0;int x;
                while((x=in.read(buf))!=-1){n+=x;if(n>MAX_VIDEO)throw new IOException("Klip melebihi batas 100 MB");out.write(buf,0,x);}
            }
            if(output.length()<2048)throw new IOException("Klip AI kosong");
            try(FileInputStream in=new FileInputStream(output)){
                byte[] header=new byte[12];if(in.read(header)!=12||header[4]!='f'||header[5]!='t'||header[6]!='y'||header[7]!='p')
                    throw new IOException("Output model bukan file MP4");
            }
        }catch(IOException e){output.delete();throw e;}
        finally {c.disconnect();}
    }
}
