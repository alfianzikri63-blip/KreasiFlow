package id.kreasiflow.studio;

/** Pure timing math: transitions affect pixels, not the scene timeline. */
final class SceneTransition {
    static String normalize(String mode){
        return "dip".equals(mode)||"flash".equals(mode)||"dissolve".equals(mode)||"cut".equals(mode)?mode:"off";
    }
    static boolean active(String mode){return "dip".equals(mode)||"flash".equals(mode)||"dissolve".equals(mode);}
    static float alpha(String mode,int index,int count,double offset,double slice,double previousSlice){
        if(!active(mode)||count<2||slice<=0)return 0f;
        double duration=Math.min("flash".equals(mode)?.16:.32,slice/4);
        if("dissolve".equals(mode)){
            if(index==0||previousSlice<=0)return 0f;
            duration=Math.min(duration,previousSlice/4);
            return (float)Math.max(0,Math.min(1,1-offset/duration));
        }
        double edge=Double.POSITIVE_INFINITY;
        if(index>0)edge=Math.min(edge,Math.max(0,offset));
        if(index<count-1)edge=Math.min(edge,Math.max(0,slice-offset));
        double peak="flash".equals(mode)?.30:.85;
        return (float)(peak*Math.max(0,Math.min(1,1-edge/duration)));
    }
}
