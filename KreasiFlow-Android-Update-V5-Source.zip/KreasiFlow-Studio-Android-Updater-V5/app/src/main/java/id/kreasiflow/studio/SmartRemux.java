package id.kreasiflow.studio;
import android.media.*;
import java.io.*;
import java.nio.*;
import java.util.*;
/** Strict passthrough: never repeat, trim, rescale or retime a scene. */
final class SmartRemux {
    private static int video(MediaExtractor e){for(int i=0;i<e.getTrackCount();i++){String m=e.getTrackFormat(i).getString(MediaFormat.KEY_MIME);if(m!=null&&m.startsWith("video/"))return i;}return -1;}
    private static boolean csd(MediaFormat a,MediaFormat b,String k){ByteBuffer x=a.getByteBuffer(k),y=b.getByteBuffer(k);return x==null?y==null:y!=null&&x.duplicate().equals(y.duplicate());}
    private static int num(MediaFormat f,String k,int d){return f.containsKey(k)?f.getInteger(k):d;}
    static boolean tryJoin(NativeVideoRenderer.Config c,File output,NativeVideoRenderer.Progress progress)throws Exception{
        if(c.captions||c.fade||c.frameBlend||!"Tanpa efek".equals(c.effect)||c.motionClips==null||c.sceneStarts==null||c.watermark!=null&&!c.watermark.trim().isEmpty())return false;
        if(c.motionClips.size()+1!=c.sceneStarts.length)return false;
        MediaFormat base=null;long frameUs=Math.round(1_000_000.0/c.fps);
        for(int i=0;i<c.motionClips.size();i++){
            File file=c.motionClips.get(i);if(file==null||!file.isFile())return false;
            MediaExtractor e=new MediaExtractor();try{
                e.setDataSource(file.getAbsolutePath());int t=video(e);if(t<0)return false;MediaFormat f=e.getTrackFormat(t);
                if(!MediaFormat.MIMETYPE_VIDEO_AVC.equals(f.getString(MediaFormat.KEY_MIME))||num(f,MediaFormat.KEY_WIDTH,0)!=c.width||num(f,MediaFormat.KEY_HEIGHT,0)!=c.height||num(f,MediaFormat.KEY_FRAME_RATE,0)!=c.fps||num(f,MediaFormat.KEY_ROTATION,0)!=0||!f.containsKey(MediaFormat.KEY_DURATION))return false;
                long expected=Math.round((c.sceneStarts[i+1]-c.sceneStarts[i])*1e6);if(Math.abs(f.getLong(MediaFormat.KEY_DURATION)-expected)>2000)return false;
                if(base==null)base=f;else if(!csd(base,f,"csd-0")||!csd(base,f,"csd-1"))return false;
                e.selectTrack(t);if((e.getSampleFlags()&MediaExtractor.SAMPLE_FLAG_SYNC)==0)return false;
                long prev=-1,first=e.getSampleTime();if(first<0)return false;
                do{if(Thread.currentThread().isInterrupted())throw new InterruptedException();long pts=e.getSampleTime();if(pts<0)break;long rel=pts-first;if(prev>=0&&(rel<=prev||Math.abs(rel-prev-frameUs)>2000))return false;prev=rel;if(e.getSampleSize()>8*1024*1024)return false;}while(e.advance());
                if(prev<0||Math.abs(prev+frameUs-expected)>2000)return false;
            }finally{e.release();}
        }
        if(base==null)return false;
        MediaMuxer m=new MediaMuxer(output.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);boolean started=false;try{
            int track=m.addTrack(base);m.start();started=true;ByteBuffer buf=ByteBuffer.allocateDirect(8*1024*1024);MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
            for(int i=0;i<c.motionClips.size();i++){MediaExtractor e=new MediaExtractor();try{e.setDataSource(c.motionClips.get(i).getAbsolutePath());e.selectTrack(video(e));long first=e.getSampleTime(),offset=Math.round(c.sceneStarts[i]*1e6);
                while(true){if(Thread.currentThread().isInterrupted())throw new InterruptedException();buf.clear();int n=e.readSampleData(buf,0);if(n<0)break;info.set(0,n,offset+e.getSampleTime()-first,(e.getSampleFlags()&MediaExtractor.SAMPLE_FLAG_SYNC)!=0?MediaCodec.BUFFER_FLAG_KEY_FRAME:0);buf.position(0);buf.limit(n);m.writeSampleData(track,buf,info);if(!e.advance())break;}
            }finally{e.release();}progress.onProgress(5+75*(i+1)/c.motionClips.size(),"Smart Render: gabung klip tanpa encoding "+(i+1));}
            m.stop();started=false;return true;
        }finally{if(started)try{m.stop();}catch(Exception ignored){}m.release();}
    }
}
