package id.kreasiflow.studio;

import java.io.InterruptedIOException;
import java.net.HttpURLConnection;

/** Tracks only the single HTTP connection used by a Story Studio idea request. */
final class StoryIdeaCancellation {
    private static final ThreadLocal<StoryIdeaCancellation> ACTIVE = new ThreadLocal<>();
    private volatile boolean cancelled;
    private HttpURLConnection connection;

    static void bind(StoryIdeaCancellation request) {
        if (request != null) ACTIVE.set(request);
    }

    static void clear() { ACTIVE.remove(); }

    static void track(HttpURLConnection connection) throws InterruptedIOException {
        StoryIdeaCancellation active = ACTIVE.get();
        if (active == null) return;
        synchronized (active) {
            if (active.cancelled) throw new InterruptedIOException("Permintaan ide dibatalkan");
            active.connection = connection;
        }
    }

    boolean isCancelled() { return cancelled; }

    void cancel() {
        HttpURLConnection pending;
        synchronized (this) {
            cancelled = true;
            pending = connection;
            connection = null;
        }
        if (pending != null) {
            // Disconnect may block while a platform stream closes. Never block the WebView bridge.
            new Thread(pending::disconnect, "kf-idea-cancel").start();
        }
    }
}
