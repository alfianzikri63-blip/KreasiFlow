package id.kreasiflow.studio;

import java.io.InterruptedIOException;
import java.net.HttpURLConnection;

/** Tracks the HTTP connection for a cancellable generation request. */
final class StoryIdeaCancellation {
    private static final ThreadLocal<StoryIdeaCancellation> ACTIVE = new ThreadLocal<>();
    private volatile boolean cancelled;
    private HttpURLConnection connection;
    private final int readMs;

    StoryIdeaCancellation(int readMs) {
        this.readMs = readMs > 0 ? Math.max(2000, Math.min(80000, readMs)) : 0;
    }

    static void applyLimits(HttpURLConnection connection) {
        StoryIdeaCancellation active = ACTIVE.get();
        if (active == null || active.readMs == 0) return;
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(active.readMs);
    }

    static boolean managed() {
        StoryIdeaCancellation active = ACTIVE.get();
        return active != null && active.readMs > 0;
    }

    static String safeError(Throwable error) {
        for (Throwable cause=error; cause!=null; cause=cause.getCause()) {
            if (cause instanceof java.net.SocketTimeoutException) return "timeout";
            if (cause instanceof java.net.SocketException || cause instanceof java.net.UnknownHostException) return "network: socket connection abort";
            String message=String.valueOf(cause.getMessage());
            if (message.startsWith("API key")) return "HTTP 401";
            java.util.regex.Matcher status=java.util.regex.Pattern.compile("\\bHTTP ([1-5][0-9]{2})\\b").matcher(message);
            if (status.find()) return "HTTP " + status.group(1);
        }
        return "Respons tidak lengkap atau permintaan tidak didukung model.";
    }

    static void bind(StoryIdeaCancellation request) {
        if (request != null) ACTIVE.set(request);
    }

    static void clear() { ACTIVE.remove(); }

    static void track(HttpURLConnection connection) throws InterruptedIOException {
        StoryIdeaCancellation active = ACTIVE.get();
        if (active == null) return;
        synchronized (active) {
            if (active.cancelled) throw new InterruptedIOException("Permintaan ide dibatalkan");
            active.connection = connection;
        }
    }

    boolean isCancelled() { return cancelled; }

    void cancel() {
        HttpURLConnection pending;
        synchronized (this) {
            cancelled = true;
            pending = connection;
            connection = null;
        }
        if (pending != null) {
            // Disconnect may block while a platform stream closes. Never block the WebView bridge.
            new Thread(pending::disconnect, "kf-idea-cancel").start();
        }
    }
}
