package id.kreasiflow.studio;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLExt;
import android.opengl.EGLSurface;
import android.opengl.GLES11Ext;
import android.opengl.GLUtils;
import android.view.Surface;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Objects;
import static android.opengl.GLES20.*;

/** Composes directly into the encoder surface. Footage stays in GPU textures. */
final class SurfaceCompositor686 implements AutoCloseable {
    private static final int EGL_RECORDABLE_ANDROID = 0x3142;
    private static final String VERTEX =
        "attribute vec2 aUv; uniform vec4 bounds; varying mediump vec2 uv;" +
        "void main(){ uv=aUv; gl_Position=vec4(2.0*(bounds.xy+aUv*bounds.zw)-1.0,0.0,1.0); }";
    private static final String VIDEO =
        "#extension GL_OES_EGL_image_external : require\nprecision mediump float;" +
        "varying mediump vec2 uv; uniform samplerExternalOES tex; uniform mat4 tx;" +
        "void main(){ gl_FragColor=texture2D(tex,(tx*vec4(uv,0.0,1.0)).xy); }";
    private static final String BITMAP =
        "precision mediump float; varying mediump vec2 uv; uniform sampler2D tex;" +
        "void main(){ gl_FragColor=texture2D(tex,vec2(uv.x,1.0-uv.y)); }";
    private static final String FILL =
        "precision mediump float; varying mediump vec2 uv; uniform float xWeight; uniform vec4 solid; uniform int mode;" +
        "void main(){float y=1.0-uv.y;" +
        "if(mode==0)gl_FragColor=vec4(mix(vec3(16.0,65.0,44.0),vec3(10.0,12.0,23.0),mix(y,uv.x,xWeight))/255.0,1.0);" +
        "else if(mode==1)gl_FragColor=vec4(0.0,0.0,0.0,clamp((y-.35)/.65,0.0,1.0)*187.0/255.0);" +
        "else gl_FragColor=solid;}";

    private final NativeVideoRenderer.Config config;
    private final FloatBuffer quad = ByteBuffer.allocateDirect(32).order(ByteOrder.nativeOrder()).asFloatBuffer();
    private EGLDisplay display = EGL14.EGL_NO_DISPLAY;
    private EGLContext context = EGL14.EGL_NO_CONTEXT;
    private EGLSurface target = EGL14.EGL_NO_SURFACE;
    private Program footage, overlay, fill;
    private Bitmap captionBitmap;
    private Canvas captionCanvas;
    private final Paint captionPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private int captionTop;
    private String previousCaption;
    private boolean previousTitle, overlayReady;
    private int videoTexture, overlayTexture, stillTexture, stillWidth, stillHeight;

    SurfaceCompositor686(NativeVideoRenderer.Config config, Surface encoderSurface) throws IOException {
        this.config = config;
        quad.put(new float[]{0,0, 1,0, 0,1, 1,1}).position(0);
        try {
            display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
            if (display == EGL14.EGL_NO_DISPLAY || !EGL14.eglInitialize(display,new int[2],0,new int[2],0))
                throw new IOException("EGL tidak tersedia.");
            int[] settings = {EGL14.EGL_RED_SIZE,8,EGL14.EGL_GREEN_SIZE,8,EGL14.EGL_BLUE_SIZE,8,
                EGL14.EGL_ALPHA_SIZE,8,EGL14.EGL_RENDERABLE_TYPE,EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_SURFACE_TYPE,EGL14.EGL_WINDOW_BIT,EGL_RECORDABLE_ANDROID,1,EGL14.EGL_NONE};
            var choices = new EGLConfig[1];
            int[] count = new int[1];
            if (!EGL14.eglChooseConfig(display,settings,0,choices,0,1,count,0) || count[0] == 0)
                throw new IOException("Konfigurasi EGL untuk encoder tidak tersedia.");
            context = EGL14.eglCreateContext(display,choices[0],EGL14.EGL_NO_CONTEXT,
                new int[]{EGL14.EGL_CONTEXT_CLIENT_VERSION,2,EGL14.EGL_NONE},0);
            target = EGL14.eglCreateWindowSurface(display,choices[0],encoderSurface,new int[]{EGL14.EGL_NONE},0);
            if (context == EGL14.EGL_NO_CONTEXT || target == EGL14.EGL_NO_SURFACE ||
                !EGL14.eglMakeCurrent(display,target,target,context)) throw new IOException("Surface EGL gagal dibuka.");
            footage = new Program(VIDEO);
            fill = new Program(FILL);
            overlay = new Program(BITMAP);
            videoTexture = createTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES);
            overlayTexture = createTexture(GL_TEXTURE_2D);
            glViewport(0,0,config.width,config.height);
            checkGl();
        } catch (RuntimeException | IOException error) {
            close();
            throw error;
        }
    }

    int videoTexture() {return videoTexture;}

    void loadStill(java.io.File file) throws IOException {
        long started=System.nanoTime();
        Bitmap bitmap=NativeVideoRenderer.decode(file,Math.max(config.width,config.height)*2);
        if (bitmap==null) throw new IOException("Gambar scene tidak dapat dibaca.");
        config.stats.frameSetupNs+=System.nanoTime()-started;
        try {
            long transfer=System.nanoTime();
            stillWidth=bitmap.getWidth();stillHeight=bitmap.getHeight();
            if (stillTexture==0) stillTexture=createTexture(GL_TEXTURE_2D);
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D,stillTexture);
            GLUtils.texImage2D(GL_TEXTURE_2D,0,bitmap,0);
            config.stats.stillUploadNs+=System.nanoTime()-transfer;
            checkGl();
        } finally {bitmap.recycle();}
    }

    void draw(SurfaceFrameReader686 reader, int scene, double time, long ptsUs) throws IOException {
        long started = System.nanoTime();
        glDisable(GL_BLEND);
        double offset = time - NativeVideoRenderer.sceneStart(config,scene);
        double slot = NativeVideoRenderer.sceneEnd(config,scene) - NativeVideoRenderer.sceneStart(config,scene);
        int sourceWidth=reader==null?stillWidth:reader.width;
        int sourceHeight=reader==null?stillHeight:reader.height;
        double scale = config.fit ? Math.min(config.width/(double)sourceWidth,config.height/(double)sourceHeight)
            : Math.max(config.width/(double)sourceWidth,config.height/(double)sourceHeight);
        boolean bridge = NativeVideoRenderer.bridgeBoundary686(config,scene);
        double zoom = !bridge && "Smooth zoom".equals(config.effect) ? 1 + .07 * offset / slot : 1;
        float width = (float)(sourceWidth * scale * zoom / config.width);
        float height = (float)(sourceHeight * scale * zoom / config.height);
        float shift = !bridge && "Slide pelan".equals(config.effect) ? (float)((offset/slot-.5)*.05) : 0;
        if (reader==null || height<1 || width-2*Math.abs(shift)<1) withFill(0,0,0);
        if (reader==null) {glEnable(GL_BLEND);glBlendFunc(GL_ONE,GL_ONE_MINUS_SRC_ALPHA);}
        Program program=reader==null?overlay:footage;
        begin(program,(1-width)*.5f+shift,(1-height)*.5f,width,height);
        glActiveTexture(GL_TEXTURE0);
        if (reader==null) glBindTexture(GL_TEXTURE_2D,stillTexture);
        else {
            glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,videoTexture);
            glUniformMatrix4fv(program.transform,1,false,reader.transform,0);
        }
        glUniform1i(program.texture,0);
        quad();
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
        withFill(1,0,0);
        if (config.fade) {
            double edge = Math.min(offset,slot-offset);
            if (edge < .25) withFill(2,0,((int)(110*(1-edge/.25)))/255f);
        }
        float transition = SceneTransition.alpha(config.sceneTransition,scene,config.scenes.size(),offset,slot,
            scene > 0 ? NativeVideoRenderer.sceneStart(config,scene)-NativeVideoRenderer.sceneStart(config,scene-1) : 0);
        if (config.smartLoop && scene == config.scenes.size()-1) transition = 0;
        if (transition > 0) withFill(2,"flash".equals(config.sceneTransition)?1:0,Math.round(255*transition)/255f);
        long subtitleStarted = System.nanoTime();
        drawOverlay(NativeVideoRenderer.captionAt686(config,time));
        long submitted = System.nanoTime();
        config.stats.subtitleNs += submitted - subtitleStarted;
        config.stats.glSubmitNs += submitted - started - (submitted - subtitleStarted);
        if (!EGLExt.eglPresentationTimeANDROID(display,target,ptsUs*1_000) ||
            !EGL14.eglSwapBuffers(display,target)) throw new IOException("Frame tidak dapat dikirim ke encoder surface.");
        config.stats.surfaceSwapNs += System.nanoTime() - submitted;
        checkGl();
    }

    private void drawOverlay(String caption) {
        boolean title = config.watermark != null && !config.watermark.trim().isEmpty();
        if (caption.isEmpty() && !title) {
            overlayReady = false;
            return;
        }
        // A stable glyph layer can remain resident between timestamps, including per-word karaoke cues.
        if (!overlayReady || !Objects.equals(caption,previousCaption) || title != previousTitle) {
            if (captionBitmap == null) {
                int height = config.height;
                int limit = Math.min(height,Math.max(4,(int)Math.ceil(config.width*.54f)));
                int baseline = Math.round(NativeVideoRenderer.captionBaseline686(config));
                captionTop = title ? 0 : Math.min(height-limit,Math.max(0,baseline-limit/2));
                if (title) limit = Math.min(height,baseline+limit/2);
                captionBitmap = Bitmap.createBitmap(config.width,limit,Bitmap.Config.ARGB_8888);
                captionCanvas = new Canvas(captionBitmap);
                captionCanvas.translate(0,-captionTop);
            }
            captionBitmap.eraseColor(Color.TRANSPARENT);
            NativeVideoRenderer.drawTextOverlay686(captionCanvas,config,caption,captionPaint);
            glBindTexture(GL_TEXTURE_2D,overlayTexture);
            if (previousCaption == null) GLUtils.texImage2D(GL_TEXTURE_2D,0,captionBitmap,0);
            else GLUtils.texSubImage2D(GL_TEXTURE_2D,0,0,0,captionBitmap);
            config.stats.subtitleUploads++;
            previousCaption = caption;
            previousTitle = title;
            overlayReady = true;
        }
        glBlendFunc(GL_ONE,GL_ONE_MINUS_SRC_ALPHA); // Canvas RGBA is premultiplied.
        float height = captionBitmap.getHeight()/(float)config.height;
        begin(overlay,0,1-captionTop/(float)config.height-height,1,height);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D,overlayTexture);
        glUniform1i(overlay.texture,0);
        quad();
    }

    private void withFill(int mode,float color,float alpha) {
        begin(fill,0,0,1,1);
        glUniform1i(fill.mode,mode);
        double w = config.width, h = config.height;
        glUniform1f(fill.xWeight,(float)(w*w/(w*w+h*h)));
        glUniform4f(fill.solid,color,color,color,alpha);
        quad();
    }

    private void begin(Program p,float x,float y,float w,float h) {
        glUseProgram(p.id);
        glUniform4f(p.bounds,x,y,w,h);
        glVertexAttribPointer(p.uv,2,GL_FLOAT,false,0,quad);
        glEnableVertexAttribArray(p.uv);
    }

    private void quad() {glDrawArrays(GL_TRIANGLE_STRIP,0,4);}

    private static int createTexture(int target) {
        int[] name = new int[1];
        glGenTextures(1,name,0);
        glBindTexture(target,name[0]);
        glTexParameteri(target,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
        glTexParameteri(target,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
        glTexParameteri(target,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);
        glTexParameteri(target,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);
        return name[0];
    }

    private static void checkGl() throws IOException {
        int error = glGetError();
        if (error != GL_NO_ERROR) throw new IOException("Komposisi GL gagal ("+error+").");
    }

    private static final class Program {
        final int id,uv,bounds,texture,transform,mode,solid,xWeight;
        Program(String source) throws IOException {
            int vert = compile(GL_VERTEX_SHADER,VERTEX), frag = 0;
            try {
                frag = compile(GL_FRAGMENT_SHADER,source);
                id = glCreateProgram();
                glAttachShader(id,vert);
                glAttachShader(id,frag);
                // All draws use the same attribute slot, irrespective of program.
                glBindAttribLocation(id,0,"aUv");
                glLinkProgram(id);
                int[] linked = new int[1];
                glGetProgramiv(id,GL_LINK_STATUS,linked,0);
                if (linked[0] == 0) {
                    glDeleteProgram(id);
                    throw new IOException("Program GL tidak kompatibel.");
                }
            } finally {
                glDeleteShader(vert);
                if (frag != 0) glDeleteShader(frag);
            }
            uv = glGetAttribLocation(id,"aUv");
            bounds = glGetUniformLocation(id,"bounds");
            texture = glGetUniformLocation(id,"tex");
            transform = glGetUniformLocation(id,"tx");
            mode = glGetUniformLocation(id,"mode");
            solid = glGetUniformLocation(id,"solid");
            xWeight = glGetUniformLocation(id,"xWeight");
        }
        private static int compile(int kind,String source) throws IOException {
            int shader = glCreateShader(kind);
            glShaderSource(shader,source);
            glCompileShader(shader);
            int[] compiled = new int[1];
            glGetShaderiv(shader,GL_COMPILE_STATUS,compiled,0);
            if (compiled[0] == 0) {
                glDeleteShader(shader);
                throw new IOException("Shader GL tidak kompatibel.");
            }
            return shader;
        }
    }

    @Override public void close() {
        if (captionBitmap != null) captionBitmap.recycle();
        if (display == EGL14.EGL_NO_DISPLAY) return;
        if (context != EGL14.EGL_NO_CONTEXT && EGL14.eglGetCurrentContext().equals(context)) {
            if (footage != null) glDeleteProgram(footage.id);
            if (overlay != null) glDeleteProgram(overlay.id);
            if (fill != null) glDeleteProgram(fill.id);
            glDeleteTextures(3,new int[]{videoTexture,overlayTexture,stillTexture},0);
        }
        EGL14.eglMakeCurrent(display,EGL14.EGL_NO_SURFACE,EGL14.EGL_NO_SURFACE,EGL14.EGL_NO_CONTEXT);
        if (target != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display,target);
        if (context != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display,context);
        EGL14.eglReleaseThread();
        EGL14.eglTerminate(display);
    }
}
