package id.kreasiflow.studio;

import android.graphics.SurfaceTexture;
import android.media.MediaCodec;
import android.media.MediaCodecList;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.os.Handler;
import android.view.Surface;
import java.io.File;
import java.io.IOException;

/** Decode in presentation order. Only selected frames enter the GL texture queue. */
final class SurfaceFrameReader686 implements AutoCloseable {
    private final MediaExtractor extract = new MediaExtractor();
    private final MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
    private final Object frameSignal = new Object();
    private final RenderStats685 stats;
    private MediaCodec decoder;
    private SurfaceTexture texture;
    private Surface surface;
    private boolean signalled, inputEnd, outputEnd, pendingEnd;
    private int pending = -1;
    private long base, previous = -1, pendingPts, targetBefore = -1;
    final int width, height, fps;
    final double seconds;
    final float[] transform = new float[16];

    SurfaceFrameReader686(File file, int textureId, Handler callback, RenderStats685 stats) throws Exception {
        this.stats = stats;
        long started = System.nanoTime();
        try {
            extract.setDataSource(file.getAbsolutePath());
            int video = NativeVideoRenderer.findTrack(extract, "video/");
            if (video < 0) throw new IOException("Video tidak punya trek.");
            MediaFormat format = extract.getTrackFormat(video);
            validateFormat(format);
            width = format.getInteger(MediaFormat.KEY_WIDTH);
            height = format.getInteger(MediaFormat.KEY_HEIGHT);
            fps = parseFrameRate(format, file);
            seconds = Math.max(.1, format.getLong(MediaFormat.KEY_DURATION) / 1_000_000.0);
            extract.selectTrack(video);
            base = extract.getSampleTime();
            if (base < 0) throw new IOException("Trek video tidak punya sampel.");
            texture = new SurfaceTexture(textureId);
            texture.setOnFrameAvailableListener(t -> {
                synchronized (frameSignal) {
                    signalled = true;
                    frameSignal.notifyAll();
                }
            }, callback);
            surface = new Surface(texture);
            decoder = openHardwareDecoder(format);
            stats.decoders.add(decoder.getName());
        } catch (Exception e) {
            close();
            throw e;
        } finally {
            stats.frameSetupNs += System.nanoTime() - started;
        }
    }

    static void validateFormat(MediaFormat format) throws IOException {
        int standard = format.getInteger(MediaFormat.KEY_COLOR_STANDARD, 0);
        if (format.getInteger(MediaFormat.KEY_ROTATION, 0) != 0
            || format.getInteger("sar-width", 1) != format.getInteger("sar-height", 1)
            || format.getInteger(MediaFormat.KEY_COLOR_TRANSFER, MediaFormat.COLOR_TRANSFER_SDR_VIDEO) > MediaFormat.COLOR_TRANSFER_SDR_VIDEO
            || (standard != 0 && standard != MediaFormat.COLOR_STANDARD_BT709 &&
                standard != MediaFormat.COLOR_STANDARD_BT601_PAL && standard != MediaFormat.COLOR_STANDARD_BT601_NTSC)
            || format.containsKey(MediaFormat.KEY_HDR_STATIC_INFO)
            || !format.containsKey(MediaFormat.KEY_DURATION)) {
            throw new IOException("Footage memerlukan jalur kompatibilitas.");
        }
    }

    private static int parseFrameRate(MediaFormat format, File file) {
        try {
            int rate = Math.round(format.getNumber(MediaFormat.KEY_FRAME_RATE, 0).floatValue());
            if (rate >= 1 && rate <= 240) return rate;
        } catch (RuntimeException ignored) {}
        return NativeVideoRenderer.sourceFrameRate(file);
    }

    private MediaCodec openHardwareDecoder(MediaFormat format) throws IOException, InterruptedException {
        String mime = format.getString(MediaFormat.KEY_MIME);
        for (var info : new MediaCodecList(MediaCodecList.REGULAR_CODECS).getCodecInfos()) {
            NativeVideoRenderer.cancelIfInterrupted();
            if (info.isEncoder() || info.isAlias() || !info.isHardwareAccelerated()) continue;
            MediaCodec candidate = null;
            try {
                if (!info.getCapabilitiesForType(mime).isFormatSupported(format)) continue;
                candidate = MediaCodec.createByCodecName(info.getName());
                candidate.configure(format, surface, null, 0);
                candidate.start();
                return candidate;
            } catch (RuntimeException | IOException failure) {
                if (candidate != null) candidate.release();
            }
        }
        throw new IOException("Decoder hardware sesuai footage tidak tersedia.");
    }

    void moveTo(long target) throws Exception {
        long started = System.nanoTime();
        try {
            if (target < targetBefore) throw new IOException("Timeline footage mundur.");
            if (targetBefore < 0 && target >= 1_000_000L)
                extract.seekTo(base+target,MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            targetBefore = target;
            if (previous >= target) return;
            int earlier=-1;
            long earlierPts=-1;
            boolean earlierEnd=false;
            while (true) {
                if (pending < 0 && !outputEnd && !earlierEnd) readNext();
                if (pending < 0 || pendingPts > target) break;
                if (earlier >= 0) decoder.releaseOutputBuffer(earlier,false);
                earlier=pending;earlierPts=pendingPts;earlierEnd=pendingEnd;
                pending=-1;
                if (earlierPts == target) break;
            }
            long floor=earlier<0?previous:earlierPts;
            if (pending >= 0 && RenderFrameClock686.takeNext(target,floor,pendingPts)) {
                if (earlier >= 0) decoder.releaseOutputBuffer(earlier,false);
                renderFrame(pending,pendingPts,pendingEnd);
                pending=-1;
            } else if (earlier >= 0) {
                renderFrame(earlier,earlierPts,earlierEnd || outputEnd);
            } else if (previous < 0) {
                throw new IOException("Tidak ada frame yang dapat ditampilkan.");
            }
        } finally {
            stats.decodeNs += System.nanoTime() - started;
        }
    }

    private void readNext() throws Exception {
        long deadline = System.nanoTime() + 4_000_000_000L;
        while (System.nanoTime() < deadline) {
            NativeVideoRenderer.cancelIfInterrupted();
            if (!inputEnd) {
                int index = decoder.dequeueInputBuffer(0);
                if (index >= 0) {
                    var buffer = decoder.getInputBuffer(index);
                    if (buffer == null) throw new IOException("Buffer decoder kosong.");
                    buffer.clear();
                    int size = extract.readSampleData(buffer, 0);
                    if (size < 0) {
                        decoder.queueInputBuffer(index, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        inputEnd = true;
                    } else {
                        decoder.queueInputBuffer(index, 0, size, extract.getSampleTime(), 0);
                        extract.advance();
                    }
                }
            }
            int index = decoder.dequeueOutputBuffer(info, 2_000);
            if (index < 0) continue;
            boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
            if (info.size == 0 || (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                decoder.releaseOutputBuffer(index, false);
                if (eos) {outputEnd = true; return;}
                continue;
            }
            pending = index;
            pendingEnd = eos;
            pendingPts = Math.max(0, info.presentationTimeUs - base);
            stats.decodedFrames++;
            return;
        }
        throw new IOException("Decoder hardware tidak mengembalikan frame.");
    }

    private void renderFrame(int index,long pts,boolean eos) throws Exception {
        long started = System.nanoTime();
        try {
            synchronized (frameSignal) {signalled = false;}
            decoder.releaseOutputBuffer(index, true);
            long deadline = System.nanoTime() + 2_000_000_000L;
            synchronized (frameSignal) {
                while (!signalled) {
                    long remaining = deadline - System.nanoTime();
                    if (remaining <= 0) throw new IOException("Frame tidak tiba di SurfaceTexture.");
                    frameSignal.wait(Math.max(1, remaining / 1_000_000L));
                }
            }
            texture.updateTexImage();
            texture.getTransformMatrix(transform);
            previous = pts;
            outputEnd = eos;
            stats.latchedFrames++;
        } finally {
            stats.textureLatchNs += System.nanoTime() - started;
        }
    }

    @Override public void close() {
        if (decoder != null) {
            try {decoder.stop();} catch (RuntimeException ignored) {}
            try {decoder.release();} catch (RuntimeException ignored) {}
        }
        extract.release();
        if (surface != null) surface.release();
        if (texture != null) texture.release();
    }
}
