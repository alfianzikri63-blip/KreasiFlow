package id.kreasiflow.studio;

import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.Surface;
import java.io.File;
import java.io.IOException;

/** Hardware decoder SurfaceTexture -> EGL compositor -> AVC encoder input surface. */
final class SurfaceVideoRenderer686 {
    private static final int SURFACE = MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface;

    static String ineligible(NativeVideoRenderer.Config c) {
        for (int i=0;i<c.scenes.size();i++) {
            File clip=clip(c,i);
            if (clip!=null && !clip.isFile()) return "File footage tidak tersedia.";
            File still=c.scenes.get(i).image;
            if (clip==null && (c.smartLoop || still==null || !still.isFile()))
                return "Scene tanpa footage memerlukan komposisi kompatibilitas.";
        }
        if (c.outro != null) return "Outro memerlukan komposisi kompatibilitas.";
        if (c.frameBlend) return "Frame Blend memerlukan komposisi kompatibilitas.";
        if ("dissolve".equals(c.sceneTransition)) return "Dissolve memerlukan komposisi kompatibilitas.";
        if (c.clipParts != null)
            for (double[] parts : c.clipParts)
                if (parts != null && parts.length > 0) return "Timeline memiliki lompatan sumber di dalam scene.";
        return "";
    }

    private static File clip(NativeVideoRenderer.Config c,int i) {
        return c.motionClips!=null&&i<c.motionClips.size()?c.motionClips.get(i):null;
    }

    static void encode(NativeVideoRenderer.Config config, File file, NativeVideoRenderer.Progress progress) throws Exception {
        RenderStats685 stats = config.stats;
        long setup = System.nanoTime();
        preflightSources(config);
        String name = encoderName(config);
        HandlerThread callbacks = new HandlerThread("KF-decode-surface");
        callbacks.start();
        Handler handler = new Handler(callbacks.getLooper());
        MediaCodec codec = null;
        Surface surface = null;
        SurfaceFrameReader686 reader = null;
        boolean muxStarted = false;
        try {
            codec = MediaCodec.createByCodecName(name);
            MediaFormat format = NativeVideoRenderer.outputFormat686(config.width, config.height, config.fps, SURFACE);
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            surface = codec.createInputSurface();
            codec.start();
            try (SurfaceCompositor686 compositor = new SurfaceCompositor686(config,surface)) {
                MediaMuxer mux = new MediaMuxer(file.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                try {
                    stats.path = "codec-surface";
                    stats.encoder = codec.getName();
                    stats.hardware = true;
                    stats.phase = "video";
                    stats.frameTotal = (int)Math.ceil(config.seconds*config.fps);
                    stats.videoNs = System.nanoTime();
                    stats.videoSetupNs += stats.videoNs - setup;
                    progress.onProgress(0,"Decoding berurutan dan komposisi GPU");
                    int frames = stats.frameTotal;
                    int lastScene = -1, track = -1;
                    long lastUpdate = 0;
                    MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
                    try {
                        for (int f = 0; f < frames; f++) {
                            NativeVideoRenderer.cancelIfInterrupted();
                            double time = f/(double)config.fps;
                            int scene = NativeVideoRenderer.sceneAt(config,time);
                            if (scene != lastScene) {
                                if (reader != null) reader.close();
                                reader = null;
                                File clip = clip(config,scene);
                                if (clip != null)
                                    reader = new SurfaceFrameReader686(clip,compositor.videoTexture(),handler,stats);
                                else compositor.loadStill(config.scenes.get(scene).image);
                                lastScene = scene;
                                stats.scenes = scene+1;
                            }
                            if (reader != null) {
                                double start = NativeVideoRenderer.sceneStart(config,scene);
                                double slot = NativeVideoRenderer.sceneEnd(config,scene)-start;
                                boolean end = config.smartLoop && config.directLoop && scene == config.scenes.size()-1;
                                double trim = config.trimStarts == null ? 0 : config.trimStarts[scene];
                                int index = RenderFrameClock686.sourceIndex(time-start,slot,reader.seconds,reader.fps,
                                    NativeVideoRenderer.bridgeBoundary686(config,scene),trim,null,end,
                                    f,(int)Math.ceil(start*config.fps-1e-7),frames);
                                reader.moveTo(RenderFrameClock686.ptsUs(index,reader.fps));
                            }
                            compositor.draw(reader,scene,time,RenderFrameClock686.ptsUs(f,config.fps));
                            long drain = System.nanoTime();
                            var result = NativeVideoRenderer.drainVideo(codec,mux,track,muxStarted,info,false,stats);
                            stats.encoderOutputNs += System.nanoTime()-drain;
                            track = result.track;
                            muxStarted = result.started;
                            stats.frames += result.samples;
                            long now = System.nanoTime();
                            if (now-lastUpdate >= 500_000_000L) {
                                progress.onProgress((int)(stats.frames*100L/frames),"Encoding H.264 dari GPU");
                                lastUpdate = now;
                            }
                        }
                    } finally {
                        if (reader != null) {reader.close(); reader = null;}
                    }
                    long finish = System.nanoTime();
                    codec.signalEndOfInputStream();
                    var end = NativeVideoRenderer.drainVideo(codec,mux,track,muxStarted,info,true,stats);
                    stats.encoderOutputNs += System.nanoTime()-finish;
                    stats.encoderInputNs = stats.surfaceSwapNs;
                    stats.encodeNs = stats.encoderInputNs + stats.encoderOutputNs;
                    muxStarted = end.started;
                    stats.frames += end.samples;
                    stats.videoEndNs = System.nanoTime();
                    if (!muxStarted || stats.frames != frames)
                        throw new IOException("Jumlah frame hasil codec surface tidak utuh ("+stats.frames+"/"+frames+").");
                    long stopping = System.nanoTime();
                    mux.stop();
                    muxStarted = false;
                    stats.videoFinalizeNs += System.nanoTime()-stopping;
                } finally {
                    if (muxStarted) try {mux.stop();} catch (RuntimeException ignored) {}
                    mux.release();
                }
            }
        } finally {
            if (reader != null) reader.close();
            if (codec != null) {
                try {codec.stop();} catch (RuntimeException ignored) {}
                try {codec.release();} catch (RuntimeException ignored) {}
            }
            if (surface != null) surface.release();
            callbacks.quitSafely();
        }
    }

    private static void preflightSources(NativeVideoRenderer.Config config) throws IOException, InterruptedException {
        if (config.motionClips == null) return;
        for (File clip : new java.util.HashSet<>(config.motionClips)) {
            if (clip == null) continue;
            NativeVideoRenderer.cancelIfInterrupted();
            MediaExtractor ex = new MediaExtractor();
            try {
                ex.setDataSource(clip.getAbsolutePath());
                int track = NativeVideoRenderer.findTrack(ex,"video/");
                if (track < 0) throw new IOException("Footage tidak punya trek video.");
                SurfaceFrameReader686.validateFormat(ex.getTrackFormat(track));
            } finally {ex.release();}
        }
    }

    private static String encoderName(NativeVideoRenderer.Config c) throws IOException {
        for (MediaCodecInfo info : new MediaCodecList(MediaCodecList.REGULAR_CODECS).getCodecInfos()) {
            if (!info.isEncoder() || info.isAlias() || !info.isHardwareAccelerated()) continue;
            try {
                var caps = info.getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_AVC);
                if (caps.getVideoCapabilities().areSizeAndRateSupported(c.width,c.height,c.fps))
                    for (int color : caps.colorFormats) if (color == SURFACE) return info.getName();
            } catch (IllegalArgumentException ignored) {}
        }
        throw new IOException("Encoder AVC hardware tidak menerima Surface untuk pengaturan proyek.");
    }
}
