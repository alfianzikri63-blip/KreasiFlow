package id.kreasiflow.studio;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import org.json.JSONObject;
import java.io.IOException;

/** Local reusable animated end card. No AI, no external network. */
final class ThemeOutro {
    final String id,headline,text,channel;
    final int background,accent;
    final double seconds;
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private ThemeOutro(JSONObject o)throws IOException{
        id=o.optString("id","general");headline=limit(o.optString("headline"),70);text=limit(o.optString("text"),180);channel=limit(o.optString("channel"),60);
        seconds=o.optDouble("seconds",5);
        if(!Double.isFinite(seconds)||seconds<3||seconds>15||headline.isEmpty()||text.isEmpty())throw new IOException("Template outro tidak valid");
        try{background=Color.parseColor(o.optString("background"));accent=Color.parseColor(o.optString("accent"));}catch(Exception e){throw new IOException("Warna template outro tidak valid",e);}
    }
    static ThemeOutro fromJson(JSONObject o)throws IOException{return new ThemeOutro(o);}
    private static String limit(String s,int n){return s.substring(0,Math.min(n,s.length()));}
    private void color(int c,float width){p.setColor(c);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(width);}
    void draw(Canvas c,int w,int h,double t){
        float u=Math.min(w,h),cx=w/2f,cy=h*.34f,r=u*.15f;
        p.setStyle(Paint.Style.FILL);p.setShader(new LinearGradient(0,0,w,h,background,0xff080e18,Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,p);p.setShader(null);
        float pulse=(float)(1+.055*Math.sin(t*2.2));
        c.save();c.translate(cx,cy);c.scale(pulse,pulse);
        color((accent&0x00ffffff)|0x33000000,u*.003f);for(int i=1;i<=3;i++)c.drawCircle(0,0,r*(1+i*.19f),p);
        color(accent,u*.008f);p.setStrokeCap(Paint.Cap.ROUND);
        switch(id){
            case "geo": c.drawCircle(0,0,r,p);c.drawOval(-r*.48f,-r,r*.48f,r,p);c.drawOval(-r,-r*.43f,r,r*.43f,p);c.drawLine(-r,0,r,0,p);break;
            case "business": for(int i=0;i<4;i++){float x=-r+i*r*.55f;float y=r-(i+1)*r*.43f;c.drawRect(x,y,x+r*.35f,r,p);}c.drawLine(-r,-r*.3f,r,-r,p);break;
            case "whatif": p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextAlign(Paint.Align.CENTER);p.setTextSize(r*1.8f);c.drawText("?",0,r*.63f,p);break;
            case "science": for(int i=0;i<3;i++){c.save();c.rotate(i*60);c.drawOval(-r,-r*.36f,r,r*.36f,p);c.restore();}c.drawCircle(0,0,r*.13f,p);break;
            case "history": c.drawLine(-r,-r*.7f,r,-r*.7f,p);c.drawLine(-r,r*.7f,r,r*.7f,p);for(int i=-1;i<=1;i++)c.drawLine(i*r*.65f,-r*.6f,i*r*.65f,r*.6f,p);c.drawLine(-r,-r*.7f,0,-r*1.15f,p);c.drawLine(0,-r*1.15f,r,-r*.7f,p);break;
            case "tech": c.drawRoundRect(-r*.7f,-r*.7f,r*.7f,r*.7f,r*.12f,r*.12f,p);c.drawRect(-r*.32f,-r*.32f,r*.32f,r*.32f,p);for(int i=-1;i<=1;i++){float a=i*r*.38f;c.drawLine(a,-r,a,-r*.7f,p);c.drawLine(a,r,a,r*.7f,p);c.drawLine(-r,a,-r*.7f,a,p);c.drawLine(r,a,r*.7f,a,p);}break;
            case "mystery": c.drawOval(-r,-r*.64f,r,r*.64f,p);c.drawCircle(0,0,r*.35f,p);break;
            case "psychology": c.drawCircle(-r*.36f,0,r*.68f,p);c.drawCircle(r*.36f,0,r*.68f,p);break;
            default:c.drawCircle(0,0,r,p);c.drawLine(-r*.45f,0,-r*.08f,r*.36f,p);c.drawLine(-r*.08f,r*.36f,r*.52f,-r*.36f,p);
        }c.restore();
        p.setStrokeCap(Paint.Cap.BUTT);p.setStyle(Paint.Style.FILL);p.setTextAlign(Paint.Align.CENTER);
        p.setColor(accent);p.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));p.setTextSize(u*.076f);while(p.measureText(headline)>w*.84f&&p.getTextSize()>u*.035f)p.setTextSize(p.getTextSize()*.92f);c.drawText(headline,cx,h*.57f,p);
        p.setColor(Color.WHITE);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(u*.045f);float y=h*.66f;String line="";for(String word:text.split("\\s+")){String next=line.isEmpty()?word:line+" "+word;if(!line.isEmpty()&&p.measureText(next)>w*.80f){c.drawText(line,cx,y,p);y+=u*.064f;line=word;}else line=next;}if(!line.isEmpty())c.drawText(line,cx,y,p);
        p.setColor(accent);p.setTextSize(u*.032f);if(!channel.isEmpty()){while(p.measureText(channel)>w*.85f)p.setTextSize(p.getTextSize()*.9f);c.drawText(channel,cx,h*.9f,p);}
        p.setColor(accent);c.drawRect(w*.12f,h*.95f,w*.12f+w*.76f*(float)Math.min(1,t/seconds),h*.956f,p);
    }
}
