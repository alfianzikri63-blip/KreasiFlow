package id.kreasiflow.studio;

import org.json.JSONObject;
import org.json.JSONArray;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/** BYOK speech-to-text transport. Fixed HTTPS endpoints; key and audio never enter WebView JS.
 *  v5.0.39: ElevenLabs Scribe v3 preferred; Groq Whisper v3 Turbo optional fallback.
 *  Network work must run on MainActivity's apiPool, not the UI thread.
 */
final class TranscriptionProviders {
    private static final int MAX_AUDIO = 12 * 1024 * 1024;
    private static final int MAX_RESPONSE = 2 * 1024 * 1024;
    private static final String ELEVEN_URL = "https://api.elevenlabs.io/v1/speech-to-text";
    private static final String GROQ_URL = "https://api.groq.com/openai/v1/audio/transcriptions";

    static String transcribe(String provider, File audio, String mime, double seconds, String key,
                             String language) throws Exception {
        if (!"elevenlabs".equals(provider) && !"groq".equals(provider))
            throw new IOException("Provider transkripsi tidak dikenal");
        if (key == null || key.trim().length() < 8)
            throw new IOException("API key " + provider + " belum tersimpan");
        if (audio == null || !audio.isFile() || audio.length() <= 0 || audio.length() > MAX_AUDIO)
            throw new IOException("Unggah VO berukuran maksimal 12 MB dahulu");
        if (!Double.isFinite(seconds) || seconds <= 0 || seconds > 1800)
            throw new IOException("Durasi VO harus 0–30 menit");
        String ext = extensionFor(mime);
        if (ext == null) throw new IOException("Format VO tidak didukung; gunakan MP3/WAV/M4A/AAC/OGG/FLAC");
        boolean eleven = "elevenlabs".equals(provider);
        String boundary = "KF_STT_" + UUID.randomUUID().toString().replace("-", "");
        HttpURLConnection c = (HttpURLConnection) new URL(eleven ? ELEVEN_URL : GROQ_URL).openConnection();
        c.setInstanceFollowRedirects(false);
        c.setRequestMethod("POST");
        c.setConnectTimeout(20000);
        c.setReadTimeout(190000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty(eleven ? "xi-api-key" : "Authorization", eleven ? key.trim() : "Bearer " + key.trim());
        // Fixed Content-Length is more portable than chunked multipart on speech API gateways.
        ByteArrayOutputStream prefix = new ByteArrayOutputStream();
        if (eleven) {
            field(prefix, boundary, "model_id", "scribe_v3");
            field(prefix, boundary, "timestamps_granularity", "word");
            field(prefix, boundary, "tag_audio_events", "false");
            field(prefix, boundary, "diarize", "false");
            if ("id".equals(language) || "en".equals(language)) field(prefix, boundary, "language_code", language);
        } else {
            field(prefix, boundary, "model", "whisper-large-v3-turbo");
            field(prefix, boundary, "response_format", "verbose_json");
            field(prefix, boundary, "timestamp_granularities[]", "word");
            field(prefix, boundary, "timestamp_granularities[]", "segment");
            if ("id".equals(language) || "en".equals(language)) field(prefix, boundary, "language", language);
        }
        write(prefix, "--" + boundary + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"voiceover." + ext + "\"\r\nContent-Type: " + mime + "\r\n\r\n");
        byte[] closing = ("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8);
        c.setFixedLengthStreamingMode((long)prefix.size() + audio.length() + closing.length);
        try {
            try (OutputStream out = c.getOutputStream()) {
                prefix.writeTo(out);
                try (InputStream in = new FileInputStream(audio)) {
                    byte[] buf = new byte[16384]; int n;
                    while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                }
                out.write(closing);
            }
            int status = c.getResponseCode();
            if (status < 200 || status >= 300) {
                String msg = "";
                InputStream er = c.getErrorStream();
                if (er != null) msg = new String(readLimited(er, 12000), StandardCharsets.UTF_8);
                try {
                    JSONObject j = new JSONObject(msg);
                    Object detail = j.opt("detail");
                    if (detail != null) msg = detail instanceof String ? (String) detail : detail.toString();
                    JSONObject e = j.optJSONObject("error");
                    if (e != null) msg = e.optString("message", msg);
                } catch (Exception ignored) { }
                msg = msg.replaceAll("[\\r\\n\\t]+", " ");
                if (msg.length() > 190) msg = msg.substring(0, 190);
                throw new IOException(provider + " HTTP " + status + ": " + (msg.isEmpty() ? "Permintaan STT ditolak" : msg));
            }
            InputStream input = c.getInputStream();
            if (input == null) throw new IOException(provider + ": respons transkrip kosong");
            JSONObject data = new JSONObject(new String(readLimited(input, MAX_RESPONSE), StandardCharsets.UTF_8));
            if (eleven) {
                JSONArray words = data.optJSONArray("words");
                if (words == null || words.length() == 0) throw new IOException("ElevenLabs tidak mengembalikan word timestamps");
                // Preserve native word timestamps; browser groups them into SRT cues.
                return new JSONObject().put("provider", provider).put("model", "scribe_v3")
                    .put("words", words).put("text", data.optString("text", "")).toString();
            }
            JSONArray words = data.optJSONArray("words");
            JSONArray segments = data.optJSONArray("segments");
            if ((words == null || words.length() == 0) && (segments == null || segments.length() == 0))
                throw new IOException("Groq tidak mengembalikan timestamp transkrip");
            JSONObject safe = new JSONObject().put("provider", provider).put("model", "whisper-large-v3-turbo")
                .put("text", data.optString("text", ""));
            if (words != null) safe.put("words", words);
            if (segments != null) safe.put("segments", segments);
            return safe.toString();
        } finally { c.disconnect(); }
    }

    private static String extensionFor(String mime) {
        switch (mime) {
            case "audio/mpeg": case "audio/mp3": return "mp3";
            case "audio/wav": case "audio/x-wav": return "wav";
            case "audio/mp4": return "m4a";
            case "audio/aac": return "aac";
            case "audio/ogg": return "ogg";
            case "audio/flac": return "flac";
            default: return null;
        }
    }
    private static void write(OutputStream out, String text) throws IOException {
        out.write(text.getBytes(StandardCharsets.UTF_8));
    }
    private static void field(OutputStream out, String boundary, String name, String value) throws IOException {
        write(out, "--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + name + "\"\r\n\r\n" + value + "\r\n");
    }
    private static byte[] readLimited(InputStream in, int limit) throws IOException {
        try (InputStream source = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192]; int n;
            while ((n = source.read(buf)) != -1) {
                if (out.size() + n > limit) throw new IOException("Respons STT melebihi batas aman");
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        }
    }
}
