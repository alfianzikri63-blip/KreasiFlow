package id.kreasiflow.studio;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.widget.Toast;
import android.util.Log;

import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.io.File;
import java.io.FileInputStream;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/** Pembaruan APK dari GitHub Releases, tanpa silent install. */
final class UpdateController {
    private static final int PERMISSION_NOTIFICATIONS=590;
    private static final String PREFS="updates";
    private final MainActivity host;
    private final SharedPreferences prefs;
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private long promptedDownload=-1L;
    private long checkingDownload=-1L;
    private boolean promptedRelease;
    private boolean waitingForInstallPermission;
    private boolean closed;
    private boolean receiverRegistered;
    private ReleaseApi.Release latestSeen;

    private final BroadcastReceiver completed=new BroadcastReceiver(){
        @Override public void onReceive(Context c,Intent i){
            if(DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(i.getAction()) &&
                    i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID,-1L)==prefs.getLong("download_id",-1L)) {
                host.runOnUiThread(UpdateController.this::checkPendingDownload);
            }
        }
    };

    UpdateController(MainActivity host){this.host=host;this.prefs=host.getSharedPreferences(PREFS,Context.MODE_PRIVATE);}

    void start(){
        discardObsoleteDownload();
        String notified=prefs.getString("last_notified_tag", "");
        if(!notified.isEmpty()&&ReleaseApi.compare(notified,BuildConfig.VERSION_NAME)<=0)UpdateNotifier.cancel(host);
        // Jangan biarkan modul update membuat aplikasi crash ketika baru dibuka.
        try { UpdateNotifier.createChannel(host); }
        catch (RuntimeException ex) { Log.e("KreasiFlowUpdate","Notification channel unavailable",ex); }
        try {
            Constraints constraints=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
            PeriodicWorkRequest req=new PeriodicWorkRequest.Builder(UpdateWorker.class,6,TimeUnit.HOURS)
                .setConstraints(constraints).build();
            WorkManager.getInstance(host).enqueueUniquePeriodicWork("kreasiflow-release-check",ExistingPeriodicWorkPolicy.KEEP,req);
        } catch (RuntimeException ex) {
            Log.e("KreasiFlowUpdate","Background update scheduling unavailable",ex);
        }
        try {
            // Android 14+ mewajibkan flag untuk receiver dinamis non-protected.
            // DownloadManager memakai broadcast dari layanan sistem; status file
            // tetap diperiksa terhadap ID unduhan, SHA-256, dan package APK.
            ContextCompat.registerReceiver(host,completed,
                new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE),ContextCompat.RECEIVER_EXPORTED);
            receiverRegistered=true;
        } catch (RuntimeException ex) {
            // Fallback: unduhan masih bisa ditemukan oleh onResume() tanpa receiver.
            Log.e("KreasiFlowUpdate","Download receiver unavailable",ex);
        }
        // Android 13+: notifikasi perlu izin eksplisit pengguna.
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(host,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED
                && !prefs.getBoolean("notif_permission_requested",false)) {
            prefs.edit().putBoolean("notif_permission_requested",true).apply();
            host.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},PERMISSION_NOTIFICATIONS);
        }
        checkForUpdate(false,false);
    }

    void onResume(){
        if(waitingForInstallPermission && (Build.VERSION.SDK_INT<26 || host.getPackageManager().canRequestPackageInstalls())){
            waitingForInstallPermission=false;
            File f=getPendingFile();
            if(f!=null && f.exists())validateThenInstall(f,true);
        }else checkPendingDownload();
    }

    void onNotificationTap(){checkForUpdate(false,true);}
    void checkManually(){checkForUpdate(true,true);}

    private void checkForUpdate(boolean manual,boolean forcePrompt){
        if(!ReleaseApi.isConfigured()){
            if(manual)message("Repo GitHub belum disetel. Build APK dari workflow GitHub Release agar repo terisi otomatis.");
            return;
        }
        if(manual)message("Memeriksa GitHub Releases…");
        executor.execute(()->{
            try{
                ReleaseApi.Release r=ReleaseApi.latest();
                host.runOnUiThread(()->{
                    if(closed||host.isFinishing())return;
                    if(r==null){if(manual)message("Belum ada rilis stabil di GitHub.");return;}
                    latestSeen=r;
                    if(r.isNewer()){
                        UpdateNotifier.notifyIfNeeded(host,r);
                        if(forcePrompt||!promptedRelease){
                            promptedRelease=true;
                            showRelease(r);
                        }
                    }else if(manual){message("KreasiFlow Studio sudah versi terbaru (v"+BuildConfig.VERSION_NAME+").");}
                });
            }catch(Exception e){
                if(manual)host.runOnUiThread(()->message("Gagal cek update: " + e.getMessage()));
            }
        });
    }

    private void showRelease(ReleaseApi.Release r){
        String text="Terpasang: v"+BuildConfig.VERSION_NAME+"\nTersedia: "+r.tag+"\n\n"+
            (r.notes.isEmpty()?"Pembaruan KreasiFlow Studio tersedia.":r.notes);
        new AlertDialog.Builder(host).setTitle("Pembaruan tersedia")
            .setMessage(text)
            .setNegativeButton("Nanti",(d,w)->{})
            .setNeutralButton("Lihat rilis",(d,w)->host.openExternal(r.pageUrl))
            .setPositiveButton(r.canInstallInsideApp()?"Unduh APK":"Buka GitHub",(d,w)->{
                if(r.canInstallInsideApp())download(r); else {
                    message("Hash SHA-256/berkas APK tidak tersedia. Buka halaman rilis untuk instalasi manual.");
                    host.openExternal(r.pageUrl);
                }
            }).show();
    }

    private File downloadDir(){return host.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);}
    private File getPendingFile(){
        File d=downloadDir();
        String name=prefs.getString("download_filename","");
        if(d==null||!name.matches("KreasiFlow-Studio-[0-9]+\\.[0-9]+\\.[0-9]+\\.apk"))return null;
        return new File(d,name);
    }
    private void download(ReleaseApi.Release release){
        if(!release.isNewer())return;
        if(release.apkUrl==null||release.sha256==null){host.openExternal(release.pageUrl);return;}
        File dir=downloadDir();
        if(dir==null){message("Penyimpanan tidak tersedia.");return;}
        String fileName="KreasiFlow-Studio-"+release.version+".apk";
        File file=new File(dir,fileName);
        if(file.exists()&&!file.delete()){message("Tidak bisa mengganti unduhan lama.");return;}
        try{
            DownloadManager.Request req=new DownloadManager.Request(Uri.parse(release.apkUrl));
            req.setTitle("KreasiFlow Studio "+release.tag);
            req.setDescription("Pembaruan aplikasi resmi dari GitHub Releases");
            req.setMimeType("application/vnd.android.package-archive");
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalFilesDir(host,Environment.DIRECTORY_DOWNLOADS,fileName);
            DownloadManager manager=(DownloadManager)host.getSystemService(Context.DOWNLOAD_SERVICE);
            long id=manager.enqueue(req);
            promptedDownload=-1L;
            prefs.edit().putLong("download_id",id).putString("download_sha256",release.sha256)
                .putString("download_version",release.version).putString("download_filename",fileName).apply();
            message("Unduhan dimulai. Saat selesai, ketuk untuk memasang APK.");
        }catch(Exception e){message("Unduhan gagal: "+e.getMessage());host.openExternal(release.pageUrl);}
    }

    private boolean discardObsoleteDownload(){
        long id=prefs.getLong("download_id",-1L);
        if(id<0)return false;
        if(ReleaseApi.compare(prefs.getString("download_version",""),BuildConfig.VERSION_NAME)>0)return false;
        File file=getPendingFile();
        clearPending();
        try { ((DownloadManager)host.getSystemService(Context.DOWNLOAD_SERVICE)).remove(id); } catch(RuntimeException ignored){}
        if(file!=null)file.delete();
        UpdateNotifier.cancel(host);
        return true;
    }
    private void checkPendingDownload(){
        if(discardObsoleteDownload())return;
        long id=prefs.getLong("download_id",-1L);
        if(id<0 || promptedDownload==id || checkingDownload==id)return;
        DownloadManager manager=(DownloadManager)host.getSystemService(Context.DOWNLOAD_SERVICE);
        try(android.database.Cursor c=manager.query(new DownloadManager.Query().setFilterById(id))){
            if(c==null||!c.moveToFirst())return;
            int col=c.getColumnIndex(DownloadManager.COLUMN_STATUS);
            if(col<0)return;
            int state=c.getInt(col);
            if(state==DownloadManager.STATUS_SUCCESSFUL){
                File f=getPendingFile();
                if(f==null||!f.isFile()){
                    clearPending();message("File pembaruan tidak ditemukan.");return;
                }
                checkingDownload=id;
                executor.execute(()->{
                    boolean verified=verify(f,prefs.getString("download_sha256",""))&&samePackage(f);
                    host.runOnUiThread(()->{
                        checkingDownload=-1L;
                        if(closed||host.isFinishing()||prefs.getLong("download_id",-1L)!=id||discardObsoleteDownload())return;
                        if(!verified){
                            f.delete();clearPending();message("APK tidak sesuai checksum atau identitas aplikasi. Unduh ulang dari GitHub.");return;
                        }
                        promptedDownload=id;
                        showInstallDialog(f);
                    });
                });
            }else if(state==DownloadManager.STATUS_FAILED){clearPending();message("Gagal mengunduh APK. Coba lagi lewat tombol Update.");}
        }catch(Exception e){message("Gagal membaca status unduhan.");}
    }

    private boolean samePackage(File file){
        PackageInfo p=host.getPackageManager().getPackageArchiveInfo(file.getAbsolutePath(),0);
        return p!=null&&host.getPackageName().equals(p.packageName);
    }
    private static boolean verify(File file,String expected){
        if(expected==null||!expected.matches("[a-f0-9]{64}"))return false;
        try(FileInputStream in=new FileInputStream(file)){
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[] buf=new byte[32768];int n;
            while((n=in.read(buf))>=0){if(n>0)md.update(buf,0,n);}
            byte[] b=md.digest();StringBuilder sb=new StringBuilder();
            for(byte x:b)sb.append(String.format(Locale.US,"%02x",x&255));
            return expected.equals(sb.toString());
        }catch(Exception e){return false;}
    }
    private void showInstallDialog(File file){
        if(discardObsoleteDownload())return;
        String v=prefs.getString("download_version","");
        new AlertDialog.Builder(host).setTitle("APK siap dipasang")
            .setMessage("KreasiFlow v"+v+" berhasil diunduh dan lolos verifikasi SHA-256. Android akan meminta izin instalasi. Data proyek tidak dihapus jika tanda tangan aplikasinya sama.")
            .setNegativeButton("Nanti",(d,w)->{})
            .setPositiveButton("Pasang update",(d,w)->install(file)).show();
    }
    private void validateThenInstall(File f,boolean viaSettings){
        if(!viaSettings){install(f);return;}
        executor.execute(()->{
            boolean valid=verify(f,prefs.getString("download_sha256",""))&&samePackage(f);
            host.runOnUiThread(()->{if(valid)install(f);else{f.delete();clearPending();message("Verifikasi APK gagal.");}});
        });
    }
    private void install(File file){
        if(discardObsoleteDownload()||prefs.getLong("download_id",-1L)<0)return;
        if(Build.VERSION.SDK_INT>=26 && !host.getPackageManager().canRequestPackageInstalls()){
            new AlertDialog.Builder(host).setTitle("Izin instal APK")
                .setMessage("Android perlu izin 'Instal aplikasi tidak dikenal' untuk KreasiFlow. Aktifkan hanya jika kamu mempercayai rilis GitHub ini.")
                .setNegativeButton("Batal",(d,w)->{})
                .setPositiveButton("Buka pengaturan",(d,w)->{
                    waitingForInstallPermission=true;
                    Intent settings=new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:"+host.getPackageName()));
                    host.startActivity(settings);
                }).show();
            return;
        }
        try{
            Uri uri=FileProvider.getUriForFile(host,host.getPackageName()+".fileprovider",file);
            Intent i=new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri,"application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            host.startActivity(i);
        }catch(Exception e){message("Gagal membuka pemasang APK: "+e.getMessage());}
    }
    private void clearPending(){
        prefs.edit().remove("download_id").remove("download_sha256")
            .remove("download_version").remove("download_filename").apply();
    }
    private void message(String s){Toast.makeText(host,s,Toast.LENGTH_LONG).show();}
    void stop(){
        closed=true;
        if(receiverRegistered) {
            try{host.unregisterReceiver(completed);}catch(RuntimeException ignored){}
            receiverRegistered=false;
        }
        executor.shutdownNow();
    }
}
