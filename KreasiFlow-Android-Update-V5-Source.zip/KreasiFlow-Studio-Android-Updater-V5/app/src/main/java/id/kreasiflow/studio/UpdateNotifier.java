package id.kreasiflow.studio;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

final class UpdateNotifier {
    private static final String CHANNEL="kreasiflow_updates";
    private static final int NOTIF_ID=1589;
    static void cancel(Context context){
        NotificationManagerCompat.from(context).cancel(NOTIF_ID);
    }
    static void createChannel(Context context){
        NotificationManager m=context.getSystemService(NotificationManager.class);
        if(m==null)return;
        NotificationChannel c=new NotificationChannel(CHANNEL,"Pembaruan KreasiFlow",NotificationManager.IMPORTANCE_DEFAULT);
        c.setDescription("Pemberitahuan versi APK baru dari GitHub Releases");
        m.createNotificationChannel(c);
    }
    static void notifyIfNeeded(Context context,ReleaseApi.Release release){
        if(!release.isNewer()){cancel(context);return;}
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(context,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        NotificationManagerCompat manager=NotificationManagerCompat.from(context);
        if(!manager.areNotificationsEnabled())return;
        String key="last_notified_tag";
        String versionKey="last_notified_version";
        if(release.version.equals(context.getSharedPreferences("updates",Context.MODE_PRIVATE).getString(versionKey,""))
           ||release.tag.equals(context.getSharedPreferences("updates",Context.MODE_PRIVATE).getString(key,"")))return;
        createChannel(context);
        Intent i=new Intent(context,MainActivity.class);
        i.setAction("id.kreasiflow.studio.SHOW_UPDATE");
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi=PendingIntent.getActivity(context,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b=new NotificationCompat.Builder(context,CHANNEL)
            .setSmallIcon(R.drawable.ic_kreasiflow)
            .setContentTitle("KreasiFlow Studio " + release.tag + " tersedia")
            .setContentText("Ketuk untuk mengunduh dan memasang pembaruan")
            .setStyle(new NotificationCompat.BigTextStyle().bigText("Versi baru " + release.tag + " tersedia di GitHub Releases. Ketuk untuk melihat detail dan memperbarui aplikasi."))
            .setContentIntent(pi).setAutoCancel(true).setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        try {
            manager.notify(NOTIF_ID,b.build());
            context.getSharedPreferences("updates",Context.MODE_PRIVATE).edit().putString(key,release.tag).putString(versionKey,release.version).apply();
        }catch(SecurityException ignored){ /* Izin notifikasi dapat dicabut kapan saja */ }
    }
}
