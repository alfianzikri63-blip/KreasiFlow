package id.kreasiflow.studio;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/** Cek rilis saat background; WorkManager mengikuti baterai dan jaringan Android. */
public final class UpdateWorker extends Worker {
    public UpdateWorker(@NonNull Context c,@NonNull WorkerParameters p){super(c,p);}
    @NonNull @Override public Result doWork(){
        if(!ReleaseApi.isConfigured())return Result.success();
        try{
            ReleaseApi.Release r=ReleaseApi.latest();
            if(r!=null)UpdateNotifier.notifyIfNeeded(getApplicationContext(),r);
            return Result.success();
        } catch(Exception e){
            return Result.retry();
        }
    }
}
