package id.kreasiflow.studio;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * Foreground/native video preview. TextureView avoids the common black SurfaceView
 * layer on some Android devices. A decoded MP4 frame remains on screen until
 * actual video frames are rendered, and playback loops instead of ending black.
 */
public final class VideoPreviewActivity extends Activity {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private TextureView texture;
    private ImageView thumbnail;
    private FrameLayout frame;
    private TextView status, elapsed, total;
    private SeekBar seek;
    private Button play;
    private MediaPlayer player;
    private Surface surface;
    private Uri clipUri;
    private int videoWidth,videoHeight;
    private boolean prepared=false, dragging=false, frameRendered=false;

    @Override public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(5,22,15));
        clipUri=getIntent()!=null?getIntent().getData():null;
        int gap=(int)(12*getResources().getDisplayMetrics().density);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(gap,gap,gap,gap);
        root.setBackgroundColor(Color.rgb(4,18,14));
        Button back=new Button(this);back.setText("‹ Kembali ke KreasiFlow");back.setOnClickListener(v->finish());
        root.addView(back,new LinearLayout.LayoutParams(-1,-2));
        TextView title=new TextView(this);title.setText("Preview MP4 Google Flow");
        title.setTextSize(19);title.setTextColor(Color.WHITE);title.setPadding(0,gap,0,gap);
        root.addView(title);
        frame=new FrameLayout(this);frame.setBackgroundColor(Color.rgb(11,25,28));
        root.addView(frame,new LinearLayout.LayoutParams(-1,0,1));
        texture=new TextureView(this);
        frame.addView(texture,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));
        thumbnail=new ImageView(this);thumbnail.setBackgroundColor(Color.rgb(11,25,28));
        thumbnail.setScaleType(ImageView.ScaleType.FIT_CENTER);
        frame.addView(thumbnail,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));
        frame.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or_,ob)->resizeVideo());
        status=new TextView(this);status.setTextColor(Color.LTGRAY);status.setTextSize(13);
        status.setPadding(0,gap,0,gap);status.setText("Memeriksa frame video…");root.addView(status);
        LinearLayout transport=new LinearLayout(this);transport.setGravity(Gravity.CENTER_VERTICAL);
        elapsed=new TextView(this);elapsed.setTextColor(Color.WHITE);elapsed.setText("0:00");
        transport.addView(elapsed);
        seek=new SeekBar(this);seek.setMax(1000);transport.addView(seek,new LinearLayout.LayoutParams(0,-2,1));
        total=new TextView(this);total.setTextColor(Color.WHITE);total.setText("0:00");transport.addView(total);
        root.addView(transport);
        LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER);
        play=new Button(this);play.setText("▶ Putar");actions.addView(play,new LinearLayout.LayoutParams(0,-2,1));
        Button restart=new Button(this);restart.setText("↺ Ulang");actions.addView(restart,new LinearLayout.LayoutParams(0,-2,1));
        Button external=new Button(this);external.setText("↗ Player HP");actions.addView(external,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(actions);
        setContentView(root);
        play.setOnClickListener(v->{if(!prepared)return;if(player.isPlaying()){player.pause();play.setText("▶ Putar");}else{
            if(player.getDuration()>0&&player.getCurrentPosition()>=player.getDuration()-120)player.seekTo(0);
            player.start();play.setText("Ⅱ Jeda");
        }});
        restart.setOnClickListener(v->{if(!prepared)return;player.seekTo(0);player.start();play.setText("Ⅱ Jeda");});
        external.setOnClickListener(v->openExternalPlayer());
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onStartTrackingTouch(SeekBar bar){dragging=true;}
            public void onStopTrackingTouch(SeekBar bar){dragging=false;if(prepared)player.seekTo((int)((long)bar.getProgress()*Math.max(1,player.getDuration())/1000));}
            public void onProgressChanged(SeekBar bar,int p,boolean fromUser){}
        });
        if(clipUri==null){status.setText("Klip tidak tersedia. Buka ulang proyek.");return;}
        showDecodedThumbnail();
        texture.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){
            public void onSurfaceTextureAvailable(SurfaceTexture st,int w,int h){startNativePlayer(st);}
            public void onSurfaceTextureSizeChanged(SurfaceTexture st,int w,int h){resizeVideo();}
            public boolean onSurfaceTextureDestroyed(SurfaceTexture st){releasePlayer();return true;}
            public void onSurfaceTextureUpdated(SurfaceTexture st){}
        });
        ui.post(progressUpdater);
    }

    private void showDecodedThumbnail(){
        MediaMetadataRetriever retriever=new MediaMetadataRetriever();
        try {
            retriever.setDataSource(this,clipUri);
            String w=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
            String h=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
            if(w!=null&&h!=null){videoWidth=Integer.parseInt(w);videoHeight=Integer.parseInt(h);}
            String duration=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if(duration!=null){long d=Long.parseLong(duration);total.setText(timeLabel(d));}
            Bitmap bitmap=retriever.getFrameAtTime(500000,MediaMetadataRetriever.OPTION_CLOSEST);
            if(bitmap==null)bitmap=retriever.getFrameAtTime(0,MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            if(bitmap==null)bitmap=retriever.getFrameAtTime(-1);
            if(bitmap!=null){thumbnail.setImageBitmap(bitmap);status.setText("Gambar MP4 terbaca. Menyiapkan pemutaran…");}
            else status.setText("Durasi terbaca, tetapi frame belum bisa diekstrak. Coba tombol Player HP.");
        }catch(Exception e){status.setText("Frame awal gagal dibaca: "+safeMessage(e)+". Coba Player HP.");}
        finally{try{retriever.release();}catch(Exception ignored){}}
        resizeVideo();
    }

    private void startNativePlayer(SurfaceTexture st){
        if(clipUri==null)return;
        releasePlayer();
        try {
            surface=new Surface(st);
            player=new MediaPlayer();
            player.setDataSource(this,clipUri);
            player.setSurface(surface);
            player.setLooping(true); // Never stop on a black last frame for 4-second Flow clips.
            player.setOnVideoSizeChangedListener((mp,w,h)->{videoWidth=w;videoHeight=h;resizeVideo();});
            player.setOnPreparedListener(mp->{
                prepared=true;
                int d=Math.max(0,mp.getDuration());total.setText(timeLabel(d));
                status.setText("MP4 siap · "+timeLabel(d)+" · putar berulang otomatis.");
                mp.seekTo(0);mp.start();play.setText("Ⅱ Jeda");
            });
            player.setOnInfoListener((mp,what,extra)->{
                if(what==MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START){frameRendered=true;thumbnail.setVisibility(View.GONE);}
                return false;
            });
            player.setOnErrorListener((mp,what,extra)->{
                status.setText("Decoder video gagal ("+what+"/"+extra+"). Coba Player HP atau ekspor H.264.");
                play.setText("▶ Putar");thumbnail.setVisibility(View.VISIBLE);return true;
            });
            player.setOnCompletionListener(mp->{
                // Some devices ignore looping flag on short clips. Seek instead of leaving last frame black.
                mp.seekTo(0);mp.start();play.setText("Ⅱ Jeda");
            });
            player.prepareAsync();
        }catch(Exception e){status.setText("Pemutar Android gagal: "+safeMessage(e)+". Coba Player HP.");releasePlayer();}
    }

    private void resizeVideo(){
        if(frame==null||texture==null||videoWidth<=0||videoHeight<=0)return;
        int fw=frame.getWidth(),fh=frame.getHeight();if(fw<=0||fh<=0)return;
        float scale=Math.min((float)fw/videoWidth,(float)fh/videoHeight);
        int w=Math.max(1,Math.round(videoWidth*scale)),h=Math.max(1,Math.round(videoHeight*scale));
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(w,h,Gravity.CENTER);
        texture.setLayoutParams(lp);
    }

    private final Runnable progressUpdater=new Runnable(){@Override public void run(){
        if(prepared&&player!=null){
            try{
                int duration=Math.max(1,player.getDuration());int position=Math.max(0,player.getCurrentPosition());
                elapsed.setText(timeLabel(position));
                if(!dragging)seek.setProgress((int)(1000L*position/duration));
                if(player.isPlaying()&&!frameRendered&&position>1200){
                    status.setText("Audio/durasi berjalan, tetapi frame belum muncul. Coba Player HP.");
                }
            }catch(Exception ignored){}
        }
        ui.postDelayed(this,250);
    }};
    private static String timeLabel(long ms){long s=Math.max(0,ms)/1000;return (s/60)+":"+String.format(java.util.Locale.ROOT,"%02d",s%60);}
    private static String safeMessage(Exception e){String s=e.getMessage();return s==null?e.getClass().getSimpleName():s.substring(0,Math.min(s.length(),110));}
    private void openExternalPlayer(){
        if(clipUri==null)return;
        Intent intent=new Intent(Intent.ACTION_VIEW).setDataAndType(clipUri,"video/mp4")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try{startActivity(Intent.createChooser(intent,"Putar dengan aplikasi video"));}
        catch(ActivityNotFoundException e){status.setText("Tidak ada pemutar video lain yang terpasang di HP.");}
    }
    private void releasePlayer(){prepared=false;frameRendered=false;if(player!=null){try{player.reset();player.release();}catch(Exception ignored){}player=null;}
        if(surface!=null){surface.release();surface=null;}}
    @Override protected void onPause(){if(player!=null&&prepared){player.pause();play.setText("▶ Putar");}super.onPause();}
    @Override protected void onDestroy(){ui.removeCallbacks(progressUpdater);releasePlayer();super.onDestroy();}
}
