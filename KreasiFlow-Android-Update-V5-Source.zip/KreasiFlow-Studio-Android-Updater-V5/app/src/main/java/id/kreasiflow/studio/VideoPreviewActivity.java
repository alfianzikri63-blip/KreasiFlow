package id.kreasiflow.studio;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

/** Android-native Flow clip preview, independent from HTML <video> range handling. */
public final class VideoPreviewActivity extends Activity {
    private VideoView video;
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(5,22,15));
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(4,18,14));
        int inset=(int)(18*getResources().getDisplayMetrics().density);
        root.setPadding(inset,inset,inset,inset);
        Button back=new Button(this);back.setText("‹  Kembali ke KreasiFlow");
        back.setOnClickListener(v->finish());
        root.addView(back,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView title=new TextView(this);
        title.setText("Preview MP4 Google Flow");title.setTextColor(Color.WHITE);title.setTextSize(20);
        title.setPadding(0,inset,0,inset/2);
        root.addView(title);
        FrameLayout frame=new FrameLayout(this);
        video=new VideoView(this);video.setBackgroundColor(Color.BLACK);
        frame.addView(video,new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT,Gravity.CENTER));
        root.addView(frame,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));
        TextView hint=new TextView(this);
        hint.setText("Memuat video…");hint.setTextSize(14);hint.setTextColor(Color.LTGRAY);
        hint.setPadding(0,inset,0,inset);
        root.addView(hint);
        setContentView(root);
        if(getIntent()==null||getIntent().getData()==null){hint.setText("Klip tidak tersedia. Buka ulang proyek di KreasiFlow.");return;}
        MediaController controls=new MediaController(this);
        controls.setAnchorView(frame);video.setMediaController(controls);
        video.setOnPreparedListener(mp->{hint.setText("Video siap · "+Math.round(video.getDuration()/1000.0)+" detik. Ketuk video untuk kontrol.");video.start();controls.show(2400);});
        video.setOnErrorListener((mp,what,extra)->{hint.setText("MP4 gagal diputar oleh decoder HP. Periksa format/codec video atau unduh ulang dari Google Flow.");return true;});
        video.setVideoURI(getIntent().getData());
        video.requestFocus();
    }
    @Override protected void onPause(){super.onPause();if(video!=null)video.pause();}
    @Override protected void onDestroy(){if(video!=null)video.stopPlayback();super.onDestroy();}
}
