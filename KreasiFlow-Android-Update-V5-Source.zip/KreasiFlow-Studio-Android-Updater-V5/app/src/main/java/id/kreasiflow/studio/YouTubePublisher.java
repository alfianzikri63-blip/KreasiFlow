package id.kreasiflow.studio;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender;
import android.net.Uri;
import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.Scope;
import java.util.Collections;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

/** Native authorization; access tokens never enter the WebView or disk. */
final class YouTubePublisher {
    static final int AUTH_REQUEST=6431;
    private final Activity activity;
    private volatile String status="Belum terhubung";
    private volatile boolean busy;
    private Uri pending;
    private String title, description;
    YouTubePublisher(Activity activity){this.activity=activity;}
    String status(){return status;}
    void start(Uri uri,String title,String description){
        if(busy)return;
        if(title.trim().isEmpty()||title.length()>100||description.getBytes(StandardCharsets.UTF_8).length>5000){status="Judul wajib, maksimal 100 karakter; deskripsi maksimal 5000 byte.";return;}
        busy=true; pending=uri; this.title=title; this.description=description; status="Meminta izin Google…";
        AuthorizationRequest request=AuthorizationRequest.builder().setRequestedScopes(Collections.singletonList(new Scope("https://www.googleapis.com/auth/youtube.upload"))).build();
        Identity.getAuthorizationClient(activity).authorize(request).addOnSuccessListener(result->{
            if(result.hasResolution())try{activity.startIntentSenderForResult(result.getPendingIntent().getIntentSender(),AUTH_REQUEST,null,0,0,0);}catch(IntentSender.SendIntentException e){fail("Tidak dapat membuka izin Google");}
            else authorized(result);
        }).addOnFailureListener(e->fail("Otorisasi Google gagal; periksa akun penguji dan SHA-1."));
    }
    void result(int code,Intent data){
        if(!busy)return;
        if(code!=Activity.RESULT_OK||data==null){fail("Otorisasi dibatalkan");return;}
        try{authorized(Identity.getAuthorizationClient(activity).getAuthorizationResultFromIntent(data));}catch(Exception e){fail("Otorisasi gagal");}
    }
    private void fail(String message){status=message;busy=false;}
    private void authorized(AuthorizationResult result){
        String token=result.getAccessToken(); if(token==null||token.isEmpty()){fail("Token Google tidak tersedia");return;}
        new Thread(()->upload(token),"youtube-upload").start();
    }
    private static HttpURLConnection connection(URL url,String method,String token)throws IOException{
        HttpURLConnection c=(HttpURLConnection)url.openConnection();c.setRequestMethod(method);c.setConnectTimeout(30000);c.setReadTimeout(120000);c.setInstanceFollowRedirects(false);c.setRequestProperty("Authorization","Bearer "+token);return c;
    }
    private void upload(String token){
        File temp=null; HttpURLConnection init=null,put=null;
        try{
            status="Menyiapkan MP4…";temp=File.createTempFile("yt-upload-",".mp4",activity.getCacheDir());
            try(InputStream in=activity.getContentResolver().openInputStream(pending);OutputStream out=new FileOutputStream(temp)){if(in==null)throw new IOException();byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}
            long size=temp.length();if(size==0)throw new IOException();
            JSONObject meta=new JSONObject().put("snippet",new JSONObject().put("title",title).put("description",description)).put("status",new JSONObject().put("privacyStatus","private"));
            byte[] body=meta.toString().getBytes(StandardCharsets.UTF_8);
            init=connection(new URL("https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status"),"POST",token);
            init.setDoOutput(true);init.setRequestProperty("Content-Type","application/json; charset=UTF-8");init.setRequestProperty("X-Upload-Content-Type","video/mp4");init.setRequestProperty("X-Upload-Content-Length",Long.toString(size));init.setFixedLengthStreamingMode(body.length);
            try(OutputStream out=init.getOutputStream()){out.write(body);}
            int code=init.getResponseCode();if(code<200||code>=300){fail("YouTube menolak inisiasi: HTTP "+code);return;}
            URL session=new URL(init.getHeaderField("Location"));if(!"https".equals(session.getProtocol())||!(session.getHost().equals("googleapis.com")||session.getHost().endsWith(".googleapis.com")))throw new IOException();
            put=connection(session,"PUT",token);put.setDoOutput(true);put.setRequestProperty("Content-Type","video/mp4");put.setFixedLengthStreamingMode(size);
            try(InputStream in=new FileInputStream(temp);OutputStream out=put.getOutputStream()){byte[] b=new byte[65536];int n;long sent=0;while((n=in.read(b))!=-1){out.write(b,0,n);sent+=n;status="Mengirim MP4: "+Math.min(99,(int)(100.0*sent/size))+"%";}}
            status="Menunggu konfirmasi YouTube…";code=put.getResponseCode();if(code<200||code>=300){fail("Upload belum terkonfirmasi: HTTP "+code+". Periksa YouTube Studio sebelum mengulang.");return;}
            ByteArrayOutputStream response=new ByteArrayOutputStream();try(InputStream in=put.getInputStream()){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)response.write(b,0,n);}
            String id=new JSONObject(response.toString("UTF-8")).optString("id");if(!id.matches("[A-Za-z0-9_-]{11}"))throw new IOException();status="Upload Private berhasil: https://youtu.be/"+id;
        }catch(Exception e){status="Upload belum terkonfirmasi. Periksa jaringan dan YouTube Studio sebelum mengulang.";}finally{if(init!=null)init.disconnect();if(put!=null)put.disconnect();if(temp!=null)temp.delete();busy=false;}
    }
}
