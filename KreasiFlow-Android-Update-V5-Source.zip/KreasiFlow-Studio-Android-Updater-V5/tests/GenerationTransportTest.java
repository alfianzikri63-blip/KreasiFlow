package id.kreasiflow.studio;

import java.io.IOException;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.InetSocketAddress;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import com.sun.net.httpserver.HttpServer;
import org.json.JSONObject;

/** Run on a JDK with org.json in the classpath. No provider or Android needed. */
public final class GenerationTransportTest {
    private static void require(boolean result) {
        if (!result) throw new AssertionError("Generation transport assertion failed");
    }
    public static void main(String[] args) throws Exception {
        var capture=new CountDownLatch(1);
        var server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
        server.createContext("/slow",exchange->{
            capture.countDown();
            try { Thread.sleep(3000); } catch(InterruptedException ignored) { }
            exchange.close();
        });
        server.start();
        try {
            var request=new StoryIdeaCancellation(2000);
            StoryIdeaCancellation.bind(request);
            var connection=(HttpURLConnection)new URL("http://127.0.0.1:"+server.getAddress().getPort()+"/slow").openConnection();
            StoryIdeaCancellation.track(connection);
            StoryIdeaCancellation.applyLimits(connection);
            require(connection.getConnectTimeout()==5000&&connection.getReadTimeout()==2000);
            try { connection.getResponseCode();throw new AssertionError("Timeout expected"); }
            catch (SocketTimeoutException expected) { require(StoryIdeaCancellation.safeError(expected).equals("timeout")); }
            finally { connection.disconnect(); }
            require(capture.await(1,TimeUnit.SECONDS));
            request.cancel();
            require(request.isCancelled());
            try { StoryIdeaCancellation.track(connection);throw new AssertionError("Cancellation expected"); }
            catch(java.io.InterruptedIOException expected) {}
        } finally {StoryIdeaCancellation.clear();server.stop(0);}
        require(StoryIdeaCancellation.safeError(new IOException("HTTP 429 user input")).equals("HTTP 429"));
        require(StoryIdeaCancellation.safeError(new SocketException("Software caused connection abort")).equals("network: socket connection abort"));
        var raw=": processing\n\ndata: {\"choices\":[{\"delta\":{\"content\":\"Halo \"}}]}\n\n"
            +"data: {\"choices\":[{\"delta\":{\"content\":\"dunia! struct.\"},\"finish_reason\":\"stop\"}]}\n\ndata: [DONE]\n\n";
        var result=new JSONObject(OpenRouterStream.read(new StringReader(raw),4096));
        require(result.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").equals("Halo dunia! struct."));
        for(String bad:new String[]{raw.split("data: \\[DONE\\]")[0],raw.replace("stop","length"),"data: {\"error\":{\"code\":429}}\n"}) {
            try { OpenRouterStream.read(new StringReader(bad),4096);throw new AssertionError("Invalid stream was accepted"); }
            catch(IOException expected) {}
        }
        System.out.println("PASS loopback HTTP timeout, native cancel tracking, safe error mapping, SSE assembly and incomplete stream rejection");
    }
}
