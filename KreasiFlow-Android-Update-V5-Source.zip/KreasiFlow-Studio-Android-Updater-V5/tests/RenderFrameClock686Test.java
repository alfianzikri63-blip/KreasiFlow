package id.kreasiflow.studio;

final class RenderFrameClock686Test {
    private static int tests;
    private static void check(boolean ok, String name) {
        if (!ok) throw new AssertionError(name);
        tests++;
        System.out.println("PASS " + name);
    }

    public static void main(String[] args) {
        check(RenderFrameClock686.ptsUs(2617,30)==87_233_333,"2618th frame PTS");
        check(RenderFrameClock686.ptsUs(2618,30)==87_266_666,"2618-frame full nominal timeline");
        check(RenderFrameClock686.sourceIndex(.5,2,4,30,false,0,null,false,15,0,60)==30,"Compressed footage");
        check(RenderFrameClock686.sourceIndex(3,5,2,30,false,0,null,false,90,0,150)==59,"Freeze at end of short footage");
        check(RenderFrameClock686.sourceIndex(2,4,5,30,false,1.5,null,false,60,0,120)==105,"Manual trim");
        check(RenderFrameClock686.sourceIndex(2,5,8,30,false,.4,new double[]{1.5,3},false,60,0,150)==105,
              "Timeline clip split");
        check(RenderFrameClock686.sourceIndex(0,3,2,30,true,0,null,true,121,121,211)==0,"Direct Loop first endpoint");
        check(RenderFrameClock686.sourceIndex(0,3,2,30,true,0,null,true,210,121,211)==59,"Direct Loop final endpoint");
        check(!RenderFrameClock686.takeNext(80,76,100) && RenderFrameClock686.takeNext(99,76,100),
            "Nearest timestamp selects correct adjacent decoder output");
        check(!RenderFrameClock686.takeNext(88,76,100) && RenderFrameClock686.takeNext(100,76,100),
            "Earlier on ties, exact target preferred");
        check(RenderFrameClock686.takeNext(0,-1,33_333),"First available decoder frame");
        System.out.println(tests + " tests passed.");
    }
}
