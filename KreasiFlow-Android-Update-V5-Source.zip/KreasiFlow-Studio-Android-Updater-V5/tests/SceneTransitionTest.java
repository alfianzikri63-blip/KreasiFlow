package id.kreasiflow.studio;
public class SceneTransitionTest {
 static void check(boolean ok){if(!ok)throw new AssertionError();}
 public static void main(String[] args){
  check(SceneTransition.normalize(null).equals("off"));check(!SceneTransition.active("cut"));
  check(SceneTransition.alpha("dissolve",0,3,0,5,0)==0);check(SceneTransition.alpha("dissolve",1,3,0,5,5)==1);
  check(SceneTransition.alpha("dissolve",1,3,.16,5,5)==.5f);check(SceneTransition.alpha("dissolve",1,3,.32,5,5)==0);
  check(SceneTransition.alpha("dissolve",1,3,.1,.2,.2)==0);check(SceneTransition.alpha("dip",0,3,0,5,0)==0);
  check(SceneTransition.alpha("dip",0,3,5,5,0)==.85f);check(SceneTransition.alpha("dip",2,3,5,5,5)==0);
  check(SceneTransition.alpha("flash",1,3,0,5,5)==.30f);check(SceneTransition.alpha("flash",1,3,.2,5,5)==0);
  check(SceneTransition.alpha("dip",0,1,0,5,0)==0);check(SceneTransition.alpha("off",1,3,0,5,5)==0);
  System.out.println("SceneTransition timing tests passed");
 }
}
