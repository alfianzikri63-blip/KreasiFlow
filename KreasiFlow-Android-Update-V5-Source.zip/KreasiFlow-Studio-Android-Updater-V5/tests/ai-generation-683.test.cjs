const assert=require('node:assert/strict');
const {test}=require('node:test');
const engine=require('../app/src/main/assets/ai-generation-683.js');
test('socket aborts are retried at most twice with exponential backoff',async()=>{
 let calls=0;const pauses=[];
 const result=await engine.request(async()=>{
  if(++calls<3)throw Error('Software caused connection abort');
  return 'ok';
 },{deadline:10000,clock:()=>0,backoff:async ms=>pauses.push(ms)});
 assert.equal(result,'ok');assert.equal(calls,3);assert.deepEqual(pauses,[600,1200]);
});
test('permanent errors and rate limits never start a retry',async()=>{
 for(const [message,code] of [['HTTP 401','auth'],['HTTP 429','rate'],['HTTP 404','model'],['malformed JSON','response']]){
  let calls=0;
  await assert.rejects(engine.request(async()=>{calls++;throw Error(message);},{deadline:10000,clock:()=>0}),new RegExp(message));
  assert.equal(calls,1);assert.equal(engine.classify(Error(message)),code);
 }
});
test('expired budgets and pre-cancelled jobs do not launch provider requests',async()=>{
 let calls=0;const send=async()=>{calls++;};
 await assert.rejects(engine.request(send,{deadline:5,clock:()=>5}),/Batas waktu/);
 const controller=new AbortController();controller.abort();
 await assert.rejects(engine.request(send,{deadline:10,clock:()=>0,signal:controller.signal}),{name:'AbortError'});
 assert.equal(calls,0);
});
test('storyboard workers cap concurrency and preserve unrelated completed batches',async()=>{
 let active=0,peak=0;const saved=[];
 await assert.rejects(engine.batch([1,2,3,4,5],2,2,async group=>{
  active++;peak=Math.max(active,peak);await Promise.resolve();active--;
  if(group.includes(3))throw Error('JSON kosong');
  saved.push(...group);
 }),/JSON kosong/);
 assert.equal(peak,2);assert.deepEqual(saved.sort(),[1,2,5]);
});
