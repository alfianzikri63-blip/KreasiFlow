const {test}=require('node:test');const a=require('node:assert/strict');const r=require('../app/src/main/assets/ai-reliability-v6.js');
test('primary success does not use fallback',async()=>{let calls=[];a.equal(await r.run('gemini',()=>true,async p=>{calls.push(p);return 'ok'}),'ok');a.deepEqual(calls,['gemini']);});
test('503 falls back once to configured provider',async()=>{let calls=[];a.equal(await r.run('gemini',p=>p==='openrouter',async p=>{calls.push(p);if(p==='gemini')throw Error('503');return 'ok'}),'ok');a.deepEqual(calls,['gemini','openrouter']);});
test('no fallback on cancellation, timeout, or policy',async()=>{for(const msg of ['cancel 503','timeout 503','safety 503','401']){let n=0;await a.rejects(r.run('gemini',()=>true,async()=>{n++;throw Error(msg)}));a.equal(n,1);}});
test('no configured fallback preserves error',async()=>{await a.rejects(r.run('gemini',()=>false,async()=>{throw Error('429')}),/429/);});
test('fallback failure stops after two requests',async()=>{let n=0;await a.rejects(r.run('gemini',()=>true,async()=>{n++;throw Error('503')}));a.equal(n,2);});
