const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const vm=require('vm');
const path=require('path');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
const func=html.match(/async function transcribeVOWithGemini\(\)\{[\s\S]*?\n\}\n\nfunction generateTimedSubtitles/);
assert(func,'transcript function exists');
const transcriptFunction=func[0].replace(/\nfunction generateTimedSubtitles$/,'');
const Timeline=require('../app/src/main/assets/subtitle-timeline.js');
function harness(opts={}){
  const S={audioName:'vo.mp3',audioDuration:18,subtitleCues:[{start:0,end:2,text:'Old preserved'}],subtitleSource:'manual',narrationText:'Voice over original'};
  const calls=[];
  const context={
    transcribeBusy:false,transcribeStatus:'',audioUrl:'blob:audio',S,
    window:{KreasiFlowNative:{requestProvider(){},beginRenderAsset(){}}},
    providerReady:()=>opts.hasKey!==false,
    fetch:async()=>({blob:async()=>new Blob(['abc'],{type:'audio/mpeg'})}),
    transferNativeAsset:async (...x)=>{calls.push(['asset',x[1]]);return '991'},
    requestProviderAPI:async (...x)=>{calls.push(['api',x[0],x[1]]);if(opts.fail)throw new Error('HTTP 429'); return opts.response||{segments:[{start:1,end:4,text:'Halo semuanya'},{start:5,end:8,text:'Mari kita mulai'}]};},
    confirm:()=>true,notify:m=>calls.push(['notice',m]),render:()=>calls.push(['render']),persist:()=>calls.push(['persist']),
    transcriptSource:()=>S.narrationText,document:{getElementById:()=>null},KFSubtitleTimeline:Timeline,KFTranscriptionRetry:{run:(fn)=>fn('gemini-3.6-flash')},
    opFor:()=>{},Blob,Number,String,Array,Math,Error,console
  };
  vm.createContext(context);vm.runInContext(transcriptFunction,context);
  return {S,calls,context,run:()=>vm.runInContext('transcribeVOWithGemini()',context)};
}
test('AI response with valid timestamps replaces subtitle only on success',async()=>{
 const x=harness();await x.run();assert.equal(x.S.subtitleSource,'ai');assert.equal(x.S.subtitleCues.length,2);
 assert.equal(x.S.subtitleCues[1].start,5);assert.equal(x.calls.filter(x=>x[0]==='api').length,1);
 assert.equal(x.context.transcribeBusy,false);
});
test('transcription failure preserves existing user subtitles',async()=>{
 const x=harness({fail:true});await x.run();assert.equal(x.S.subtitleCues[0].text,'Old preserved');
 assert.equal(x.S.subtitleSource,'manual');
});
test('out-of-bounds / overlapping AI cues are rejected and old cues stay',async()=>{
 const x=harness({response:{segments:[{start:0,end:6,text:'First'},{start:3,end:10,text:'Overlap'}]}});
 await x.run();assert.equal(x.S.subtitleCues[0].text,'Old preserved');assert.equal(x.S.subtitleSource,'manual');
});
test('no Gemini key prevents paid request',async()=>{
 const x=harness({hasKey:false});await x.run();assert.equal(x.calls.filter(x=>x[0]==='api').length,0);
});
