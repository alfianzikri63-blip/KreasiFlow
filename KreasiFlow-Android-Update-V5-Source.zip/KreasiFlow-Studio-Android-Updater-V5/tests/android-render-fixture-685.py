"""Generate immutable test media, then inspect Android renders made with that media.

Usage:
  python tests/android-render-fixture-685.py prepare /path/to/fixture
  python tests/android-render-fixture-685.py inspect /path/to/export.mp4
"""
import array
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys
import wave

WIDTH, HEIGHT, FPS = 540, 960, 30
SCENES, SLOT, RATE = 15, 2, 44100
BITRATE = WIDTH * HEIGHT * FPS // 7


def run(*args):
    return subprocess.check_output(args)


def prepare(folder):
    folder.mkdir(parents=True, exist_ok=True)
    for scene in range(SCENES):
        run('ffmpeg', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i',
            f'testsrc2=size={WIDTH}x{HEIGHT}:rate={FPS}:duration={SCENES*SLOT}',
            '-ss', str(scene * SLOT), '-t', str(SLOT), '-an', '-vf',
            f'hue=h={24*scene}', '-c:v', 'libx264', '-preset', 'veryfast',
            '-threads', '2', '-pix_fmt', 'yuv420p', '-b:v', str(BITRATE),
            str(folder / f'Scene-{scene+1:02}.mp4'))
    samples = array.array('h', (
        round(math.sin(i * 2 * math.pi * (350 + 20*(i//(RATE*SLOT))) / RATE) * 7000)
        if RATE//2 <= i % (RATE*SLOT) < 3*RATE//2 else 0
        for i in range(RATE*SCENES*SLOT)))
    if sys.byteorder != 'little':
        samples.byteswap()
    with wave.open(str(folder / 'fixture.wav'), 'wb') as output:
        output.setparams((1, 2, RATE, 0, 'NONE', ''))
        output.writeframes(samples.tobytes())
    cues = []
    for scene in range(SCENES):
        start = scene * SLOT
        cues.append(f'{scene+1}\n00:00:{start:02},500 --> 00:00:{start+1:02},500\nUJI {scene+1:02}\n')
    (folder / 'fixture.srt').write_text('\n'.join(cues), encoding='utf-8')
    hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sorted(folder.iterdir()) if p.suffix in ('.mp4', '.wav', '.srt')}
    (folder / 'sha256.json').write_text(json.dumps(hashes, indent=2) + '\n', encoding='utf-8')
    print(f'{len(hashes)} fixture files, {SCENES*SLOT}s, {WIDTH}x{HEIGHT} {FPS}fps, target AVC {BITRATE}bps')


def inspect(path):
    info = json.loads(run('ffprobe', '-v', 'error', '-show_format', '-show_streams', '-of', 'json', str(path)))
    picture = next(track for track in info['streams'] if track['codec_type'] == 'video')
    audio = next(track for track in info['streams'] if track['codec_type'] == 'audio')
    assert (picture['width'], picture['height']) == (WIDTH, HEIGHT), picture
    assert abs(float(info['format']['duration']) - SCENES*SLOT) <= .20, info['format']
    pcm = array.array('h')
    pcm.frombytes(run('ffmpeg', '-v', 'error', '-i', str(path), '-vn', '-ac', '1',
                      '-ar', str(RATE), '-f', 's16le', '-'))
    if sys.byteorder != 'little':
        pcm.byteswap()
    onsets = []
    for scene in range(SCENES):
        start = scene*SLOT*RATE
        offset = next((i for i in range(start, start+RATE) if abs(pcm[i]) > 700), None)
        onsets.append(round(offset/RATE - scene*SLOT, 4) if offset is not None else None)
    print(json.dumps({'file': path.name, 'bytes': path.stat().st_size, 'duration': info['format']['duration'],
        'video': picture['codec_name'], 'fps': picture['avg_frame_rate'], 'videoBitrate': picture.get('bit_rate'),
        'audio': audio['codec_name'], 'audioStart': audio.get('start_time'),
        'onsetsSecondsWithinScene': onsets}, indent=2))
    assert all(onset is not None and abs(onset-.5) <= .08 for onset in onsets), onsets


if __name__ == '__main__':
    command, target = sys.argv[1:]
    {'prepare': prepare, 'inspect': inspect}[command](Path(target))
