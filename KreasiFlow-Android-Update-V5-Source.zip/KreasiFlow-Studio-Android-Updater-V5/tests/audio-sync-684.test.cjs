const assert=require('node:assert/strict');
const {test}=require('node:test');
const Match=require('../app/src/main/assets/transcript-match-684.js');
const Voice=require('../app/src/main/assets/voice-director.js');
const Timing=require('../app/src/main/assets/voice-timing-682.js');
const cue=(start,end,text)=>({start,end,text});
const line=(id,text)=>({id,text});
test('informal Indonesian, punctuation, tags, repetitions, and several cues map to actual timestamps',()=>{
 const lines=[line('a','Itu dia ngetok!'),line('b','Udah, enggak usah nengok.')];
 const source=[cue(.2,.6,'ITU dia'),cue(.63,1.2,'mengetuk!'),cue(4,4.5,'Sudah, nggak'),cue(4.5,5.4,'usah menengok.'),{...cue(1.3,2.1,'[gasp]'),type:'audio_event'}];
 const result=Match.analyze(lines,source,6);
 assert.equal(result.ready,true);
 assert.deepEqual(result.rows.map(r=>[r.start,r.end,r.status]),[[.2,1.2,'matched'],[4,5.4,'matched']]);
 assert.equal(Match.score(Match.tokens('aku aku pergi'),Match.tokens('aku pergi')),.94);
 assert.deepEqual(Match.tokens('[whispers]  Sudah, YA!'),['sudah','ya']);
});
test('keeps good dialogue when a later dialogue is missing or contains a negation mismatch',()=>{
 const lines=[line('a','Kamu dengar itu?'),line('b','Jangan pergi jauh.'),line('c','Kita pulang sekarang.')];
 const result=Match.analyze(lines,[cue(0,.9,'Kamu dengar itu'),cue(1,1.8,'Pergi jauh'),cue(6,7,'Kita pulang sekarang')],8);
 assert.deepEqual(result.rows.map(r=>r.status),['matched','missing','matched']);
 assert.equal(result.ready,false);
 assert.equal(result.extra[0].text,'Pergi jauh');
});
test('combined segment requires heard timing and accepts explicit non-overlapping corrections',()=>{
 const lines=[line('a','Dia mengetuk.'),line('b','Ayo cepat.')],cues=[cue(.2,3,'Dia ngetok. Ayo cepat.')];
 const original=Match.analyze(lines,cues,4);
 assert.equal(original.ready,false);
 assert.ok(original.rows.some(r=>r.start===undefined));
 const result=Match.analyze(lines,cues,4,{a:cue(.2,1.2,'Dia ngetok.'),b:cue(1.6,3,'Ayo cepat.')});
 assert.equal(result.ready,true);
 assert.deepEqual(result.rows.map(r=>r.status),['corrected','corrected']);
 assert.equal(Match.analyze(lines,cues,4,{a:cue(.2,2,'Dia ngetok.'),b:cue(1.6,3,'Ayo cepat.')}).ready,false);
});
test('Gemini estimated segment needs review even when text is exact',()=>{
 const result=Match.analyze([line('a','Halo')],[cue(1,2,'Halo')],3,{},false,true);
 assert.equal(result.rows[0].status,'review');
 assert.equal(result.ready,false);
});
test('same dialogue changes direction across scene emotions and plain models remain tag-free',()=>{
 const text='Itu dia ngetok!';
 const examples=['happy','afraid','sad','angry'].map(emotion=>Voice.contextualDialogue({text,emotion},{},'v4'));
 assert.deepEqual(examples,['[happy] '+text,'[frightened] '+text,'[sad] '+text,'[angry] '+text]);
 const context={atmosphere:'tegang, suasana mencekam'};
 assert.equal(Voice.contextualDialogue({text,emotion:'ceria',intensity:4},context,'v3'),'[gasps] [frightened] '+text);
 assert.equal(Voice.contextualDialogue({text:'Kamu jangan jauh-jauh ya, Kak.'},context,'v4'),'[pleading] Kamu jangan jauh-jauh ya, Kak.');
 assert.equal(Voice.contextualDialogue({text,emotion:'sad'},context,'plain'),text);
 const changing={text:'Iya, kita hadapi berdua. Asal jangan nengok ke sana lagi.',delivery:'berbisik',beats:[{sentence:2,emotion:'nervous'}]};
 assert.equal(Voice.contextualDialogue(changing,context,'v4'),'[whispers] Iya, kita hadapi berdua. [nervously] Asal jangan nengok ke sana lagi.');
});
test('packed audio preserves original nonverbal samples and scene duration while captions cover speech only',()=>{
 const rangeA=Float32Array.from([.4,.2,.2,.5,.7]),rangeB=Float32Array.from([.8,.9,.2]);
 const scenes=[{startSec:0,endSec:4}];
 const segments=[
  {row:{i:0,j:1,text:'Kedua'},source:'b',start:0,end:3,length:3,samples:rangeB,speechStart:1,speechEnd:3,packed:true},
  {row:{i:0,j:0,text:'Pertama'},source:'a',start:0,end:5,length:5,samples:rangeA,speechStart:1,speechEnd:3,packed:true}];
 const out=Timing.batch(scenes,segments,10);
 assert.deepEqual(out.starts,[0,.8]);
 assert.deepEqual(out.clips,[rangeA,rangeB]);
 assert.deepEqual(out.cues.map(row=>[row.start,row.end,row.text]),[[.1,.3,'Pertama'],[.6,.8,'Kedua']]);
});
