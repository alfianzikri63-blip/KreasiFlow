const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const root='app/src/main/';
const main=fs.readFileSync(root+'java/id/kreasiflow/studio/MainActivity.java','utf8');
const service=fs.readFileSync(root+'java/id/kreasiflow/studio/AiForegroundService.java','utf8');
const manifest=fs.readFileSync(root+'AndroidManifest.xml','utf8');
const html=fs.readFileSync(root+'assets/index.html','utf8');
test('network AI foreground work has dataSync permission, type, and is not stopped with Activity task',()=>{
 assert.match(manifest,/FOREGROUND_SERVICE_DATA_SYNC/);
 assert.match(manifest,/android:name="\.AiForegroundService"[\s\S]*?android:foregroundServiceType="dataSync"[\s\S]*?android:stopWithTask="false"/);
 assert.match(service,/ContextCompat\.startForegroundService/);
 assert.match(service,/FOREGROUND_SERVICE_TYPE_DATA_SYNC/);
 assert.match(service,/return START_NOT_STICKY/);
});
test('AI job owns its work without a retained WebView or Activity',()=>{
 assert.match(service,/extends Service/);
 assert.doesNotMatch(service,/evaluateJavascript|MainActivity\.this|new WebView\(/);
 assert.match(main,/AiForegroundService\.enqueue\(MainActivity\.this,cfg,audio\)/);
 assert.match(main,/getBackgroundAiStatus\(\)/);
 assert.match(main,/getBackgroundAiResult\(String jobId\)/);
});
test('foreground notification shows percentage and offers cancel',()=>{
 assert.match(service,/setProgress\(100,/);
 assert.match(service,/addAction\(android\.R\.drawable\.ic_delete,"Batalkan"/);
 assert.match(service,/PendingIntent\.getActivity/);
 assert.match(service,/setOnlyAlertOnce\(true\)/);
});
test('background task results survive WebView destruction and each storyboard batch checkpoint is saved',()=>{
 assert.match(service,/context\.getFilesDir\(\)|c\.getFilesDir\(\)/);
 assert.match(service,/durable\(resultFile\(this,jobId\),saved\.toString\(\)\);/);
 assert.match(service,/results\.put\(answer\)/);
 assert.match(service,/"interrupted"/);
 assert.match(html,/storyboardSaveCache\(cache\)/);
 assert.match(html,/KFAI_BG_APPLIED/);
});
test('job files never contain provider secret or unrestricted service endpoint',()=>{
 assert.match(service,/ProviderSecrets secrets=new ProviderSecrets\(this\)/);
 assert.match(service,/secrets\.get\(provider\)/);
 assert.match(service,/GeminiApi\.execute\(payload,key\)/);
 assert.match(service,/MultiProviderApi\.execute\(provider,payload,key,null\)/);
 assert.doesNotMatch(service,/job\.put\("key"/);
 assert.match(service,/job\.remove\("file"\)/);
 assert.match(service,/audio\.getCanonicalFile\(\)\.getParentFile\(\)\.equals/);
});
test('long-running buttons hand off jobs to native instead of awaiting WebView calls',()=>{
 for(const key of ['title','script','storyboard','transcription'])assert.match(service,new RegExp('"'+key+'"\\.equals\\(kind\\)'));
 assert.match(html,/kfAiNativeAvailable\(\)\?kfAiTextJob/);
 assert.match(html,/kfAiNativeAvailable\(\)\?kfAiStoryboardJob\(\)/);
 assert.match(html,/kfAiNativeAvailable\(\)\?await kfAiTranscriptionJob\(\)/);
 assert.match(html,/document\.addEventListener\('visibilitychange'/);
});
test('generated title can finish in native while WebView is suspended, then apply exactly once on resume',()=>{
 const marker=html.match(/\/\/ v\d+\.\d+\.\d+ — Native AI jobs/);const a=marker?html.indexOf(marker[0]):-1;const b=html.indexOf('async function onAction(',a);
 assert.ok(a>0&&b>a);
 const storage=new Map();let current={};let request=null;let writes=0;
 const native={
  startBackgroundAi(raw){request=JSON.parse(raw);current={jobId:'f93ef394-0000-4000-8000-000000000001',kind:request.kind,state:'queued',percent:0};return JSON.stringify({ok:true,status:current})},
  getBackgroundAiStatus(){return JSON.stringify(current)},
  getBackgroundAiResult(){return JSON.stringify({jobId:current.jobId,kind:'title',text:'{"titles":["Rahasia Kawah Ijen", "Petualangan ASAQ"]}'})}
 };
 const context={
  window:{KreasiFlowNative:native,addEventListener(){}},document:{addEventListener(){}},
  localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>{storage.set(k,v);writes++},removeItem:k=>storage.delete(k)},
  setTimeout:()=>0,setInterval:()=>0,
  S:{lang:'Indonesia',title:'Gunung Ijen',contentFormat:'Cerita',openRouterModel:'openrouter/free',sceneStyle:'Stickman Putih'},
  geoTextRule:()=>'',storyboardProviders:()=>['gemini'],activeCategory:()=> 'Petualangan',textProvider:()=> 'gemini',getTopic:()=> 'Gunung Ijen',
  opStart:()=> 'fake-operation',opUpdate:()=>{},opFinish:()=>{},operationOwners:new Map(),
  notify:()=>{},render:()=>{},persist:()=>{},confirm:()=>true,
  parseJSON:s=>{try{return JSON.parse(s)}catch{return null}},KreasiFlowScenePlanner:{},KreasiFlowMotionStyles:{geoTopic:()=>null},KFStoryboardResilience:{},categoryIdeas:{Petualangan:['Petualangan baru']},
 };
 vm.createContext(context);vm.runInContext(html.slice(html.indexOf("function fastLocalTitles()"),html.indexOf("function makeScript()"))+html.slice(a,b),context);
 assert.equal(context.kfAiTextJob('title'),true);
 assert.equal(request.kind,'title');assert.match(request.prompt,/10 judul/);
 current={...current,state:'done',percent:100};context.kfAiPoll();
 assert.equal(context.S.selected,'Rahasia Kawah Ijen');assert.equal(context.S.ideas.length,10);assert.equal(context.S.titleIdeasSource,"AI + ide lokal");
 const after=writes;context.kfAiPoll();assert.equal(writes,after,'must not commit twice');
});
