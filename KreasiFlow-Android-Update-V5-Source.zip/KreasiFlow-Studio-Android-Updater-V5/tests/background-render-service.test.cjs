const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const project = path.join(__dirname,'..');
const service = fs.readFileSync(path.join(project,'app/src/main/java/id/kreasiflow/studio/RenderForegroundService.java'),'utf8');
const activity = fs.readFileSync(path.join(project,'app/src/main/java/id/kreasiflow/studio/MainActivity.java'),'utf8');
const manifest = fs.readFileSync(path.join(project,'app/src/main/AndroidManifest.xml'),'utf8');
const html = fs.readFileSync(path.join(project,'app/src/main/assets/index.html'),'utf8');

test('foreground render service is registered with mediaProcessing type + permissions',()=>{
 for(const p of ['FOREGROUND_SERVICE','FOREGROUND_SERVICE_MEDIA_PROCESSING','WAKE_LOCK','POST_NOTIFICATIONS'])assert.ok(manifest.includes('android.permission.'+p));
 assert.doesNotMatch(fs.readFileSync(path.join(project,'app/src/debug/AndroidManifest.xml'),'utf8'),/POST_NOTIFICATIONS/);
 assert.match(manifest,/android:name="\.RenderForegroundService"[\s\S]*?android:exported="false"[\s\S]*?android:foregroundServiceType="mediaProcessing"/);
});
test('service uses foreground notification, not a detached WebView timer',()=>{
 assert.match(service,/startForeground\(NOTIFICATION_ID/);
 assert.match(service,/setProgress\(measured\?stats.frameTotal/);
 assert.match(service,/setContentIntent\(open\)/);
 assert.match(service,/KreasiFlow • Render MP4/);
 assert.doesNotMatch(service,/import android\.webkit\.WebView|evaluateJavascript\(/);
});
test('work is owned by Service; activity is only a launcher',()=>{
 assert.match(activity,/RenderForegroundService\.enqueue\(this,mode,input,assets\)/);
 assert.match(activity,/startForegroundRender\("moving",config\)/);
 assert.match(activity,/startForegroundRender\("slideshow",config\)/);
 assert.doesNotMatch(activity,/runNativeMovingRender\(String json\)|runNativeRender\(String json\)|renderPool\.shutdownNow\(\)/);
});
test('render input snapshot is durable and excludes keys',()=>{
 assert.match(service,/getFilesDir\(\),"render-jobs"/);
 assert.match(service,/out\.getFD\(\)\.sync\(\)/);
 assert.match(service,/put\("config",config\)\.put\("assets",assets\)/);
 assert.doesNotMatch(service,/API_KEY|apiKey|providerSecrets/);
});
test('service protects cache path and does not delete assets while Activity is destroyed',()=>{
 assert.match(service,/\.getCanonicalFile\(\)/);
 assert.match(service,/getPath\(\)\.startsWith\(base\.getPath\(\)\+File\.separator\)/);
 assert.doesNotMatch(activity,/for\(File f:renderAssets\.values\(\)\)f\.delete\(\)/);
});
test('notification supports cancel and status is saved for recreation',()=>{
 assert.match(service,/ACTION_CANCEL/);
 assert.match(service,/worker\.interrupt|t\.interrupt\(\)/);
 assert.match(service,/getSharedPreferences\(PREF,MODE_PRIVATE\)/);
 assert.match(activity,/getBackgroundRenderStatus\(\)/);
 assert.match(activity,/pushBackgroundRenderStatus\(\)/);
});
test('progress does not claim completion until publish finished',()=>{
 assert.match(service,/Math\.min\(98,percent\)/);
 assert.match(service,/updateProgress\(99,"Menyimpan MP4/);
 assert.match(service,/finishJob\("done",100,/);
});
test('status sync handles queued/running/done/error without repeating completion',()=>{
 const start=html.indexOf('// Native foreground render continues when this WebView');
 const end=html.indexOf('window.__kreasiflowRenderDone=(ok,message,terminal)=>{',start);
 assert.ok(start>0 && end>start);
 const snippet=html.slice(start,end);
 let events=[];
 const window = {
  __kreasiflowRenderProgress:(p,m)=>events.push(['progress',p,m]),
  __kreasiflowRenderDone:(ok,m)=>events.push(['done',ok,m]),
  KreasiFlowNative:{getBackgroundRenderStatus:()=>JSON.stringify({state:'running',jobId:'b',percent:42,message:'encoding'})}
 };
 const context={window,document:{hidden:false,addEventListener:()=>{}},setInterval:()=>{},setTimeout:()=>{},console,
  renderMonitor685:null,paintRender685:()=>{},renderEngine685:()=> 'Render Go',updateAuroraActivity:()=>{}};
 vm.runInNewContext('let rendering=false;'+snippet,context);
 window.__kreasiflowBackgroundRenderSync({jobId:'x',state:'queued',percent:0,message:'Antre'});
 window.__kreasiflowBackgroundRenderSync({jobId:'x',state:'running',percent:42,message:'Encoding'});
 window.__kreasiflowBackgroundRenderSync({jobId:'x',state:'done',percent:100,message:'Sukses'});
 window.__kreasiflowBackgroundRenderSync({jobId:'x',state:'done',percent:100,message:'Sukses'});
 assert.equal(events.filter(e=>e[0]==='done').length,1);
 assert.equal(events.find(e=>e[0]==='done')[1],true);
 window.__kreasiflowBackgroundRenderSync({jobId:'y',state:'error',percent:50,message:'Gagal codec'});
 assert.equal(events.filter(e=>e[0]==='done').length,2);
 assert.equal(events[events.length-1][1],false);
});
test('no automatic restart after Android kills service and cache files still retained',()=>{
 assert.match(service,/START_NOT_STICKY/);
 assert.match(service,/"interrupted"/);
 assert.match(service,/wakeLock\.release\(\)/);
});
