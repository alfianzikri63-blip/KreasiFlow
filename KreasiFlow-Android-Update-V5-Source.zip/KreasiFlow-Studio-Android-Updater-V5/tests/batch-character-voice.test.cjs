const test=require('node:test'),assert=require('node:assert/strict'),{match,assemble}=require('../app/src/main/assets/scene-voice.js');
test('matches repeated dialogue in order and multiple cues',()=>assert.deepEqual(match(['Halo Bimo','Halo Bimo'],[{start:0,end:1,text:'Halo'},{start:1,end:2,text:'Bimo'},{start:3,end:4,text:'Halo Bimo!'}]),[{start:0,end:2},{start:3,end:4}]));
test('rejects mismatched and extra cues',()=>{assert.throws(()=>match(['Halo'],[{start:0,end:1,text:'Hai'}]));assert.throws(()=>match(['Halo'],[{start:0,end:1,text:'Halo'},{start:1,end:2,text:'Hai'}]));});
test('four second slots preserve samples and reject overflow',()=>{const w=assemble([new Float32Array(24000).fill(.5),new Float32Array(48000)],4);assert.equal(w.byteLength,44+8*24000*2);assert.throws(()=>assemble([new Float32Array(96001)],4));});
test('six and eight second slots preserve dialogue samples and the next actor onset',()=>{
 for(const seconds of [6,8]){
  const audio=new DataView(assemble([Float32Array.of(.5),Float32Array.of(-.5)],seconds,1000));
  assert.equal(audio.byteLength,44+seconds*4000);
  assert.equal(audio.getInt16(44,true),16384);
  assert.equal(audio.getInt16(44+(1000*seconds-1)*2,true),0);
  assert.equal(audio.getInt16(44+1000*seconds*2,true),-16384);
 }
});
test('dialogue delivery changes style cues while preserving the original words',()=>{
 const director=require('../app/src/main/assets/voice-director.js');
 const text='Tunggu... itu suara siapa?';
 assert.equal(director.dialogue(text),'[curiously] '+text);
 assert.equal(director.dialogue(text,'worried'),'[quietly, a little nervous] '+text);
 assert.equal(director.dialogue(''), '');
});
test('only words determine the boundaries of each transcribed turn',()=>{
 assert.deepEqual(match(['Halo Rani','Sampai nanti'],[
  {start:0,end:.2,text:'Halo'},{start:.2,end:.4,text:'Rani'},{start:.4,end:.42,text:'!'},
  {start:1.5,end:1.7,text:'Sampai'},{start:1.7,end:2,text:'nanti'}
 ]),[{start:0,end:.4},{start:1.5,end:2}]);
});
