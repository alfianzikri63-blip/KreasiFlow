"""Real browser fallback exports for an identical 15-scene, 6-second fixture."""
import base64
import io
import json
import math
from pathlib import Path
import struct
import subprocess
import sys
from tempfile import NamedTemporaryFile
import wave

from playwright.sync_api import sync_playwright

HOOK=r"""
const bench685={prepare:null,decode:null,capture:null,peak:0,begin:0,bitrate:0};
const originalImages685=loadSceneImages;
loadSceneImages=async(...args)=>{
 const start=performance.now();
 const out=await originalImages685(...args);
 bench685.decode=performance.now()-start;
 return out;
};
const recorderStart685=MediaRecorder.prototype.start;
MediaRecorder.prototype.start=function(...args){
 const start=performance.now();
 bench685.prepare=start-bench685.begin;bench685.bitrate=this.videoBitsPerSecond;
 this.addEventListener('stop',()=>{bench685.capture=performance.now()-start;},{once:true});
 return recorderStart685.apply(this,args);
};
window.kfBench685={bench685,async setup(wav){
 await newProject('short');
 S.projectKind='short';S.smartLoop=false;S.templateOutroMode='off';S.audioVolume=100;
 S.resolution='540';S.ratio='9:16';S.fps='30';S.fade=false;S.sceneTransition='cut';
 S.effect='Tidak Ada';S.captions=true;S.subtitlePreset='classic';S.subtitleColor='#ffffff';
 S.script='Fixture 15 scene';S.narrationText=S.script;
 const bytes=Uint8Array.from(atob(wav),c=>c.charCodeAt(0));
 await loadAudioFile(new File([bytes],'fixture.wav',{type:'audio/wav'}),false);
 S.scenes=Array.from({length:15},(_,i)=>({id:'bench-'+i,name:'Adegan '+(i+1),voice:'UJI '+(i+1),startSec:i*.4,endSec:(i+1)*.4}));
 images=S.scenes.map((_,i)=>{
  const c=document.createElement('canvas');c.width=180;c.height=320;
  const g=c.getContext('2d');g.fillStyle='#09172'+i.toString(16);g.fillRect(0,0,180,320);
  g.fillStyle='#172745';g.fillRect(15+i,80,38,35);return c.toDataURL('image/png');
 });
 S.subtitleCues=S.scenes.map((_,i)=>({start:i*.4+.08,end:i*.4+.32,text:'UJI '+(i+1)}));
 S.subtitleSource='imported';S.subtitleTextSnapshot=transcriptSource();S.phase=3;if(typeof kfHomeOpen!=='undefined')kfHomeOpen=false;render();
},run(){
 bench685.begin=performance.now();
 const timer=setInterval(()=>{bench685.peak=Math.max(bench685.peak,performance.memory?.usedJSHeapSize||0);if(!rendering&&videoUrl)clearInterval(timer);},200);
 return renderVideo();
},get ready(){return !!videoUrl&&!rendering;},async result(){
 const blob=await (await fetch(videoUrl)).blob(),bytes=new Uint8Array(await blob.arrayBuffer());
 let text='';for(let i=0;i<bytes.length;i+=8192)text+=String.fromCharCode(...bytes.subarray(i,i+8192));
 return {metrics:bench685,bytes:btoa(text),ext:videoExt};
}};
"""

def audio():
    out=io.BytesIO()
    with wave.open(out,'wb') as f:
        f.setparams((1,2,48000,0,'NONE',''))
        samples=[]
        for index in range(6*48000):
            t=index/48000
            sample=int(6500*math.sin(index/9)) if .08 <= t%0.4 < .32 else 0
            samples.append(struct.pack('<h',sample))
        f.writeframes(b''.join(samples))
    return base64.b64encode(out.getvalue()).decode()

def test():
    chromium,output,*roots=sys.argv[1:]
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    signal=audio()
    with sync_playwright() as runner:
        browser=runner.chromium.launch(executable_path=chromium,args=['--no-sandbox','--enable-precise-memory-info','--autoplay-policy=no-user-gesture-required'])
        for version,root in zip((670,684,685),roots):
            assets=Path(root).resolve()/'app/src/main/assets'
            source=(assets/'index.html').read_text().replace('})();\n</script>\n</body></html>',HOOK+'})();\n</script>\n</body></html>')
            with NamedTemporaryFile(dir=assets,suffix='.html') as target:
                target.write(source.encode());target.flush()
                page=browser.new_page(viewport={'width':390,'height':830})
                page.on('dialog',lambda dialog:dialog.accept())
                page.route('http**://**',lambda route:route.abort())
                page.goto(Path(target.name).as_uri())
                page.evaluate('wav=>kfBench685.setup(wav)',signal)
                page.evaluate('kfBench685.run()')
                page.wait_for_function('kfBench685.ready',timeout=20000)
                result=page.evaluate('kfBench685.result()')
                file=output/f'KF{version}.{result["ext"]}'
                file.write_bytes(base64.b64decode(result['bytes']))
                detail=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(file)]))
                video=next(s for s in detail['streams'] if s['codec_type']=='video')
                sound=next(s for s in detail['streams'] if s['codec_type']=='audio')
                assert video['width']==540 and video['height']==960 and sound['sample_rate']=='48000'
                pcm=subprocess.check_output(['ffmpeg','-v','error','-i',str(file),'-vn','-ac','1','-ar','48000','-f','s16le','-'])
                active=next(i for i,(value,) in enumerate(struct.iter_unpack('<h',pcm)) if abs(value)>200)/48000
                # Check that the only light glyphs are present inside a cue and absent between two cues.
                verified=[]
                for time in [.15,.36]:
                    raw=subprocess.check_output(['ffmpeg','-v','error','-ss',str(time),'-i',str(file),'-frames:v','1','-vf','crop=240:140:150:690','-f','rawvideo','-pix_fmt','gray','-'])
                    verified.append(sum(x>200 for x in raw))
                assert verified[0]>15 and (version!=685 or verified[1]<15),verified
                assert abs(active-.08)<.1,active
                print(json.dumps(dict(version=version,**result['metrics'],size=file.stat().st_size,video=video['codec_name'],
                    resolution='540x960',fps=video['r_frame_rate'],audio=sound['codec_name'],activeAudio=round(active,3),
                    captionPixels=verified,duration=detail['format'].get('duration','not signalled'))),flush=True)
                page.close()
if __name__=='__main__':
    test()
