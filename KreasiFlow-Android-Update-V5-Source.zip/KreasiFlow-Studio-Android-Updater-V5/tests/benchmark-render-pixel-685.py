"""Reproducible benchmark of the Android Java pixel-conversion kernel from three sources."""
from pathlib import Path
from io import BytesIO
from zipfile import ZipFile
import subprocess
import sys
from tempfile import TemporaryDirectory

def load(archive):
    with ZipFile(archive) as outer:
        direct=next((n for n in outer.namelist() if n.endswith('/NativeVideoRenderer.java')),None)
        if direct:
            return outer.read(direct).decode()
        with ZipFile(BytesIO(outer.read(next(n for n in outer.namelist() if n.endswith('.zip'))))) as inner:
            name=next(n for n in inner.namelist() if n.endswith('/NativeVideoRenderer.java'))
            return inner.read(name).decode()

def method(source, marker):
    start=source.index(marker)
    begin=source.index('{',start)
    depth=1
    for end in range(begin+1,len(source)):
        depth+=(source[end]=='{')-(source[end]=='}')
        if depth==0:
            return source[start:end+1]

HARNESS=r"""
package id.kreasiflow.studio;
import java.util.*;
import java.security.*;
public class KernelBench {
 static final int W=540,H=960,FPS=30,FRAMES=180;
 static final int[][] inputs=new int[15][W*H];
 static final byte[] out=new byte[W*H*3/2];
 static void frame(int version,int index,boolean planar){
  int[] pixels=inputs[(index/12)%15];
  if(version==0)Legacy670.packBytes(pixels,W,H,out,planar?19:21);
  else if(version==1)Legacy684.packBytes(pixels,W,H,out,planar?19:21);
  else RenderPixel685.pack(pixels,W,H,out,planar);
 }
 static String hash(int version,boolean planar)throws Exception{
  var digest=MessageDigest.getInstance("SHA-256");
  for(int i=0;i<FRAMES;i++){frame(version,i,planar);digest.update(out);}
  return HexFormat.of().formatHex(digest.digest());
 }
 public static void main(String[] args)throws Exception{
  var random=new Random(685L);
  for(var frame:inputs)for(int i=0;i<frame.length;i++)frame[i]=random.nextInt();
  for(boolean planar:new boolean[]{true,false}){
   var reference=new String[]{hash(0,planar),hash(1,planar),hash(2,planar)};
   if(!reference[0].equals(reference[1])||!reference[0].equals(reference[2]))
    throw new AssertionError("Different packed pixels");
   for(int v=0;v<3;v++)for(int f=0;f<120;f++)frame(v,f,planar);
   long[][] timing=new long[3][3];volatileCheck=0;
   for(int run=0;run<3;run++)for(int order=0;order<3;order++){
    int v=(order+run)%3;
    long start=System.nanoTime();
    for(int f=0;f<FRAMES;f++){frame(v,f,planar);volatileCheck+=out[f];}
    timing[v][run]=System.nanoTime()-start;
   }
   for(int v=0;v<3;v++){
    Arrays.sort(timing[v]);
    System.out.printf(Locale.ROOT,"%s %d: %.2f ms, %d frames, %dx%d %dfps, SHA %s%n",planar?"I420":"NV12",new int[]{670,684,685}[v],timing[v][1]/1e6,FRAMES,W,H,FPS,reference[v]);
   }
  }
 }
 static volatile long volatileCheck;
}
"""

def main():
    src=Path(__file__).resolve().parents[1]/'app/src/main/java/id/kreasiflow/studio/RenderPixel685.java'
    with TemporaryDirectory() as temp:
        temp=Path(temp)
        files=[]
        for version,archive in zip((670,684),sys.argv[1:]):
            source=load(archive)
            methods='\n'.join(method(source,marker) for marker in ('private static int y(','private static int u(','private static int v(','private static int clamp(','private static void packBytes('))
            methods=methods.replace('private static void packBytes','static void packBytes').replace('MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar','19')
            file=temp/f'Legacy{version}.java'
            file.write_text(f'package id.kreasiflow.studio; class Legacy{version} {{\n{methods}\n}}')
            files.append(str(file))
        harness=temp/'KernelBench.java';harness.write_text(HARNESS)
        subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-d',str(temp),*files,str(harness),str(src)],check=True)
        subprocess.run(['java','-cp',str(temp),'id.kreasiflow.studio.KernelBench'],check=True)

if __name__=='__main__':
    main()
