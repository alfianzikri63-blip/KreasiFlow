"""Host-only long-GOP decode experiment. Requires PyAV and prepared Android fixture."""
import hashlib
from pathlib import Path
import statistics
import sys
import time
import av


def run(files, mode):
    digest = hashlib.sha256()
    decoded = used = 0
    now = time.perf_counter
    began = now()
    decoder_sec = hashing_sec = 0
    for file in files:
        with av.open(str(file)) as source:
            stream = source.streams.video[0]
            stream.codec_context.thread_count = 1
            # Fixture is CFR 30fps with 60 frames per scene and timestamps starting at zero.
            count = 60
            def seek_frames():
                for index in range(count):
                    target = round(index / (30 * stream.time_base))
                    source.seek(target, stream=stream, backward=True, any_frame=False)
                    for frame in source.decode(stream):
                        nonlocal decoded
                        decoded += 1
                        if frame.pts >= target:
                            if frame.pts != target:
                                raise AssertionError((file.name, frame.pts, target))
                            yield frame
                            break
            frames = iter(source.decode(stream)) if mode == 'sequential' else seek_frames()
            for index in range(count):
                started = now()
                frame = next(frames)
                decoder_sec += now()-started
                assert frame.pts == round(index / (30 * stream.time_base)), (file.name, index, frame.pts)
                if mode == 'sequential':
                    decoded += 1
                started = now()
                plane = frame.planes[0]
                # Decode comparison includes all active luma bytes, excluding row padding.
                data = memoryview(plane)
                for row in range(frame.height):
                    offset = row*plane.line_size
                    digest.update(data[offset:offset+frame.width])
                hashing_sec += now()-started
                used += 1
    return dict(total=now()-began, decode=decoder_sec, hash=hashing_sec, decoded=decoded, frames=used, sha=digest.hexdigest())


if __name__ == '__main__':
    files=sorted(Path(sys.argv[1]).glob('Scene-*.mp4'))
    assert len(files)==15
    modes=('seek','sequential')
    values={m:[] for m in modes}
    for trial in range(3):
        for mode in modes[trial%2:]+modes[:trial%2]:
            value=run(files,mode)
            values[mode].append(value)
            print(mode,trial+1,value,flush=True)
    assert len({value['sha'] for results in values.values() for value in results})==1
    for mode,results in values.items():
        print('median',mode,round(statistics.median(v['decode'] for v in results),3),
              'decode seconds;',results[0]['decoded'],'decoded frames',flush=True)
