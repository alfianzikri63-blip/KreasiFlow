"""Exercise the real Short Studio controls through the native API fixture."""
import json
from pathlib import Path
import sys
from tempfile import NamedTemporaryFile
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'app/src/main/assets'
FIXTURES=json.loads((ROOT/'tests/fixtures/content-accuracy-688.json').read_text())
HOOK=r"""
window.contentSetup688=(title,genre)=>{
 S.title='Tema acak: rumah berhantu';
 S.selected=title;
 S.category=genre; S.genre=genre;
 S.aiCache683=null;render();
};
window.liveScenes688=()=>S.scenes;
"""
BRIDGE=r"""
window.contentRequests688=[];
window.fixture688=null;window.fault688='';
window.KreasiFlowNative={
 providerStatus:()=>JSON.stringify({gemini:true}),
 cancelGenerationRequest(){},
 requestProvider(id,provider,payload){
  const req=JSON.parse(payload);window.contentRequests688.push({...req,provider});
  let text;
  if(req.prompt.includes('Direct filmable visual scenes')){
   const scenes=JSON.parse(req.prompt.split(' Requested ')[1]);
   text=JSON.stringify({scenes:scenes.map(({scene,content_subjects})=>({
    scene,title:'Gambar '+scene,action:'Reveal the location and follow visible details',camera:'Slow side tracking shot',
    setting:'Natural light with distinct setting',image_prompt:'Wide view with contextual details.',
    video_prompt:fault688==='scene'&&content_subjects?.length===1?'Replace it with '+(content_subjects[0]==='Wembley Stadium'?'Maracanã':'Wembley Stadium')+'.':'Move along one identifiable landmark.'
   }))});
  }else {
   const reply=structuredClone(fixture688.reply);
   if(typeof reply!=='string'&&(fault688==='always'||fault688==='once'&&!req.prompt.includes('PERBAIKAN TERARAH')))reply.items.pop();
   text=typeof reply==='string'?reply:JSON.stringify(reply);
  }
  setTimeout(()=>window.__kreasiflowApiResolve(id,JSON.stringify({text}),''),5);
 }
};
"""

def main():
    html=(ASSETS/'index.html').read_text().replace('})();\n</script>\n</body></html>',HOOK+'})();\n</script>\n</body></html>')
    with NamedTemporaryFile(dir=ASSETS,suffix='.html') as file,sync_playwright() as pw:
        file.write(html.encode());file.flush()
        browser=pw.chromium.launch(executable_path=sys.argv[1],args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':390,'height':840},is_mobile=True,has_touch=True)
        page.set_default_timeout(12000)
        errors=[]
        page.on('dialog',lambda dialog:dialog.accept())
        page.on('pageerror',lambda error:errors.append(str(error)))
        page.route('http**://**',lambda route:route.abort())
        page.add_init_script(BRIDGE)
        page.goto(Path(file.name).as_uri())
        def click(action):
            page.locator('[data-action="'+action+'"]').first.click()
        def status(text):
            page.wait_for_function('(text)=>document.querySelector("#kfGeneration683 [role=status]")?.textContent.includes(text)&&!document.querySelector("#kfGeneration683 progress")',arg=text)
        def setup(fixture,genre):
            page.evaluate('([f,g])=>{window.fixture688=f;contentSetup688(f.title,g)}',[fixture,genre])
        def storyboard(fixture):
            page.locator('.phase[data-tab="2"]').click()
            before=page.evaluate('contentRequests688.length')
            click('storyboard-primary')
            page.wait_for_function('(n)=>contentRequests688.length>n',arg=before)
            status('Selesai.')
            scenes=page.evaluate('liveScenes688()')
            assert scenes
            if fixture['type']=='list':
                expected=[item['name'] for item in fixture['reply']['items']]
                actual=list(dict.fromkeys(name for scene in scenes for name in scene.get('contentSubjects688',[])))
                assert actual==expected,actual
                for scene in scenes:
                    for name in scene.get('contentSubjects688',[]):
                        assert name in scene['prompt'] and name in scene['videoPrompt'] and name in scene['flowShot']['action']
            else:
                expected=fixture['reply']
                assert ' '.join(s['voice'] for s in scenes)==expected
            assert page.evaluate('contentRequests688.length')>before
            page.locator('.phase[data-tab="0"]').click()
        click('new-short')
        for fixture in FIXTURES:
            for genre in ('Semua tema (acak)','Dokumenter','Horor','Edukasi'):
                setup(fixture,genre)
                before=page.evaluate('contentRequests688.length')
                click('script-ai');status('Selesai.')
                req=page.evaluate('contentRequests688.at(-1)')
                assert page.evaluate('contentRequests688.length')==before+1,(fixture['title'],genre)
                assert fixture['title'] in req['prompt'] and 'rumah berhantu' not in req['prompt']
                assert req['structured']==(fixture['type']=='list')
                text=page.locator('[data-field=script]').input_value()
                subjects=fixture['reply']['items'] if fixture['type']=='list' else []
                assert all(x['name'] in text for x in subjects)
                assert page.get_by_text('Klaim faktual perlu verifikasi',exact=False).count()>0
            storyboard(fixture)
        setup(FIXTURES[0],'Horor')
        page.evaluate("fault688='once'")
        before=page.evaluate('contentRequests688.length')
        click('script-ai');status('Selesai.')
        assert page.evaluate('contentRequests688.length')==before+2
        assert 'tepat 5 item terstruktur' in page.evaluate('contentRequests688.at(-1).prompt')
        saved=page.locator('[data-field=script]').input_value()
        setup(FIXTURES[0],'Horor')
        page.evaluate("fault688='always'")
        before=page.evaluate('contentRequests688.length')
        click('script-ai');status('Judul meminta 5 objek berbeda.')
        assert page.evaluate('contentRequests688.length')==before+2
        assert page.locator('[data-field=script]').input_value()==saved
        page.evaluate("fault688=''")
        storyboard(FIXTURES[0])
        prior=page.evaluate('liveScenes688()')
        page.evaluate("""()=>{localStorage.removeItem('kf683-scene-parts');fault688='scene';}""")
        page.locator('.phase[data-tab="2"]').click()
        click('storyboard-primary')
        status('di luar urutan')
        assert page.evaluate('liveScenes688()')==prior
        assert not errors,errors
        print('PASS 24 title/theme combinations, one request on valid replies, one corrective request on invalid replies, last valid script retained, all six storyboard timelines, wrong scene rejected.')
if __name__=='__main__':
    main()
