"""Run Short Studio controls through the native provider interface using fixtures."""
import json
from pathlib import Path
import sys
from tempfile import NamedTemporaryFile
from playwright.sync_api import sync_playwright

root=Path(__file__).resolve().parents[1]
assets=root/'app/src/main/assets'
hook=r"""
window.special689=(title, media=false)=>{
 S.title=title;S.selected='';S.genre='Horor';S.category='Semua tema (acak)';
 S.aiCache683=null;
 if(media){S.audioName='old-voice.wav';S.scenes=[{voice:'Adegan lama'}];}
 render();
};
window.scene689=()=>({audio:S.audioName,scenes:S.scenes.map(s=>s.voice),type:S.shortAccuracy688?.type,metadata:S.shortAccuracy688});
"""
bridge=r"""
window.requests689=[];window.mode689='ok';
window.KreasiFlowNative={
 providerStatus:()=>JSON.stringify({gemini:true}),
 cancelGenerationRequest(){},
 requestProvider(id,provider,input){
  const req=JSON.parse(input);
  requests689.push(req);
  let reply, evidence=[];
  if(req.prompt.includes('Tanjiro')&&req.prompt.includes('Akaza')){
   if(!req.prompt.includes('Edisi fixture B')) reply={clarify:['Edisi fixture A','Edisi fixture B']};
   else reply={opening:'Tanjiro menghadapi Akaza di ruang pertarungan.',work:'Demon Slayer',scope:'Edisi fixture B',
    beats:[
     {stage:'setup',narration:'Tanjiro melihat Akaza memasuki ruang pertarungan.',characters:['Tanjiro','Akaza'],action:'Tanjiro watches.'},
     {stage:'conflict',narration:'Akaza bergerak maju ketika Tanjiro mengangkat pedang.',characters:['Tanjiro','Akaza'],action:'Akaza approaches.'},
     {stage:'climax',narration:'Tanjiro menghindari serangan Akaza dengan mundur satu langkah.',characters:['Tanjiro','Akaza'],action:'Tanjiro steps away.'},
     {stage:'outcome',narration:'Tanjiro dan Akaza berhenti pada batas adegan uji.',characters:['Tanjiro','Akaza'],action:'Both stop.'}],
    closing:'Urutan adegan selesai sesuai batas contoh pengujian.',
    verify:['Contoh fixture, tidak digunakan sebagai fakta kanon.']};
  }else{
   reply='Ketika tombol bor listrik ditekan, motor mulai berputar. Roda gigi menyalurkan putaran ke pencekam. Mata bor kemudian bergerak dan memotong material.';
   if(req.url_context_689)evidence=[{retrievedUrl:'https://example.org/ref',urlRetrievalStatus:window.mode689==='url-ok'?'URL_RETRIEVAL_STATUS_SUCCESS':'URL_RETRIEVAL_STATUS_ERROR'}];
  }
  const error=mode689==='error'?'HTTP 429':'';
  setTimeout(()=>window.__kreasiflowApiResolve(id,JSON.stringify({text:typeof reply==='string'?reply:JSON.stringify(reply),url_context_689:evidence}),error),10);
 }
};
"""
def test():
    html=(assets/'index.html').read_text().replace('})();\n</script>\n</body></html>',hook+'})();\n</script>\n</body></html>')
    with NamedTemporaryFile(dir=assets,suffix='.html') as tmp,sync_playwright() as pw:
        tmp.write(html.encode());tmp.flush()
        browser=pw.chromium.launch(executable_path=sys.argv[1],args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
        page.set_default_timeout(9000)
        answers=[];accept=True
        def dialog(d):
            answers.append(d.message)
            if accept:d.accept()
            else:d.dismiss()
        page.on('dialog',dialog)
        page.add_init_script(bridge)
        errs=[]
        page.on('pageerror',lambda e:errs.append(str(e)))
        page.route('http**://**',lambda route:route.abort())
        page.goto(Path(tmp.name).as_uri())
        def click(action):
            page.locator('[data-action="'+action+'"]').first.click()
        def status(text):
            page.wait_for_function('(text)=>document.querySelector("#kfGeneration683 [role=status]")?.textContent.includes(text)&&!document.querySelector("#kfGeneration683 progress")',arg=text)
        click('new-short')
        page.evaluate("special689('Bagaimana Bor Listrik Bekerja?')")
        modes=page.locator('select[data-field=directorType689]')
        assert modes.locator('option').count()==14 and modes.input_value()=='auto'
        assert 'Cara Kerja' in page.locator('#directorSummary689').inner_text()
        assert page.locator('input[data-field=directorParts689]').count()==1
        assert page.locator('input[data-field=directorWork689]').count()==0
        assert page.locator('select[data-field=contentFormat]').count()==0
        modes.select_option('recreation')
        page.wait_for_selector('[data-action=content689-auto]')
        click('script-ai');status('Judul mengarah')
        assert page.evaluate('requests689.length')==0
        click('content689-auto')
        page.locator('textarea[data-field=factSources]').fill('https://example.org/ref')
        click('script-ai');status('Selesai.')
        assert page.evaluate('requests689.length===1&&requests689[0].url_context_689===true')
        assert 'Belum terverifikasi' in page.locator('#directorQualityHost689').text_content()
        assert 'belum berhasil diakses' in page.locator('#directorQualityHost689').text_content()
        page.evaluate("mode689='url-ok';special689('Bagaimana Bor Listrik Bekerja?')")
        click('script-ai');status('Selesai.')
        assert 'URL yang berhasil diakses' in page.locator('#directorQualityHost689').text_content()
        assert 'example.org' not in page.locator('textarea[data-field=script]').input_value()
        prior=page.locator('textarea[data-field=script]').input_value()
        page.evaluate("mode689='error';special689('Bagaimana Bor Listrik Bekerja?')")
        click('script-ai');status('membatasi')
        assert page.locator('textarea[data-field=script]').input_value()==prior
        page.evaluate("mode689='ok';special689('Reka Ulang Adegan Tanjiro vs Akaza',true)")
        assert 'mungkin tidak sesuai' in page.locator('#directorQualityHost689').text_content()
        assert page.locator('select[data-field=directorFidelity689recreation]').input_value()=='canon'
        before=page.evaluate('requests689.length')
        accept=False;click('script-ai')
        assert page.evaluate('requests689.length')==before
        assert page.evaluate("scene689().audio==='old-voice.wav'&&scene689().scenes[0]==='Adegan lama'")
        accept=True;click('script-ai');status('Pilih versi')
        assert page.evaluate('requests689.length')==before+1
        assert page.locator('textarea[data-field=script]').input_value()==prior
        click('content689-version-1');status('Selesai.')
        saved=page.evaluate('scene689()')
        assert saved['audio']=='old-voice.wav' and saved['scenes']==['Adegan lama']
        assert saved['type']=='recreation' and len(saved['metadata']['beats'])==4
        assert saved['metadata']['scope']=='Edisi fixture B'
        assert answers and not errs,errs
        print('PASS 14 selector entries, contextual settings, no duplicate format, mismatch blocks before API, URL evidence, rate limit, stale media confirmation and ambiguous source selection.')
if __name__=='__main__':test()
