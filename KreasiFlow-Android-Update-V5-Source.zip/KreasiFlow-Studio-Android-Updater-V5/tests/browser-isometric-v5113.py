from playwright.sync_api import sync_playwright
from pathlib import Path
import re
p=Path(__file__).resolve().parents[1]/'app/src/main/assets/index.html';h=p.read_text();h=re.sub(r'<script src="([^"]+)"></script>',lambda m:'<script>'+ (p.parent/m[1]).read_text()+'</script>',h)
h=h.replace('</head>','<script>const mem=new Map();Object.defineProperty(window,"localStorage",{value:{getItem:k=>mem.get(k)||null,setItem:(k,v)=>mem.set(k,v),removeItem:k=>mem.delete(k)}});Object.defineProperty(navigator,"clipboard",{value:{writeText:async t=>window.__copied=t}});</script></head>')
h=h.replace('})();\n</script>\n</body>', '''window.__iso={setup:(style)=>{S.selected='Pulau';S.script='Pulau di lautan. Truk bergerak menuju gudang. Detail mesin.';S.scenes=['Pulau di lautan','Truk bergerak menuju gudang','Detail mesin'].map((voice,i)=>({name:'Scene '+(i+1),voice,prompt:voice,flowShot:{action:voice,camera:'Old wide shot',setting:'Island'}}));S.sceneStyle=style;S.directorEnabled=false;S.flowCreditMode='image-first';tab(2);},image:i=>flowDirectSceneImagePrompt(i),video:i=>googleFlowPrompt(i),style:()=>S.sceneStyle};})();\n</script>\n</body>''')
with sync_playwright() as w:
 b=w.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']);page=b.new_page(viewport={'width':390,'height':844});errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(h,wait_until='domcontentloaded',timeout=10000)
 for style in ('Isometric 3D Cinematic','Isometric 3D Diorama','Isometric 3D Hybrid'):
  page.evaluate('s=>__iso.setup(s)',style)
  for a in ('frames-copy-master','frames-copy-video-master'):
   page.locator('[data-action="'+a+'"]').click(timeout=4000);copied=page.evaluate('window.__copied');assert style in copied,(style,a)
   if style.endswith('Hybrid'):
    assert 'isolated miniature diorama base' in copied and 'full-frame environment, no terrain base' in copied,(style,a)
   elif style.endswith('Cinematic'):assert 'full-frame environment, no terrain base' in copied,(style,a)
   else:assert 'isolated miniature diorama base' in copied,(style,a)
  assert 'full-frame' in page.evaluate('__iso.image(1)') if not style.endswith('Diorama') else 'isolated miniature diorama base' in page.evaluate('__iso.image(1)')
  print('PASS actual master T2I/I2V copy and per-scene prompt:',style,flush=True)
 assert not errors,errors;b.close()
