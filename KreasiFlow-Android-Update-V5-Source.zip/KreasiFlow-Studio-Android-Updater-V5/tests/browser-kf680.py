from pathlib import Path
from io import BytesIO
import struct
import wave
import sys
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[1] / 'app/src/main/assets/index.html'
chromium = sys.argv[1] if len(sys.argv) > 1 else None

def audio(amplitude):
    with BytesIO() as stream:
        with wave.open(stream, 'wb') as wav:
            wav.setparams((1, 2, 24000, 0, 'NONE', ''))
            wav.writeframes(struct.pack('<h', amplitude) * 24000)
        return stream.getvalue()

with sync_playwright() as pw:
    browser = pw.chromium.launch(executable_path=chromium, headless=True, args=['--no-sandbox'])
    context = browser.new_context(viewport={'width':390,'height':844}, is_mobile=True, has_touch=True)
    page = context.new_page()
    errors=[]
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.on('dialog', lambda dialog: dialog.accept())
    page.route('http**://**', lambda route: route.abort())
    page.goto(root.as_uri())
    assert page.get_by_role('button',name='Short Studio').is_visible()
    page.get_by_role('button',name='Short Studio').click()
    assert page.get_by_role('heading',name='Short Studio',exact=True).is_visible()
    assert page.locator('#storyMode').count()==0
    page.locator('#kfHomeNav').click()
    page.locator('[data-action="new-series"]').click()
    assert page.locator('#storyMode').input_value()=='single'
    assert page.locator('[data-kf-fold="story-episodes"]').count()==0
    page.locator('#storyMode').select_option('series')
    assert page.locator('[data-kf-fold="story-episodes"]').count()==1
    page.locator('[data-kfref="sample-story"]').click()
    assert 'payung' in page.locator('#storyExperience').input_value()
    page.locator('[data-action="titles"]').click()
    assert 'Aku kesiangan' in page.locator('.titleitem').first.inner_text()
    page.locator('[data-kfref="sample-cast"]').click()
    page.locator('[data-kfref="add"]').click()
    page.locator('#seriesLead').select_option('Nara')
    card=page.locator('.kf-library-card').filter(has_text='Nara').first
    card.locator('summary').first.click()
    card.locator('[data-cast-image]').set_input_files(str(root.parent/'style-previews/5.webp'))
    page.wait_for_selector('img[alt="Acuan Nara"]')
    page.locator('[data-kf-fold="story-locations"] > summary').click()
    page.locator('[data-series-extra="sample-location"]').click()
    page.locator('[data-series-extra="add-location"]').click()
    loc=page.locator('.kf-library-card').filter(has_text='Halte sekolah').first
    loc.locator('summary').click()
    loc.locator('input').set_input_files(str(root.parent/'style-previews/0.webp'))
    page.wait_for_selector('img[alt="Acuan Halte sekolah"]')
    page.locator('[data-kf-fold="style-gallery"] > summary').click()
    gallery=page.locator('[data-kf-fold="style-gallery"] img')
    assert gallery.count()==20
    for img in gallery.all():
        img.scroll_into_view_if_needed()
        img.evaluate('(el) => el.decode()')
        assert img.evaluate('(el) => el.naturalWidth > 0')
    page.locator('[data-style="Cinematic Anime"]').click()
    assert '8.webp' in page.locator('.kf-selected-style img').get_attribute('src')
    script=('Aku menunggu di Halte sekolah sambil melihat hujan yang semakin deras. Temanku datang membawa payung kuning. '
            'Kami berjalan menuju sekolah dan menghindari genangan di pinggir jalan. Saat tiba, aku mengucapkan terima kasih karena ia sudah menolongku.')
    page.locator('[data-field="script"]').fill(script)
    page.locator('[data-field="duration"]').select_option('1')
    cap=page.locator('[data-scene-cap]')
    assert cap.locator('option').all_text_contents()==['4 detik','6 detik','8 detik']
    cap.select_option('8')
    assert 'Target 8 scene' in page.locator('[data-scene-target-status]').inner_text()
    page.locator('.phase[data-tab="1"]').click()
    cap.select_option('6')
    assert 'Target 10 scene' in page.locator('[data-scene-target-status]').inner_text()
    page.locator('.phase[data-tab="2"]').click()
    page.locator('[data-action="storyboard-primary"]').click()
    page.wait_for_selector('.scene-card')
    assert page.locator('.scene-card').count()==10
    prompt=page.locator('[data-scene-prompt="0"]').input_value()
    assert all(token in prompt for token in ('Nara','Halte sekolah','location photo','DIRECTOR:','VISUAL CONTINUITY'))
    assert 'ASAQ' not in prompt and 'ZAYN' not in prompt
    motion=page.locator('[data-flow-prompt-override="0"]').input_value()
    assert 'Nara' in motion and '6-second' in motion and 'ASAQ' not in motion
    assert not page.get_by_text('Google Flow via Chrome',exact=False).count()
    page.locator('.phase[data-tab="0"]').click()
    page.locator('[data-kf-fold="series-dialogue"] > summary').click()
    page.locator('[data-kfdialogue="sample"]').click()
    field=page.locator('#kfDialogueDraft')
    assert 'Nara: Tunggu' in field.input_value()
    first,second='Tunggu... itu suara siapa?','Aku cuma mengetuk pintu.'
    field.fill(f'Nara: {first}\nNARATOR: {second}')
    page.locator('[data-kfdialogue="apply"]').click()
    page.locator('.phase[data-tab="1"]').click()
    cap.select_option('8')
    assert 'Target 2 scene' in page.locator('[data-scene-target-status]').inner_text()
    assert page.get_by_text('Voice-over per karakter',exact=True).is_visible()
    page.locator('[data-batch-delivery="0"]').select_option('worried')
    for i, (line, amplitude) in enumerate([(first, 2000),(second,-2000)]):
        page.locator(f'[data-batch-file="{i}"]').set_input_files({'name':f'speaker-{i}.wav','mimeType':'audio/wav','buffer':audio(amplitude)})
        srt=f'1\n00:00:00,000 --> 00:00:01,000\n{line}\n'
        page.locator(f'[data-batch-srt="{i}"]').set_input_files({'name':f'speaker-{i}.srt','mimeType':'text/plain','buffer':srt.encode()})
    page.locator('#batchMerge').click()
    page.wait_for_function("document.querySelector('.filegood')?.textContent.includes('character-voice-sync.wav')")
    samples=page.locator('audio.audioplay').first.evaluate('''async a=>{
        const buffer=await(await fetch(a.src)).arrayBuffer();
        const view=new DataView(buffer);
        return [view.getUint32(40,true),view.getInt16(44,true),view.getInt16(48044,true),view.getInt16(384044,true)];
    }''')
    assert samples[0]==16*24000*2 and samples[1]>1000 and samples[2]==0 and samples[3]<-1000, samples
    assert 'timestamp sinkronisasi VO karakter' in page.locator('#content').inner_text()
    page.reload()
    page.locator('.phase[data-tab="0"]').click()
    assert page.locator('#storyMode').input_value()=='series'
    assert page.locator('#seriesLead').input_value()=='Nara'
    assert page.locator('img[alt="Acuan Nara"]').count()==1
    assert not errors, errors
    print('PASS Chromium mobile 390px: separate studios, both story modes, local POV titles, cast and location photo galleries, 20 decoded offline images, 4/6/8 choices, 8-to-10 storyboard target, cast identity and camera prompts, no dedicated Chrome menu, dialogue template, two WAV+SRT tracks merged into verified 8-second slots, project metadata reloaded.')
