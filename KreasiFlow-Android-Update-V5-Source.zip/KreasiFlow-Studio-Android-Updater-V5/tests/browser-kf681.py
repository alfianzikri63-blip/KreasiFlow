"""Exercises Android bridge calls using provider fixtures, plus real browser audio and video."""
from io import BytesIO
from pathlib import Path
import struct
import sys
import wave
from playwright.sync_api import sync_playwright

AROOT=Path(__file__).resolve().parents[1]/'app/src/main/assets/index.html'
PRELUDE=r"""
window.calls=[];window.renders=[];let seq=0;
window.KreasiFlowNative={
 providerStatus:()=>JSON.stringify({gemini:true,elevenlabs:true}),
 beginRenderAsset:()=>String(++seq),appendRenderAsset:()=>true,finishRenderAsset:()=>true,
 startMovingMp4Render:raw=>window.renders.push(JSON.parse(raw)),
 startMp4Render:raw=>window.renders.push(JSON.parse(raw)),
 requestCoverFrame:(req,id)=>setTimeout(()=>window.__kfCoverFrame(req,{error:'fixture frame unavailable'}),5),
 requestProvider(id,provider,raw){
  const req=JSON.parse(raw);window.calls.push(req);
  let payload;
  if(req.op==='creative_vision')payload={text:'Topi biru dan latar polos.'};
  else if(req.op==='creative_transform'||req.op==='image')payload={image_base64:'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+a2ioAAAAASUVORK5CYII=',mime_type:'image/png'};
  else if(req.op==='transcribe_audio')payload={words:[{text:'Halo',start:0,end:.4}]};
  else if(req.prompt.includes('tepat lima ide'))payload={text:JSON.stringify({ideas:Array.from({length:5},(_,i)=>({title:'Cerita '+(i+1),synopsis:'Hari itu hujan, seorang tokoh berteduh di halte '+(i+1)+'.',conflict:'Tidak ada payung.',characters:['ASAQ'],locations:['Halte'],mood:'Tenang'}))})};
  else if(req.prompt.includes('DATA CERITA:')){
   const cfg=JSON.parse(req.prompt.split('DATA CERITA: ')[1]),n=cfg.sequence?cfg.sequence.to-cfg.sequence.from+1:Number(req.prompt.match(/Beri tepat (\d+)/)[1]);
   payload={text:JSON.stringify({scenes:Array.from({length:n},(_,i)=>({action:'Anak menunggu di halte.',camera:'Wide angle',expression:'Tenang',locationId:cfg.locations[0]?.id||'',castIds:cfg.cast.map(x=>x.id),dialogues:i===0&&(!cfg.sequence||cfg.sequence.from===1)?[{characterId:cfg.cast[0]?.id||'narrator',text:'Halo',seconds:.7,emotion:'hangat',delivery:'pelan'}]:[]}))})};
  }else if(req.prompt.includes('{"assets"'))payload={text:JSON.stringify({assets:[{name:'Nara Fixture',profile:'Jaket biru.',prompt:'Draw a cartoon character with blue coat, front and side view.',voice:'Santai'}]})};
  else payload={text:'Narasi dari provider fixture.'};
  setTimeout(()=>window.__kreasiflowApiResolve(id,JSON.stringify(payload),''),10);
 }
};
"""
def signal_file(duration=1,level=2000):
    with BytesIO() as stream:
        with wave.open(stream,'wb') as wav:
            wav.setparams((1,2,24000,0,'NONE',''))
            wav.writeframes(struct.pack('<h',level)*int(duration*24000))
        return stream.getvalue()

def test():
    if len(sys.argv)<3:
        raise SystemExit('Usage: python tests/browser-kf681.py /path/to/chromium /path/to/test.mp4')
    with sync_playwright() as pw:
        browser=pw.chromium.launch(executable_path=sys.argv[1],headless=True,args=['--no-sandbox','--allow-file-access-from-files','--autoplay-policy=no-user-gesture-required'])
        page=browser.new_page(viewport={'width':360,'height':820},is_mobile=True,has_touch=True)
        page.set_default_timeout(11000)
        errors=[]
        page.on('pageerror',lambda error:errors.append(str(error)))
        page.on('dialog',lambda d:d.accept())
        page.add_init_script(PRELUDE)
        page.goto(AROOT.as_uri())
        def act(key): page.locator(f'[data-action="{key}"]').first.click()
        def tab(n): page.locator(f'.phase[data-tab="{n}"]').click()
        assert page.locator('.dock-nav .phase').count()==6
        assert page.locator('#projectCover681').evaluate('(e)=>e.naturalWidth > 0')
        act('home-manage')
        page.locator('#homeCoverFile').set_input_files(str(AROOT.parent/'style-previews/6.webp'))
        page.wait_for_function("document.querySelector('#projectCover681').src.startsWith('blob:')")
        act('new-short')
        assert 'Referensi fakta' in page.locator('#content').inner_text()
        act('script-ai')
        page.wait_for_function("document.querySelector('[data-field=script]').value.includes('provider fixture')")
        page.locator('#kfHomeNav').click()
        act('new-series')
        assert 'Referensi fakta' not in page.locator('#content').inner_text()
        choice=page.locator('[data-field="storyPerspective"] + .kf681-choose-proxy')
        choice.click()
        page.get_by_role('button',name='Third Person',exact=True).click()
        assert page.locator('[data-field="storyPerspective"]').input_value()=='third'
        page.locator('[data-field="storyMode"]').select_option('series')
        assert page.locator('[data-kf-fold="story-episodes"]').count()==1
        page.locator('#storyExperience').fill('Saya menunggu di halte ketika turun hujan.')
        act('story-method-ai')
        act('story-ai-ideas')
        page.wait_for_selector('[data-action="story-idea-4"]')
        assert page.evaluate("calls.at(-1).prompt.includes('orang ketiga')")
        act('story-idea-0')
        page.locator('[data-action="creative-cast"]').click()
        page.wait_for_selector('#creativeSearch')
        page.locator('[data-action="creative-item-legacy-asaq-pick"]').click()
        act('creative-location')
        page.wait_for_selector('#creativeSearch')
        act('creative-new')
        page.locator('#creativeSeed').fill('Halte kecil menghadap sekolah')
        act('creative-generate')
        page.wait_for_selector('[data-action="creative-save-0"]')
        act('creative-use-0')
        page.wait_for_function("document.querySelector('#creativeError').textContent.includes('tersimpan')")
        page.locator('[data-action="close-modal"]').click()
        act('story-ai-script')
        page.wait_for_selector('[data-kf-fold="structured-0"]')
        assert page.locator('[data-kf-fold^="structured-"]').count()==15
        tab(1)
        assert page.locator('[data-batch-file]').count()==1
        assert '1 pembicara' in page.locator('#content').inner_text()
        page.locator('[data-batch-file="0"]').set_input_files({'name':'actor.wav','mimeType':'audio/wav','buffer':signal_file()})
        page.wait_for_function("document.querySelector('#content').textContent.includes('actor.wav')")
        act('voice681-transcribe')
        page.wait_for_timeout(500)
        page.wait_for_function("document.querySelector('#content').textContent.includes('1 ditranskripsi')")
        page.locator('#batchMerge').click()
        page.get_by_role('button',name='Gunakan hasil sinkronisasi',exact=True).click()
        page.wait_for_function("document.querySelector('#content').textContent.includes('1 tersinkronisasi')")
        page.wait_for_function("document.querySelector('#content').textContent.includes('character-voice-sync.wav')")
        tab(2)
        act('storyboard-primary')
        page.wait_for_function("document.querySelector('#storyboardLaunchNotice')?.textContent.includes('Storyboard siap')")
        page.wait_for_selector('.scene-card')
        assert 'ASAQ' in page.locator('[data-scene-prompt="0"]').input_value()
        assert not page.get_by_text('Google Flow via Chrome',exact=False).count()
        page.locator('[data-flow-clip="0"]').set_input_files(sys.argv[2])
        page.wait_for_function("document.querySelector('#content').textContent.includes('1/15 klip')")
        tab(3)
        act('timeline681-open')
        page.wait_for_selector('#timelineMedia681 video')
        page.wait_for_function("document.querySelector('#timelineMedia681 video').readyState>=2")
        act('timeline681-play')
        page.wait_for_function("document.querySelector('#timelineMedia681 video').currentTime>.15")
        act('timeline681-play')
        page.locator('#timelineSeek681').evaluate("(el)=>{el.value='0.5';el.dispatchEvent(new Event('input',{bubbles:true}));}")
        act('timeline681-split')
        act('timeline681-undo')
        act('timeline681-redo')
        act('timeline681-save')
        page.locator('#musicFile').set_input_files({'name':'bed.wav','mimeType':'audio/wav','buffer':signal_file(2)})
        page.wait_for_selector('#musicWave681')
        page.wait_for_function("document.querySelector('#musicSelection681')?.textContent.includes('2.00')")
        canvas=page.locator('#musicWave681')
        canvas.scroll_into_view_if_needed()
        box=canvas.bounding_box()
        page.mouse.move(box['x']+box['width']-2,box['y']+35)
        page.mouse.down()
        page.mouse.move(box['x']+box['width']*.75,box['y']+35,steps=8)
        page.mouse.up()
        selected=page.locator('#musicSelection681').inner_text()
        assert 1.4 < float(selected.split(' · ')[0].split('–')[1]) < 1.6, selected
        act('music681-full')
        act('music681-pause')
        act('music681-cut')
        act('music681-stop')
        page.locator('#sfxFile681').set_input_files({'name':'sfx.wav','mimeType':'audio/wav','buffer':signal_file(.6)})
        page.wait_for_function("document.querySelector('#content').textContent.includes('sfx.wav')")
        act('render681-go')
        page.wait_for_function("renders.length===1")
        payload=page.evaluate('renders[0]')
        assert 'sceneCap' not in payload and payload['resolution']==1080 and abs(payload['sceneStarts'][-1]-57)<.03
        assert abs(payload['sceneStarts'][1]-1)<.03
        assert payload['subtitles'][0]['text']=='Halo' and payload['audioId'] and payload['musicId'] and payload['separateSfxId']
        assert payload['fastRender'] is False
        page.evaluate("window.__kreasiflowRenderDone(false,'Fixture: encoded MP4 is not produced')")
        act('render681-fast')
        page.wait_for_function("renders.length===2")
        assert page.evaluate('renders[1].fastRender===true')
        page.evaluate("window.__kreasiflowRenderDone(false,'Fixture complete')")
        page.locator('[data-field=renderTimelineSource]').select_option('manual')
        act('render681-go')
        page.wait_for_function('renders.length===3')
        assert page.evaluate('renders[2].scenes[0].parts[0].after')==0.5
        assert page.evaluate("document.documentElement.scrollWidth <= innerWidth")
        page.locator('#kfHomeNav').click()
        act('home-new-photo')
        page.locator('#creativePhoto').set_input_files(str(AROOT.parent/'style-previews/5.webp'))
        act('creative-generate')
        page.wait_for_selector('[data-action="creative-image-0"]')
        act('creative-image-0')
        page.wait_for_selector('img[alt="Hasil visual"]')
        assert page.evaluate("calls.some(c=>c.op==='creative_vision') && calls.some(c=>c.op==='creative_transform')")
        assert not errors,errors
        for width in [320,390,480]:
            mobile=browser.new_page(viewport={'width':width,'height':820},is_mobile=True,has_touch=True)
            mobile.route('http**://**',lambda route:route.abort())
            mobile.goto(AROOT.as_uri())
            mobile.wait_for_selector('#projectCover681')
            assert mobile.evaluate('document.documentElement.scrollWidth<=innerWidth')
            assert mobile.evaluate('''async()=>{for(let i=0;i<20;i++){const image=new Image();image.src='style-previews/'+i+'.webp';await image.decode();if(!image.naturalWidth)return false;}return true;}''')
            mobile.close()
        print('PASS Chromium 360 px with real WAV/MP4 and provider/renderer bridge fixtures: project cover, two studios, custom selector, AI ideas and structured script, global assets, vision/image transform dispatch, unique VO, per-character transcription, timestamp merge, storyboard, waveform, video timeline split/undo/redo, both render payloads and no page errors.')

if __name__=='__main__':
    test()
