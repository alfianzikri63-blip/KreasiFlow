"""Chromium integration with real stereo-independent WAV data and network disabled."""
from pathlib import Path
import io
import math
import struct
import sys
from tempfile import NamedTemporaryFile
import wave
from playwright.sync_api import sync_playwright

ASSETS=Path(__file__).resolve().parents[1]/'app/src/main/assets'
HOOK=r'''
window.fixture={
 showSettings, newProject, render, sceneSyncPlan, musicRenderBlob,
 get state(){return S;}, get waveform(){return waveform;}, get music(){return musicPreview;}
};
'''

def audio_fixture(seconds,rate=8000):
    out=io.BytesIO()
    with wave.open(out,'wb') as clip:
        clip.setparams((1,2,rate,0,'NONE','not compressed'))
        clip.writeframes(b''.join(struct.pack('<h',int(7000*math.sin(i/7))) for i in range(int(seconds*rate))))
    return out.getvalue()

def test():
    html=(ASSETS/'index.html').read_text().replace('})();\n</script>\n</body></html>',HOOK+'})();\n</script>\n</body></html>')
    with NamedTemporaryFile(dir=ASSETS,suffix='.html') as test_page, sync_playwright() as runner:
        test_page.write(html.encode())
        test_page.flush()
        browser=runner.chromium.launch(executable_path=sys.argv[1],args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':360,'height':820},is_mobile=True,has_touch=True)
        page.route('http**://**',lambda route:route.abort())
        page.on('dialog',lambda dialog:dialog.accept())
        errors=[]
        page.on('pageerror',lambda error:errors.append(str(error)))
        page.goto(Path(test_page.name).as_uri())
        page.evaluate("fixture.showSettings()")
        page.locator('#kfThemeChoice + button').click()
        page.get_by_role('button',name='Aurora Pro',exact=True).click()
        assert page.evaluate("document.documentElement.dataset.kfTheme")=='aurora-pro'
        page.locator('[data-aurora=saver]').check()
        page.locator('[data-aurora=intensity]').evaluate("(el)=>{el.value=73;el.dispatchEvent(new Event('input',{bubbles:true}));}")
        page.reload()
        assert page.locator('html').get_attribute('data-kf-theme')=='aurora-pro'
        assert page.locator('html').get_attribute('data-aurora-motion')=='static'
        assert page.evaluate("Number(getComputedStyle(document.documentElement).getPropertyValue('--aurora-opacity'))")==.73
        assert page.evaluate("getComputedStyle(document.body,'::before').backgroundImage.includes('radial-gradient')")
        assert page.evaluate("document.documentElement.scrollWidth<=innerWidth")
        def action(key):
            page.locator(f'[data-action="{key}"]').first.click()
        action('home-templates')
        action('story-category-all')
        search=page.locator('#storyTemplateSearch682')
        search.fill('wader')
        assert search.input_value()=='wader' and page.locator('.kf682-idea-card').count()>=1
        assert 'wader' in page.locator('.kf682-idea-card').first.inner_text().lower()
        page.evaluate("""async()=>{
          await fixture.newProject('short');
          fixture.state.scenes=[{id:'one',voice:'Kalimat pertama.',startSec:0,endSec:4},{id:'two',voice:'Kalimat kedua.',startSec:4,endSec:8}];
          fixture.render();
        }""")
        page.locator('.phase[data-tab="1"]').click()
        vo=page.locator('#audioFile')
        vo.set_input_files({'name':'voice.wav','mimeType':'audio/wav','buffer':audio_fixture(17.35)})
        page.wait_for_function('fixture.state.audioDuration>17')
        srt=b'1\n00:00:00,450 --> 00:00:12,700\nKalimat pertama.\n\n2\n00:00:13,200 --> 00:00:16,000\nKalimat kedua.\n'
        page.locator('#subtitleFile').set_input_files({'name':'voice.srt','mimeType':'text/plain','buffer':srt})
        page.wait_for_function("fixture.state.subtitleCues.length===2")
        assert page.evaluate('fixture.sceneSyncPlan().starts')==[0,12.95,17.35]
        for target in ['0','4','6','8','10']:
            page.locator('[data-scene-cap]').first.select_option(target)
            assert page.evaluate('fixture.sceneSyncPlan().starts[1]')==12.95
        assert page.evaluate("""()=>{
          const s=fixture.state, oldKey=JSON.stringify([
           s.projectId,s.storyRevision,s.storyboardSceneCap||s.sceneEvery,s.scenes.map(x=>[x.id,x.voice]),s.audioName,s.audioDuration
          ]);
          s.manualTimeline681={fingerprint:oldKey,starts:[0,13,17.35],trims:{1:.4}};
          s.renderTimelineSource='manual';
          const retained=fixture.sceneSyncPlan().starts[1]===13&&s.manualTimeline681.trims[1]===.4&&s.manualTimeline681.fingerprint!==oldKey;
          s.renderTimelineSource='auto';
          return retained;
        }""")
        page.locator('.phase[data-tab="3"]').click()
        page.locator('#musicFile').set_input_files({'name':'bed.wav','mimeType':'audio/wav','buffer':audio_fixture(3)})
        page.wait_for_function("fixture.waveform?.some(v=>v>.1)&&fixture.state.musicDuration===3")
        page.locator('[data-music-handle=start]').evaluate("(el)=>{el.value=.5;el.dispatchEvent(new Event('input',{bubbles:true}));}")
        page.locator('[data-music-handle=end]').evaluate("(el)=>{el.value=2.5;el.dispatchEvent(new Event('input',{bubbles:true}));}")
        page.locator('[data-field=musicFadeIn]').first.evaluate("(el)=>{el.value=1;el.dispatchEvent(new Event('input',{bubbles:true}));}")
        action('music681-cut')
        page.wait_for_function('fixture.music.currentTime>.65&&fixture.music.volume>0&&fixture.music.volume<.13')
        action('music681-pause')
        assert page.evaluate('fixture.music.paused')
        action('music681-stop')
        assert page.evaluate('fixture.music.currentTime')==.5
        assert page.evaluate('''async()=>{const blob=await fixture.musicRenderBlob(); const view=new DataView(await blob.arrayBuffer());
          return blob.type==='audio/wav'&&view.getInt16(44,true)===0&&view.getUint32(40,true)===2*22050*2;}''')
        assert not errors,errors
        print('PASS Aurora Pro persistence and reduced-motion mode, offline image gallery search, real WAV duration 17.35 s and scene 12.95 s under all five preferences, waveform, interactive preview, WAV trim/fade export, and legacy manual timeline migration.')
if __name__=='__main__':
    test()
