"""Exercises offline template selection and the bounded idea-provider bridge in Chromium."""
from pathlib import Path
import sys
from playwright.sync_api import sync_playwright

PAGE=(Path(__file__).resolve().parents[1]/'app/src/main/assets/index.html').as_uri()
NATIVE=r"""
const normalTimeout=window.setTimeout.bind(window);
window.setTimeout=(fn,ms,...args)=>normalTimeout(fn,ms===26000&&window.mode682==='timeout'?180:ms,...args);
window.calls=[];window.cancels=[];window.mode682='good';
window.KreasiFlowNative={
 providerStatus:()=>JSON.stringify({gemini:true}),
 cancelStoryIdeasRequest:id=>cancels.push(id),
 requestProvider:(id,provider,raw)=>{
  const request=JSON.parse(raw),mode=window.mode682;
  calls.push({provider,request,id});
  if(mode==='timeout')return;
  if(mode==='fail'){setTimeout(()=>window.__kreasiflowApiResolve(id,'','HTTP 429 provider sibuk'),30);return;}
  const ideas=Array.from({length:5},(_,i)=>({title:'Pancing '+(i+1),
   synopsis:mode==='irrelevant'&&i===4?'Tokoh membuat roti di dapur.':'Tokoh memancing wader di tikungan kali '+i+'.',
   conflict:'Arus berubah mendadak.',characters:['Tokoh'],locations:['Kali'],mood:'Santai'}));
  setTimeout(()=>window.__kreasiflowApiResolve(id,JSON.stringify({text:JSON.stringify({ideas})}),''),mode==='slow'?650:45);
 }
};
"""

def main():
    with sync_playwright() as playwright:
        browser=playwright.chromium.launch(executable_path=sys.argv[1],headless=True,args=['--no-sandbox'])
        home=browser.new_page(viewport={'width':360,'height':820},is_mobile=True,has_touch=True)
        errors=[]
        home.on('pageerror',lambda error:errors.append(str(error)))
        home.on('dialog',lambda dialog:dialog.accept())
        home.route('http**://**',lambda route:route.abort())
        home.add_init_script(NATIVE)
        home.goto(PAGE)
        def act(key):
            home.locator(f'[data-action="{key}"]').first.click()
        def text(selector):
            return home.locator(selector).inner_text()
        def count():
            return home.locator('.kf682-idea-card').count()
        home.set_default_timeout(8000)
        act('new-series')
        assert text('[data-action="story-method-template"]')=='Template Instan'
        assert home.locator('[data-action="story-method-template"]').get_attribute('aria-pressed')=='true'
        assert home.locator('.kf682-category-list img').count()==20 and count()==10
        for settings in [('storyMode','series'),('storyPerspective','dialog')]:
            home.locator(f'[data-field="{settings[0]}"]').select_option(settings[1])
        act('story-category-memancing')
        assert count()==10 and 'wader' in text('.kf682-idea-grid').lower()
        act('story-template-pick-memancing-1')
        assert home.locator('[data-field="selected"]').input_value()=='Wader Sebelum Senja'
        act('story-random-template')
        assert home.locator('[data-field="selected"]').input_value()!='Wader Sebelum Senja'
        assert home.locator('[data-field=storyMode]').input_value()=='series'
        assert home.locator('[data-field=storyPerspective]').input_value()=='dialog'
        act('story-edit-idea')
        assert home.locator('#storyExperience').evaluate('(el)=>document.activeElement===el')
        act('story-method-own')
        home.locator('#storyExperience').fill('Tokoh pergi memancing di tepi kali.')
        assert home.evaluate('calls.length')==0
        home.locator('[data-field="storyTheme"]').fill('Mancing Wader')
        home.locator('[data-field="storyPerspective"]').select_option('third')
        act('story-method-ai')
        act('story-ai-ideas')
        home.wait_for_selector('[data-action="story-idea-4"]')
        request=home.evaluate('calls[0].request')
        assert request['idea_fast'] and request['fast_text'] and request['max_tokens']==1050
        assert 'orang ketiga' in request['prompt'] and 'Mancing Wader' in request['prompt'] and 'storyboard' not in request['prompt']
        assert '5 ide baru siap dipilih' in text('.kf682-idea-status')
        act('story-idea-0')
        assert not home.locator('.kf682-idea-old').count()
        act('story-idea-1')
        assert home.locator('[data-field="selected"]').input_value()=='Pancing 2'
        home.locator('[data-field="storyTheme"]').fill('Mancing Lele')
        home.wait_for_selector('.kf682-idea-old')
        assert not home.locator('[data-action="story-idea-0"]').count()
        home.evaluate("window.mode682='slow'")
        act('story-ai-ideas')
        home.wait_for_selector('[data-action="story-cancel-ideas"]')
        act('story-cancel-ideas')
        assert 'dibatalkan' in text('.kf682-idea-status')
        home.wait_for_timeout(720)
        assert home.evaluate('cancels.length')==1 and home.locator('.kf682-idea-old').count()
        home.locator('[data-field="storyTheme"]').fill('Mancing Wader')
        home.evaluate("window.mode682='slow'")
        act('story-ai-ideas')
        home.wait_for_selector('[data-action="story-cancel-ideas"]')
        home.locator('[data-field="storyGenre"]').select_option('Misteri')
        home.wait_for_function("cancels.length===2")
        assert home.locator('.kf682-idea-old').count()==1
        home.wait_for_timeout(720)
        assert home.locator('.kf682-idea-old').count()==1
        home.evaluate("window.mode682='irrelevant'")
        act('story-ai-ideas')
        home.wait_for_selector('[data-action="story-ai-fallback"]')
        assert 'tidak cukup sesuai tema' in text('.kf682-idea-status')
        assert text('[data-action="story-ai-ideas"]')=='Coba Lagi'
        home.evaluate("window.mode682='timeout'")
        act('story-ai-ideas')
        home.wait_for_function("document.querySelector('.kf682-idea-status').textContent.includes('batas tunggu 26 detik')")
        assert home.evaluate('cancels.length')==3
        home.evaluate("window.mode682='fail'")
        act('story-ai-ideas')
        home.wait_for_function("document.querySelector('.kf682-idea-status').textContent.includes('429')")
        act('story-ai-fallback')
        assert home.locator('[data-action="story-category-memancing"]').get_attribute('aria-pressed')=='true'
        assert count()==10
        assert not errors,errors
        assert home.evaluate('document.documentElement.scrollWidth <= innerWidth')
        print('PASS Chromium 360px: default offline gallery, categories, pick/random/edit, Story mode and perspective retained, compact one-request AI, old result marking, true cancel dispatch, off-theme rejection, accelerated timeout and retry/fallback.')
        browser.close()

if __name__=='__main__':
    main()
