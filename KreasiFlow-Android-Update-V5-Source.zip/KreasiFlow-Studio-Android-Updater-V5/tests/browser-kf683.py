"""Managed AI integration using the live UI and a controlled Android text bridge."""
from pathlib import Path
import sys
from time import monotonic
from playwright.sync_api import sync_playwright

PAGE=(Path(__file__).resolve().parents[1]/'app/src/main/assets/index.html').as_uri()
BRIDGE=r"""
window.requests683=[];window.cancels683=[];window.mode683='normal';window.failures683=0;
let firstAttempt=true;
window.KreasiFlowNative={
 providerStatus:()=>JSON.stringify({gemini:true}),
 cancelGenerationRequest:id=>window.cancels683.push(id),
 requestProvider(id,provider,raw){
  const req=JSON.parse(raw);requests683.push({id,provider,...req});
  const answer=(text,error='')=>window.__kreasiflowApiResolve(id,JSON.stringify({text}),error);
  if(mode683==='hang')return;
  if(mode683==='rate'){setTimeout(()=>answer('','HTTP 429'),10);return;}
  if(mode683==='abort'&&failures683++===0){setTimeout(()=>answer('','Software caused connection abort'),10);return;}
  let output;
  if(req.prompt.includes('tepat lima judul'))output=JSON.stringify({titles:['Satu','Dua','Tiga','Empat','Lima']});
  else if(req.prompt.includes('tepat lima ide'))output=JSON.stringify({ideas:Array.from({length:5},(_,i)=>({title:'Pancing Wader '+i,synopsis:'Tokoh memancing wader di lokasi '+i,conflict:'Air keruh.',characters:['Tokoh'],locations:['Sungai'],mood:'Tenang'}))});
  else if(req.prompt.includes('DATA CERITA:')){
   const count=Number(req.prompt.match(/Beri tepat (\d+)/)[1]);
   output=JSON.stringify({scenes:Array.from({length:count},(_,i)=>({action:'Hujan turun di peron '+i,camera:'Wide angle track',lighting:'Soft daylight',expression:'Tenang',locationId:'',castIds:[],dialogues:i===0?[{characterId:'narrator',text:'Halo, hujan sudah tiba.',seconds:2}]:[]}))});
  }else if(req.prompt.includes('Direct filmable')){
   const scenes=JSON.parse(req.prompt.split(' Requested ')[1]);
   output=JSON.stringify({scenes:scenes.map(({scene})=>({scene,title:'Peron '+scene,action:'A train arrives at the station slowly.',camera:'Wide angle tracking shot',setting:'Train station visible in the rain',image_prompt:'A wide view of the rainy platform beside the trees.',video_prompt:'Slowly track with the arriving train across the frame.'}))});
  }else if(req.prompt.includes('Perbaiki hanya kalimat pertama'))output=JSON.stringify({first:'Air hujan memenuhi peron kereta.',last:'Rangkaian ini dimulai ketika:'});
  else if(req.prompt.includes('Balas satu kata'))output='OK';
  else output='Kereta tiba di peron ketika hujan. Penumpang menunggu pengumuman. Petugas memeriksa jalur. Setelah itu, kereta bergerak kembali.';
  setTimeout(()=>answer(output),mode683==='slow'?900:12);
 }
};
"""
def main():
    with sync_playwright() as pw:
        browser=pw.chromium.launch(executable_path=sys.argv[1],args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':390,'height':840},is_mobile=True,has_touch=True)
        page.set_default_timeout(9000)
        page.on('dialog',lambda dialog:dialog.accept())
        errors=[]
        page.on('pageerror',lambda err:errors.append(str(err)))
        page.route('http**://**',lambda route:route.abort())
        page.add_init_script(BRIDGE)
        page.goto(PAGE)
        def act(key):
            page.locator(f'[data-action="{key}"]').first.click()
        def finished(text='Selesai.'):
            page.wait_for_function('(message)=>document.querySelector("#kfGeneration683 [role=status]")?.textContent.includes(message)',arg=text)
        def tab(index):
            page.locator(f'.phase[data-tab="{index}"]').click()
        act('new-short')
        page.locator('[data-field=title]').fill('Kereta pada musim hujan')
        act('title-ai')
        finished()
        assert page.locator('[data-title-index]').count()==5
        act('title-ai')
        finished()
        assert page.evaluate('requests683.length')==1
        page.locator('[data-field=title]').fill('Kereta terakhir')
        page.wait_for_function('!document.querySelector("[data-title-index]")')
        act('go-process')
        assert page.locator('.phase[data-tab="0"]').evaluate("(element)=>element.classList.contains('on')")
        page.evaluate("mode683='abort'")
        act('script-ai')
        tab(1)
        finished()
        assert page.evaluate('requests683.length')==3
        tab(0)
        assert 'Kereta tiba' in page.locator('[data-field=script]').input_value()
        act('loop-toggle')
        act('ai683-loop')
        page.get_by_role('button',name='Terapkan',exact=True).click()
        finished()
        assert page.locator('[data-field=script]').input_value().startswith('Air hujan')
        page.evaluate("mode683='rate'")
        act('script-ai')
        finished('membatasi')
        rate_count=page.evaluate('requests683.length')
        page.wait_for_timeout(800)
        assert page.evaluate('requests683.length')==rate_count
        page.evaluate("mode683='hang'")
        act('ai683-retry')
        page.wait_for_function('(count)=>requests683.length===count+1',arg=rate_count)
        act('ai683-cancel')
        page.get_by_role('button',name='Batalkan AI',exact=True).click()
        finished('dibatalkan')
        assert page.evaluate('cancels683.length')==1
        page.locator('#kfHomeNav').click()
        act('new-series')
        page.locator('[data-field=storyTheme]').fill('Mancing Wader')
        page.locator('#storyExperience').fill('Aku belajar memancing wader di sungai.')
        act('story-method-ai')
        page.evaluate("mode683='normal'")
        act('story-ai-ideas')
        finished()
        assert page.locator('[data-action^=story-idea-]').count()==5
        before=page.evaluate('requests683.length')
        page.locator('[data-field=storyPerspective]').select_option('third')
        act('story-ai-script')
        finished()
        assert page.evaluate('requests683.length')==before+1
        assert page.locator('[data-kf-fold^=structured-]').count()==15
        tab(2)
        act('storyboard-primary')
        page.wait_for_function("document.querySelector('#kfGeneration683 b')?.textContent==='Generate Scene AI'")
        finished()
        scene_requests=page.evaluate("requests683.filter(r=>r.prompt.includes('Direct filmable')).length")
        assert scene_requests==4,scene_requests
        act('storyboard-primary')
        finished()
        assert page.evaluate("requests683.filter(r=>r.prompt.includes('Direct filmable')).length")==scene_requests
        tab(0)
        page.locator('[data-field=storyMode]').select_option('series')
        act('story-ai-script')
        finished()
        assert page.locator('[data-kf-fold^=structured-]').count()==15
        assert not errors,errors
        page.locator('#kfHomeNav').click()
        page.locator('.kf681-home [data-action=settings]').click()
        page.locator('[data-kf-fold=ai683-performance] summary').click()
        page.locator('[data-field=geminiTextModel683]').select_option('gemini-3.5-flash')
        act('ai683-test')
        finished()
        assert page.evaluate("requests683.at(-1).model==='gemini-3.5-flash'")
        for managed in (False,True):
            sample=browser.new_page(viewport={'width':390,'height':840})
            sample.on('dialog',lambda dialog:dialog.accept())
            sample.route('http**://**',lambda route:route.abort())
            sample.add_init_script(BRIDGE+("" if managed else "delete window.KreasiFlowNative.cancelGenerationRequest;"))
            sample.goto(PAGE)
            sample.locator('[data-action=new-series]').first.click()
            sample.locator('[data-field=storyTheme]').fill('Kereta saat musim hujan')
            sample.locator('#storyExperience').fill('Aku menunggu kereta di bawah atap peron.')
            sample.evaluate("mode683='slow'")
            begin=monotonic()
            sample.locator('[data-action=story-ai-script]').first.click()
            sample.wait_for_selector('[data-kf-fold=structured-14]')
            duration_ms=round((monotonic()-begin)*1000)
            count=sample.evaluate('requests683.length')
            assert count==(1 if managed else 2)
            print(f"BENCH 60-second Story fixture: {'managed' if managed else 'legacy'} {count} requests, {duration_ms} ms")
            sample.close()
        print('PASS managed Short/Story ideas and scripts, cache, stale themes, production gate, retry connection abort, rate limit, native cancel, work across tabs, Direct Loop approval, Standalone and Series dialogue, four storyboard batches and cache reuse.')
if __name__=='__main__':
    main()
