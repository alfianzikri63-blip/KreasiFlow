"""Runs the real editor on local WAV files with a timed transcription bridge fixture."""
from pathlib import Path
from tempfile import NamedTemporaryFile
from playwright.sync_api import sync_playwright
import io
import math
import struct
import sys
import wave

ASSETS=Path(__file__).resolve().parents[1]/'app/src/main/assets'
HOOK=r"""
window.fixture684={newProject,render,sceneSyncPlan,context:()=>visualEmotion684(S.scenes[0],0),get state(){return S;}};
"""
BRIDGE=r"""
window.calls684=[];window.cancel684=[];window.released684=[];window.copied684='';
window.transcriptMode684='normal';let id=0,failed=false;
Object.defineProperty(navigator,'clipboard',{value:{writeText:text=>{window.copied684=text;return Promise.resolve();}}});
window.KreasiFlowNative={
 providerStatus:()=>JSON.stringify({elevenlabs:true,gemini:true}),
 beginRenderAsset:()=>String(++id),appendRenderAsset:()=>true,finishRenderAsset:()=>true,
 cancelGenerationRequest:id=>window.cancel684.push(id),releaseTranscriptionAsset:id=>window.released684.push(id),
 requestProvider(id,provider,raw){
  const req=JSON.parse(raw);window.calls684.push({id,provider,req});
  if(window.transcriptMode684==='hang')return;
  if(window.transcriptMode684==='retry'&&!failed){
   failed=true;setTimeout(()=>window.__kreasiflowApiResolve(id,'','network: socket connection abort'),40);return;
  }
  const word=(text,start,end,type='word')=>({text,start,end,type});
  const words=req.duration_seconds>3.5?[word('Itu',.25,.4),word('dia',.4,.66),word('mengetuk!',.66,1.2),word('[tawa]',1.35,1.65,'audio_event')]:
   [word('Iya,',.15,.31),word('kita',.31,.42),word('hadapi',.42,.6),word('berdua.',.6,.9)];
  setTimeout(()=>window.__kreasiflowApiResolve(id,JSON.stringify({words}),''),230);
 }
};
"""

def wav(seconds,rate=8000):
    blob=io.BytesIO()
    with wave.open(blob,'wb') as f:
        f.setparams((1,2,rate,0,'NONE',''))
        f.writeframes(b''.join(struct.pack('<h',int(4000*math.sin(i/9))) for i in range(int(seconds*rate))))
    return blob.getvalue()

def test():
    html=(ASSETS/'index.html').read_text().replace('})();\n</script>\n</body></html>',HOOK+'})();\n</script>\n</body></html>')
    with NamedTemporaryFile(dir=ASSETS,suffix='.html') as target, sync_playwright() as pw:
        target.write(html.encode());target.flush()
        browser=pw.chromium.launch(executable_path=sys.argv[1],args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':390,'height':820})
        page.set_default_timeout(9000)
        errors=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.on('dialog',lambda dialog:dialog.accept())
        page.route('http**://**',lambda route:route.abort())
        page.add_init_script(BRIDGE)
        page.goto(Path(target.name).as_uri())
        page.evaluate("""async()=>{
          await fixture684.newProject('series','single');
          const s=fixture684.state;
          s.storyStructured=true;s.voModel683='v4';s.seriesCast=[];
          s.scenes=[
           {id:'s1',name:'Bunyi pintu',action:'Suasana mencekam',atmosphere:'Tegang',startSec:0,endSec:4,voice:'Itu dia ngetok! Iya, kita hadapi berdua.',
            dialogues:[{id:'a1',speaker:'ASAQ',text:'Itu dia ngetok!',emotion:'ceria',intensity:4},{id:'z1',speaker:'ZAYN',text:'Iya, kita hadapi berdua.',delivery:'berbisik'}]},
           {id:'s2',name:'Tunggu kakak',action:'Asaq ketakutan',startSec:4,endSec:8,voice:'Kamu jangan jauh-jauh ya, Kak.',
            dialogues:[{id:'a2',speaker:'ASAQ',text:'Kamu jangan jauh-jauh ya, Kak.'}]}];
          s.script=s.scenes.map(x=>x.voice).join(' ');
          fixture684.render();
        }""")
        def click(selector):
            page.locator(selector).first.click()
        def status(text):
            page.wait_for_function("(text)=>document.querySelector('#kfGeneration683 [role=status]')?.textContent.includes(text)",arg=text)
        click('.phase[data-tab="1"]')
        click('[data-batch-directed="0"]')
        page.wait_for_function("copied684.includes('[frightened]')&&copied684.includes('[pleading]')")
        assert 'Takut' in page.evaluate('fixture684.context()')
        click('[data-batch-copy="0"]')
        page.wait_for_function("copied684.includes('ngetok')&&!copied684.includes('[')")
        page.locator('[data-field=voModel683]').select_option('plain')
        click('[data-batch-directed="0"]')
        assert '[' not in page.evaluate('copied684')
        for i,seconds in enumerate((4,3)):
            page.locator(f'[data-batch-file="{i}"]').set_input_files({'name':f'voice{i}.wav','mimeType':'audio/wav','buffer':wav(seconds)})
            page.wait_for_function("(i)=>document.querySelector('#content').textContent.includes('voice'+i+'.wav')",arg=i)
        page.evaluate("transcriptMode684='retry'")
        click('[data-action=voice681-transcribe]')
        status('Percobaan ulang')
        assert page.locator('#kfGeneration683 progress').count()==1
        click('.phase[data-tab="2"]')
        status('Selesai.')
        click('.phase[data-tab="1"]')
        assert page.evaluate('calls684.length')==3
        assert page.locator('#kfGeneration683 [role=status]').inner_text().endswith('2/2 karakter')
        assert '1 dialog perlu diperiksa' in page.locator('#content').inner_text()
        click('[data-action=voice684-review-0]')
        assert 'Tidak cocok' in page.locator('.kf684-correction').inner_text()
        click('.kf684-correction summary:text("Gabung atau pisah cue")')
        count=page.locator('#voiceCue684 option').count()
        click('[data-corr-op=join]')
        assert page.locator('#voiceCue684 option').count()==count-1
        click('.kf684-correction summary:text("Gabung atau pisah cue")')
        page.locator('#voiceSplit684').fill('0.4')
        page.locator('#voiceSplitWord684').fill('2')
        click('[data-corr-op=split]')
        assert page.locator('#voiceCue684 option').count()==count
        page.locator('[data-corr-start="1"]').fill('2.2')
        page.locator('[data-corr-end="1"]').fill('3.2')
        click('[data-corr-original="1"]')
        click('[data-corr-play="1"]')
        page.wait_for_function("document.querySelector('.kf684-correction audio').currentTime>=2.2")
        click('[data-corr-verify="1"]')
        assert 'Sudah dikoreksi' in page.locator('.kf684-correction').inner_text()
        click('[data-corr-op=save]')
        page.wait_for_selector('.kf684-correction',state='detached')
        click('#batchMerge')
        page.get_by_role('button',name='Gunakan hasil sinkronisasi',exact=True).click()
        page.wait_for_function("fixture684.state.subtitleSource==='batch'")
        actual=page.evaluate('fixture684.sceneSyncPlan().starts')
        assert len(actual)==3 and abs(actual[-1]-7)<.001,actual
        subtitles=page.evaluate('fixture684.state.subtitleCues')
        assert [cue['text'] for cue in subtitles]==['Itu dia ngetok!','Iya, kita hadapi berdua.','Kamu jangan jauh-jauh ya, Kak.']
        assert [cue['start'] for cue in subtitles]==[.25,2.35,5.2],subtitles
        page.evaluate("transcriptMode684='hang'")
        click('[data-batch-transcribe="0"]')
        status('Menunggu transkripsi provider')
        click('[data-action=ai683-cancel]')
        page.get_by_role('button',name='Batalkan AI',exact=True).click()
        status('dibatalkan')
        assert page.evaluate('cancel684.length')==1
        assert 'Audio terverifikasi' in page.locator('#content').inner_text()
        page.evaluate("fixture684.newProject('short')")
        click('.phase[data-tab="1"]')
        page.locator('#audioFile').set_input_files({'name':'single.wav','mimeType':'audio/wav','buffer':wav(3)})
        page.wait_for_function('fixture684.state.audioDuration===3')
        page.evaluate("transcriptMode684='normal'")
        click('[data-action=subtitle-ai]')
        status('Menunggu transkripsi provider')
        assert page.locator('#kfGeneration683 progress').get_attribute('value') is None
        status('Selesai.')
        assert page.evaluate("fixture684.state.subtitleSource==='ai'&&fixture684.state.subtitleCues.length>0")
        assert not errors,errors
        print('PASS local WAV, 2 speakers, V4 and plain copy, retry progress, partial and manual correction, 7 s reordered VO and subtitle, cancel preserving results, Single VO progress')
if __name__=='__main__':
    test()
