"""Tests the real progress UI and cancellation bridge with controlled service events."""
from pathlib import Path
from tempfile import NamedTemporaryFile
import sys
from playwright.sync_api import sync_playwright

ASSETS=Path(__file__).resolve().parents[1]/'app/src/main/assets'
HOOK="window.theme685=kfTheme;"
NATIVE=r"""
window.cancels685=[];
window.KreasiFlowNative={
 beginRenderAsset:()=>1,
 cancelRender685:id=>{cancels685.push(id);return true;},
 getBackgroundRenderStatus:()=>''};
"""

def main():
    source=(ASSETS/'index.html').read_text().replace('})();\n</script>\n</body></html>',HOOK+'})();\n</script>\n</body></html>')
    with NamedTemporaryFile(dir=ASSETS,suffix='.html') as html,sync_playwright() as pw:
        html.write(source.encode());html.flush()
        browser=pw.chromium.launch(executable_path=sys.argv[1],args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':390,'height':820})
        page.add_init_script(NATIVE)
        page.route('http**://**',lambda route:route.abort())
        errors=[]
        page.on('pageerror',lambda error:errors.append(str(error)))
        page.goto(Path(html.name).as_uri())
        page.evaluate("theme685('aurora-pro')")
        assert page.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--kf-progress-main').trim()")=='#8B5CF6'
        assert page.evaluate("getComputedStyle(document.querySelector('#kfRenderMonitor685')).backgroundColor")=='rgb(24, 27, 41)'
        page.evaluate("""()=>{
          const box=document.createElement('div');box.className='operation-progress-fill';document.body.append(box);
          if(!getComputedStyle(box).backgroundImage.includes('139, 92, 246'))throw Error('Progress fill is not purple');
          box.remove();
          window.__kreasiflowBackgroundRenderSync({state:'queued',jobId:'test',updatedAt:Date.now(),startedAt:Date.now(),message:'Menyiapkan media'});
        }""")
        assert page.locator('#kfRenderFrames685').is_hidden()
        assert page.locator('#kfRenderOverall685').get_attribute('value') is None
        page.evaluate("""window.__kreasiflowBackgroundRenderSync({
          state:'running',jobId:'test',updatedAt:Date.now(),
          message:'Encoding video',telemetry:{phase:'video',engine:'Render Cepat V2',
          frames:72,frameTotal:180,scenes:6,sceneTotal:15,encoder:'c2.test.avc',hardware:true,throughput:38,etaVideoSeconds:4}
        })""")
        assert page.locator('#kfRenderTitle685').inner_text()=='Render Cepat V2'
        assert page.locator('#kfRenderFrames685').get_attribute('value')=='72'
        assert '72/180 frame · 40%' in page.locator('#kfRenderNumbers685').inner_text()
        assert 'hardware encoder' in page.locator('#kfRenderNumbers685').inner_text()
        page.evaluate("""window.__kreasiflowBackgroundRenderSync({
          state:'running',jobId:'test',updatedAt:Date.now()-95000,message:'Menunggu codec',
          telemetry:{phase:'video',frames:72,frameTotal:180,etaVideoSeconds:4}
        })""")
        assert '90 detik' in page.locator('#kfRenderDetail685').inner_text()
        assert 'Sisa tahap' not in page.locator('#kfRenderNumbers685').inner_text()
        page.locator('#kfRenderCancel685').click()
        page.locator('dialog[open]').get_by_role('button',name='Batalkan render',exact=True).click()
        page.wait_for_function('cancels685.length===1&&cancels685[0]==="test"')
        page.evaluate("window.__kreasiflowBackgroundRenderSync({state:'cancelled',jobId:'test',message:'Render dibatalkan'})")
        assert page.locator('#kfRenderCancel685').is_hidden()
        assert page.locator('#kfRenderOverall685').is_hidden()
        page.evaluate("theme685('midnight')")
        assert page.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--kf-progress-track').trim()")=='#252A3D'
        assert not errors,errors
        print('PASS Aurora Pro and Midnight, one themed monitor, actual frame count, elapsed/stall, hardware/status, and cancel bridge.')
if __name__=='__main__':
    main()
