from playwright.sync_api import sync_playwright
from pathlib import Path
import re, base64, io
from PIL import Image
p=Path(__file__).resolve().parents[1]/'app/src/main/assets/index.html';h=p.read_text();h=re.sub(r'<script src="([^"]+)"></script>',lambda m:'<script>'+ (p.parent/m[1]).read_text()+'</script>',h)
h=h.replace('</head>','<script>const mem=new Map();Object.defineProperty(window,"localStorage",{value:{getItem:k=>mem.get(k)||null,setItem:(k,v)=>mem.set(k,v),removeItem:k=>mem.delete(k)}});</script></head>');h=h.replace('})();\n</script>\n</body>', '''window.__prod={S:()=>S,setup:()=>{S.selected='Rahasia distribusi barang';S.script='Distribusi barang.';S.scenes=[{name:'Scene 1',voice:'Distribusi barang.',startSec:0,endSec:6}];S.captions=false;tab(3);}};})();\n</script>\n</body>''')
with sync_playwright() as w:
 b=w.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']);page=b.new_page(viewport={'width':390,'height':844},accept_downloads=True);errs=[];page.on('pageerror',lambda e:errs.append(str(e)));page.set_content(h,wait_until='domcontentloaded',timeout=10000);page.evaluate('__prod.setup()')
 def click(a):page.locator('[data-action="'+a+'"]').click(timeout=4000)
 def panel():
  d=page.locator('[data-kf-fold="production-tools"]');
  if d.get_attribute('open') is None:d.locator('summary').click(timeout=4000)
 panel();click('production-check');page.wait_for_function("document.querySelector('#productionCheckStatus').textContent.startsWith('Selesai')");assert 'belum ada footage' in page.locator('#productionCheckResult').inner_text();click('close-modal');print('PASS quality checker actual click',flush=True)
 panel();click('production-brand');page.locator('#productionBrandName').fill('Channel Test');page.locator('#productionWatermark').fill('TEST');page.locator('#productionChannel').fill('CHANNEL');click('production-brand-save');assert page.evaluate('__prod.S().watermark')=='TEST';assert page.evaluate('__prod.S().templateOutroChannel')=='CHANNEL';assert 'Channel Test' in page.locator('#productionBrandSelect').inner_text();page.locator('#productionBrandSelect').select_option('0');click('production-brand-apply');assert 'diterapkan' in page.locator('#productionBrandStatus').inner_text();click('close-modal');print('PASS brand save and apply',flush=True)
 panel();click('production-cover');im=Image.new('RGB',(200,300),(30,120,150));buf=io.BytesIO();im.save(buf,format='PNG');page.locator('#productionCoverFile').set_input_files({'name':'test.png','mimeType':'image/png','buffer':buf.getvalue()});page.wait_for_function("document.querySelector('#productionCoverStatus').textContent.startsWith('Gambar siap')");page.locator('#productionCoverRatio').select_option('1:1');assert page.locator('#productionCoverCanvas').evaluate('(c)=>[c.width,c.height]')==[1080,1080];
 with page.expect_download(timeout=5000) as d:click('production-cover-save')
 out=Image.open(d.value.path());assert out.size==(1080,1080) and out.format=='JPEG';print('PASS cover upload, preview and actual JPEG export',flush=True);assert not errs,errs;b.close()
