"""Compile and exercise the renderer shaders with WebGL. Android EGL/OES needs a device."""
import json
from pathlib import Path
import re
import sys
from playwright.sync_api import sync_playwright

root=Path(__file__).resolve().parents[1]
source=(root/'app/src/main/java/id/kreasiflow/studio/SurfaceCompositor686.java').read_text()
shaders={}
for name in ('VERTEX','VIDEO','BITMAP','FILL'):
    declaration=re.search(r'\b'+name+r'\s*=\s*((?:"(?:[^"\\]|\\.)*"\s*(?:\+\s*)?)+);',source)
    assert declaration,name
    shaders[name]=''.join(json.loads(s) for s in re.findall(r'"(?:[^"\\]|\\.)*"',declaration.group(1)))
# WebGL has no Android SurfaceTexture external sampler. Use a regular texture for matrix tests only.
shaders['VIDEO']=shaders['VIDEO'].split('\n',1)[1].replace('samplerExternalOES','sampler2D')
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path=sys.argv[1],args=['--no-sandbox','--enable-unsafe-swiftshader','--use-angle=swiftshader','--enable-webgl'])
    page=browser.new_page()
    print(page.evaluate("""shaders=>{
      const canvas=document.createElement('canvas');canvas.width=8;canvas.height=8;
      const g=canvas.getContext('webgl',{antialias:false,preserveDrawingBuffer:true});
      if(!g)throw Error('WebGL unavailable');
      const compile=(kind,source)=>{
        const shader=g.createShader(kind);g.shaderSource(shader,source);g.compileShader(shader);
        if(!g.getShaderParameter(shader,g.COMPILE_STATUS))throw Error(g.getShaderInfoLog(shader));
        return shader;
      };
      const program=source=>{
        const p=g.createProgram();
        g.attachShader(p,compile(g.VERTEX_SHADER,shaders.VERTEX));
        g.attachShader(p,compile(g.FRAGMENT_SHADER,source));
        g.bindAttribLocation(p,0,'aUv');g.linkProgram(p);
        if(!g.getProgramParameter(p,g.LINK_STATUS))throw Error(g.getProgramInfoLog(p));
        return p;
      };
      const pixel=(x,y)=>{const out=new Uint8Array(4);g.readPixels(x,y,1,1,g.RGBA,g.UNSIGNED_BYTE,out);return [...out]};
      const main=program(shaders.VIDEO),overlay=program(shaders.BITMAP),fill=program(shaders.FILL);
      const quad=g.createBuffer();g.bindBuffer(g.ARRAY_BUFFER,quad);
      g.bufferData(g.ARRAY_BUFFER,new Float32Array([0,0,1,0,0,1,1,1]),g.STATIC_DRAW);
      g.enableVertexAttribArray(0);g.vertexAttribPointer(0,2,g.FLOAT,false,0,0);
      const bounds=(p,...rect)=>{g.useProgram(p);g.uniform4f(g.getUniformLocation(p,'bounds'),...rect)};
      const draw=()=>g.drawArrays(g.TRIANGLE_STRIP,0,4);
      bounds(fill,0,0,1,1);g.uniform1i(g.getUniformLocation(fill,'mode'),0);
      g.uniform1f(g.getUniformLocation(fill,'xWeight'),0.5);draw();
      const outside=pixel(0,0);
      const tex=g.createTexture();g.bindTexture(g.TEXTURE_2D,tex);
      g.texParameteri(g.TEXTURE_2D,g.TEXTURE_MIN_FILTER,g.NEAREST);
      g.texParameteri(g.TEXTURE_2D,g.TEXTURE_MAG_FILTER,g.NEAREST);
      g.texImage2D(g.TEXTURE_2D,0,g.RGBA,1,2,0,g.RGBA,g.UNSIGNED_BYTE,new Uint8Array([255,0,0,255,0,0,255,255]));
      bounds(main,.25,0,.5,1);
      g.uniformMatrix4fv(g.getUniformLocation(main,'tx'),false,new Float32Array([1,0,0,0,0,-1,0,0,0,0,1,0,0,1,0,1]));
      draw();
      if(pixel(3,7)[0]!==255 || pixel(3,0)[2]!==255 || pixel(0,0).join()!==outside.join())
        throw Error('Transformed texture or Fit border incorrect');
      bounds(overlay,0,0,1,1);draw();
      if(pixel(4,7)[0]!==255 || pixel(4,0)[2]!==255) throw Error('Bitmap orientation incorrect');
      bounds(fill,0,0,1,1);g.uniform1i(g.getUniformLocation(fill,'mode'),1);
      g.enable(g.BLEND);g.blendFunc(g.SRC_ALPHA,g.ONE_MINUS_SRC_ALPHA);draw();
      if(pixel(4,0)[2]>=200 || pixel(4,7)[0]!==255 || g.getError()!==0) throw Error('Shade blend incorrect');
      return 'PASS shader link, texture transform, Fit border, Canvas bitmap orientation and shade blend';
    }""",shaders))
