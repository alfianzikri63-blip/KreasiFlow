from pathlib import Path
import re,json,base64
from playwright.sync_api import sync_playwright
p=Path(__file__).resolve().parents[1]/'app/src/main/assets/index.html'
h=p.read_text();h=re.sub(r'<script src="([^"]+)"></script>',lambda m:'<script>'+ (p.parent/m[1]).read_text()+'</script>',h)
# The runner disallows file:// navigation. Keep the app code intact and simulate bundled image delivery with data URLs.
assets={str(x.relative_to(p.parent)):'data:image/webp;base64,'+base64.b64encode(x.read_bytes()).decode() for x in (p.parent/'style-previews').glob('*.webp')}
h=h.replace('</head>','<script>const mem=new Map();Object.defineProperty(window,"localStorage",{value:{getItem:k=>mem.get(k)||null,setItem:(k,v)=>mem.set(k,v),removeItem:k=>mem.delete(k)}});</script></head>')
h=h.replace("(()=>{'use strict';",'const previewOriginal=window.KFStylePreview;const previewData='+json.dumps(assets)+';window.KFStylePreview={names:previewOriginal.names,get:name=>previewData[previewOriginal.get(name)]||null};'+"(()=>{'use strict';",1)
with sync_playwright() as w:
 b=w.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--allow-file-access-from-files'])
 page=b.new_page(viewport={'width':390,'height':844});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(h,wait_until='domcontentloaded',timeout=12000)
 sel=page.locator('select[data-field="sceneStyle"]');assert sel.count()==1
 styles=sel.locator('option').evaluate_all('(xs)=>xs.map(x=>x.value)');assert len(styles)==76
 def check(style):
  page.locator('select[data-field="sceneStyle"]').select_option(style,timeout=3000)
  preview=page.locator('[data-kf-style-preview]');assert preview.locator('strong').inner_text()==style
  preview.locator('img').evaluate('(img)=>img.decode()');assert preview.locator('img').evaluate('(img)=>img.naturalWidth')==640
 for style in styles:check(style)
 print('PASS: all 76 style selections, local WebP decoded',flush=True)
 page.locator('[data-tab="1"]').click();page.locator('[data-kf-fold="audio-advanced"] > summary').click();check('Isometric 3D Cinematic');print('PASS: Audio tab preview updates',flush=True)
 page.locator('[data-tab="2"]').click();page.locator('[data-kf-fold="scene-style"] > summary').click();check('Isometric 3D Diorama');print('PASS: Scene tab preview updates',flush=True)
 page.locator('[data-kf-fold="scene-style"] details > summary').click();page.locator('[data-style="Isometric 3D Hybrid"]').click();assert page.locator('[data-kf-style-preview] strong').inner_text()=='Isometric 3D Hybrid'
 page.locator('[data-tab="0"]').click();assert page.locator('[data-kf-style-preview] strong').inner_text()=='Isometric 3D Hybrid';assert page.evaluate("JSON.parse(localStorage.getItem('kreasiflow-current-v3')).sceneStyle")=='Isometric 3D Hybrid';print('PASS: gallery selection and persisted preference',flush=True)
 assert not errors,errors
 b.close()
