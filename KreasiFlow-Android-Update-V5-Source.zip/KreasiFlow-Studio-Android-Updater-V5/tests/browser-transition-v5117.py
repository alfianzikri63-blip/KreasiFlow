from playwright.sync_api import sync_playwright
from pathlib import Path
import re
p=Path(__file__).resolve().parents[1]/'app/src/main/assets/index.html';h=p.read_text();h=re.sub(r'<script src="([^"]+)"></script>',lambda m:'<script>'+ (p.parent/m[1]).read_text()+'</script>',h)
h=h.replace('</head>','<script>const mem=new Map();Object.defineProperty(window,"localStorage",{value:{getItem:k=>mem.get(k)||null,setItem:(k,v)=>mem.set(k,v),removeItem:k=>mem.delete(k)}});</script></head>')
h=h.replace('})();\n</script>\n</body>', '''window.__tr={S:()=>S,setup:()=>{S.selected='Test transition';S.script='Halo semua. Selamat datang.';S.scenes=[{name:'Scene 1',voice:'Halo semua'},{name:'Scene 2',voice:'Selamat datang'}];tab(3);},mode:()=>nativeTransitionMode(),rerender:()=>render()};})();\n</script>\n</body>''')
with sync_playwright() as w:
 b=w.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']);page=b.new_page(viewport={'width':390,'height':844});errs=[];page.on('pageerror',lambda e:errs.append(str(e)));page.set_content(h,wait_until='domcontentloaded',timeout=10000);page.evaluate('__tr.setup()');sel=page.locator('[data-field="sceneTransition"]');assert sel.input_value()=='legacy';
 for mode in ['cut','dissolve','dip','flash','auto']:
  sel.select_option(mode,timeout=4000);assert page.evaluate('__tr.S().sceneTransition')==mode;page.evaluate('__tr.rerender()');assert sel.input_value()==mode
 page.evaluate("__tr.S().sceneStyle='Misteri Gelap'");assert page.evaluate('__tr.mode()')=='dip';page.evaluate("__tr.S().sceneStyle='Isometric 3D Cinematic'");assert page.evaluate('__tr.mode()')=='dissolve';assert not errs,errs;print('PASS actual UI selection, state retention across render and automatic mode');b.close()
