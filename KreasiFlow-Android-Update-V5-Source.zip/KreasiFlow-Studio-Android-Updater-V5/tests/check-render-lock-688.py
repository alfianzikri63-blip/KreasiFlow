"""Compare the protected KF687 render implementation against this source tree."""
from io import BytesIO
import hashlib
from pathlib import Path
import sys
from zipfile import ZipFile

root=Path(__file__).resolve().parents[1]
source_zip='KreasiFlow-Android-Update-V5-Source.zip'
prefix=root.name+'/'
with ZipFile(sys.argv[1]) as outer:
    assert outer.testzip() is None
    with ZipFile(BytesIO(outer.read(source_zip))) as baseline:
        assert baseline.testzip() is None
        paths=[n[len(prefix):] for n in baseline.namelist() if n.startswith(prefix) and not n.endswith('/')]
        changed=[]
        for path in paths:
            candidate=root/path
            assert candidate.is_file(),f'Baseline file missing: {path}'
            if candidate.read_bytes()!=baseline.read(prefix+path):
                changed.append(path)
        allowed={'app/build.gradle','app/src/main/assets/index.html'}
        assert not set(path for path in changed if not path.startswith('tests/'))-allowed,changed
        before=baseline.read(prefix+'app/src/main/assets/index.html').decode()
        after=(root/'app/src/main/assets/index.html').read_text()
        regions={
          'settings_mixer_render_ui':('function nativeTransitionMode()','function providerStatus()'),
          'canvas_and_preview':('function loadSceneImages()','async function prepareVideoInput('),
          'asset_cache_progress_engines':('const renderAssets685=','// v5.0.36'),
          'engine_actions':(" if(action==='render685-cancel')"," }if(action.startsWith('voice681-')")
        }
        for name,(start,end) in regions.items():
            section=lambda s:s[s.index(start):s.index(end,s.index(start))]
            assert section(after)==section(before),f'Changed render region: {name}'
            print(name,hashlib.sha256(section(after).encode()).hexdigest())
        java=sum(p.startswith('app/src/main/java/') and p.endswith('.java') for p in paths)
        workflows=sum(p.startswith('.github/workflows/') for p in paths)
        assert java and workflows
        b=baseline.read(prefix+'app/build.gradle').decode()
        a=(root/'app/build.gradle').read_text()
        assert a==b.replace('6.8.7','6.8.8').replace('6008008','6008009')
        print(f'{java} Java files, {workflows} workflows and four render regions are byte-identical')
