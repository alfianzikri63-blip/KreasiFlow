"""Audit file and inline render checksums against the exact KF688 source package."""
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile
import difflib
import hashlib
import sys

root=Path(__file__).resolve().parents[1]
prefix=root.name+'/'
sha=lambda value:hashlib.sha256(value).hexdigest()
with ZipFile(sys.argv[1]) as outer,ZipFile(BytesIO(outer.read('KreasiFlow-Android-Update-V5-Source.zip'))) as base:
    paths=[n[len(prefix):] for n in base.namelist() if n.startswith(prefix) and not n.endswith('/')]
    current=lambda p:(root/p).read_bytes()
    first=lambda p:base.read(prefix+p)
    changes=[p for p in paths if current(p)!=first(p)]
    allowed={'app/build.gradle','app/src/main/assets/index.html','app/src/main/assets/content-accuracy-688.js',
        'app/src/main/java/id/kreasiflow/studio/GeminiApi.java'}
    assert not {p for p in changes if not p.startswith('tests/')}-allowed,changes
    gemini='app/src/main/java/id/kreasiflow/studio/GeminiApi.java'
    def isolate_provider(s):
        return s[:s.index(b'    static String fastText(')]+s[s.index(b'    static JSONObject creativePhoto'):]
    assert isolate_provider(current(gemini))==isolate_provider(first(gemini))
    print('GeminiApi diff is limited to fastText (AI URL retrieval):',
          sum(line.startswith(('+','-')) for line in difflib.unified_diff(first(gemini).decode().splitlines(),current(gemini).decode().splitlines())))
    render_java=[p for p in paths if p.startswith('app/src/main/java/') and p.endswith('.java') and p!=gemini]
    for p in render_java:assert sha(current(p))==sha(first(p)),p
    print(f'{len(render_java)} Java files outside GeminiApi, plus all render modules and CSS assets: identical')
    path='app/src/main/assets/index.html'
    regions={
      'settings_mixer_render_ui':('function nativeTransitionMode()','function providerStatus()'),
      'canvas_and_preview':('function loadSceneImages()','async function prepareVideoInput('),
      'asset_cache_progress_engines':('const renderAssets685=','// v5.0.36'),
      'engine_actions':(" if(action==='render685-cancel')"," }if(action.startsWith('voice681-')"),
      'timeline':('function timelineKey681()','async function productionCheck('),
      'subtitle_payload':('function subtitleForRender()','function wireSubtitlePlayer(')
    }
    for name,(a,b) in regions.items():
        def section(raw):
            start=raw.index(a.encode())
            return raw[start:raw.index(b.encode(),start)]
        s,t=section(first(path)),section(current(path))
        assert sha(s)==sha(t) and not list(difflib.unified_diff(s.decode().splitlines(),t.decode().splitlines())),name
        print(name,sha(t))
    p='app/build.gradle'
    assert current(p)==first(p).replace(b'6.8.8',b'6.8.9').replace(b'6008009',b'6008010')
    assert all(current(p)==first(p) for p in paths if p.startswith('.github/workflows/'))
    print('Signing and GitHub Actions unchanged. Release version is 6.8.9 / 6008010.')
