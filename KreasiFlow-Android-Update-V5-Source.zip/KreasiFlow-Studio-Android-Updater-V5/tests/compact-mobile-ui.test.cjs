const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const H=fs.readFileSync('app/src/main/assets/index.html','utf8');
const J=fs.readFileSync('app/src/main/java/id/kreasiflow/studio/MainActivity.java','utf8');
const G=fs.readFileSync('app/build.gradle','utf8');
test('one navigation header with no duplicate native provider shortcut carousel',()=>{
 assert.doesNotMatch(J,/HorizontalScrollView shortcuts=new HorizontalScrollView/);
 assert.doesNotMatch(J,/links.addView\(button\("✦ Gemini"/);
 assert.match(H,/title="Pengaturan"/);
 assert.match(H,/data-action="history"/);
 assert.match(H,/data-action="open-flow"/);
 assert.doesNotMatch(H,/class="statusbar"/);
});
test('four thumb-friendly tabs and production advanced options remain accessible',()=>{
 for(const x of ['Mulai','Audio','Scene','Render'])assert.ok(H.includes('</em> '+x+'</button>'),x);
 assert.match(H,/class="kf-advanced"/);
 assert.doesNotMatch(H,/data-field="autoImageCount"/);
 assert.match(H,/Opsi AI/);
 assert.match(H,/case 'quick-menu':showQuickMenu\(\)/);
 assert.match(H,/case 'open-flow':openUrl\(H.flow\)/);
});
test('project actions and update remain reachable in compact navigation',()=>{
 assert.match(H,/data-action="save"/);assert.match(H,/data-action="new"/);
 for(const action of ['history','cloud-account','export-project','project-import-zip','settings','check-app-update'])assert.ok(H.includes("btn('"+action+"'"),action);
 assert.match(J,/@JavascriptInterface public void checkAppUpdate\(\)/);
 assert.match(J,/updater\.checkManually\(\)/);
});
test('progress and long-running features remain intact',()=>{
 for(const x of ['operationProgressPinned','autoProgressPinned','storyboard-ai','sheet-generate','subtitle-ai','render-video','project-import-zip'])assert.ok(H.includes(x),x);
 assert.match(H,/const shown=tasks.length\?tasks.slice\(-2\):completed.slice\(-1\)/);
 assert.match(G,/5\.0\.59/);
});
