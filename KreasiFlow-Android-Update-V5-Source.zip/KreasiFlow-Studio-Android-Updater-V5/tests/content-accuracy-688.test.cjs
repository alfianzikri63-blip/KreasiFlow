const test=require('node:test');
const assert=require('node:assert/strict');
const A=require('../app/src/main/assets/content-accuracy-688.js');
const fixtures=require('./fixtures/content-accuracy-688.json');
for(const fixture of fixtures){
 test('title intent and fixture: '+fixture.title,()=>{
  const plan=A.intent(fixture.title);
  assert.equal(plan.type,fixture.type);
  assert.match(A.instruction(plan),/Tema acak, genre, visual, director dan gaya tutur tidak boleh mengubah/);
  const response=A.validate(fixture.reply,plan);
  assert.ok(response.ok,response.error);
  assert.match(response.warnings.join(' '),/perlu verifikasi/);
  if(!plan.count)return;
  assert.equal(response.items.length,plan.count);
  for(const name of response.items)assert.ok(response.text.includes(name));
  assert.equal(new Set(response.items).size,plan.count);
  const assembled=structuredClone(fixture.reply);
  const chunks=[{voice:assembled.opening},...assembled.items.map(x=>({voice:x.name+'. '+x.detail})),{voice:assembled.closing}];
  assert.deepEqual(A.align(response.text,chunks,response.items,response.ending),[[],...response.items.map(x=>[x]),[]]);
 });
}
test('missing, duplicate, generic or cross-item response is refused',()=>{
 const {title,reply}=fixtures[0],cfg=A.intent(title);
 for(const alter of [
  r=>r.items.pop(),
  r=>{r.items[1].name='Stadion Wembley (London)';},
  r=>{r.items[0].name='Stadion A';},
  r=>{r.items[0].detail+=' Kemudian bandingkan dengan Maracanã.';},
  r=>{r.items[0].detail='Seekor kucing melompat ke atas perabot.';r.items[0].name='Kucing';}
 ]){
  const raw=structuredClone(reply);alter(raw);
  assert.equal(A.validate(raw,cfg).ok,false);
 }
});
test('false source and claim categories are guarded',()=>{
 const {title,reply}=fixtures[0],plan=A.intent(title);
 for(const phrase of [' Ini peringkat resmi.',' Lihat https://contoh.invalid.',' Ada arwah gentayangan yang datang.']){
  const data={...reply,closing:reply.closing+phrase};
  assert.equal(A.validate(data,plan).ok,false);
 }
 assert.equal(A.validate({...reply,closing:reply.closing+' Ini bukan peringkat resmi.'},plan).ok,true);
});
test('process needs explanation, contrast needs both subjects',()=>{
 assert.equal(A.validate('Bor listrik merupakan barang menarik. Barang ini sangat menarik bagi para penonton.',A.intent(fixtures[3].title)).ok,false);
 assert.equal(A.validate('Kucing ada di rumah. Hewan ini memiliki kaki dan ekor.',A.intent('Kucing vs Anjing')).ok,false);
 assert.equal(A.intent('10.000 Orang dalam Stadion').count,0);
 assert.equal(A.intent('5G Bagaimana Cara Kerjanya').count,0);
 assert.equal(A.intent('Lima Teknologi Masa Depan').count,5);
});
test('scene rejects contamination and injects exact subject into both prompt types',()=>{
 const row={scene:2,action:'Reveal the arch over the pitch.',image_prompt:'Wide daytime shot.',video_prompt:'Pan over the pitch.'};
 const names=['Wembley Stadium','Maracanã'];
 const locked=A.lockRow(row,[names[0]],names);
 assert.ok(locked.action.includes(names[0])&&locked.image_prompt.includes(names[0])&&locked.video_prompt.includes(names[0]));
 assert.throws(()=>A.lockRow({...row,video_prompt:'Cut to Maracanã.'},[names[0]],names),/luar urutan/);
 assert.match(A.lockRow(row,names,names).video_prompt,/Wembley Stadium → Maracanã/);
});
