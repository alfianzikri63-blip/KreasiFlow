const test=require('node:test');
const assert=require('node:assert/strict');
const A=require('../app/src/main/assets/content-accuracy-688.js');
const old=require('./fixtures/content-accuracy-688.json');
const titles=[
 ['5 Stadion Termegah di Dunia','list'],['7 Hewan Tercepat di Dunia','list'],['10 Bangunan Tertinggi di Dunia','list'],
 ['Bagaimana Bor Listrik Bekerja?','mechanism'],['Bagaimana Mesin Mobil Bekerja?','mechanism'],
 ['Bagaimana Black Hole Terbentuk?','science'],['Bagaimana Luka pada Kulit Sembuh?','science'],
 ['Reka Ulang Adegan Tanjiro vs Akaza','recreation'],['Reka Ulang Pertarungan Naruto vs Pain','recreation'],
 ['Alur Cerita Demon Slayer','recap'],['Mengapa Gojo Sangat Kuat?','character'],
 ['Bagaimana Jika Luffy Menjadi Angkatan Laut?','whatif'],['Perbandingan Mesin Diesel dan Mesin Bensin','comparison'],
 ['Misteri di Balik Piramida Mesir','mystery'],['Petualangan Dua Anak di Hutan','story']
];
for(const [title,type] of titles)test('intent local: '+title,()=>{
 const plan=A.planDirector(title);
 assert.equal(plan.type,type);
 assert.equal(plan.manual,'auto');
 assert.deepEqual(plan.conflict,[]);
 assert.ok(plan.rule.length>12);
});
for(const type of Object.keys(A.types).slice(1,14))test('manual selector retains '+type,()=>{
 const plan=A.planDirector('Kapal di samudra',{mode:type});
 assert.equal(plan.type,type);
 assert.deepEqual(plan.conflict,[]);
 const broad=A.planDirector('5 Stadion Termegah di Dunia',{mode:type});
 assert.equal(broad.conflict.length>0,!['list','ranking'].includes(type));
});
test('rank structure, count and compatible scopes',()=>{
 assert.equal(A.planDirector('Top 5 Stadion Termegah di Dunia').type,'ranking');
 assert.equal(A.planDirector('Top 5 Stadion Termegah di Dunia').count,5);
 assert.equal(A.planDirector('Bangunan Dunia',{mode:'ranking',fields:{Count:'7',Criteria:'Ketinggian',Order:'Menurun'}}).count,7);
 assert.match(A.planDirector('5 Stadion Termegah di Dunia',{mode:'list',fields:{Count:'3'}}).conflict[0],/5/);
 assert.equal(A.planDirector('Bagaimana Bor Listrik Bekerja?',{mode:'mechanism',fields:{Subject:'Bor tangan',Parts:'motor',Stages:'daya ke mata bor',Depth:'ringkas'}}).details.Parts,'motor');
});
test('out-of-scope input is excluded from plan and title-owned count remains stable',()=>{
 const plan=A.planDirector('5 Stadion Termegah di Dunia',{fields:{Work:'Bocoran episode',Count:'5',Criteria:'Bentuk atap'}});
 assert.deepEqual(plan.details,{Count:'5',Criteria:'Bentuk atap'});
 assert.equal(plan.fidelity,'');
 assert.match(A.contentPrompt(plan),/Bentuk atap/);
 assert.doesNotMatch(A.contentPrompt(plan),/Bocoran episode/);
});
const recreation={
 opening:'Tanjiro bertemu Akaza di ruang pertarungan.',
 work:'Demon Slayer',scope:'Cakupan uji',
 beats:[
 {stage:'setup',narration:'Tanjiro melihat Akaza berdiri di ruang pertarungan.',action:'Tanjiro enters',characters:['Tanjiro','Akaza'],location:'Ruang pertarungan'},
 {stage:'conflict',narration:'Akaza mendekat sementara Tanjiro mengubah posisi bertahan.',action:'Akaza approaches',characters:['Akaza','Tanjiro'],location:'Ruang pertarungan'},
 {stage:'climax',narration:'Tanjiro menahan serangan Akaza sebelum mundur satu langkah.',action:'Tanjiro steps back',characters:['Tanjiro','Akaza'],location:'Ruang pertarungan'},
 {stage:'outcome',narration:'Akaza berhenti bergerak dan Tanjiro menurunkan pedangnya.',action:'Akaza stops',characters:['Tanjiro','Akaza'],location:'Ruang pertarungan'}],
 closing:'Adegan berakhir pada batas kronologi yang ditentukan.',
 objects:[{name:'Tanjiro',kind:'Karakter fiksi',visual:'Kostum dari referensi fixture'},{name:'Akaza',kind:'Karakter fiksi'}],
 verify:['Fixture struktur; bukan cuplikan kanon.']
};
test('source clarification, canon fidelity, action sequence and no invented attribution',()=>{
 const plan=A.planDirector(titles[7][0]);
 assert.equal(plan.fidelity,'canon');
 assert.deepEqual(plan.characters,['Tanjiro','Akaza']);
 assert.deepEqual(A.validate({clarify:['Versi A','Versi B']},plan).choices,['Versi A','Versi B']);
 const correct=A.validate(recreation,plan);
 assert.ok(correct.ok,correct.error);
 const outOfOrder=structuredClone(recreation);
 [outOfOrder.beats[1],outOfOrder.beats[2]]=[outOfOrder.beats[2],outOfOrder.beats[1]];
 assert.match(A.validate(outOfOrder,plan).error,/berurutan/);
 assert.match(A.validate(recreation,A.planDirector(titles[7][0],{fields:{Work:'Karya lain'}})).error,/berbeda/);
 assert.equal(A.planDirector(titles[9][0]).fidelity,'canon');
 assert.match(A.validate(recreation,A.planDirector(titles[7][0],{fidelity:'adaptation'})).error,/adaptasi/);
});
test('alternate fiction is separated from actual sources',()=>{
 const plan=A.planDirector(titles[11][0]);
 assert.equal(plan.fidelity,'alternative');
 assert.match(A.contentPrompt(plan),/hipotetis/);
 const value={...recreation,opening:'Dalam versi alternatif, Luffy menjadi anggota Angkatan Laut.',beats:[
  {stage:'awal',narration:'Luffy memilih pergi bersama pelaut sejak awal.'},
  {stage:'konsekuensi',narration:'Keputusan Luffy mengubah hubungan dengan teman lamanya.'},
  {stage:'hasil',narration:'Dalam skenario ini Luffy akhirnya bertemu mereka sebagai lawan.'}
 ]};
 assert.equal(A.validate(value,plan).reference.label,'Fiksi atau adaptasi');
 value.opening='Luffy menjadi anggota Angkatan Laut pada pagi hari.';
 assert.match(A.validate(value,plan).error,/alternatif/);
});
test('reference URL evidence must be successful and belong to the current request',()=>{
 const url='https://example.org/ref';
 const plan=A.planDirector(titles[3][0]);
 const bad=A.referenceStatus(url,plan,[{retrievedUrl:url,urlRetrievalStatus:'URL_RETRIEVAL_STATUS_ERROR'}]);
 assert.equal(bad.label,'Belum terverifikasi');
 assert.equal(bad.external,false);
 assert.equal(A.referenceStatus('Kutipan pengguna '+url,plan,[]).label,'Berdasarkan referensi pengguna');
 const good=A.referenceStatus(url,plan,[{retrievedUrl:url,urlRetrievalStatus:'URL_RETRIEVAL_STATUS_SUCCESS'},{retrievedUrl:'https://elsewhere.example',urlRetrievalStatus:'URL_RETRIEVAL_STATUS_SUCCESS'}]);
 assert.deepEqual(good.checked,[url]);
 assert.equal(good.external,true);
});
test('word targets, low duration and title-shaped hooks',()=>{
 const plan=A.planDirector(old[0].title);
 assert.ok(A.targetWords(1,'English',plan,'science')>A.targetWords(1,'Indonesia',plan,'science'));
 assert.match(A.validate(old[0].reply,plan,{target:25}).warnings.join(' '),/sangat pendek/);
 assert.match(A.validate('Pernahkah Anda bertanya-tanya? '+old[3].reply,A.planDirector(old[3].title)).error,/klise/);
});
test('unknown titles can receive typed context from the single response',()=>{
 const plan=A.planDirector('Jembatan Suramadu');
 const result=A.validate({narration:'Jembatan Suramadu menghubungkan dua kawasan. Pembukaannya membawa perubahan pada jalur perjalanan masyarakat.',context:{type:'history'},differences:['Periksa tanggal pembukaan.']},plan);
 assert.equal(result.inferredByAI,true);
 assert.equal(result.resolvedType,'history');
 assert.match(result.warnings.join(' '),/Perbedaan sumber/);
});
test('scene reuses exact objects and current story phase',()=>{
 const plan=A.planDirector(titles[7][0]),saved=A.validate(recreation,plan);
 const rows=recreation.beats.map(b=>({voice:b.narration}));
 const locked=A.visualContext(saved.text,rows,saved,[]);
 assert.deepEqual(locked.map(x=>x.stage),['setup','conflict','climax','outcome']);
 assert.deepEqual(locked[1].objects.map(x=>x.name),['Tanjiro','Akaza','Ruang pertarungan']);
 assert.equal(locked[1].previous,'setup');
 assert.equal(locked[1].next,'climax');
 assert.match(A.contextualRow({action:'Use slow dolly.',image_prompt:'Wide shot',video_prompt:'Dolly'},locked[1]).image_prompt,/Tanjiro.*conflict/);
});
