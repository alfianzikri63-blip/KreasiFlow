const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const main = fs.readFileSync('app/src/main/assets/index.html','utf8');
const api = fs.readFileSync('app/src/main/java/id/kreasiflow/studio/GeminiApi.java','utf8');
const service = fs.readFileSync('app/src/main/java/id/kreasiflow/studio/AiForegroundService.java','utf8');
const gradle = fs.readFileSync('app/build.gradle','utf8');

test('storyboard Gemini has one 45s read-timeout request without nested retries',()=>{
 const start=api.indexOf('static String fastStoryboard(');
 const end=api.indexOf('    private static JSONObject image(',start);
 assert.ok(start>0 && end>start);
 const body=api.slice(start,end);
 assert.match(body,/gemini-3\.5-flash-lite:generateContent/);
 assert.match(body,/45000/);
 assert.match(body,/12000/);
 assert.doesNotMatch(body,/requestTextWithRetry/);
 assert.match(api,/setReadTimeout\(readTimeout\)/);
 assert.match(service,/GeminiApi\.fastStoryboard\(payload,key\)/);
 assert.match(service,/int attempts=1;/);
});
test('foreground service persists each batch and reports actual scene count',()=>{
 assert.match(service,/validateStoryboardJson\(body,indices\)/);
 assert.match(service,/completedScenes\+=indices==null\?0:indices\.length\(\)/);
 assert.match(service,/"Storyboard "\+completedScenes\+"\/"\+totalScenes\+" scene tersimpan"/);
 assert.match(service,/beralih ke AI cadangan/);
 assert.match(service,/kf-ai-storyboard-heartbeat/);
 assert.match(service,/menunggu "\+seconds\+" detik/);
 assert.match(service,/timed out\|timeout/);
});
test('14 scenes use 5 compact batches, each max 3 scenes, background service',()=>{
 const a=main.indexOf('function kfAiStoryboardJob(){');
 const b=main.indexOf('async function kfAiTranscriptionJob()',a);
 assert.ok(a>0 && b>a);
 const fragment=main.slice(a,b);
 let enqueued;
 const fakeRows=Array.from({length:14},(_,i)=>({voice:`narasi scene ${i+1}`}));
 const context={
  S:{duration:1,sceneEvery:4,audioDuration:52,openRouterModel:'openrouter/free',ratio:'9:16',sceneStyle:'2D Flat Vector Motion Graphic',character:''},
  storyboardProviders:()=>['gemini','openrouter'],textProvider:()=> 'gemini',notify:()=>{},getTopic:()=> 'Uji 14 adegan',
  showSettings:()=>{},scriptToNarration:()=> 'Sebuah narasi contoh',
  KreasiFlowScenePlanner:{plan:()=>fakeRows},movingClips:[],confirm:()=>true,
  storyboardGetCache:()=>({key:'demo',rows:{}}),
  KreasiFlowMotionStyles:{aiTextRule:()=> 'Pure 2D flat vector art'},
  kfAiStart:(job,meta)=>{enqueued={job,meta};return true;}
 };
 vm.runInNewContext(fragment,context);
 assert.equal(context.kfAiStoryboardJob(),true);
 assert.equal(enqueued.job.sceneCount,14);
 assert.equal(enqueued.job.batches.length,5);
 assert.deepEqual(Array.from(enqueued.job.batches,b=>Array.from(b.indices)),[[0,1,2],[3,4,5],[6,7,8],[9,10,11],[12,13]]);
 assert.ok(enqueued.job.batches.every(b=>b.prompt.includes('Return ONLY compact JSON')));
});
test('release APK version bumped with same package and signing config',()=>{
 assert.match(gradle,/5\.1\.0/);
 assert.match(gradle,/5001000/);
 assert.match(gradle,/applicationId 'id\.kreasiflow\.studio'/);
 assert.match(gradle,/signingConfig signingConfigs\.publishedRelease/);
});
