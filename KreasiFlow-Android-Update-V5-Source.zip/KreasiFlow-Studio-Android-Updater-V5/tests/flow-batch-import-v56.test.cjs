const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const clips=require('../app/src/main/assets/flow-batch-import.js');
const file=(name,size=4*1024*1024,type='video/mp4')=>({name,size,type});

test('extract scene numbers using names common in Flow downloads',()=>{
 for(const [name,n] of [['Scene_01.mp4',1],['scene-010_take-2.mp4',10],['KreasiFlow SCENE 2.mp4',2],['clip 7 final.mp4',7],['S01.mp4',1],['12-test.mp4',12],['20261122-test.mp4',null],['Flow-video.mp4',null]]){
  assert.equal(clips.sceneNumber(name),n,name);
 }
});
test('numbered clips assign exact scene independent of selection order',()=>{
 const result=clips.plan([file('Scene-10.mp4'),file('Scene-02.mp4'),file('Scene-01.mp4')],14);
 assert.equal(result.mode,'numbered');assert.deepEqual(result.items.map(x=>x.scene),[1,2,10]);
 assert.deepEqual(result.items.map(x=>x.file.name),['Scene-01.mp4','Scene-02.mp4','Scene-10.mp4']);
});
test('can import numbered subset without overwriting earlier scene numbers',()=>{
 assert.deepEqual(clips.plan([file('SCENE-08.mp4'),file('SCENE-05.mp4')],14).items.map(x=>x.index),[4,7]);
});
test('unnumbered Flow filenames sort naturally (2 before 10)',()=>{
 const res=clips.plan([file('flow-video10.mp4'),file('flow-video2.mp4'),file('flow-video1.mp4')],5);
 assert.equal(res.mode,'sorted');assert.deepEqual(res.items.map(x=>x.file.name),['flow-video1.mp4','flow-video2.mp4','flow-video10.mp4']);
 assert.deepEqual(res.items.map(x=>x.index),[0,1,2]);
});
test('duplicate scene numbers refuse before any media transfer',()=>{
 assert.throws(()=>clips.plan([file('scene1.mp4'),file('scene_01 (copy).mp4')],4),/Nomor Scene 1/);
});
test('mixed explicit and implicit numbering refused',()=>{
 assert.throws(()=>clips.plan([file('Scene-01.mp4'),file('random video.mp4')],4),/bercampur/);
});
test('unavailable scene number refused',()=>{
 assert.throws(()=>clips.plan([file('Scene-15.mp4')],14),/14 scene/);
});
test('oversized, empty, wrong type, wrong extension rejected',()=>{
 for(const f of [file('Scene-01.mp4',0),file('Scene-01.mp4',251*1024*1024),file('Scene-01.mov'),file('Scene-01.mp4',1,'image/jpeg')]){
  assert.throws(()=>clips.plan([f],2));
 }
});
test('cannot choose clips without storyboard or more clips than scenes',()=>{
 assert.throws(()=>clips.plan([file('Scene-01.mp4')],0),/storyboard/);
 assert.throws(()=>clips.plan([file('Scene-01.mp4'),file('Scene-02.mp4')],1),/melebihi/);
});
test('UI has multi-file chooser, progress and existing single-scene backup',()=>{
 const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');
 assert.match(html,/id="flowBulkFiles"[^>]*multiple/);
 assert.match(html,/KFFlowBatchImport\.plan\(files,S\.scenes\.length\)/);
 assert.match(html,/trackOperation\('flow-bulk-import'/);
 assert.match(html,/kfSaveAssetsQueued\(\)/);
 assert.match(html,/data-flow-clip="\$\{i\}"/);
 assert.match(html,/movingClips\[index\]=\{id,url:URL\.createObjectURL\(file\)/);
});
