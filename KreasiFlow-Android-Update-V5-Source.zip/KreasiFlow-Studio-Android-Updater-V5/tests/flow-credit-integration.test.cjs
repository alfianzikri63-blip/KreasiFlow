const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const service=fs.readFileSync('app/src/main/java/id/kreasiflow/studio/RenderForegroundService.java','utf8');
test('default project uses image-first, with credit estimate and scene mode picker',()=>{
 assert.match(html,/flowCreditMode:'image-first'/);
 assert.match(html,/flowCreditPerVideo:30/);
 assert.match(html,/function flowSaverPanel/);
 assert.match(html,/KFFlowSaver\.summary/);
 assert.match(html,/data-flow-clip-mode/);
});
test('text-to-image is visible with manual handoff/upload/save controls',()=>{
 const card=html.slice(html.indexOf('function simpleFlowSceneCard'),html.indexOf('function renderScenes'));
 assert.match(card,/Prompt Text-to-Image/);
 for(const token of ['data-scene-file','data-copy-image-storyboard','data-save-scene-frame']) assert.ok(card.includes(token));
 assert.doesNotMatch(card,/data-generate-image/);
 assert.match(html,/case 'image-master-open'/);
 assert.match(html,/case 'image-master-copy'/);
});
test('image-to-video handoff blocks missing starting frame and never claims automatic upload',()=>{
 const f=html.slice(html.indexOf('async function prepareSceneForGoogleFlow'),html.indexOf('async function importFlowClip'));
 assert.match(f,/sceneMode==='image-first'&&!images\[i\]/);
 assert.match(f,/Unggah frame awal yang sama secara manual/);
});
test('local scenes are still images, with dedicated slideshow path for zero motion clips',()=>{
 const f=html.slice(html.indexOf('async function renderMovingVideo'),html.indexOf('window.__kreasiflowRenderProgress='));
 assert.match(f,/if\(!count\)\{if\(images\.some/);
 assert.match(f,/flowSceneMode\(S\.scenes\[i\]\)==='local'/);
 assert.match(service,/cfg\.scenes\.add\(new NativeVideoRenderer\.Scene/);
});
test('flow mode persists in storyboard revisions and legacy JSON import',()=>{
 assert.match(html,/flowClipMode:same\?\(old\?\.flowClipMode/);
 assert.match(html,/flowClipMode:same\?\(old\.flowClipMode/);
 assert.match(html,/flowClipMode:\['image-first','text-to-video','local'\]/);
});
