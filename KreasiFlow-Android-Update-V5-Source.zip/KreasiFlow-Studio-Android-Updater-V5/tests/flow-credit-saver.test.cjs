const test=require('node:test');
const assert=require('node:assert/strict');
const s=require('../app/src/main/assets/flow-credit-saver.js');
test('default uses image-first and local scene costs zero video credits',()=>{
  const sum=s.summary([{},{flowClipMode:'local'},{flowClipMode:'text-to-video'}],'image-first',30,1);
  assert.deepEqual([sum.imageFirst,sum.textToVideo,sum.local,sum.videoCount,sum.credits],[1,1,1,2,60]);
});
test('short image prompt locks first frame and no speech',()=>{
  const p=s.imageToVideoPrompt({index:1,duration:8,ratio:'9:16',style:'2D Flat Vector Motion Graphic',character:'ASAQ navy bear hat',action:'ASAQ ducks behind crater rocks while blue flames rise',camera:'Slow upward tilt'});
  assert.match(p,/uploaded first-frame image/);assert.match(p,/ASAQ navy bear hat/);assert.match(p,/no 3D/i);assert.match(p,/no speech/i);assert.ok(p.split(/\s+/).length<100);
});
test('estimated credits follow editable rate and number of outputs',()=>{
  assert.equal(s.summary([{},{}],'image-first',8,2).credits,32);
  assert.equal(s.summary([{flowClipMode:'local'}],'image-first',30,1).credits,0);
});
test('fallback mode on unrecognized input remains image-first',()=>{
  assert.equal(s.mode({flowClipMode:'other'},'other'),'image-first');
});
