const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const shots=require('../app/src/main/assets/flow-shot-planner.js');
const index=fs.readFileSync('app/src/main/assets/index.html','utf8');
const narration=[
 'Karakter putih membuka pintu microwave di atas meja dapur.',
 'Kemudian dia memasukkan segelas air ke dalam microwave.',
 'Dia menekan tombol start dan microwave menyala.',
 'Setelah selesai, karakter mengeluarkan gelas dari microwave.',
 'Sekarang ia menuangkan air ke dalam gelas lain.',
 'Terakhir ia memasukkan es batu ke gelas.'
];
test('six sequential kitchen scenes have distinct grounded events and camera compositions',()=>{
 const plans=shots.all(narration);
 assert.deepEqual(plans.map(x=>x.id.split('-').slice(0,-1).join('-')),['microwave-open','microwave-insert','microwave-switch','microwave-out','pour','ice']);
 assert.equal(new Set(plans.map(x=>x.camera)).size,plans.length);
 assert.equal(new Set(plans.map(x=>x.action)).size,plans.length);
 assert.ok(plans.every((x,i)=>x.action.includes(narration[i])));
});
test('split narration fragments inherit complete sentence but show different stages',()=>{
 const inputs=['Seorang tokoh membuka','pintu microwave di dapur.','Tokoh itu memasukkan','segelas air ke dalam microwave.'];
 const plan=shots.all(inputs);
 assert.ok(plan[0].id.startsWith('microwave-open'));
 assert.ok(plan[1].id.startsWith('microwave-open'));
 assert.match(plan[0].action,/FIRST STAGE ONLY/);
 assert.match(plan[1].action,/FINAL STAGE ONLY/);
 assert.match(plan[1].action,/Seorang tokoh membuka pintu microwave di dapur/);
 assert.notEqual(plan[0].action,plan[1].action);
});
test('all text-to-video prompts use the specific shot planner by default',()=>{
 const start=index.indexOf('function googleFlowPrompt(i){');
 const end=index.indexOf('function simpleFlowSceneCard',start);
 const code=index.slice(start,end);
 assert.ok(start>0);
 assert.match(code,/KreasiFlowFlowShots\.makeShot/);
 assert.match(code,/UNIQUE VISIBLE EVENT IN THIS SCENE/);
 assert.match(code,/SHOT COMPOSITION AND CAMERA/);
 assert.match(code,/no English\/Indonesian speech/);
 assert.doesNotMatch(code,/Show the event represented by this narration as one clear animated action/);
 assert.match(index,/<script src="flow-shot-planner\.js"><\/script>/);
});
test('source preserves edited prompts and offers AI scene differentiation + reset',()=>{
 assert.match(index,/case 'flow-ai-distinct'/);
 assert.match(index,/case 'flow-reset-prompts'/);
 assert.match(index,/if\(String\(sc\.flowPromptOverride\|\|''\)\.trim\(\)\)return sc\.flowPromptOverride/);
 assert.match(index,/sc\.flowShot=\{/);
 assert.match(index,/MP4 hasil impor tidak dihapus/);
});
