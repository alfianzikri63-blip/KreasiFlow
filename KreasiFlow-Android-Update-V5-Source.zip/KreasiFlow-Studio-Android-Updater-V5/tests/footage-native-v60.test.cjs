const test=require('node:test');const assert=require('node:assert/strict');const fs=require('fs');const path=require('path');
const base=path.join(__dirname,'..');const audit=require('../app/src/main/assets/flow-footage-audit.js');
const page=fs.readFileSync(path.join(base,'app/src/main/assets/index.html'),'utf8');
const main=fs.readFileSync(path.join(base,'app/src/main/java/id/kreasiflow/studio/MainActivity.java'),'utf8');
const inspector=fs.readFileSync(path.join(base,'app/src/main/java/id/kreasiflow/studio/FlowVideoInspector.java'),'utf8');
test('MP4 imported natively remains eligible for audit even without WebView URL',()=>{
 assert.match(page,/movingClips\.map\(\(c,i\)=>c\?\.id\|\|c\?\.url\?i:-1\)/);
 assert.match(page,/nativeVideoFingerprints\(clip\.id\)/);
});
test('Java bridge fingerprints stored asset on worker and resolves asynchronously',()=>{
 assert.match(main,/@JavascriptInterface public void requestFlowClipFingerprint/);
 assert.match(main,/apiPool\.execute\(\(\)->/);
 assert.match(main,/FlowVideoInspector\.fingerprint\(video\)/);
 assert.match(inspector,/getScaledFrameAtTime/);
 assert.match(inspector,/OPTION_CLOSEST/);
});
test('dHash comparisons find identical and ignore low-detail scene',()=>{
 const a='0'.repeat(64),b='1'.repeat(64);
 const r=audit.analyse([{scene:1,hashes:[a,a]},{scene:2,hashes:[a,a]},{scene:3,hashes:[b,b],lowDetail:true}]);
 assert.equal(r.suspects.length,1);assert.deepEqual([r.suspects[0].a,r.suspects[0].b],[1,2]);
 assert.deepEqual(r.lowDetail,[3]);assert.equal(r.comparable,2);
});
test('invalid frame hashes cannot be considered similarity evidence',()=>{
 const r=audit.analyse([{scene:1,hashes:['','']},{scene:2,hashes:['0'.repeat(64),'0'.repeat(64)]}]);
 assert.equal(r.suspects.length,0);assert.equal(r.comparable,1);
 assert.throws(()=>audit.distance('short','0'.repeat(64)));
});
