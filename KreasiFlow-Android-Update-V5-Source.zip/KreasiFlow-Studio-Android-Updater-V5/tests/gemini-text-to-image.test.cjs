const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const sheet=require('../app/src/main/assets/storyboard-sheet.js');
const java=fs.readFileSync('app/src/main/java/id/kreasiflow/studio/GeminiApi.java','utf8');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');

test('Gemini image accepts longer multi-scene prompts and does not silently truncate them',()=>{
 assert.match(java,/prompt\.length\(\)>60000/);
 assert.doesNotMatch(java,/prompt\.length\(\)>3000/);
 assert.match(java,/\.put\("text",prompt\)/);
 assert.match(java,/gemini-3\.1-flash-lite-image/);
});
test('Gemini image requests explicit response_format, MIME, valid ratio, and 1K lite image size',()=>{
 for(const part of ['.put("response_format",format)', '.put("type","image")', '.put("aspect_ratio",aspect)', '.put("image_size","1K")', '.put("mime_type","image/jpeg")'])assert.ok(java.includes(part),part);
});
test('scene image request includes selected 9:16 or 16:9 ratio',()=>{
 assert.match(html,/const ratio=S\.ratio\.startsWith\('9:16'\)\?'9:16':'16:9'/);
 assert.match(html,/provider==='gemini'\?\{op:'image',prompt:.*aspect_ratio:ratio\}/);
});
test('contact sheet aspect ratio respects grid layout and selected scene ratio',()=>{
 assert.equal(sheet.aspectRatio(14,'auto','9:16'), '9:16');
 assert.equal(sheet.aspectRatio(7,'auto','9:16'), '5:4');
 assert.equal(sheet.aspectRatio(1,'auto','16:9'), '16:9');
 assert.match(html,/aspect_ratio:KFStoryboardSheet\.aspectRatio\(S\.scenes\.length,S\.storyboardSheetColumns,S\.ratio\)/);
});
test('native parser accepts output_image and steps, and error messages separate Gemini from Cloudflare',()=>{
 assert.match(java,/root\.optJSONObject\("output_"\+type\)/);
 assert.match(java,/JSONArray steps=root\.optJSONArray\("steps"\)/);
 assert.match(html,/function showGeminiImageQuotaHelp/);
 assert.match(html,/if\(imageProvider\(\)==='gemini'\)/);
 assert.match(html,/case 'test-gemini-image':return await testGeminiImage/);
});
test('test image asks consent, requests only one image, and does not overwrite scene images',()=>{
 assert.match(html,/if\(!confirm\('Tes membuat SATU gambar Gemini/);
 assert.match(html,/op:'image',aspect_ratio:'9:16',prompt:'Create one simple photo/);
 assert.match(html,/Gambar tes ini tidak mengganti frame scene/);
});
