"""Validate full duration and decoded frame count of an exported video."""
import argparse
import json
from pathlib import Path
import subprocess

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('file',type=Path)
parser.add_argument('--frames',type=int,required=True)
parser.add_argument('--fps',type=float,required=True)
parser.add_argument('--audio',action='store_true')
args=parser.parse_args()
payload=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams',
    '-show_format','-of','json',str(args.file)]))
video=next((track for track in payload['streams'] if track['codec_type']=='video'),{})
audio=next((track for track in payload['streams'] if track['codec_type']=='audio'),{})
result={
    'videoFrames':int(video.get('nb_read_frames',0)), 'videoSeconds':float(video.get('duration',0)),
    'expectedSeconds':args.frames/args.fps, 'size':args.file.stat().st_size,
    'width':video.get('width'), 'height':video.get('height'), 'bitrate':video.get('bit_rate'),
    'videoCodec':video.get('codec_name'), 'audioCodec':audio.get('codec_name')
}
print(json.dumps(result,indent=2))
if result['videoFrames']!=args.frames or abs(result['videoSeconds']-result['expectedSeconds'])>max(.060,2/args.fps):
    raise SystemExit('Trek video tidak utuh.')
if args.audio and (not audio or int(audio.get('nb_read_frames','0'))<=0):
    raise SystemExit('Trek audio tidak dapat didekode.')
