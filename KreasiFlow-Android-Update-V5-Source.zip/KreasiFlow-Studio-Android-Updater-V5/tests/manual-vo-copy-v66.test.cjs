const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');const vm=require('node:vm');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const card=html.slice(html.indexOf('function simpleFlowSceneCard('),html.indexOf('function renderScenes('));
test('image-first card exposes copy-only T2I and I2V, while text-to-video remains unchanged',()=>{
 const ctx={S:{sceneEvery:4,flowI2VDuration:'4'},movingClips:[],Number,Math,esc:x=>String(x??''),KFFlowSaver:{duration:()=>4},flowSceneMode:s=>s.mode,googleFlowPrompt:()=> 'locked I2V prompt',sceneUiIsOpen:()=>true,sceneDifferenceHint:()=>'',flowModeOptions:()=>'',window:{}};
 vm.createContext(ctx);vm.runInContext(card,ctx);
 const out=ctx.simpleFlowSceneCard({mode:'image-first',prompt:'T2I scene'},0);
 assert.match(out,/data-copy-image-storyboard="0"/);assert.match(out,/data-flow-video-copy="0"/);assert.match(out,/locked I2V prompt/);assert.doesNotMatch(out,/data-flow-scene=|data-flow-image-scene=|Salin prompt video & buka Flow/);
 const t=ctx.simpleFlowSceneCard({mode:'text-to-video'},0);assert.match(t,/data-flow-scene="0"/);assert.doesNotMatch(t,/data-flow-video-copy=/);
});
test('copy handlers copy exact current prompt and never open a website',async()=>{
 for(const [key,expected] of [['copyImageStoryboard','T2I: 2'],['flowVideoCopy','I2V: 2']]){
  const start=html.indexOf('if(b.dataset.'+key+'!==undefined)');assert.ok(start>=0);const end=html.indexOf('return}',start)+7;const handler=html.slice(start,end);let copied=[];
  const ctx={b:{dataset:{[key]:'2'}},e:{preventDefault(){}},Number,copy:async x=>copied.push(x),flowDirectSceneImagePrompt:i=>'T2I: '+i,googleFlowPrompt:i=>'I2V: '+i,notify:()=>{},openUrl:()=>{throw Error('Unexpected browser navigation')}};
  vm.createContext(ctx);await vm.runInContext('(async()=>{'+handler+'})()',ctx);assert.deepEqual(copied,[expected]);
 }
});
