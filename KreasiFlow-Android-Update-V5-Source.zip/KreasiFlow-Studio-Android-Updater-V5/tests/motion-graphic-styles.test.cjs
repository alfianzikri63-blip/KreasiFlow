const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const Motion=require('../app/src/main/assets/motion-graphic-styles.js');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const listed=['Motion Graphic 2D','Motion Graphic 3D','Motion Graphic Edukasi','Kinetic Typography'];
test('exactly four distinctive motion styles and all have meaningful locked style bibles',()=>{
 assert.deepEqual(Motion.names(),listed);
 for(const name of listed){
  assert.ok(Motion.isMotion(name));
  assert.match(Motion.rule(name),/MOTION GRAPHIC STYLE LOCK/);
  assert.match(Motion.rule(name),/CONTINUITY/);
  assert.ok(Motion.get(name).bible.length>160);
  assert.ok(html.includes("['"+name+"'"));
 }
 assert.equal(Motion.isMotion('Stickman Putih'),false);
 assert.equal(Motion.rule('Stickman Putih'),'');
});
test('2D, 3D, educational, and typography have specific noninterchangeable directions',()=>{
 assert.match(Motion.rule('Motion Graphic 2D'),/Strictly 2D/);
 assert.match(Motion.rule('Motion Graphic 3D'),/material|3D rotations/);
 assert.match(Motion.rule('Motion Graphic Edukasi'),/cause-and-effect|flow path/);
 assert.match(Motion.rule('Kinetic Typography'),/letterforms|tracking/);
 assert.equal(Motion.isTypography('Kinetic Typography'),true);
 assert.equal(Motion.isTypography('Motion Graphic 2D'),false);
});
test('styles are wired into storyboard requests, flow prompts, prompt refinements and both style selectors',()=>{
 assert.match(html,/script src="motion-graphic-styles\.js"/);
 assert.match(html,/GLOBAL MOTION GRAPHIC VISUAL BIBLE: \$\{motionStyleRule\(\)\}/);
 assert.match(html,/style_bible:KreasiFlowMotionStyles\.aiTextRule/);
 assert.match(html,/MOTION STYLE LOCK: \$\{motionStyleRule\(\)/);
 assert.ok((html.match(/motionStyleHint\(\)/g)||[]).length>=3);
 assert.match(html,/storyboard-ai-storyboard-cache-v5041|kreasiflow-ai-storyboard-cache-v5041/);
});
test('existing characters and difference checks remain available',()=>{
 assert.match(html,/S\.character/);
 assert.match(html,/function sceneDifferencePanel\(/);
 assert.match(html,/function googleFlowPrompt\(/);
 assert.match(html,/KreasiFlowSceneDifference\.audit/);
 assert.match(html,/transcriptionProvider/);
});
test('generated Flow prompt actually carries fixed 2D motion language and character identity',()=>{
 const vm=require('node:vm');
 const start=html.indexOf('function googleFlowPrompt(i)');
 const end=html.indexOf('function simpleFlowSceneCard',start);
 const ctx={
  S:{scenes:[{name:'ASAQ di lereng',voice:'ASAQ berjalan mendekati kawah',prompt:'ASAQ on rock',videoPrompt:'ASAQ crouches',flowShot:{action:'ASAQ crouches behind the crater',camera:'Low-angle tilt up',setting:'Rocky volcanic crater'}}],sceneEvery:10,ratio:'9:16 Shorts/Reels',sceneStyle:'Motion Graphic 2D',character:'ASAQ chibi boy, navy bear ears hat, brown striped shirt',flowTextMode:false,toonMode:false,edu3DMode:false},
  KreasiFlowFlowShots:{makeShot:(_,__,custom)=>custom},
  motionStyleRule:()=>Motion.rule(ctx.S.sceneStyle),
  KreasiFlowMotionStyles:Motion
 };
 vm.createContext(ctx);
 vm.runInContext(html.slice(start,end),ctx);
 const prompt=ctx.googleFlowPrompt(0);
 assert.match(prompt,/ASAQ chibi boy/);
 assert.match(prompt,/GLOBAL MOTION GRAPHIC VISUAL BIBLE:/);
 assert.match(prompt,/Strictly 2D/);
 assert.match(prompt,/SCENE 1\/1/);
 assert.match(prompt,/Do not invent visual text/);
 ctx.S.sceneStyle='Motion Graphic 3D';
 assert.match(ctx.googleFlowPrompt(0),/3D rotations/);
 assert.doesNotMatch(ctx.googleFlowPrompt(0),/Strictly 2D/);
 ctx.S.sceneStyle='Kinetic Typography';
 assert.match(ctx.googleFlowPrompt(0),/one or two short exact design keywords/);
 assert.match(ctx.googleFlowPrompt(0),/No subtitles/);
});
test('all 51 style names are available in source after upgrade',()=>{
 const vm=require('node:vm');
 const begin=html.indexOf('const visualStyles=');
 const end=html.indexOf(';\n',begin);
 const entries=vm.runInNewContext(html.slice(begin,end)+';visualStyles');
 assert.equal(entries.length,51);
 assert.ok(entries.every(x=>x.length===3));
 assert.equal(new Set(entries.map(x=>x[0])).size,51);
});
