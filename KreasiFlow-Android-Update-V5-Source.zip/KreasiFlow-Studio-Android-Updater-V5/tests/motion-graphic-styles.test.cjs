const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const Motion=require('../app/src/main/assets/motion-graphic-styles.js');
const Saver=require('../app/src/main/assets/flow-credit-saver.js');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const listed=['2D Flat Vector Motion Graphic','Motion Graphic 2D','Motion Graphic 3D','Motion Graphic Edukasi','Kinetic Typography'];
test('five distinctive motion styles and all have meaningful locked style bibles',()=>{
 assert.deepEqual(Motion.names().slice(0,5),listed);
 for(const name of listed){
  assert.ok(Motion.isMotion(name));
  assert.match(Motion.rule(name),/MOTION GRAPHIC STYLE LOCK/);
  assert.match(Motion.rule(name),/CONTINUITY/);
  assert.ok(Motion.get(name).bible.length>160);
  assert.ok(html.includes("['"+name+"'"));
 }
 assert.equal(Motion.isMotion('Stickman Putih'),false);
 assert.equal(Motion.rule('Stickman Putih'),'');
});
test('2D, 3D, educational, and typography have specific noninterchangeable directions',()=>{
 assert.match(Motion.rule('Motion Graphic 2D'),/Strictly 2D/);
 assert.match(Motion.rule('Motion Graphic 3D'),/material|3D rotations/);
 assert.match(Motion.rule('Motion Graphic Edukasi'),/cause-and-effect|flow path/);
 assert.match(Motion.rule('Kinetic Typography'),/letterforms|tracking/);
 assert.equal(Motion.isTypography('Kinetic Typography'),true);
 assert.equal(Motion.isTypography('Motion Graphic 2D'),false);
 assert.equal(Motion.isTypography('2D Flat Vector Motion Graphic'),false);
 assert.match(Motion.rule('2D Flat Vector Motion Graphic'),/STRICT NO-3D RULE/);
 assert.match(Motion.rule('2D Flat Vector Motion Graphic'),/solid opaque color fills/);
 assert.match(Motion.rule('2D Flat Vector Motion Graphic'),/no photorealism/);
});
test('styles are wired into storyboard requests, flow prompts, prompt refinements and both style selectors',()=>{
 assert.match(html,/script src="motion-graphic-styles\.js"/);
 assert.match(html,/GLOBAL MOTION GRAPHIC VISUAL BIBLE: \$\{motionStyleRule\(\)\}/);
 assert.match(html,/style_bible:KreasiFlowMotionStyles\.aiTextRule/);
 assert.match(html,/MOTION STYLE LOCK: \$\{motionStyleRule\(\)/);
 assert.ok((html.match(/motionStyleHint\(\)/g)||[]).length>=3);
 assert.match(html,/storyboard-ai-storyboard-cache-v5041|kreasiflow-ai-storyboard-cache-v5041/);
});
test('existing characters and difference checks remain available',()=>{
 assert.match(html,/S\.character/);
 assert.match(html,/function sceneDifferencePanel\(/);
 assert.match(html,/function googleFlowPrompt\(/);
 assert.match(html,/KreasiFlowSceneDifference\.audit/);
 assert.match(html,/transcriptionProvider/);
});
test('generated Flow prompt actually carries fixed 2D motion language and character identity',()=>{
 const vm=require('node:vm');
 const start=html.indexOf('function googleFlowPrompt(i)');
 const end=html.indexOf('function simpleFlowSceneCard',start);
 const ctx={
  S:{scenes:[{name:'ASAQ di lereng',voice:'ASAQ berjalan mendekati kawah',prompt:'ASAQ on rock',videoPrompt:'ASAQ crouches',flowShot:{action:'ASAQ crouches behind the crater',camera:'Low-angle tilt up',setting:'Rocky volcanic crater'}}],sceneEvery:10,ratio:'9:16 Shorts/Reels',sceneStyle:'Motion Graphic 2D',character:'ASAQ chibi boy, navy bear ears hat, brown striped shirt',flowCreditMode:'text-to-video',flowTextMode:false,toonMode:false,edu3DMode:false},
  KreasiFlowFlowShots:{makeShot:(_,__,custom)=>custom},
  motionStyleRule:()=>Motion.rule(ctx.S.sceneStyle),
  KreasiFlowMotionStyles:Motion,KFFlowSaver:Saver
 };
 vm.createContext(ctx);
 vm.runInContext(html.slice(start,end),ctx);
 const prompt=ctx.googleFlowPrompt(0);
 assert.match(prompt,/ASAQ chibi boy/);
 assert.match(prompt,/GLOBAL MOTION GRAPHIC VISUAL BIBLE:/);
 assert.match(prompt,/Strictly 2D/);
 assert.match(prompt,/SCENE 1\/1/);
 assert.match(prompt,/Do not invent visual text/);
 ctx.S.sceneStyle='Motion Graphic 3D';
 assert.match(ctx.googleFlowPrompt(0),/3D rotations/);
 assert.doesNotMatch(ctx.googleFlowPrompt(0),/Strictly 2D/);
 ctx.S.sceneStyle='Kinetic Typography';
 assert.match(ctx.googleFlowPrompt(0),/one or two short exact design keywords/);
 assert.match(ctx.googleFlowPrompt(0),/No subtitles/);
});
test('all 74 style names are available in source after upgrade',()=>{
 const vm=require('node:vm');
 const begin=html.indexOf('const visualStyles=');
 const end=html.indexOf(';\n',begin);
 const entries=vm.runInNewContext(html.slice(begin,end)+';visualStyles');
 assert.equal(entries.length,74);
 assert.ok(entries.every(x=>x.length===3));
 assert.equal(entries[0][0],'2D Flat Vector Motion Graphic');
 assert.equal(new Set(entries.map(x=>x[0])).size,74);
});

test('flat vector style is DEFAULT for new projects and has its own strict Flow/AI visual rules',()=>{
 assert.match(html,/sceneStyle:'2D Flat Vector Motion Graphic'/);
 assert.match(html,/Motion Style Lock: \$\{esc\(S\.sceneStyle\)\}/);
 assert.match(html,/pure 2D flat vector motion-graphic keyframe/);
 assert.match(html,/MANDATORY STYLE LOCK/);
 assert.match(html,/GLOBAL STYLE LOCK/);
 assert.match(html,/GLOBAL MOTION GRAPHIC VISUAL BIBLE/);
 const vm=require('node:vm');
 const start=html.indexOf('function googleFlowPrompt(i)');
 const end=html.indexOf('function simpleFlowSceneCard',start);
 const ctx={
  S:{scenes:[{name:'Laut',voice:'Tetes hujan menjadi sungai',prompt:'Flat blue water droplets',videoPrompt:'2D water drops slide across flat shapes',flowShot:{action:'Flat droplets join into one river',camera:'Static vertical composition, 2D shape movement only',setting:'Blue geometric landscape'}}],sceneEvery:10,ratio:'9:16 Shorts/Reels',sceneStyle:'2D Flat Vector Motion Graphic',character:'ASAQ, navy bear hat, striped shirt',flowCreditMode:'text-to-video',flowTextMode:false,toonMode:false,edu3DMode:false},
  KreasiFlowFlowShots:{makeShot:(_,__,custom)=>custom},motionStyleRule:()=>Motion.rule(ctx.S.sceneStyle),KreasiFlowMotionStyles:Motion,KFFlowSaver:Saver
 };
 vm.createContext(ctx);
 vm.runInContext(html.slice(start,end),ctx);
 const prompt=ctx.googleFlowPrompt(0);
 assert.match(prompt,/ASAQ, navy bear hat/);
 assert.match(prompt,/PURE 2D FLAT VECTOR MOTION GRAPHIC ONLY/);
 assert.match(prompt,/NO CGI/);
 assert.match(prompt,/no realistic depth/);
 assert.match(prompt,/Each scene must show a DISTINCT story-driven action/);
});
