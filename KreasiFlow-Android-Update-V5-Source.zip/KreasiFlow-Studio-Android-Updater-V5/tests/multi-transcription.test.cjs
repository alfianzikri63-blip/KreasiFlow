const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const STT=require('../app/src/main/assets/transcription-multi.js');
const Timeline=require('../app/src/main/assets/subtitle-timeline.js');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
const java=fs.readFileSync(path.join(root,'app/src/main/java/id/kreasiflow/studio/TranscriptionProviders.java'),'utf8');
const main=fs.readFileSync(path.join(root,'app/src/main/java/id/kreasiflow/studio/MainActivity.java'),'utf8');
const keys=fs.readFileSync(path.join(root,'app/src/main/java/id/kreasiflow/studio/ProviderSecrets.java'),'utf8');
const backup=fs.readFileSync(path.join(root,'app/src/main/java/id/kreasiflow/studio/CloudKeyBackup.java'),'utf8');

test('default ElevenLabs with configured Groq/Gemini fallback',()=>{
 assert.deepEqual(STT.order('elevenlabs',{elevenlabs:true,groq:true,gemini:true}),['elevenlabs','groq','gemini']);
 assert.deepEqual(STT.order('elevenlabs',{elevenlabs:true,groq:false,gemini:true}),['elevenlabs','gemini']);
 assert.deepEqual(STT.order('elevenlabs',{elevenlabs:false,groq:true,gemini:true}),['groq','gemini']);
});
test('fallback disabled never starts another provider',()=>{
 assert.deepEqual(STT.order('elevenlabs',{elevenlabs:true,groq:true,gemini:true},false),['elevenlabs']);
 assert.deepEqual(STT.order('elevenlabs',{elevenlabs:false,groq:true},false),[]);
});
test('Scribe word and spacing events grouped in real audio time, no invented timeline',()=>{
 const words=[
  {text:'Halo',start:1,end:1.4,type:'word'},
  {text:' ',start:1.4,end:1.4,type:'spacing'},
  {text:'semuanya,',start:1.4,end:2.05,type:'word'},
  {text:'sekarang',start:2.1,end:2.6,type:'word'},
  {text:'kita',start:2.7,end:2.95,type:'word'},
  {text:'mulai.',start:3,end:3.7,type:'word'},
  {text:'Lanjut',start:6,end:6.4,type:'word'},
  {text:'ke',start:6.45,end:6.6,type:'word'},
  {text:'bab',start:6.65,end:6.82,type:'word'},
  {text:'dua.',start:6.9,end:7.4,type:'word'},
  {text:'(suara)',start:8,end:9,type:'audio_event'}
 ];
 const cues=STT.normalize({words},12);
 assert.equal(cues.length,2);assert.deepEqual(cues.map(c=>c.text),['Halo semuanya, sekarang kita mulai.','Lanjut ke bab dua.']);
 assert.equal(cues[0].start,1);assert.equal(cues[0].end,3.7);
 assert.equal(cues[1].start,6);assert.equal(cues[1].end,7.4);
 assert.deepEqual(Timeline.validate(cues,12),[]);
 assert.match(Timeline.serialize(cues),/00:00:01,000 --> 00:00:03,700/);
});
test('Groq word field supported, and Gemini segment adapter still works',()=>{
 const whisper=STT.normalize({words:[{word:'Tes',start:0.2,end:0.5},{word:'dua',start:0.6,end:1}]},4);
 assert.equal(whisper[0].text,'Tes dua');
 const legacy=STT.normalize({segments:[{start:0,end:2,text:'Halo'}]},4);
 assert.equal(legacy[0].text,'Halo');
});
test('invalid or absent timestamps never silently estimates based on naskah',()=>{
 assert.throws(()=>STT.normalize({words:[]},60),/timestamp/i);
 assert.throws(()=>STT.normalize({words:[{text:'oops',start:29,end:80}]},30),/melampaui/i);
});
test('long VO does not silently drop words, bounded to 250 subtitle cues',()=>{
 const words=Array.from({length:2700},(_,i)=>({text:'kata'+i,start:i*0.36,end:i*0.36+0.26,type:'word'}));
 const cues=STT.cuesFromWords(words,1000);
 assert.ok(cues.length<=250);assert.equal(Timeline.validate(cues,1000).length,0);
 const transcript=cues.map(x=>x.text).join(' ');
 assert.ok(transcript.includes('kata0'));assert.ok(transcript.includes('kata2699'));
 assert.equal((transcript.match(/kata\d+/g)||[]).length,2700);
});
test('word-level subtitle at end cannot exceed audio duration',()=>{
 assert.throws(()=>STT.normalize({words:[{text:'finish',start:9.3,end:11}]},10),/melampaui/i);
});
test('provider status errors that can be fallback: 429 and 5xx only',()=>{
 for(const status of [429,500,502,503,504])assert.equal(STT.shouldFallback(Error('elevenlabs HTTP '+status+': busy')),true);
 for(const status of [400,401,402,403,404])assert.equal(STT.shouldFallback(Error('HTTP '+status+': key error')),false);
 assert.equal(STT.shouldFallback(Error('network timeout after request')),false);
});
test('fallback is a single call per provider, and only provider with key is called',async()=>{
 const calls=[],stages=[];
 const data=await STT.run({preferred:'elevenlabs',available:{elevenlabs:true,groq:true,gemini:false},
  call:async p=>{calls.push(p);if(p==='elevenlabs')throw Error('elevenlabs HTTP 503: busy');return {segments:[{start:0,end:1,text:'ok'}]};},
  onStage:s=>stages.push(s.stage)});
 assert.deepEqual(calls,['elevenlabs','groq']);assert.equal(data.provider,'groq');
 assert.deepEqual(stages,['request','fallback','request']);
});
test('auth errors never fallback and preserve exception',async()=>{
 const calls=[];
 await assert.rejects(STT.run({available:{elevenlabs:true,groq:true},call:p=>{calls.push(p);throw Error('elevenlabs HTTP 401: invalid key');}}),/HTTP 401/);
 assert.deepEqual(calls,['elevenlabs']);
});
test('native Android uses encrypted BYOK storage and allowlisted fixed STT URLs',()=>{
 assert.match(java,/https:\/\/api\.elevenlabs\.io\/v1\/speech-to-text/);
 assert.match(java,/https:\/\/api\.groq\.com\/openai\/v1\/audio\/transcriptions/);
 assert.match(java,/"scribe_v3"/);
 assert.match(java,/"whisper-large-v3-turbo"/);
 assert.match(java,/"timestamps_granularity", "word"/);
 assert.match(java,/"timestamp_granularities\[\]", "word"/);
 assert.match(main,/TranscriptionProviders\.transcribe\(/);
 assert.match(keys,/"groq"\.equals\(provider\)/);
 assert.match(keys,/AES\/GCM\/NoPadding/);
 assert.match(backup,/"elevenlabs","groq"/);
});
test('UI defaults ElevenLabs, offers fallback, SRT export, and a 0-100 progress bar',()=>{
 assert.match(html,/transcriptionProvider:'elevenlabs'/);
 assert.match(html,/transcriptionFallback:true/);
 assert.match(html,/field\('keyElevenLabs',/);
 assert.match(html,/field\('keyGroq',/);
 assert.match(html,/case 'subtitle-ai':return kfAiNativeAvailable\(\)\?await kfAiTranscriptionJob\(\):await transcribeVOWithMultiAI\(\)/);
 assert.match(html,/KFMultiTranscription\.normalize\(result,dur\)/);
 assert.match(html,/const errors=KFSubtitleTimeline\.validate\(cues,dur\)/);
 assert.match(html,/downloadSRT\(\)/);
 assert.match(html,/operation-progress-track/);
 assert.match(html,/S\.subtitleCues=cues;S\.subtitleSource='ai'/);
});

const vm=require('node:vm');
const uiFunction=html.match(/async function transcribeVOWithMultiAI\(\)\{[\s\S]*?\n\}\n\nfunction generateTimedSubtitles/);
assert.ok(uiFunction,'Multi-provider UI function must exist');
function uiHarness({errorOnEleven=false,invalid=false,available={elevenlabs:true,groq:true,gemini:false},fallback=true}={}){
 const S={audioName:'vo.mp3',audioDuration:9,subtitleCues:[{start:0,end:2,text:'SUBTITLE LAMA'}],subtitleSource:'manual',
  transcriptionProvider:'elevenlabs',transcriptionFallback:fallback,narrationText:'Sample narration'};
 const calls=[], notices=[], progress=[];
 const ctx={
  S,transcribeBusy:false,transcribeStatus:'',audioUrl:'blob:voice',window:{KreasiFlowNative:{requestProvider(){},beginRenderAsset(){}}},
  providerStatus:()=>available,showSettings:()=>{},notify:v=>notices.push(v),
  fetch:async()=>({blob:async()=>new Blob([Uint8Array.from([2,3,4])])}),
  transferNativeAsset:async()=>('123'),requestProviderAPI:async p=>{
   calls.push(p);
   if(p==='elevenlabs'&&errorOnEleven)throw Error('elevenlabs HTTP 503: overloaded');
   if(invalid)return {words:[{text:'Halo',start:7,end:20}]};
   return {words:[{text:'Halo',start:0,end:.5},{text:'semua',start:.6,end:1.3}]};
  },confirm:()=>true,opFor:(...x)=>progress.push(x),render:()=>{},
  persist:()=>{},transcriptSource:()=>S.narrationText,
  document:{getElementById:()=>null},Blob,Number,String,Array,Math,Error,console,
  KFMultiTranscription:STT,KFSubtitleTimeline:Timeline,KFTimelineEditor:require('../app/src/main/assets/timeline-editor.js'),
  transcribeVOWithGemini:()=>{throw Error('Legacy Gemini should not be called here');}
 };
 vm.createContext(ctx);
 vm.runInContext(uiFunction[0].replace(/\nfunction generateTimedSubtitles$/,''),ctx);
 return {run:()=>vm.runInContext('transcribeVOWithMultiAI()',ctx),S,calls,notices,progress,ctx};
}
test('UI commits word-timed SRT cues only after a successful ElevenLabs result',async()=>{
 const x=uiHarness();assert.equal(await x.run(),true);
 assert.equal(x.S.subtitleSource,'ai');assert.equal(x.S.subtitleProvider,'elevenlabs');
 assert.equal(x.S.subtitleCues[0].text,'Halo semua');assert.equal(x.S.subtitleWords.length,2);assert.equal(x.S.subtitleWords[1].start,.6);
 assert.deepEqual(x.calls,['elevenlabs']);
 assert.equal(x.ctx.transcribeBusy,false);
 assert.ok(x.progress.some(p=>p[1]>=88));
});
test('UI falls back to Groq on ElevenLabs HTTP 503',async()=>{
 const x=uiHarness({errorOnEleven:true});assert.equal(await x.run(),true);
 assert.equal(x.S.subtitleProvider,'groq');assert.deepEqual(x.calls,['elevenlabs','groq']);
});
test('UI never overwrites earlier subtitle when AI timestamps are invalid',async()=>{
 const x=uiHarness({invalid:true});assert.equal(await x.run(),false);
 assert.equal(x.S.subtitleSource,'manual');assert.equal(x.S.subtitleCues[0].text,'SUBTITLE LAMA');
 assert.equal(x.ctx.transcribeBusy,false);
});
test('UI respects disabled fallback on provider failure',async()=>{
 const x=uiHarness({errorOnEleven:true,fallback:false});assert.equal(await x.run(),false);
 assert.deepEqual(x.calls,['elevenlabs']);
});
