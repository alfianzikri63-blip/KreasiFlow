const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const clips=require('../app/src/main/assets/flow-batch-import.js');
const base=path.join(__dirname,'../app/src/main');
const html=fs.readFileSync(path.join(base,'assets/index.html'),'utf8');
const activity=fs.readFileSync(path.join(base,'java/id/kreasiflow/studio/MainActivity.java'),'utf8');
const store=fs.readFileSync(path.join(base,'java/id/kreasiflow/studio/ProjectStore.java'),'utf8');
const file=(name)=>({name,size:3*1024*1024,type:'video/mp4',token:name});
test('14 Flow clips selected together map to exact numbered scenes, regardless of gallery selection order',()=>{
 const files=Array.from({length:14},(_,i)=>file(`Scene-${String(14-i).padStart(2,'0')}.mp4`));
 const plan=clips.plan(files,14);
 assert.equal(plan.items.length,14);
 assert.deepEqual(plan.items.map(x=>x.scene),Array.from({length:14},(_,i)=>i+1));
 assert.deepEqual(plan.items.map(x=>x.index),Array.from({length:14},(_,i)=>i));
});
test('14 unnumbered clips naturally sort by file name without dropping selection',()=>{
 const files=Array.from({length:14},(_,i)=>file(`Flow-video${14-i}.mp4`));
 const plan=clips.plan(files,14);
 assert.equal(plan.items.length,14);
 assert.deepEqual(plan.items.map(x=>x.file.name),Array.from({length:14},(_,i)=>`Flow-video${i+1}.mp4`));
});
test('UI uses native Android picker with gallery and files fallback, not only WebView input',()=>{
 assert.match(html,/case 'flow-bulk-pick':return chooseAllFlowVideos\('gallery'\)/);
 assert.match(html,/case 'flow-bulk-pick-files':return chooseAllFlowVideos\('files'\)/);
 assert.match(html,/__kfNativeFlowFilesSelected/);
 assert.match(html,/__kfNativeFlowClipImported/);
 assert.match(html,/__kfNativeFlowImportFinished/);
 assert.match(html,/importSelectedFlowVideos\(JSON\.stringify\(jobs\)\)/);
 assert.match(html,/id="flowBulkFiles"[^>]*multiple/);
});
test('native picker collects ClipData of all media, not just first Intent URI',()=>{
 assert.match(activity,/Intent\.EXTRA_ALLOW_MULTIPLE,true/);
 assert.match(activity,/PICK_ALL_FLOW_CLIPS/);
 assert.match(activity,/getClipData\(\)/);
 assert.match(activity,/group\.getItemCount\(\)/);
 assert.match(activity,/ACTION_OPEN_DOCUMENT:Intent\.ACTION_GET_CONTENT/);
 assert.match(activity,/OpenableColumns\.DISPLAY_NAME/);
});
test('native import streams videos without Base64/WebView overhead',()=>{
 const start=activity.indexOf('private boolean importSelectedFlowClips(');
 const end=activity.indexOf('private static final class AssetSession',start);
 const code=activity.slice(start,end);
 assert.match(code,/openInputStream\(uris\.get\(token\)\)/);
 assert.match(code,/byte\[\] block=new byte\[131072\]/);
 assert.match(code,/renderAssets\.put\(id,output\)/);
 assert.match(code,/__kfNativeFlowClipImported/);
 assert.match(code,/__kfNativeFlowImportFinished/);
 assert.doesNotMatch(code,/Base64\.encode|Base64\.decode/);
});
test('saving and reopening project restores native render IDs for MP4',()=>{
 assert.match(store,/findSavedClip\(String id,int index\)/);
 assert.match(activity,/restoreSavedFlowClip\(String projectId,int sceneIndex\)/);
 assert.match(html,/restoreSavedFlowClip\?\.\(id,i\)/);
 assert.match(html,/movingClips\[i\]=\{id:clipId/);
});
