const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const base='app/src/main/';
const html=fs.readFileSync(base+'assets/index.html','utf8');
const native=fs.readFileSync(base+'java/id/kreasiflow/studio/MainActivity.java','utf8');
const inspector=fs.readFileSync(base+'java/id/kreasiflow/studio/FlowVideoInspector.java','utf8');
const manifest=fs.readFileSync(base+'AndroidManifest.xml','utf8');
const paths=fs.readFileSync(base+'res/xml/file_paths.xml','utf8');
const player=fs.readFileSync(base+'java/id/kreasiflow/studio/VideoPreviewActivity.java','utf8');
test('imported MP4 only declared successful after native video track and duration inspection',()=>{
 const start=native.indexOf('private boolean importSelectedFlowClips(');
 const end=native.indexOf('private static final class AssetSession',start);
 const code=native.slice(start,end);
 assert.ok(code.indexOf('FlowVideoInspector.inspect(output)')>0);
 assert.ok(code.indexOf('FlowVideoInspector.inspect(output)')<code.indexOf('renderAssets.put(id,output)'));
 assert.match(code,/durationMs/);
 assert.match(inspector,/MediaExtractor/);assert.match(inspector,/video\//);
 assert.match(inspector,/durationMs<=0/);assert.match(inspector,/0:00/);
});
test('in app scene uses native preview instead of WebView 0:00 player',()=>{
 assert.match(html,/data-preview-clip=\"\$\{i\}\"/);
 assert.match(html,/pemutar native Android/);
 assert.match(html,/previewGeneratedClip/);
 assert.match(native,/new Intent\(this,VideoPreviewActivity.class\)/);
 assert.match(player,/VideoView/);assert.match(player,/setVideoURI/);
});
test('saved media path can be shared via FileProvider after reopen',()=>{
 assert.match(paths,/files-path name=\"saved_project_videos\"/);
 assert.match(manifest,/VideoPreviewActivity/);
 assert.match(native,/restoreSavedFlowClip/);
 assert.match(native,/inspectFlowClip/);
});
