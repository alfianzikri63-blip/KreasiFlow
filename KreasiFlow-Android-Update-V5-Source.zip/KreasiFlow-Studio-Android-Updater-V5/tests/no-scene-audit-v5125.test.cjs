const {test}=require('node:test'),a=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const h=fs.readFileSync('app/src/main/assets/index.html','utf8');
test('scene checker, AI repair actions, cached reports and visual pair comparisons removed',()=>{
 a.doesNotMatch(h,/scene-audit|scene-difference\.js|sceneDifferenceHint|sceneDifferencePanel|auditedScenes|storyboard-check|storyboard-fix|footage-check|repairStoryboardSimilarity|KFFootageAudit\.analyse|differenceAuditCache|footageAudit/);
 a.ok(!fs.existsSync('app/src/main/assets/scene-difference.js'));
});
test('distinct prompt instructions, optional manual refinement, and technical MP4/loop checks survive',()=>{
 a.match(h,/Each numbered scene needs footage VISUALLY DIFFERENT/);
 a.match(h,/case 'flow-ai-distinct':return await refineDistinctFlowShots/);
 a.match(h,/function productionCheck\(deep=false\)/);
 a.match(h,/inspectFlowClip\(c\.id\)/);
 a.match(h,/r\.lowDetail=!!f\.lowDetail/);
 a.match(h,/function loopFootageWarning\(/);
});
test('storyboard generation accepts matching shots without automatic revision request and preserves imported clips',async()=>{
 const planned=[{voice:'Opening'},{voice:'Closing'}],clip={id:'mp4'};let calls=0;
 const c={S:{scenes:planned.map(p=>({...p})),duration:1,sceneEvery:4,smartLoop:false},images:[null,null],movingClips:[clip,null],storyboardAiBusy:false,validateCombinedOutro:()=>true,storyboardProviders:()=>['mock'],scriptToNarration:()=> 'Opening Closing',mainVoiceDuration:()=>8,KreasiFlowScenePlanner:{plan:()=>planned},confirm:()=>true,planStoryboardRows:async()=>{calls++;return planned.map(()=>({image_prompt:'same',action:'same'}));},sceneFromAi:(p,r)=>({...p,prompt:r.image_prompt}),opFor:()=>{},storyboardClearCache:()=>{},persist:()=>{},render:()=>{},notify:()=>{},KFStoryboardResilience:{safeError:e=>String(e)}};
 vm.createContext(c);vm.runInContext(h.slice(h.indexOf('async function generateStoryboardWithAI(){'),h.indexOf('// Text AI ONLY, one-pass shot plan;')),c);
 a.equal(await c.generateStoryboardWithAI(),true);a.equal(calls,1);a.equal(c.S.scenes.length,2);a.equal(c.movingClips[0],clip);a.equal(c.storyboardAiBusy,false);
});
