const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const f=require('../app/src/main/assets/flow-credit-saver.js');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const gradle=fs.readFileSync('app/build.gradle','utf8');

test('Omni 1.1 Flash default image-to-video prompt is 4 seconds, same frame, speech-free',()=>{
 const p=f.imageToVideoPrompt({index:0,ratio:'9:16',style:'2D Flat Vector Motion Graphic',action:'Tectonic plates shift and cyan seismic rings spread',camera:'slow upward tilt'});
 for(const v of ['OMNI 1.1 FLASH','IMAGE-TO-VIDEO','Duration 4 seconds','first-frame image','one continuous unbroken shot','no narration','no human or synthetic voice','no dialogue','no speech','no 3D'])assert.ok(p.toLowerCase().includes(v.toLowerCase()),v);
 assert.ok(p.split(/\s+/).length<125);
 assert.doesNotMatch(p,/\b(?:NARASI INDONESIA|FULL INDONESIAN VOICE-OVER SCRIPT)\b/);
});
test('sound-effects mode still excludes all voices, narrative dialogue and music',()=>{
 const p=f.imageToVideoPrompt({index:2,duration:4,audioMode:'sfx',action:'A warning beacon starts blinking'});
 assert.match(p,/Foley ONLY/);
 for(const t of ['no narration','no voice-over','no dialogue','no speech','background conversation','radio\/TV voices','no music'])assert.match(p,new RegExp(t,'i'));
});
test('edited prompt retains custom action but forces Omni 4s and voice lock once',()=>{
 const p=f.enforceOmniAudio('Duration 10 seconds. Custom wave action.\n\nOMNI 1.1 FLASH AUDIO LOCK: old warning',{duration:4,audioMode:'silent'});
 assert.match(p,/Duration 4 seconds/);assert.doesNotMatch(p,/Duration 10 seconds/);assert.match(p,/Custom wave action/);
 assert.equal((p.match(/OMNI 1\.1 FLASH AUDIO LOCK:/g)||[]).length,1);
 assert.equal((f.enforceOmniAudio(p,{duration:4}).match(/OMNI 1\.1 FLASH AUDIO LOCK:/g)||[]).length,1);
});
test('existing project prompts get voice lock at copy time',()=>{
 assert.match(html,/KFFlowSaver\.enforceOmniAudio\(overridden/);
 assert.match(html,/const prompt=googleFlowPrompt\(i\)/);
 assert.match(html,/duration:S\.flowI2VDuration/);
});
test('4s is independent of storyboard scene timing; default render mutes Flow audio',()=>{
 assert.match(html,/sceneEvery:5,flowI2VDuration:'4',flowI2VAudioMode:'silent'/);
 assert.match(html,/flowAudioMode:'mute'/);
 assert.match(html,/return 'mute';/);
 assert.match(html,/data-field="flowI2VDuration"/);
 assert.match(html,/data-field="flowI2VAudioMode"/);
 assert.match(gradle,/6\.8\.7/);
});
