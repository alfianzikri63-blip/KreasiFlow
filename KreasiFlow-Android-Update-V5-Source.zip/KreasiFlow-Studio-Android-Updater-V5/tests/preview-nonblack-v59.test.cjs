const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const player=fs.readFileSync('app/src/main/java/id/kreasiflow/studio/VideoPreviewActivity.java','utf8');
const activity=fs.readFileSync('app/src/main/java/id/kreasiflow/studio/MainActivity.java','utf8');
const inspector=fs.readFileSync('app/src/main/java/id/kreasiflow/studio/FlowVideoInspector.java','utf8');

test('native preview uses TextureView surface, not black VideoView overlay',()=>{
 assert.match(player,/new TextureView\(this\)/);
 assert.match(player,/new Surface\(st\)/);
 assert.match(player,/player\.setSurface\(surface\)/);
 assert.doesNotMatch(player,/new VideoView\(/);
});
test('native preview extracts a real frame and keeps it visible before rendering',()=>{
 assert.match(player,/MediaMetadataRetriever/);
 assert.match(player,/getFrameAtTime\(500000/);
 assert.match(player,/thumbnail\.setImageBitmap\(bitmap\)/);
 assert.match(player,/MEDIA_INFO_VIDEO_RENDERING_START/);
 assert.match(player,/thumbnail\.setVisibility\(View\.GONE\)/);
});
test('four-second video loops and offers native controls and external player fallback',()=>{
 assert.match(player,/setLooping\(true\)/);
 assert.match(player,/setOnCompletionListener/);
 assert.match(player,/mp\.seekTo\(0\)/);
 assert.match(player,/SeekBar/);
 assert.match(player,/Intent\.ACTION_VIEW/);
 assert.match(player,/FLAG_GRANT_READ_URI_PERMISSION/);
});
test('import uses stable FileProvider Uri and validates video before marking success',()=>{
 assert.match(activity,/new Intent\(this,VideoPreviewActivity\.class\)/);
 assert.match(activity,/FileProvider\.getUriForFile/);
 assert.match(activity,/FlowVideoInspector\.inspect\(output\)/);
 assert.match(inspector,/MediaExtractor/);
});
