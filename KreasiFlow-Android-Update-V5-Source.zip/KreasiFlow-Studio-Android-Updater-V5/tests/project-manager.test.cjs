const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const root='app/src/main/';
const java=fs.readFileSync(root+'java/id/kreasiflow/studio/ProjectStore.java','utf8');
const main=fs.readFileSync(root+'java/id/kreasiflow/studio/MainActivity.java','utf8');
const ui=fs.readFileSync(root+'assets/index.html','utf8');
const gradle=fs.readFileSync('app/build.gradle','utf8');

test('source version 5.0.64 and package/signing identity remain unchanged',()=>{
 assert.match(gradle,/KREASIFLOW_VERSION_NAME'\) \?: '5\.1\.3'/);
 assert.match(gradle,/KREASIFLOW_VERSION_CODE'\) \?: '5001003'/);
 assert.match(gradle,/applicationId 'id\.kreasiflow\.studio'/);
});
test('project metadata stored in private permanent Android folder, atomically',()=>{
 assert.match(java,/getFilesDir\(\),"saved-projects-v1"/);
 assert.match(java,/project\.json\.writing/);
 assert.match(java,/StandardCopyOption\.REPLACE_EXISTING/);
 assert.doesNotMatch(java,/getCacheDir\(\)/);
});
test('project assets persist separately from WebView local storage',()=>{
 assert.match(main,/@JavascriptInterface public String saveProjectMedia/);
 assert.match(main,/@JavascriptInterface public String openSavedProject/);
 assert.match(java,/saveAsset\(String id,String key,File source,String mime/);
 assert.match(ui,/transferNativeAsset\(blob,row\.kind==='clip'/);
 assert.match(ui,/projectMedia:/);
});
test('saved MP4/audio/image paths can be reopened as same-origin private media',()=>{
 assert.match(main,/projectStore\.serveMedia\(request\.getUrl\(\)\.getPath\(\)/);
 assert.match(java,/\/project-media\//);
 assert.match(java,/Content-Range/);
 assert.match(java,/Accept-Ranges/);
 assert.match(java,/new WebResourceResponse\(mimeOf\(f\)/);
});
test('opening saved project re-registers media ids for Android renderer',()=>{
 assert.match(main,/renderAssets\.put\(assetId,f\)/);
 assert.match(main,/entry\.put\("nativeId",assetId\)/);
 assert.match(ui,/movingClips\[i\]=\{id:clipId/);
 assert.match(ui,/audioUrl=media\.url/);
 assert.match(ui,/images\[i\]=media\.url/);
});
test('autosave restores project without requiring manual JSON export',()=>{
 assert.match(ui,/kfAutoSaveTimer=setTimeout\(kfSaveMetadata,1000\)/);
 assert.match(ui,/kfAssetSaveTimer=setTimeout/);
 assert.match(ui,/if\(existing\.some\(x=>x\.id===S\.projectId\)\)await kfOpenProject/);
 assert.match(ui,/kfSaveAssetsQueued/);
});
test('no binary is serialized to JSON metadata or provider keys exported',()=>{
 assert.match(ui,/for\(const key of Object\.keys\(defaults\)\)result\[key\]=S\[key\]/);
 assert.match(java,/zip\.putNextEntry\(new ZipEntry\("project\.json"\)\)/);
 assert.match(java,/zip\.putNextEntry\(new ZipEntry\("media\/"\+f\.getName\(\)\)\)/);
 assert.doesNotMatch(java,/ProviderSecrets|API_KEY|apikey|Bearer/);
});
test('ZIP import rejects traversal, duplicates and oversized data',()=>{
 assert.match(java,/!names\.add\(path\)/);
 assert.match(java,/MAX_ARCHIVE_UNPACKED/);
 assert.match(java,/MAX_FILES/);
 assert.match(java,/path\.matches\("media\//);
 assert.match(java,/validKey\(key\)/);
 assert.match(java,/deleteRecursive\(folder\)/);
});
test('ZIP backup and import use Android document picker, no broad storage permission',()=>{
 assert.match(main,/Intent\.ACTION_CREATE_DOCUMENT/);
 assert.match(main,/Intent\.ACTION_OPEN_DOCUMENT/);
 assert.match(main,/projectStore\.writeZip/);
 assert.match(main,/projectStore\.readZip/);
 const manifest=fs.readFileSync(root+'AndroidManifest.xml','utf8');
 assert.doesNotMatch(manifest,/MANAGE_EXTERNAL_STORAGE|READ_EXTERNAL_STORAGE|WRITE_EXTERNAL_STORAGE/);
});
test('project manager exposes save, open, backup, duplicate, delete, import',()=>{
 for(const label of ['Simpan proyek lengkap','Backup ZIP','Duplikat','Impor backup ZIP','data-project-open','data-project-delete','data-project-copy','data-project-backup'])assert.ok(ui.includes(label),'missing '+label);
 assert.match(ui,/case 'save':await save\(\)/);
 assert.match(ui,/case 'new':await newProject\(\)/);
});
test('new project waits for previous media, backup survives application updates',()=>{
 assert.match(ui,/async function newProject\(\)/);
 assert.match(ui,/const previous=await kfSaveAssetsQueued\(\)/);
 assert.match(ui,/if\(previous\.failed\.length\)/);
 assert.match(java,/saved-projects-v1/);
});
test('legacy lightweight JSON import/export remain supported',()=>{
 assert.match(ui,/function exportProject\(\)/);
 assert.match(ui,/async function importProject\(file\)/);
 assert.match(ui,/JSON ringan/);
});
