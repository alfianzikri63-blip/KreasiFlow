const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const main=fs.readFileSync(path.join(root,'app/src/main/java/id/kreasiflow/studio/MainActivity.java'),'utf8');
const gradle=fs.readFileSync(path.join(root,'app/build.gradle'),'utf8');
test('background AI errors use JSON quoting without unchecked JSONObject.put calls',()=>{
  const start=main.indexOf('@JavascriptInterface public String startBackgroundAi(');
  const end=main.indexOf('@JavascriptInterface public String getBackgroundAiStatus()',start);
  assert.ok(start>=0&&end>start);
  const method=main.slice(start,end);
  assert.match(method,/JSONObject\.quote\(message\.substring/);
  assert.doesNotMatch(method,/return new JSONObject\(\)\.put\("ok",false\)/);
});
test('fallback version is v5.0.64 and release code consistent',()=>{
  assert.match(gradle,/KREASIFLOW_VERSION_NAME'\) \?: '6\.6\.0'/);
  assert.match(gradle,/KREASIFLOW_VERSION_CODE'\) \?: '6006000'/);
});
