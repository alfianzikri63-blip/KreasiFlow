const assert=require('node:assert/strict');
const {test}=require('node:test');
const R=require('../app/src/main/assets/render-progress-685.js');
test('only actual codec samples enable a determinate encoding bar',()=>{
 assert.equal(R.frameProgress({frameTotal:720,frames:0},'prepare'),null);
 assert.deepEqual(R.frameProgress({frameTotal:720,frames:10},'video'),{value:10,total:720});
 assert.equal(R.frameProgress({},'video'),null);
 assert.equal(R.frameProgress({frameTotal:720,frames:720},'audio'),null);
});
test('waiting, slow, stalled and terminal failure are distinct',()=>{
 assert.match(R.activity('queued',94000),/Menunggu/);
 assert.match(R.activity('running',26000),/lambat/);
 assert.match(R.activity('running',92000),/90 detik/);
 assert.match(R.activity('error',92000),/gagal/);
 assert.match(R.activity('cancelled',0),/dibatalkan/);
});
test('a source or trim revision cannot hit an older asset and missing ids are discarded',()=>{
 const c=new R.AssetCache(16,2);
 const key=R.immutableKey('p','blob:abc','audio',[0,1,0,1]);
 const trim=R.immutableKey('p','blob:abc','audio',[0,2,0,1]);
 assert.notEqual(key,trim);assert.equal(R.immutableKey('p','https://appassets/android','audio'),'');
 c.remember(key,'1',10);
 assert.equal(c.get(trim,()=>true),null);
 assert.equal(c.get(key,()=>false),null);
 assert.equal(c.bytes,0);
});
test('cache eviction reserves space without deleting assets pinned to the new render',()=>{
 const c=new R.AssetCache(16,3);
 c.remember('a','A',6);c.remember('b','B',6);
 assert.deepEqual(c.trim(new Set(['A']),9,1),['B']);
 assert.equal(c.bytes,6);
});
