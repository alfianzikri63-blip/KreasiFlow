const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
const service=fs.readFileSync(path.join(root,'app/src/main/java/id/kreasiflow/studio/RenderForegroundService.java'),'utf8');
const renderer=fs.readFileSync(path.join(root,'app/src/main/java/id/kreasiflow/studio/NativeVideoRenderer.java'),'utf8');
const gradle=fs.readFileSync(path.join(root,'app/build.gradle'),'utf8');

test('24, 30, 60 FPS selectable and 30 default for new projects',()=>{
  assert.match(html,/opts\(\['24','30','60'\],S\.fps\)/);
  assert.match(html,/fps:'30',frameBlend:false/);
  assert.match(html,/data-field="frameBlend"/);
  assert.match(html,/Interpolasi ringan \(Frame Blend\)/);
});
test('native moving render receives explicit frame blend preference',()=>{
  assert.match(html,/fps:Number\(S\.fps\)\|\|30,frameBlend:!!S\.frameBlend/);
  assert.match(service,/cfg\.frameBlend=cfg\.fps==60 && args\.optBoolean\("frameBlend",false\)/);
  assert.equal((service.match(/Math\.min\(60,args\.optInt\("fps",30\)\)/g)||[]).length,2);
});
test('60 FPS is encoded and codec capability checked instead of silent fallback',()=>{
  assert.match(renderer,/fmt\.setInteger\(MediaFormat\.KEY_FRAME_RATE,fps\)/);
  assert.match(renderer,/areSizeAndRateSupported\(w,h,60\.0\)/);
  assert.match(renderer,/Encoder HP tidak mendukung/);
});
test('sampling respects source frame cadence, no hard-coded 12 FPS capture',()=>{
  assert.match(renderer,/sourceFps=sourceFrameRate\(clip\)/);
  assert.match(renderer,/MediaFormat\.KEY_FRAME_RATE/);
  assert.match(renderer,/Math\.floor\(sourceTime\*sourceFps/);
  assert.doesNotMatch(renderer,/sourceTime\*12\.0/);
});
test('blend is optional and only for imported motion clips below 60 FPS',()=>{
  assert.match(renderer,/c\.frameBlend && fps==60 && sourceFps<fps/);
  assert.match(renderer,/drawBitmap\(next,null,dest,paint\)/);
  assert.match(renderer,/Math\.round\(255\*blend\)/);
  assert.match(renderer,/if\(motionNext!=null\)motionNext\.recycle\(\)/);
});
test('existing background service and 5.0.55 version intact',()=>{
  assert.match(service,/startForeground\(NOTIFICATION_ID/);
  assert.match(gradle,/KREASIFLOW_VERSION_NAME'\) \?: '6\.3\.1'/);
  assert.match(gradle,/KREASIFLOW_VERSION_CODE'\) \?: '6003001'/);
});
