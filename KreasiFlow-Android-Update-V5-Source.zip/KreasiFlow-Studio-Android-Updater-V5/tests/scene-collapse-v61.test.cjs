const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');

test('scene cards have per-scene hide/show with accessibility and independent bodies',()=>{
 assert.match(html,/data-scene-toggle=\"\$\{i\}\"/);
 assert.match(html,/aria-controls=\"scene-body-\$\{i\}\"/);
 assert.match(html,/class=\"scene-body\" id=\"scene-body-\$\{i\}\"/);
 assert.match(html,/scene-body\[hidden\]\{display:none!important\}/);
 assert.match(html,/S\.sceneUiExpanded=\[\.\.\.current\]\.sort/);
});

test('all-scene toggles are wired and do not mutate content',()=>{
 assert.match(html,/data-scene-all=\"close\"/);
 assert.match(html,/data-scene-all=\"open\"/);
 assert.match(html,/function setAllSceneUiOpen\(isOpen\)/);
 assert.match(html,/setSceneUiOpen\(i,!sceneUiIsOpen\(i\)\)/);
 assert.match(html,/function simpleFlowSceneCard\(s,i\)/);
 assert.match(html,/sceneUiExpanded:\[0\]/);
 // Collapsing should never unset a moving clip or remove media references.
 const fn=html.match(/function setSceneUiOpen\([\s\S]*?\n}\nfunction setAllSceneUiOpen/)[0];
 assert.doesNotMatch(fn,/movingClips\[|S\.scenes\[|delete |images\[/);
});
