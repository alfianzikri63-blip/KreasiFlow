const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const P=require('../app/src/main/assets/scene-planner.js');
const F=require('../app/src/main/assets/story-consistency.js');
const example='Bertemu Romeo flamboyan si cendrawasih jantan, dia memasuki arena hutan lebat Papua, memutar musik tarian cinta paling dramatis yang pernah ada. Dia berubah dari penari santai menjadi aktor panggung yang luar biasa. Burung ini membuka sayapnya yang indah, lalu menari memutar dan melompat dengan elegan. Setiap gerakan dibuat untuk menarik hati betina. Daun dan dahan bergoyang di sekitar mereka. Sang betina mengamati dari atas cabang. Romeo terus berusaha mengesankan, menari di antara sinar matahari, dan menunjukkan bulu yang gemerlap. Ketika waktunya tiba, ia mendekat secara perlahan. Penonton hutan menyaksikan momen itu. Pada akhirnya, tarian istimewa tersebut menjadi cara bertahan hidup dan berkembang biak di hutan Papua.';
test('60-second narration at 6 seconds per scene becomes exactly 10 real editable scenes',()=>{
 const expected=P.targetCount(example,60,6);
 const planned=P.plan(example,60,6);
 assert.equal(expected,10);assert.equal(planned.length,expected);
 assert.ok(P.narrationMatches(example,planned));
 assert.equal(planned[0].startSec,0);assert.equal(planned.at(-1).endSec,60);
 assert.ok(planned.every(x=>x.voice&&x.durationSec>0));
});
test('Text-to-Video mode uses the same count planner and loses no words',()=>{
 const planned=F.splitNarration(example,60,6);
 assert.equal(planned.length,P.targetCount(example,60,6));
 assert.ok(F.narrationMatches(example,planned));
});
test('Scene UI no longer demands reference stills, and source has no image generator controls in each scene',()=>{
 const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
 const start=html.indexOf('function simpleFlowSceneCard');
 const end=html.indexOf('function renderScenes',start);
 const card=html.slice(start,end);
 assert.match(card,/data-flow-prompt-override/);
 assert.match(card,/data-flow-clip/);
 assert.match(card,/data-flow-scene/);
 assert.doesNotMatch(card,/data-generate-image|data-generate-video|data-scene-file|data-motion-scene/);
 const opener=html.slice(html.indexOf('async function prepareSceneForGoogleFlow'),html.indexOf('async function importFlowClip'));
 assert.doesNotMatch(opener,/!images\[i\]|Buat atau upload gambar/);
 assert.match(opener,/googleFlowPrompt\(i\)/);
 assert.match(html,/case 'sync-scene-count'/);
});
