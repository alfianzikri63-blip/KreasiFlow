const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const mod=require('../app/src/main/assets/scene-difference.js');
const index=fs.readFileSync('app/src/main/assets/index.html','utf8');
const shot=(action,camera,setting='indoor kitchen')=>({flowShot:{action,camera,setting},prompt:action+' cinematic illustration'});
test('identical footage descriptions are flagged across all scenes',()=>{
 const a=shot('woman opens the red door and steps inside the room','wide dolly tracking from entrance');
 const b=shot('woman opens the red door and steps inside the room','wide dolly tracking from entrance');
 const c=shot('woman carefully pours orange juice into the blue glass','macro close-up with sideways movement');
 const report=mod.audit([a,c,b]);
 assert.equal(report.risk,1);
 assert.equal(report.conflicts[0].scene,3);
 assert.equal(report.conflicts[0].against,1);
 assert.equal(report.items[0].status,'risk');
 assert.equal(report.items[1].status,'distinct');
});
test('distinct actions and cameras pass without requiring new character identity',()=>{
 const a=shot('the same woman turns the metal doorknob and opens the door','wide establishing lateral dolly');
 const b=shot('the same woman removes orange juice from a tall refrigerator','over shoulder slow arc');
 const c=shot('the same woman pours orange juice into a blue glass','macro insert slow push');
 assert.equal(mod.audit([a,b,c]).risk,0);
});
test('AI storyboard button is wired, and text-only local generation is not substituted',()=>{
 assert.match(index,/data-action="\$\{action\}"/);
 assert.match(index,/btn\('storyboard-ai','✨ Buat storyboard dengan AI'/);
 assert.match(index,/case 'storyboard-ai':return kfAiNativeAvailable\(\)\?kfAiStoryboardJob\(\):await generateStoryboardWithAI\(\)/);
 assert.match(index,/if\(!providerReady\(textProvider\(\)\)\)/);
 assert.match(index,/sceneDifferencePanel\(\)/);
 assert.match(index,/audit(?:edScenes)?\(/);
 assert.match(index,/case 'storyboard-fix':return await repairStoryboardSimilarity\(\)/);
 assert.match(index,/sc\.flowPromptOverride/);
});
