const {test} = require('node:test');
const assert = require('node:assert/strict');
const P = require('../app/src/main/assets/scene-planner.js');
test('empty narrator does not generate fake scenes', ()=> assert.deepEqual(P.plan('   ',60,5),[]));
test('short narration never duplicates spoken words to fill target duration',()=>{
 const source='Hari ini semua terasa indah. Sore itu datang dengan cerah.';
 const s=P.plan(source,120,2);
 assert.equal(P.normalize(s.map(x=>x.voice).join(' ')),P.normalize(source));
 assert.ok(s.length<=Math.ceil(P.wordCount(source)/5));
 assert.ok(s.every(x=>x.voice&&x.durationSec>0));
});
test('5-minute narration subdivides into bounded scenes with continuous timing',()=>{
 const source=Array.from({length:750},(_,i)=>`kata${i+1}`).join(' ');
 const s=P.plan(source,300,5);
 assert.equal(s.length,60);
 assert.equal(s[0].startSec,0);
 assert.equal(s.at(-1).endSec,300);
 for(let i=1;i<s.length;i++) assert.equal(s[i-1].endSec,s[i].startSec);
 assert.equal(s.map(x=>x.voice).join(' '),source);
 assert.ok(s.every(x=>x.estimated));
});
test('large requested duration stays under safety cap',()=>{
 const source=Array.from({length:1000},(_,i)=>`word${i}`).join(' ');
 assert.equal(P.plan(source,10000,3,100).length,100);
});
test('narrationMatches detects duplication and missing words',()=>{
 assert.equal(P.narrationMatches('Kue hilang! Zayn mencari.',P.plan('Kue hilang! Zayn mencari.',30,5)),true);
 assert.equal(P.narrationMatches('Kue hilang!',[{voice:'Kue hilang! Kue hilang!'}]),false);
});
