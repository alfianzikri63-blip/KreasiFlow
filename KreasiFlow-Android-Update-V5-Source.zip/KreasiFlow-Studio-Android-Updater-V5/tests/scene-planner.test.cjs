const {test} = require('node:test');
const assert = require('node:assert/strict');
const P = require('../app/src/main/assets/scene-planner.js');
test('empty narrator does not generate fake scenes', ()=> assert.deepEqual(P.plan('   ',60,5),[]));
test('short narration never duplicates spoken words to fill target duration',()=>{
 const source='Hari ini semua terasa indah. Sore itu datang dengan cerah.';
 const s=P.plan(source,120,2);
 assert.equal(P.normalize(s.map(x=>x.voice).join(' ')),P.normalize(source));
 assert.ok(s.length<=Math.ceil(P.wordCount(source)/5));
 assert.ok(s.every(x=>x.voice&&x.durationSec>0));
});
test('5-minute narration subdivides into bounded scenes with continuous timing',()=>{
 const source=Array.from({length:750},(_,i)=>`kata${i+1}`).join(' ');
 const s=P.plan(source,300,5);
 assert.ok(s.length>=1&&s.length<=100); // sentence-aware planner keeps unpunctuated source intact
 assert.equal(s[0].startSec,0);
 assert.equal(s.at(-1).endSec,300);
 for(let i=1;i<s.length;i++) assert.equal(s[i-1].endSec,s[i].startSec);
 assert.equal(s.map(x=>x.voice).join(' '),source);
 assert.ok(s.every(x=>x.estimated));
});
test('large requested duration stays under safety cap',()=>{
 const source=Array.from({length:1000},(_,i)=>`word${i}.`).join(' ');
 assert.equal(P.plan(source,10000,3,100).length,100);
});
test('narrationMatches detects duplication and missing words',()=>{
 assert.equal(P.narrationMatches('Kue hilang! Zayn mencari.',P.plan('Kue hilang! Zayn mencari.',30,5)),true);
 assert.equal(P.narrationMatches('Kue hilang!',[{voice:'Kue hilang! Kue hilang!'}]),false);
});
test('capped storyboard uses the selected maximum through the full VO',()=>{
 const source=Array.from({length:65},(_,i)=>'kata'+(i+1)+(i%17===0?',':'')).join(' ');
 for(const max of [4,6,8]){
  const planned=P.planCapped(source,42,max);
  assert.equal(planned.length,Math.ceil(42/max));
  assert.equal(planned[0].startSec,0);
  assert.equal(planned.at(-1).endSec,42);
  assert.ok(planned.every((scene,i)=>scene.durationSec<=max&&(!i||scene.startSec===planned[i-1].endSec)));
  assert.ok(P.narrationMatches(source,planned));
 }
});
test('capped storyboard preserves a separate outro and reports impossible plans',()=>{
 const outro='Simpan klip ini untuk nanti.';
 const text='Aku berjalan ke halte sambil menunggu hujan reda. Temanku membawa sebuah payung. '+outro;
 const scene=P.planCapped(text,25,8,100,outro);
 assert.ok(P.narrationMatches(text,scene));
 assert.equal(scene.at(-1).voice,outro);
 assert.equal(scene.at(-1).outro,true);
 assert.ok(scene.every(x=>x.durationSec<=8));
 assert.deepEqual(P.planCapped('Satu kata',60,8),[]);
 assert.deepEqual(P.planCapped('kata '.repeat(205),801,8),[]);
});
