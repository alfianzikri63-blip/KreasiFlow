const assert=require('node:assert/strict');const {plan}=require('../app/src/main/assets/scene-sync.js');
const scenes=[{voice:'Halo semua ini pembuka yang penting.'},{voice:'Sekarang mari kita lihat penjelasan kedua lebih dekat.'},{voice:'Akhirnya terima kasih semuanya.'}];
const cues=[{start:0,end:3,text:'Halo semua ini pembuka yang penting'},{start:3,end:9,text:'Sekarang mari kita lihat penjelasan kedua lebih dekat'},{start:9,end:13,text:'Akhirnya terima kasih semuanya'}];
const p=plan(scenes,cues,14);assert.equal(p.starts[0],0);assert.equal(p.starts.at(-1),14);assert.equal(p.method,'cocok kata transkrip VO');assert.ok(p.starts[1]>2.5&&p.starts[1]<3.5,p.starts[1]);assert.ok(p.starts[2]>8&&p.starts[2]<10,p.starts[2]);
const fallback=plan(scenes,[],14);assert.equal(fallback.method,'proporsi kata narasi');assert.ok(fallback.starts[1]>0&&fallback.starts[2]>fallback.starts[1]);
const manual=plan(scenes,cues,14,{1:4.3,2:10.2});assert.equal(manual.starts[1],4.3);assert.equal(manual.starts[2],10.2);
assert.throws(()=>plan(scenes,cues,14,{1:12,2:9}),/bertumpuk/);
console.log('scene-sync test passed');
