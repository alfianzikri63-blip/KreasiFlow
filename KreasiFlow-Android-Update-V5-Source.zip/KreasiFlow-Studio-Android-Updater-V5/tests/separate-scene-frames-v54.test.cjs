const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const frames=require('../app/src/main/assets/separate-scene-frames.js');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const gradle=fs.readFileSync('app/build.gradle','utf8');
const example={title:'Early Warning Tsunami',style:'Motion Graphic 3D',ratio:'9:16',character:'ASAQ navy bear hat',styleRules:'Only matte objects and glowing cyan',scenes:Array.from({length:7},(_,i)=>({name:'Scene '+(i+1),prompt:`Unique visible action number ${i+1}`,flowShot:{camera:`Angle ${i+1}`}}))};
test('one combined Gemini prompt requests separate standalone images, never a sheet',()=>{
 const p=frames.masterPrompt(example);
 assert.match(p,/ONE MASTER REQUEST FOR 7 SEPARATE IMAGES/);
 assert.match(p,/SCENE 01/);assert.match(p,/SCENE 07/);
 assert.match(p,/NOT a storyboard sheet, NOT a collage, NOT a grid/);
 assert.match(p,/ASAQ navy bear hat/);
 assert.match(p,/Motion Graphic 3D/);
 assert.ok(p.indexOf('SCENE 01')<p.indexOf('SCENE 07'));
 assert.ok(p.split('\n').length>8);
});
test('each API prompt is for EXACTLY one standalone frame with consistent visual rules',()=>{
 const ps=example.scenes.map((_,i)=>frames.scenePrompt(example,i));
 assert.equal(new Set(ps).size,7);
 ps.forEach((p,i)=>{
  assert.match(p,/Generate ONE standalone 9:16/);
  assert.match(p, new RegExp(`Unique visible action number ${i+1}`));
  assert.match(p,/Never create a contact sheet, collage, grid or multiple panels/);
  assert.match(p,/Same recurring character/);
 });
 assert.throws(()=>frames.scenePrompt(example,7),/Scene tidak ditemukan/);
});
test('image bulk import uses numbered filenames safely and sorts by scene',()=>{
 const files=[{name:'Scene-03.png',type:'image/png',size:1024},{name:'Scene-01.png',type:'image/png',size:1024},{name:'Scene-02.png',type:'image/png',size:1024}];
 const ordered=frames.orderFiles(files,7);
 assert.deepEqual(ordered.map(x=>[x.index,x.file.name]),[[0,'Scene-01.png'],[1,'Scene-02.png'],[2,'Scene-03.png']]);
 assert.throws(()=>frames.orderFiles([files[1],files[1]],7),/duplikat/);
 assert.throws(()=>frames.orderFiles([{name:'scene-100.png',type:'image/png',size:1024}],7),/di luar rentang/);
});
test('unknown names sort numerically and incompatible files are rejected',()=>{
 const files=[{name:'Gemini_10.png',size:1,type:'image/png'},{name:'Gemini_2.png',size:1,type:'image/png'}];
 assert.deepEqual(frames.orderFiles(files,5).map(x=>x.file.name),['Gemini_2.png','Gemini_10.png']);
 assert.throws(()=>frames.orderFiles([{name:'x.exe',type:'application/octet-stream',size:12}],7),/PNG\/JPG\/WebP/);
 assert.throws(()=>frames.orderFiles([{name:'x.png',type:'image/png',size:13*1024*1024}],7),/12 MB/);
});
test('scene UI prepares Flow prompts and keeps no import/generate image controls in normal mode',()=>{
 assert.match(html,/separateFramesPanel\(\)/);
 assert.match(html,/frames-copy-master/);assert.doesNotMatch(html,/frames-open-flow/);
 const panel=html.split('function separateFramesPanel(){')[1].split('async function importSeparateSceneFrames')[0];
 assert.doesNotMatch(panel,/data-frames-files|frames-generate-all|frames-import-all/);
 assert.match(html,/KFSeparateFrames\.flowScenePrompt\(stills,i\)/);
 assert.match(html,/ProjectStore|kfSaveMetadata|kfAssetSaveChain/);
});
test('version is v5.0.64 with unchanged package name',()=>{
 assert.match(gradle,/5\.1\.27/);assert.match(gradle,/5001027/);
 assert.match(gradle,/applicationId 'id\.kreasiflow\.studio'/);
});
