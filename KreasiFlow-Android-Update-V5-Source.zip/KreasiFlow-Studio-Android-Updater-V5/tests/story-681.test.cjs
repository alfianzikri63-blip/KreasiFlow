const test=require('node:test');
const assert=require('node:assert/strict');
const story=require('../app/src/main/assets/story-681.js');
const planner=require('../app/src/main/assets/scene-planner.js');
const {pcm}=require('../app/src/main/assets/scene-voice.js');
const config={cast:[{id:'a',name:'ASAQ'},{id:'b',name:'ZAYN'},{id:'c',name:'Bimo'},{id:'quiet',name:'Visual'}],
 locations:[{id:'home',name:'Rumah'}],language:'Indonesia',genre:'Slice of Life',perspective:'first',cap:4,slot:4,adapt:true};
const line=(id,text)=>({characterId:id,text,seconds:1,emotion:'tenang',delivery:'pelan'});
const row=(...dialogues)=>({castIds:['a','b','quiet'],locationId:'home',action:'Mereka duduk',dialogues});
test('production presets preserve five real dimensions and bound every scene',()=>{
 assert.deepEqual(Object.keys(story.ratios).map(r=>story.dimensions(r,1080)),[[1080,1920],[1920,1080],[1080,1080],[1080,1350],[2520,1080]]);
 for(const cap of story.caps){
  const text='Saya melihat hujan turun sambil berhenti di halte. '.repeat(15).trim();
  const scenes=planner.planCapped(text,60,cap);
  assert.equal(scenes.length,Math.ceil(60/cap));
  assert.equal(scenes.map(sc=>sc.voice).join(' '),text);
  story.validateTimeline([0,...scenes.map(sc=>sc.endSec)],cap);
 }
 assert.throws(()=>story.validateTimeline([0,10.5],10),/melampaui/);
});
test('perspectives and real experience use separate constraints',()=>{
 for(const perspective of story.perspectives){
  const prompt=story.storyPrompt('ideas',{...config,perspective},5);
  assert.match(prompt,/Beri tepat lima ide/);assert.match(prompt,/Pertahankan kejadian/);
  assert.match(prompt,new RegExp(['pilih sesuai','orang pertama','orang ketiga','tanpa narator'][story.perspectives.indexOf(perspective)]));
 }
 assert.throws(()=>story.scenes({scenes:[row(line('narrator','Pagi hari'))]},{...config,perspective:'dialog'},1),/pembicara/);
});
test('dialogue rows retain IDs, reject invented cast, group only actual speakers',()=>{
 const response={scenes:[row(line('a','Halo'),line('b','Hai')),row(line('c','Pagi'),line('narrator','Mulai'))]};
 const scenes=story.scenes(response,config,2);
 assert.deepEqual(story.groups(scenes).map(([name])=>name),['ASAQ','ZAYN','Bimo','NARATOR']);
 assert.equal(story.groups([scenes[0]])[0][1][0].id,'scene-1-line-1');
 assert.equal(story.groups([{dialogues:[],castIds:['a']}]).length,0);
 assert.throws(()=>story.scenes({scenes:[row(line('unknown','Hai'))]},config,1),/pembicara/);
 assert.throws(()=>story.scenes({scenes:[row(line('a','kata '.repeat(24)))]},config,1),/terlalu panjang/);
});
test('multi VO reorders speech across actors and yields timestamped clean cues',()=>{
 const scenes=story.scenes({scenes:[row(line('a','Halo'),line('b','Hai')),row(line('a','Pagi'))]},config,2);
 const units=story.groups(scenes).flatMap(([,rows],i)=>rows.map(item=>({row:item,samples:new Float32Array(500).fill(i?-.5:.5)})));
 const {clips,cues}=story.align([0,4,8],units,4,1000);
 assert.deepEqual(cues.map(c=>[c.start,c.end,c.text]),[[0,.5,'Halo'],[.62,1.12,'Hai'],[4,4.5,'Pagi']]);
 const wav=new DataView(pcm(clips,1000));
 assert.equal(wav.getInt16(44,true),16384);
 assert.equal(wav.getInt16(44+620*2,true),-16384);
 assert.equal(wav.getInt16(44+4000*2,true),16384);
});
