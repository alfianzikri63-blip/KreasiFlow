const test=require('node:test');
const assert=require('node:assert/strict');
const templates=require('../app/src/main/assets/story-templates-682');
const ideas=require('../app/src/main/assets/story-ideas-682');

const config={
 theme:'Mancing Wader',idea:'Saya ingin membuat kisah di tepi kali.',language:'Indonesia',genre:'Petualangan',
 adapt:false,perspective:'third',lead:['b'],cast:[{id:'a',name:'Tokoh A',profile:'SHEET PRIVATE'},{id:'b',name:'Tokoh B',voice:'VOICE PRIVATE'}],
 locations:[{id:'river',name:'LOCATION PRIVATE'}],memory:'MEMORY PRIVATE',director:'DIRECTOR PRIVATE',ratio:'21:9',render:'RENDER PRIVATE'
};
function payload(){
 return {ideas:Array.from({length:5},(_,i)=>({title:'Percobaan '+(i+1),synopsis:'Tokoh memancing wader di tikungan sungai '+i+'.',conflict:'Umpan hilang saat arus naik.',characters:['Tokoh A'],locations:['Tepi sungai'],mood:'Tegang'}))};
}
test('200 individually authored premises with all six fields and no character names fixed in templates',()=>{
 assert.equal(templates.categories.length,20);
 assert.equal(templates.templates.length,200);
 for(const key of ['id','title','synopsis','conflict'])assert.equal(new Set(templates.templates.map(row=>row[key])).size,200);
 for(const category of templates.categories){
  const rows=templates.list(category.id);
  assert.equal(rows.length,10);
  assert.ok(rows.every(row=>row.title&&row.synopsis&&row.conflict&&row.locations.length&&row.roles.length&&row.genre));
 }
 assert.ok(!templates.templates.some(row=>/\b(ASAQ|ZAYN)\b/.test(JSON.stringify(row))));
 const sample=templates.find('memancing-1');
 const cast=[{id:'a',name:'Nara'},{id:'b',name:'Tika'}];
 assert.deepEqual(templates.assign(sample,cast,['b']).map(r=>r.name),['Tika','Nara']);
 assert.ok(templates.assign(sample).every(r=>!r.name&&r.role));
});
test('idea context contains current names, genre, narrative perspective and theme, without production data',()=>{
 const context=ideas.context({storyMode:'single'},config,'openrouter','my-model');
 assert.equal(context.model,'my-model');
 assert.equal(context.mode,'standalone');
 assert.equal(context.theme,'Mancing Wader');
 assert.deepEqual(context.cast,[{name:'Tokoh A',lead:false},{name:'Tokoh B',lead:true}]);
 assert.equal(ideas.context({storyMode:'series'},config,'gemini','my-model').mode,'series');
 const prompt=ideas.prompt(context);
 assert.match(prompt,/orang ketiga/);assert.match(prompt,/Mancing Wader/);assert.match(prompt,/Petualangan/);
 assert.match(prompt,/Tokoh B \(utama\)/);
 assert.doesNotMatch(prompt,/PRIVATE|21:9|storyboard|character sheet/i);
 assert.ok(prompt.length<1500);
 for(const [perspective,expected] of [['first','orang pertama'],['dialog','tanpa narator'],['auto','pilih perspektif']]){
  assert.ok(ideas.prompt({...context,perspective}).includes(expected));
 }
});
test('all five ideas must contain fishing activity and wader in synopsis or conflict',()=>{
 const result=payload();
 assert.equal(ideas.parse(JSON.stringify(result),config.theme).length,5);
 result.ideas[4].synopsis='Tokoh memancing mujair.';
 assert.throws(()=>ideas.parse(JSON.stringify(result),config.theme),/Ide 5.*sesuai tema/);
 result.ideas[4].synopsis='Tokoh memasak ikan wader di rumah.';
 result.ideas[4].conflict='Bumbu habis.';
 assert.throws(()=>ideas.parse(JSON.stringify(result),config.theme),/Ide 5.*sesuai tema/);
 assert.equal(ideas.suggestCategory(config.theme),'memancing');
});
test('rejects malformed, missing and duplicate ideas, while accepting fenced JSON',()=>{
 const result=payload();
 assert.equal(ideas.parse('```json\n'+JSON.stringify(result)+'\n```','').length,5);
 assert.throws(()=>ideas.parse('{ broken',''),/tidak terbaca/);
 const cropped=structuredClone(result);cropped.ideas.pop();
 assert.throws(()=>ideas.parse(JSON.stringify(cropped),''),/lima ide/);
 result.ideas[4].synopsis=result.ideas[3].synopsis;
 assert.throws(()=>ideas.parse(JSON.stringify(result),''),/ide yang sama/);
});
