const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const svc=fs.readFileSync('app/src/main/java/id/kreasiflow/studio/AiForegroundService.java','utf8');
const api=fs.readFileSync('app/src/main/java/id/kreasiflow/studio/MultiProviderApi.java','utf8');
const ui=fs.readFileSync('app/src/main/assets/index.html','utf8');
const gradle=fs.readFileSync('app/build.gradle','utf8');
test('storyboard selects two explicit free text-capable fallback models instead of random openrouter/free',()=>{
 assert.match(svc,/"openrouter\/free"\.equals\(configured\)/);
 assert.match(svc,/"google\/gemma-4-26b-a4b-it:free"/);
 assert.match(svc,/"inclusionai\/ling-3\.2-flash:free"/);
 assert.match(svc,/new String\[\]\{"openrouter"\.equals\(provider\)\?configured:"groq"\.equals\(provider\)\?"openai\/gpt-oss-20b":"cloudflare"\.equals\(provider\)\?"@cf\/meta\/llama-3\.3-70b-instruct-fp8-fast":"nvidia"\.equals\(provider\)\?"google\/gemma-4-31b-it":"gemini"\}/);
});
test('native request has hard per-read limit and asks for JSON instead of invisible reasoning',()=>{
 assert.match(api,/connection\.setReadTimeout\(60000\)/);
 assert.match(api,/"reasoning",new JSONObject\(\)\.put\("effort","none"\)/);
 assert.match(api,/"response_format",new JSONObject\(\)\.put\("type","json_object"\)/);
 assert.match(api,/"max_completion_tokens"/);
 assert.match(svc,/"storyboard_job",storyboard&&!"gemini"\.equals\(provider\)/);
});
test('parses visible text content from multiple OpenRouter formats without exposing hidden reasoning',()=>{
 assert.match(svc,/part\.optString\("text",part\.optString\("output_text",""\)\)/);
 assert.match(svc,/"model tidak menghasilkan teks"/);
 assert.match(svc,/"reasoning_tokens"/);
 assert.match(svc,/validateStoryboardJson\(body,indices\)/);
 assert.doesNotMatch(svc,/output\.append\(message\.optString\("reasoning"/);
});
test('no local draft generator; previous local scenes remain labelled non-AI',()=>{
 assert.doesNotMatch(ui,/btn\('storyboard-local-draft'/);
 assert.doesNotMatch(ui,/case 'storyboard-local-draft'/);
 assert.doesNotMatch(ui,/S\.storyboardSource='draft-local'/);
 assert.match(ui,/Scene lama \(bukan AI\)/);
 assert.match(ui,/S\.storyboardSource==='draft-local'/);
});
test('version and project features retained',()=>{
 assert.match(gradle,/5\.1\.19/);
 assert.match(gradle,/5001019/);
 for(const id of ['project-import-zip','sheet-generate','subtitle-ai','render-ai-motion'])assert.ok(ui.includes(id),id);
});
