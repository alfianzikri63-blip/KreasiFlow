const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const R=require('../app/src/main/assets/storyboard-resilience.js');
const src=fs.readFileSync('app/src/main/assets/index.html','utf8');
const make=(number)=>({scene:number,title:'Pemandangan di pelabuhan',action:'The fisherman lifts a heavy net while a wooden boat moves across water.',camera:'Wide shot from a low angle with a controlled slow tracking move.',setting:'Traditional harbor, fishing boats and blue water',image_prompt:'Photorealistic fishing boat and fisherman lifting a net under morning light.',video_prompt:'Slow steady tracking camera as fisherman pulls in a net with visible physical effort.'});
test('parses fenced AI JSON and explanatory prologue safely',()=>{
 const raw='Here is the result:\n```json\n'+JSON.stringify({scenes:[make(1)]})+'\n```';
 assert.equal(R.rows(raw,[0])[0].scene,1);
});
test('accepts aliases while preserving AI-authored action and image prompt',()=>{
 const obj={storyboard:[{scene_number:'2',name:'Penjaga Hutan',visual_action:make(2).action,camera_angle:make(2).camera,location:make(2).setting,imagePrompt:make(2).image_prompt,motionPrompt:make(2).video_prompt}]};
 const scenes=R.rows(obj,[1]); assert.equal(scenes[0].scene,2);assert.equal(scenes[0].image_prompt,make(2).image_prompt);
});
test('derives missing prompts only from AI-written shot information, never local template scene',()=>{
 const one=make(1);delete one.video_prompt;delete one.image_prompt;
 const scenes=R.rows({scenes:[one]},[0]);assert.match(scenes[0].video_prompt,/fisherman/);assert.match(scenes[0].image_prompt,/Traditional harbor/);
});
test('rejects missing required AI shot descriptions',()=>{
 const one=make(1);delete one.action;
 assert.throws(()=>R.rows({scenes:[one]},[0]),/belum melengkapi/);
});
test('rejects wrong scene count and reordered scene numbers',()=>{
 assert.throws(()=>R.rows({scenes:[make(2)]},[0]),/Nomor scene/);
 assert.throws(()=>R.rows({scenes:[make(1)]},[0,1]),/seharusnya 2/);
});
test('chooses fallback AI when preferred key missing',()=>{
 assert.deepEqual(R.preferredList('gemini',{gemini:false,openrouter:true}),['openrouter']);
 assert.deepEqual(R.preferredList('gemini',{gemini:true,openrouter:true}),['gemini','openrouter']);
 assert.deepEqual(R.preferredList('openrouter',{gemini:true,openrouter:true}),['openrouter','gemini']);
});
test('bounded provider fallback attempts available providers once each',async()=>{
 const used=[];
 const res=await R.attempt(['gemini','openrouter'],async p=>{used.push(p);if(p==='gemini')throw Error('Gemini HTTP 503');return {scenes:[make(1)]}});
 assert.deepEqual(used,['gemini','openrouter']);assert.equal(res.provider,'openrouter');
});
test('preserves both provider failure details when no fallback succeeds',async()=>{
 await assert.rejects(R.attempt(['openrouter','gemini'],async p=>{throw Error(p==='openrouter'?'HTTP 429':'Gemini HTTP 503');}),/OpenRouter|openrouter.*429.*gemini.*503/i);
});
test('cache signature changes when narration or selected art style changes',()=>{
 const a=R.fingerprint({narration:'hi',style:'stickman'});
 assert.notEqual(a,R.fingerprint({narration:'hello',style:'stickman'}));
 assert.notEqual(a,R.fingerprint({narration:'hi',style:'realism'}));
});
test('UI connects automatic provider fallback, cache, detailed error and storyboard scene difference checker',()=>{
 assert.match(src,/function storyboardProviders/);
 assert.match(src,/storyboardSaveCache/);
 assert.match(src,/storyboardLastError/);
 assert.match(src,/requestStoryboardBatch/);
 assert.match(src,/const check=auditedScenes\(draft\)/);
 assert.match(src,/KFStoryboardResilience\.rows/);
 assert.match(src,/<script src="storyboard-resilience\.js"><\/script>/);
});
test('planning resumes completed AI batches after an error, without recreating previous scenes',async()=>{
 const vm=require('node:vm');
 const start=src.indexOf('function validateStoryboardRows(rows,indices)');
 const end=src.indexOf('function sceneFromAi(p,row,old)',start);
 const code=src.slice(start,end);
 const storage=new Map();
 const calls=[];
 let failThird=true;
 const context={
  KFStoryboardResilience:R,
  S:{sceneStyle:'Stickman Putih',ratio:'9:16',character:'',sceneEvery:5},
  getTopic:()=> 'Cerita uji',
  notify:()=>{},opFor:()=>{},
  localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},
  storyboardProviders:()=>['openrouter'],
  storyboardGetCache:()=>{const value=storage.get('cache');return value?JSON.parse(value):{key:'scenario-1',rows:{}}},
  storyboardSaveCache:c=>storage.set('cache',JSON.stringify(c)),
  callTextAI:async(prompt,{provider})=>{
    assert.equal(provider,'openrouter');
    const indices=JSON.parse(prompt.slice(prompt.lastIndexOf('INPUT: ')+7)).requested.map(x=>x.scene);
    calls.push(indices.join(','));
    if(indices.includes(3)&&failThird)throw Error('HTTP 503');
    return JSON.stringify({scenes:indices.map(make)});
  }
 };
 vm.createContext(context);vm.runInContext(code,context);
 const planned=Array.from({length:3},(_,i)=>({voice:'scene '+(i+1)}));
 await assert.rejects(context.planStoryboardRows(planned,[0,1,2],[],null,{useCache:true}),/Scene 3/);
 assert.ok(storage.has('cache'));
 assert.equal(Object.keys(JSON.parse(storage.get('cache')).rows).length,2);
 failThird=false;
 const rows=await context.planStoryboardRows(planned,[0,1,2],[],null,{useCache:true});
 assert.equal(rows.length,3);
 assert.equal(calls.filter(x=>x==='1,2').length,1,'Scene 1/2 should be reused from cache');
});
