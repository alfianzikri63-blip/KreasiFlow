const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const sheet=require('../app/src/main/assets/storyboard-sheet.js');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const gradle=fs.readFileSync('app/build.gradle','utf8');

test('a seven-scene sheet is a single 4x2 grid and one empty tile',()=>{
 assert.deepEqual(sheet.grid(7),{count:7,cols:4,rows:2,empty:1});
});
test('manual 2-column selection supports external Gemini 2x4 sheets',()=>{
 assert.deepEqual(sheet.grid(7,'2'),{count:7,cols:2,rows:4,empty:1});
});
test('sheet prompt contains seven distinct instructions and a single image request',()=>{
 const scenes=Array.from({length:7},(_,i)=>({prompt:'A different physical event '+i+' with a tsunami early warning sensor and glowing cyan pulse',flowShot:{camera:'different camera angle '+i}}));
 const p=sheet.prompt({scenes,style:'Motion Graphic 3D',ratio:'9:16',title:'Tsunami',character:'ASAQ'});
 assert.match(p,/CREATE EXACTLY ONE STORYBOARD CONTACT SHEET/);
 assert.match(p,/4 COLUMNS x 2 ROWS/);
 assert.match(p,/PANEL 01/);assert.match(p,/PANEL 07/);
 assert.doesNotMatch(p,/PANEL 08/);
 assert.match(p,/NO labels/i);
 assert.match(p,/Google Flow will animate the cropped panels separately/);
 assert.match(p,/Recurring character identity: ASAQ/);
});
test('panel crops preserve chronological row-major order, 9:16 aspect and no duplication',()=>{
 const tiles=sheet.tiles(1800,1600,7,'9:16');
 assert.equal(tiles.length,7);
 assert.equal(tiles[0].cell.x,0);assert.equal(tiles[0].cell.y,0);
 assert.equal(tiles[1].cell.x,450);assert.equal(tiles[1].cell.y,0);
 assert.equal(tiles[4].cell.x,0);assert.equal(tiles[4].cell.y,800);
 assert.equal(tiles[6].cell.x,900);assert.equal(tiles[6].cell.y,800);
 assert.equal(tiles[0].width/tiles[0].height,9/16);
 assert.ok(tiles.every(x=>x.x>=x.cell.x&&x.y>=x.cell.y&&x.x+x.width<=x.cell.x+x.cell.width+0.01&&x.y+x.height<=x.cell.y+x.cell.height+0.01));
});
test('landscape sheet crops preserve 16:9 output',()=>{
 const t=sheet.tiles(1600,900,3,'16:9');
 assert.equal(t.length,3);
 assert.ok(t.every(r=>Math.abs(r.width/r.height-16/9)<0.00001));
});
test('bad count and low-resolution images fail safely',()=>{
 assert.throws(()=>sheet.grid(17),/1–16/);
 assert.throws(()=>sheet.grid(0),/1–16/);
 assert.throws(()=>sheet.tiles(200,200,7),/terlalu kecil/);
});
test('one sheet image can be created once with Gemini or uploaded externally',()=>{
 for(const text of ['storySheetPanel','makeStoryboardSheetGemini','requestProviderAPI(\'gemini\'','data-sheet-file','KFStoryboardSheet.tiles','new Blob','storyboard_sheet']){
  assert.ok(html.includes(text),'missing '+text);
 }
 assert.match(html,/case 'sheet-copy'/);
 assert.match(html,/case 'sheet-generate'/);
 assert.match(html,/case 'sheet-save'/);
 assert.match(html,/canvas\.toBlob\(/);
});
test('sheet itself and all separately cropped scene frames are kept with the project',()=>{
 assert.match(html,/key:'storyboard_sheet'/);
 assert.match(html,/key:'scene_image_'/);
 assert.match(html,/else if\(key==='storyboard_sheet'\)/);
 assert.match(html,/S\.storyboardSheetMeta=/);
});
test('user is told images are made and used in Google Flow, and clips still generate separately',()=>{
 const panel=html.split('function separateFramesPanel(){')[1].split('async function importSeparateSceneFrames')[0];
 assert.match(panel,/Google Flow/);
 assert.match(panel,/Flow hanya membuat satu/);
 assert.match(html,/Frames to Video/);
 assert.match(html,/Impor Semua MP4 Google Flow/);
});
test('release version is 5.0.64 and package id has not changed',()=>{
 assert.match(gradle,/5\.0\.69/);
 assert.match(gradle,/5000069/);
 assert.match(gradle,/applicationId 'id\.kreasiflow\.studio'/);
});

test('Android ProjectStore supports storyboard_sheet and only image types',()=>{
 const java=fs.readFileSync('app/src/main/java/id/kreasiflow/studio/ProjectStore.java','utf8');
 assert.match(java,/music\|storyboard_sheet\|scene_image_/);
 assert.match(java,/key\.equals\("storyboard_sheet"\)/);
});
test('a single tap can export all cropped frames to Downloads for manual Flow attachment',()=>{
 assert.match(html,/async function saveAllStoryboardFrames\(/);
 assert.match(html,/case 'sheet-save-frames'/);
 assert.match(html,/KreasiFlow-Frame-/);
 assert.match(html,/nativeSaveBlob\(blob,name\)/);
});
