const {test}=require('node:test');const assert=require('node:assert/strict');const v=require('../app/src/main/assets/studio-v6.js');
test('empty production is not ready',()=>assert.equal(v.readiness().percent,0));
test('complete checklist',()=>assert.equal(v.readiness({title:'a',script:'b',audio:true,scenes:[{clip:true},{image:true}]}).percent,100));
test('missing scene media',()=>assert.equal(v.readiness({scenes:[{clip:true},{}]}).ready,1));
test('draft failure reported',()=>assert.equal(v.saveDraft({setItem(){throw Error('quota');}},{}),false));
test('draft saves existing storage key',()=>{let row;assert.equal(v.saveDraft({setItem(...a){row=a;}},{title:'x'}),true);assert.deepEqual(row,['kreasiflow-current-v3','{"title":"x"}']);});
test('only newer draft for same project wins',()=>{assert.equal(v.preferDraft({projectId:'a',draftUpdatedAt:2},{projectId:'a',draftUpdatedAt:1}),true);assert.equal(v.preferDraft({projectId:'b',draftUpdatedAt:2},{projectId:'a'}),false);assert.equal(v.preferDraft({projectId:'a',draftUpdatedAt:1},{projectId:'a',draftUpdatedAt:2}),false);});
