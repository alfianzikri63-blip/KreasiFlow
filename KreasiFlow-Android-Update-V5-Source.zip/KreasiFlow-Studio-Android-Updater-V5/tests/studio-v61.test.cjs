const test=require('node:test'),a=require('node:assert/strict'),m=require('../app/src/main/assets/studio-v61.js');
test('research query encoded',()=>a.equal(new URL(m.researchUrl('a&b')).searchParams.get('gsrsearch'),'a&b'));
test('sources reject foreign urls',()=>a.equal(m.sources({query:{pages:{a:{extract:'x',fullurl:'https://evil.test/'},b:{extract:'y',fullurl:'https://id.wikipedia.org/wiki/Y'}}}}).length,1));
test('subtitle reading speed',()=>a.equal(m.audit([{start:0,end:1,text:'x'.repeat(21)}]).length,1));
test('estimate',()=>a.equal(m.estimate(60,4000000),30));
test('camera variation',()=>a.notEqual(m.camera(0),m.camera(1)));
