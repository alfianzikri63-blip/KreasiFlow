const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const M=require('../app/src/main/assets/motion-graphic-styles.js');
const Frames=require('../app/src/main/assets/separate-scene-frames.js');
const Saver=require('../app/src/main/assets/flow-credit-saver.js');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const expected=['Isometric 3D Cinematic','Claymation 3D','Cinematic 3D Cartoon','Scientific 3D Cutaway','Low Poly 3D','Toy Brick Animation','Tiny World Macro','Cinematic Hyperrealistic','Paper Cut Animation','Graphic Novel Cinematic','Cinematic Anime','Classical Engraving','Flat Motion Graphic','Exploded View 3D','Satellite Earth Cinematic','3D Topographic Terrain','Geopolitical Dark Map','Historical Atlas Animation','Geo Data Visualization','Cinematic Route Map','Isometric Geo City','Geological Cross Section'];
test('all requested styles have distinct visual and motion rules and correct categories',()=>{
 assert.deepEqual(M.names().slice(5),expected);assert.equal(new Set(expected.map(M.t2i)).size,22);assert.equal(new Set(expected.map(M.i2v)).size,22);
 for(const [i,n] of expected.entries()){assert.equal(M.get(n).category,i<7?'Animasi 3D':i<14?'Artistik & Storytelling':'Geo Map');assert.match(M.t2i(n),/T2I STYLE LOCK/);assert.match(M.i2v(n),/I2V STYLE LOCK/);assert.ok(M.get(n).bible.length>100);assert.ok(M.get(n).movement.length>80);assert.ok(html.includes(n));}
});
test('8 Geo Map categories provide distinct titles and compatible recommended presets',()=>{
 assert.equal(Object.keys(M.GEO_TOPICS).length,8);for(const [key,g] of Object.entries(M.GEO_TOPICS)){assert.ok(M.isGeo(g.style));assert.ok(html.includes(key));assert.equal(M.topicTitles(key).length,4);assert.equal(M.topicTitles(key,'Jawa').length,7);assert.match(M.geoTextRule(key,'Semua'),/Do not invent statistics/);assert.match(M.t2i(g.style),/verified map\/reference/);assert.match(M.i2v(g.style),/Do not invent routes/);}
 assert.deepEqual(M.topicTitles('unknown'),[]);assert.equal(M.geoTextRule('Sejarah','Semua'),' ');
});
test('T2I master and per-scene prompt include full geography lock and separate scene content',()=>{
 const input={scenes:[{prompt:'A volcano beside the coast'},{prompt:'River valley near a town'}],style:'3D Topographic Terrain',styleRules:M.t2i('3D Topographic Terrain'),fullStyleRules:true,ratio:'16:9'};
 const master=Frames.flowMasterPrompt(input);assert.match(master,/SCENE 01/);assert.match(master,/SCENE 02/);assert.match(master,/A volcano beside the coast/);assert.match(master,/River valley near a town/);assert.match(master,/add verified labels and legends in editing/);assert.match(Frames.flowScenePrompt(input,1),/River valley near a town/);
});
test('every I2V preset enters the actual Flow prompt and respects duration/audio',()=>{
 for(const style of expected){const p=Saver.imageToVideoPrompt({index:1,duration:4,ratio:'9:16',style,styleRules:M.i2v(style),action:'Visible object moves',camera:'slow pan',audioMode:'mute'});assert.ok(p.includes(M.i2v(style)));assert.match(p,/SCENE 2/);assert.match(p,/EXACTLY 4 seconds/);assert.match(p,/Audio: SILENT/);}
});
test('actual image-first UI prompt calls the new style rules and separate master is wired',()=>{
 const ctx={S:{sceneStyle:'Cinematic Route Map',scenes:[{voice:'Kapal membawa barang',flowShot:{action:'Ship travels along route',camera:'gentle pan',setting:'sea'}}],flowCreditMode:'image-first',flowI2VDuration:4,flowI2VAudioMode:'mute',ratio:'9:16',character:''},KreasiFlowFlowShots:{makeShot:(_,__,v)=>v},KreasiFlowMotionStyles:M,KFFlowSaver:Saver,motionStyleRule:()=>M.rule(ctx.S.sceneStyle)};
 vm.createContext(ctx);vm.runInContext(html.slice(html.indexOf('function googleFlowPrompt(i)'),html.indexOf('function simpleFlowSceneCard')),ctx);assert.match(ctx.googleFlowPrompt(0),/Trace only a verified/);assert.match(html,/case 'frames-copy-video-master':await copy\(flowDirectMasterVideoPrompt\(\)\)/);assert.match(html,/geoTopicPanel\(\)/);assert.match(html,/case 'geo-apply-style':geoApplyStyle\(\)/);assert.match(html,/function styleOptions\(/);
});
test('legacy default and old style logic remain unchanged',()=>{assert.match(M.rule('2D Flat Vector Motion Graphic'),/STRICT NO-3D RULE/);assert.equal(M.i2v('Motion Graphic 2D'),'');assert.equal(M.t2i('Motion Graphic 2D'),M.rule('Motion Graphic 2D'));assert.match(html,/sceneStyle:'2D Flat Vector Motion Graphic'/);});
