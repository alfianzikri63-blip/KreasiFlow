const assert=require('node:assert/strict');const x=require('../app/src/main/assets/subtitle-timeline.js');
assert.equal(x.seconds('00:01:02,345'),62.345);assert.equal(x.clock(62.345),'00:01:02,345');
const srt=`1\n00:00:00,000 --> 00:00:02,000\nHalo semua!\n\n2\n00:00:02,100 --> 00:00:04,300\nKita ke pantai.\n`;
let cues=x.parse(srt);assert.equal(cues.length,2);assert.equal(cues[0].text,'Halo semua!');assert.deepEqual(x.validate(cues,5),[]);assert.equal(x.cueAt(cues,3),1);assert.equal(x.cueAt(cues,2.05),-1);
assert.deepEqual(x.parse(x.serialize(cues)),cues);
assert.ok(x.validate([{start:0,end:4,text:'A'},{start:3,end:6,text:'B'}],5).length>=2);
const estimate=x.estimate('Ini adalah kalimat pertama yang cukup panjang. Lalu kalimat kedua yang singkat.',12);assert.ok(estimate.length>=2);assert.equal(estimate[0].start,0);assert.equal(estimate.at(-1).end,12);assert.deepEqual(x.validate(estimate,12),[]);assert.equal(estimate.map(x=>x.text).join(' ').replace(/\s+/g,' '),'Ini adalah kalimat pertama yang cukup panjang. Lalu kalimat kedua yang singkat.');
console.log('subtitle-timeline test passed');
