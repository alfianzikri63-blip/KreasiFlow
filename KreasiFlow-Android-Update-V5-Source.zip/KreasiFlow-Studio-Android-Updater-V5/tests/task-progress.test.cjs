const {test}=require('node:test');
const assert=require('node:assert/strict');
const progress=require('../app/src/main/assets/task-progress.js');
test('percent is monotonic and stops at 99 until success',()=>{
 const p=progress.create(),id=p.start('Storyboard AI');
 p.update(id,30,'Batch 1');p.update(id,10,'Batch 2');assert.equal(p.get(id).percent,30);
 p.update(id,200);assert.equal(p.get(id).percent,99);p.finish(id,true);
 assert.equal(p.get(id).percent,100);assert.equal(p.get(id).state,'done');
 p.update(id,4);assert.equal(p.get(id).percent,100);
});
test('error does not display fake 100%',()=>{
 const p=progress.create(),id=p.start('Import MP4');p.update(id,60);
 p.finish(id,false,'Jaringan terputus');assert.equal(p.get(id).percent,60);
 assert.equal(p.get(id).state,'error');assert.match(p.get(id).detail,/terputus/);
});
test('independent simultaneous operations do not overwrite each other',()=>{
 const p=progress.create(),a=p.start('AI'),b=p.start('Render');
 p.steps(a,2,5);p.steps(b,3,4);assert.equal(p.get(a).percent,40);
 assert.equal(p.get(b).percent,75);p.finish(a,true);
 assert.equal(p.get(b).state,'running');p.forget(a);assert.equal(p.get(a),null);
});
test('invalid step counts rejected',()=>{
 const p=progress.create(),a=p.start('Test');assert.throws(()=>p.steps(a,1,0));
});
