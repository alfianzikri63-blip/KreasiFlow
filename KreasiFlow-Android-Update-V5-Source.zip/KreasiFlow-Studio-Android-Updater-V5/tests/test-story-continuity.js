const assert=require('node:assert/strict');
const eng=require('../app/src/main/assets/story-consistency.js');
const examples=[
 ['simple','Pria yang sama menyiapkan adonan pisang. Ia memasukkan pisang ke wajan. Gorengan diangkat dan ditiriskan. Ia mencicipi makanan yang sudah matang.',60,8],
 ['5-minutes',Array.from({length:75},(_,i)=>`Pada langkah ${i+1}, seorang koki mempersiapkan makanan dan mengamati perubahan suhu secara perlahan.`).join(' '),300,8],
 ['long-sentence','Koki yang sama terus memasak dengan teliti '.repeat(45),60,8],
 ['paragraphs','Satu kejadian terjadi.\n\nKemudian datang kejadian lain.\n\nPada akhirnya masalah selesai.',30,6]
];
for(const [name,text,dur,clip] of examples){
 const scenes=eng.splitNarration(text,dur,clip);
 assert(scenes.length>0);
 assert.equal(eng.narrationMatches(text,scenes),true,name+' dropped or duplicated words');
 eng.assertScenes(text,scenes);
 scenes.forEach((s,i)=>{
   assert(s.endSec>s.startSec);
   assert(s.startSec>=0);
   if(i>0) assert.equal(s.startSec,scenes[i-1].endSec);
   assert(s.endSec<=dur);
 });
 assert.equal(scenes.at(-1).endSec,dur);
 console.log(name,scenes.length,'scenes,',dur,'sec target,',eng.wordCount(text),'words');
}
assert.equal(eng.splitNarration('',60).length,0);
const short='Satu kalimat saja.'; assert.equal(eng.splitNarration(short,300,8).length,1);
console.log('PASS: scene continuity: no dropped words, duplicates, empty scenes, invalid times.');
