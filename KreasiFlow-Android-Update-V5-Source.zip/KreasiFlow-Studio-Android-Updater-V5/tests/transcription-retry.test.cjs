const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const helper=require('../app/src/main/assets/transcription-retry.js');
const base=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(base,'app/src/main/assets/index.html'),'utf8');
const java=fs.readFileSync(path.join(base,'app/src/main/java/id/kreasiflow/studio/GeminiApi.java'),'utf8');
const main=fs.readFileSync(path.join(base,'app/src/main/java/id/kreasiflow/studio/MainActivity.java'),'utf8');
test('audio plan limited to three whitelisted model calls',()=>{assert.deepEqual(helper.PLAN.map(x=>x.model),['gemini-3.6-flash','gemini-3.8-flash','gemini-3.8-flash']);});
test('retry 503 switches to second model after wait; progress describes attempts',async()=>{
 const calls=[], stages=[], sleeps=[];
 const result=await helper.run(async(model,n)=>{calls.push([model,n]);if(n===1)throw Error('Gemini HTTP 503: high demand');return {segments:[]}},x=>stages.push(x),async ms=>sleeps.push(ms));
 assert.equal(calls.length,2);assert.equal(calls[1][0],'gemini-3.8-flash');assert.deepEqual(sleeps,[3000]);assert.equal(result.segments.length,0);
 assert.deepEqual(stages.map(x=>x.stage),['request','wait','request']);
});
test('capacity errors stop after exactly three attempts with friendly error',async()=>{
 const calls=[],sleeps=[];
 await assert.rejects(()=>helper.run(async(model,n)=>{calls.push(n);throw Error('Gemini HTTP 503: overloaded')},()=>{},async ms=>sleeps.push(ms)),/3 percobaan/);
 assert.deepEqual(calls,[1,2,3]);assert.deepEqual(sleeps,[3000,8000]);
});
test('auth and quota errors are never retried',async()=>{
 for(const status of [401,403,429]){
  let n=0;
  await assert.rejects(()=>helper.run(async()=>{n++;throw Error('Gemini HTTP '+status+': forbidden')},()=>{},async()=>{}),new RegExp(status.toString()));
  assert.equal(n,1);
 }
});
test('404 from original model uses alternate once; 404 from backup halts',async()=>{
 let n=0;
 await assert.rejects(()=>helper.run(async()=>{n++;throw Error('Gemini HTTP 404: missing')},()=>{},async()=>{}),/model cadangan/i);
 assert.equal(n,2);
});
test('transcription UI sends the allowlisted audio_model and keeps progress',()=>{
 assert.match(html,/KFTranscriptionRetry\.run/);
 assert.match(html,/audio_model:model/);
 assert.match(html,/maksimal 3 permintaan/);
 assert.match(html,/opFor\('subtitle-ai',stage\.percent,msg\)/);
 assert.match(html,/Only replace existing cues after a fully validated result/);
 assert.match(main,/audioModel=input\.optString\("audio_model","gemini-3\.6-flash"\)/);
 assert.match(java,/if\(!"gemini-3\.6-flash"\.equals\(audioModel\) && !"gemini-3\.8-flash"\.equals\(audioModel\)\)/);
});
