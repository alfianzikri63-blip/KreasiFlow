const assert=require('node:assert/strict');
const {test}=require('node:test');
const timing=require('../app/src/main/assets/voice-timing-682.js');
const library=require('../app/src/main/assets/story-templates-682.js');
const story=require('../app/src/main/assets/story-681.js');

test('timed scenes preserve entire segments and end at actual audio length for every target',()=>{
 const cues=[{start:.45,end:12.7,text:'Kalimat panjang yang dibaca perlahan.'},{start:13.2,end:15.5,text:'Tokoh tiba di dermaga.'},{start:15.7,end:16,text:'Diam.'}];
 for(const target of [0,4,6,8,10]){
  const scenes=timing.fromTranscript(cues,17.35,target);
  assert.equal(scenes[0].startSec,0);
  assert.equal(scenes.at(-1).endSec,17.35);
  assert.ok(scenes[0].durationSec>10);
  assert.equal(scenes.map(scene=>scene.voice).join(' '),cues.map(cue=>cue.text).join(' '));
  assert.ok(scenes.slice(1).every(scene=>!cues.some(cue=>cue.start<scene.startSec&&scene.startSec<cue.end)));
 }
});
test('scene preferences affect grouping but leave overlapping cues intact',()=>{
 const cues=[{start:0,end:1,text:'A.'},{start:.8,end:2,text:'B.'},{start:2.6,end:4,text:'C.'}];
 assert.deepEqual(timing.fromTranscript(cues,5,0).map(x=>x.voice),['A. B.','C.']);
 assert.deepEqual(timing.fromTranscript(cues,5,10).map(x=>x.voice),['A. B. C.']);
});
test('existing scenes align to real pauses rather than evenly dividing audio',()=>{
 const cues=[{start:0,end:12,text:'Kalimat pertama.'},{start:13,end:14,text:'Kalimat kedua.'}];
 assert.deepEqual(timing.align([0,7,15],cues,[],15),[0,12.5,15]);
 assert.equal(timing.align([0,5,10,15],cues,[],15),null);
 assert.doesNotThrow(()=>story.validateTimeline([0,12.5,15]));
});
test('batch merge orders actors, preserves source silence and separates natural dialog from actual samples',()=>{
 const rate=100,scenes=[{}, {}, {startSec:0,endSec:1.5}];
 const a={row:{i:0,j:0,id:'one',text:'Satu'},source:'a',start:20,end:1270,length:1390,samples:new Float32Array(1250).fill(.25)};
 const b={row:{i:0,j:1,id:'two',text:'Dua'},source:'a',start:1300,end:1350,length:1390,samples:new Float32Array(50).fill(.5)};
 const c={row:{i:1,j:0,id:'three',text:'Tiga'},source:'b',start:100,end:150,length:190,samples:new Float32Array(50).fill(.75)};
 const result=timing.batch(scenes,[c,b,a],rate);
 assert.deepEqual(result.starts,[0,13.5,14.52,16.02]);
 assert.deepEqual(result.cues.map(({start,end,dialogueId})=>[start,end,dialogueId]),[[.2,12.7,'one'],[13,13.5,'two'],[13.62,14.12,'three']]);
 assert.equal(result.clips[1][1],.25);
 assert.equal(result.clips[2].length,30);
});
test('fade law preserves full gain between fades and reaches silence at both ends',()=>{
 assert.deepEqual([0,.25,1,2.5,3].map(t=>timing.envelope(t,3,1,1)),[0,.25,1,.5,0]);
 assert.equal(timing.envelope(.1,3,0,0),1);
});
test('all offline categories have distinct media, search and development tied to the setting',()=>{
 assert.equal(new Set(library.categories.map(x=>x.image)).size,20);
 assert.equal(library.list('all').length,200);
 assert.ok(library.templates.every(x=>x.development.includes(x.locations[0].toLowerCase())));
 const fishing=library.list('all','wader');assert.ok(fishing.length);
 assert.ok(fishing.every(x=>x.category==='memancing'));
 assert.equal(library.list('romantis','wader').length,0);
 assert.equal(library.assign(fishing[0],[{id:'a',name:'ASAQ'}],['a'])[0].name,'ASAQ');
});
