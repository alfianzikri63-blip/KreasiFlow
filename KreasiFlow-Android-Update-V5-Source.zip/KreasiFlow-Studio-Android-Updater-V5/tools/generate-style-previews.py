from pathlib import Path
import re,json,random,math,html
from PIL import Image
import cairosvg,io
root=Path('app/src/main/assets'); src=(root/'index.html').read_text(); names=[m[0] or m[1] for m in re.findall(r'''\[\s*(?:'([^']+)'|"([^"]+)")\s*,\s*(?:'[^']+'|"[^"]+")\s*,''',src[src.index('const visualStyles='):src.index('// v5.0.41')])]; assert len(names)==76, len(names)
folder=root/'style-previews';folder.mkdir(exist_ok=True)
# Purpose-built original reference illustrations. Same canvas, varied techniques and compositions.
W,H=640,360
class Art:
 def __init__(self,i,bg='#20374b'):
  self.r=random.Random(140+i);self.i=i;self.a=[];self.defs=[];self.rect(0,0,W,H,bg)
 def add(self,s):self.a.append(s)
 def rect(self,x,y,w,h,c,rx=0,stroke='none',sw=1):self.add(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{c}" stroke="{stroke}" stroke-width="{sw}"/>')
 def poly(self,p,c,stroke='none',sw=1):self.add(f'<polygon points="'+ ' '.join(f'{x:.1f},{y:.1f}' for x,y in p)+f'" fill="{c}" stroke="{stroke}" stroke-width="{sw}" stroke-linejoin="round"/>')
 def line(self,p,c,sw=2,dash=''):self.add(f'<polyline points="'+ ' '.join(f'{x:.1f},{y:.1f}' for x,y in p)+f'" fill="none" stroke="{c}" stroke-width="{sw}" stroke-linejoin="round" stroke-linecap="round" {f"stroke-dasharray={chr(34)}{dash}{chr(34)}" if dash else ""}/>')
 def circle(self,x,y,r,c,stroke='none',sw=1):self.add(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{c}" stroke="{stroke}" stroke-width="{sw}"/>')
 def ell(self,x,y,rx,ry,c):self.add(f'<ellipse cx="{x}" cy="{y}" rx="{rx}" ry="{ry}" fill="{c}"/>')
 def text(self,x,y,t,size,c,weight=700):self.add(f'<text x="{x}" y="{y}" fill="{c}" font-family="DejaVu Sans,sans-serif" font-weight="{weight}" font-size="{size}" text-anchor="middle">{html.escape(t)}</text>')
 def grad(self,n,c,d,rad=False):self.defs.append(f'<{ "radialGradient" if rad else "linearGradient"} id="{n}" '+('cx="35%" cy="25%" r="78%"' if rad else 'x1="0" y1="0" x2="0.8" y2="1"')+f'><stop stop-color="{c}"/><stop offset="1" stop-color="{d}"/></'+('radialGradient' if rad else 'linearGradient')+'>');return f'url(#{n})'
 def noise(self,c='#ffffff',n=250,opacity=.18):
  self.add(f'<g opacity="{opacity}">');
  for _ in range(n):
   x=self.r.randrange(W);y=self.r.randrange(H);self.line([(x,y),(x+self.r.randrange(2,8),y+self.r.randrange(-3,4))],c,self.r.choice([.5,1,1.5]))
  self.add('</g>')
 def save(self,p):
  svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}"><defs>{"".join(self.defs)}</defs>{"".join(self.a)}</svg>'
  img=Image.open(io.BytesIO(cairosvg.svg2png(bytestring=svg.encode()))).convert('RGB');img.save(p,'WEBP',quality=83,method=4)
def shade(c,k):return '#'+''.join(f'{max(0,min(255,int(int(c[j:j+2],16)*k))):02x}' for j in (1,3,5))
def iso(a,mode='full',palette=None):
 pal=palette or ['#76a86a','#b4c879','#e6b881','#d37155','#f2e2bf','#2c6a78']; ground,trees,wall,roof,road,water=pal
 a.rect(0,0,W,H,a.grad('sea',shade(water,1.35),shade(water,.57)))
 scale=1.0 if mode=='box' else 1.8; ox=320;oy=124 if mode=='box' else 43
 def P(x,y,z=0):return (ox+(x-y)*scale,oy+(x+y)*.49*scale-z*scale)
 def face(points,c):a.poly([P(*p) for p in points],c)
 def block(x,y,w,d,h,c,top=None):
  face([(x,y+d,0),(x+w,y+d,0),(x+w,y+d,h),(x,y+d,h)],shade(c,.72));face([(x+w,y,0),(x+w,y+d,0),(x+w,y+d,h),(x+w,y,h)],shade(c,.88));face([(x,y,h),(x+w,y,h),(x+w,y+d,h),(x,y+d,h)],top or shade(c,1.2))
 size=238 if mode=='box' else 320; x0=-100 if mode=='box' else -45;y0=x0
 if mode=='box':
  face([(x0,y0+size,0),(x0+size,y0+size,0),(x0+size,y0+size,-48),(x0,y0+size,-48)],'#79513b');face([(x0+size,y0,0),(x0+size,y0+size,0),(x0+size,y0+size,-48),(x0+size,y0,-48)],'#aa7950');
 face([(x0,y0,0),(x0+size,y0,0),(x0+size,y0+size,0),(x0,y0+size,0)],ground)
 for x,y in [(x0+10,y0+100),(x0+130,y0+12)]:
  face([(x,y,0),(x+size-20,y,0),(x+size-20,y+25,0),(x,y+25,0)],road)
  for j in range(8):
   a.line([P(x+j*28,y+12,.5),P(x+j*28+12,y+12,.5)],'#fff4cf',1.8)
 # Draw back to front.
 buildings=[(-45,-45,38,38,40), (17,-42,46,36,62),(73,-34,38,40,34),(-58,50,40,36,32),(0,55,45,37,42),(74,55,42,35,54),(-55,122,38,35,32),(25,121,40,35,48)]
 if mode!='box':buildings += [(140,0,42,38,52),(150,81,45,35,56),(95,145,43,40,38)]
 for j,(x,y,w,d,h) in enumerate(sorted(buildings,key=lambda b:b[0]+b[1])):
  c=wall if j%2 else shade(wall,1.12);block(x,y,w,d,h,c,roof if j%3==0 else shade(c,1.18));
  for zz in range(10,h-4,13):
   for xx in range(x+5,x+w-6,13):face([(xx,y+d+.2,zz),(xx+7,y+d+.2,zz),(xx+7,y+d+.2,zz+7),(xx,y+d+.2,zz+7)],'#426574')
  for zz in range(10,h-4,13):
   for yy in range(y+5,y+d-6,13):face([(x+w+.2,yy,zz),(x+w+.2,yy+7,zz),(x+w+.2,yy+7,zz+7),(x+w+.2,yy,zz+7)],'#5b858e')
  if j%3==0:
   face([(x,y,h),(x+w,y,h),(x+w,y+d/2,h+12),(x,y+d/2,h+12)],shade(roof,1.16));face([(x,y+d/2,h+12),(x+w,y+d/2,h+12),(x+w,y+d,h),(x,y+d,h)],shade(roof,.85))
 for x,y in [(-72,-30),(-75,24),(-65,108),(54,105),(106,106),(124,38),(114,-42),(4,169),(68,169),(167,138)]:
  if mode=='box' and (x>136 or y>136):continue
  px,py=P(x,y);a.ell(px,py+1,10*scale,4*scale,shade(ground,.73));a.line([(px,py),(px,py-13*scale)],'#765339',3*scale);a.circle(px,py-16*scale,9*scale,shade(trees,.8));a.circle(px-3*scale,py-19*scale,6*scale,trees)
 for x,y,c in [(-25,12,'#d85647'),(61,12,'#3c7198'),(25,111,'#e3b137')]:block(x,y,18,9,7,c)
 if mode=='box':
  for j in range(9):a.line([(45+j*61,320+(j%3)*9),(70+j*61,320+(j%3)*9)],'#5c9ca1',1)
def hills(a,p,kind='flat'):
 sky,far,mid,ground,sun,accent=p
 a.rect(0,0,W,H,a.grad('sky',sky,shade(sky,.85)) if kind not in ('flat','pixel','sketch') else sky)
 a.circle(489,78,43,sun)
 if kind=='pixel':
  for i in range(10):a.rect(30+i*64,70+(i%3)*10,32,12,'#f9e8bf')
  for layer,c in enumerate([far,mid,ground]):
   for x in range(0,W,16):
    y=int((145+layer*44+math.sin(x/65+layer)*42)/16)*16;a.rect(x,y,16,H-y,c)
 else:
  for i,c in enumerate([far,mid,ground]):
   points=[(0,H)]+[(x,150+i*48+math.sin(x/78+i*1.3)*42+math.cos(x/37+i)*12) for x in range(-10,660,20)]+[(W,H)];a.poly(points,c,shade(c,.8) if kind=='ink' else 'none',1.8)
 a.poly([(270,360),(393,360),(357,245),(315,220),(300,220),(320,257)],accent)
 for i in range(10):
  x=22+i*66;y=240+int(math.sin(i*2)*32);scale=.7+(i%3)*.24
  if kind=='low':a.poly([(x-17*scale,y),(x,y-60*scale),(x+18*scale,y)],shade(mid,.8));a.poly([(x,y-60*scale),(x,y),(x+18*scale,y)],shade(mid,1.25))
  elif kind=='pixel':a.rect(x-7,y-30,14,28,shade(mid,.7));a.rect(x-13,y-22,26,16,shade(mid,.9));a.rect(x-2,y,4,12,'#735335')
  else:a.line([(x,y+5),(x,y-19)],shade(ground,.55),4);a.ell(x,y-29,18*scale,26*scale,shade(mid,.8));a.ell(x-5,y-34,12*scale,20*scale,mid)
 if kind in ('paint','water','film','ink','sketch','paper','crayon'):a.noise('#ffffff' if kind not in ('sketch','ink') else '#29221e',700,.14)
def character(a,p,kind):
 bg,ground,skin,hair,shirt,accent=p;a.rect(0,0,W,H,a.grad('back',bg,shade(bg,.65)));a.ell(320,322,225,42,ground)
 for x in (80,570):a.rect(x-10,128,20,170,shade(ground,.7),5);a.ell(x,128,44,66,shade(ground,1.15))
 if kind=='stick':
  a.circle(320,95,42,'none','#ffffff',7);a.line([(320,138),(320,225),(268,307)],'#ffffff',8);a.line([(320,225),(380,307)],'#ffffff',8);a.line([(232,175),(320,160),(405,135)],'#ffffff',8);return
 outline='#283543' if kind in ('anime','comic','rubber','flat','chibi') else 'none';sw=3
 for x in (272,346):a.rect(x,237,29,64,shade(shirt,.55),12,outline,sw);a.ell(x+13,302,28,12,shade(hair,.8))
 a.line([(254,179),(216,218),(193,183)],skin,27);a.line([(384,180),(423,211),(449,165)],skin,27)
 a.rect(249,151,142,101,a.grad('shirt',shade(shirt,1.25),shade(shirt,.7),True) if kind not in ('anime','comic','flat','chibi','rubber','paper') else shirt,40,outline,sw)
 r=69 if kind in ('chibi','clay','felt','toy') else 56;a.circle(320,104,r+6,hair,outline,sw);a.circle(320,116,r,a.grad('skin',shade(skin,1.08),shade(skin,.72),True) if outline=='none' else skin,outline,sw)
 a.poly([(264,82),(278,48),(333,40),(369,65),(380,101),(346,77),(319,94),(294,73),(266,110)],hair,outline,sw)
 for x in (298,343):a.ell(x,112,11 if kind in ('anime','chibi') else 7,14,'#fffdf1');a.ell(x+1,114,5,9,'#283543');a.circle(x-1,109,2,'#ffffff')
 a.line([(305,142),(319,148),(335,141)],shade(skin,.48),3);a.circle(286,132,7,'#db907b');a.circle(354,132,7,'#db907b')
 if kind=='felt':
  a.line([(262,196),(264,227),(282,242),(350,242),(380,226)],'#eee0d1',2,'5 5');a.noise('#e9d9c8',1200,.3)
 if kind=='clay':a.noise('#fff5d8',500,.14)
 if kind=='comic':
  for y in range(10,340,12):
   for x in range(15,630,12):
    if x<180 or x>460:a.circle(x,y,1.8,shade(bg,.65))
def tech(a,kind):
 a.rect(0,0,W,H,a.grad('tech','#26394a','#101d31'));cols=['#68d4cb','#ecc86b','#e87561','#78a8e4'];
 if kind=='type':
  a.text(320,121,'GERAK',74,'#f6f1d9');a.rect(90,151,460,62,'#54cfc5',8);a.text(320,197,'RITME',56,'#14283e');a.text(320,274,'VISUAL',48,'#ecc86b');return
 if kind in ('cut','explode','science'):
  for j in range(4):
   x=127+j*123;y=180+(j%2)*12;r=59-j*6
   a.ell(x,y+15,r,30,shade(cols[j],.55));a.rect(x-r,y-13,r*2,28,shade(cols[j],.75),8);a.ell(x,y-14,r,32,cols[j]);a.ell(x,y-14,r*.5,14,'#223747');
   if j<3:a.line([(x+r,y+4),(x+118-r,y+4)],'#dfeef0',2,'5 6')
   if kind=='cut':a.poly([(x,y-14),(x+r,y-14),(x+r,y+14),(x,y+14)],'#d77d64','#f7caa6',2)
  return
 for j in range(3):
  x=112+j*208;a.circle(x,152,66,shade(cols[j],.65));a.circle(x,140,56,cols[j]);
  if j==0:a.rect(x-26,117,52,48,'#213347',6);a.rect(x-18,106,36,12,'#ffffff',3)
  elif j==1:
   for k in range(4):a.rect(x-30+k*17,160-k*12,11,14+k*12,'#263b4b',2)
  else:a.line([(x-28,140),(x-5,163),(x+32,116)],'#233745',10)
  a.rect(x-46,236,92,8,'#c3d3db',4);a.rect(x-30,253,60,5,'#7693a4',3)
  if j<2:a.line([(x+72,142),(x+135,142),(x+124,133)],'#e8e8d0',3)
 if kind=='3d':
  for j in range(4):a.circle(50+j*180,315,9,cols[j])
def mapart(a,kind):
 a.rect(0,0,W,H,a.grad('ocean','#254e69','#122a3f'));land=[(66,82),(130,46),(214,74),(254,50),(320,93),(360,65),(435,91),(478,133),(558,155),(560,226),(491,248),(445,299),(380,257),(330,289),(273,238),(216,274),(155,225),(87,210),(44,150)]
 if kind=='satellite':
  a.circle(320,179,160,'#0b263e');a.circle(320,175,150,a.grad('earth','#4b9bb0','#154568',True));a.add('<clipPath id="globe"><circle cx="320" cy="175" r="150"/></clipPath><g clip-path="url(#globe)">');land=[(320+(x-320)*.66,175+(y-180)*.9) for x,y in land]
 a.poly(land,'#86975c' if kind!='dark' else '#36546b','#e3d8af',2)
 if kind=='geo':
  for i in range(6):
   x=120+i*70;y=138+int(math.sin(i)*30);a.poly([(x-35,y-35),(x+32,y-45),(x+39,y+30),(x-23,y+42)],['#8bb79a','#eac46d','#d87e62','#87a7bc','#c7b675','#5f998b'][i],'#233d4a',2)
 elif kind=='topo':
  for j in range(12):
   p=[(320+math.cos(t/24*math.tau)*(210-j*13)*(1+.12*math.sin(t)),175+math.sin(t/24*math.tau)*(120-j*8)) for t in range(25)];a.poly(p,shade('#a8b779',.65+j*.045),'#e1d8ad',1)
 elif kind=='cross':
  a.rect(0,0,W,H,'#a3c2cc');a.poly([(0,130),(110,90),(205,150),(285,57),(385,136),(510,73),(640,125),(640,360),(0,360)],'#798b5b');
  for i,c in enumerate(['#bc935f','#96714e','#795b50','#584b58','#cc7652']):a.poly([(0,165+i*36),(160,150+i*34),(320,178+i*30),(480,154+i*34),(640,164+i*36),(640,360),(0,360)],c)
 elif kind=='route':
  p=[(110,147),(213,184),(281,110),(386,160),(485,222)];a.line(p,'#fbe6a1',5,'8 5');
  for x,y in p:a.circle(x,y,8,'#f6c854','#fff1c9',2)
 else:
  for i in range(8):
   x=110+i*58;y=140+int(math.sin(i*1.4)*55);a.line([(x,94),(x-12,y),(x+25,236)],'#b3bc9c',1.5);a.circle(x,y,4,'#ead69b')
 if kind=='satellite':a.add('</g>')
 if kind=='atlas':a.noise('#5e4d31',1100,.26)
 if kind!='cross':
  a.line([(584,68),(584,25),(575,41),(584,25),(593,41)],'#f5eac9',2);a.text(584,19,'N',13,'#f5eac9')
# Each index corresponds to the exact preset list, not a shared generic placeholder.
flat=['#a7d9d4','#729fa4','#427d81','#2d5968','#f9cd78','#e8aa66'];warm=['#f2d8ac','#acb7a3','#719b87','#466e60','#f5c36c','#dfaa7c'];night=['#24334d','#48536b','#3b5361','#1a3645','#e6d99c','#a27273'];ink=['#e7d8b9','#b9ad91','#8e8b7c','#55564f','#f5e7cc','#c4b6a0'];neon=['#20234c','#483786','#5a359c','#30245c','#ffb268','#f34eb1'];char=['#b6cfb8','#799b83','#efb78c','#4b3a36','#4b96ac','#f6cc6c'];
for i,name in enumerate(names):
 a=Art(i)
 if name=='Semua':
  for j,c in enumerate(['#407d84','#b16c6c','#8c85b3','#cda264']):a.rect((j%2)*320,(j//2)*180,320,180,c);a.circle((j%2)*320+160,(j//2)*180+85,48,shade(c,1.4));a.poly([((j%2)*320+85,(j//2)*180+155),((j%2)*320+158,(j//2)*180+55),((j%2)*320+238,(j//2)*180+155)],shade(c,.7))
 elif name in ['3D Isometrik','Isometric 3D Cinematic','Isometric 3D Diorama','Isometric 3D Hybrid','Isometric Geo City','Papercraft Isometric','Clay Diorama','Arsitektur 3D','Toy Brick Animation']:
  box=name in ['3D Isometrik','Isometric 3D Diorama','Clay Diorama','Papercraft Isometric'];iso(a,'box' if box else 'full', ['#a9b68a','#d5c484','#e6c49d','#a78168','#e6ddbd','#557c86'] if name=='Papercraft Isometric' else ['#709a74','#7cb48f','#c0c5cf','#486881','#d6d8d2','#244b61'] if name=='Arsitektur 3D' else ['#65a359','#75b349','#e4c071','#ce5c42','#c0c9c5','#4589a1'] if name=='Toy Brick Animation' else None)
  if name=='Isometric 3D Hybrid':
   b=Art(i);iso(b,'box');# inset picture demonstrates opening vs full
   a.add('<g transform="translate(14 12) scale(.35)">');a.rect(-5,-5,650,370,'#f1e3c8',10);a.a.extend(b.a);a.defs.extend(x.replace('id="sea"','id="sea2"') for x in b.defs);a.a[-len(b.a):]=[x.replace('url(#sea)','url(#sea2)') for x in b.a];a.add('</g>')
  if name in ['Clay Diorama','Papercraft Isometric']:a.noise('#f5ddbd',350,.2)
 elif name in ['Satellite Earth Cinematic','3D Topographic Terrain','Geopolitical Dark Map','Historical Atlas Animation','Geo Data Visualization','Cinematic Route Map','Geological Cross Section']:
  mapart(a,{'Satellite Earth Cinematic':'satellite','3D Topographic Terrain':'topo','Geopolitical Dark Map':'dark','Historical Atlas Animation':'atlas','Geo Data Visualization':'geo','Cinematic Route Map':'route','Geological Cross Section':'cross'}[name])
 elif name in ['Motion Graphic 3D','Motion Graphic Edukasi','Kinetic Typography','Infografis 3D','Edu Sains Minimalis','Scientific 3D Cutaway','Exploded View 3D','2D Flat Vector Motion Graphic','Motion Graphic 2D','Flat Motion Graphic']:
  tech(a,{'Kinetic Typography':'type','Scientific 3D Cutaway':'cut','Exploded View 3D':'explode','Edu Sains Minimalis':'science','Motion Graphic 3D':'3d','Infografis 3D':'3d'}.get(name,'flat'))
 elif name in ['Komik / Manhwa','3D Clay Lucu','3D Edukasi Pastel','Anime','Stickman Putih','Animasi 2D Chibi','Kartun 2D Flat','Kartun 3D Stylized','Stop Motion Plastisin','Boneka Kertas','Anime Slice of Life','Anime Petualangan','Komik Halftone','Puppet Felt','Kartun Rubber Hose','Claymation 3D','Cinematic 3D Cartoon','Graphic Novel Cinematic','Cinematic Anime','Paper Cut Animation','Kolase Kertas']:
  kind='clay' if any(k in name for k in ['Clay','Plastisin']) else 'felt' if 'Felt' in name else 'stick' if 'Stickman' in name else 'comic' if any(k in name for k in ['Komik','Graphic Novel']) else 'anime' if 'Anime' in name else 'chibi' if 'Chibi' in name else 'rubber' if 'Rubber' in name else 'paper' if any(k in name for k in ['Kertas','Paper']) else 'flat' if '2D' in name else 'toy';p=char.copy();p[0]=['#c4d5b8','#b0c4dc','#e1bba0','#97bcb5','#c7b7d6'][i%5];p[4]=['#448fa7','#b36e69','#7c8cba','#75956a','#bc985a'][i%5];
  if kind=='stick':p[0]='#243140';p[1]='#192331'
  if kind=='rubber':p=['#a7a69b','#70746d','#dcd7c7','#252b30','#a5a59b','#ddd1b9']
  character(a,p,kind)
 elif name in ['Makro Realistis','Visual ASMR Detail','Tiny World Macro']:
  a.rect(0,0,W,H,a.grad('macro','#395b50','#102a31'));a.ell(320,280,260,58,'#213e3e');a.ell(320,175,196,110,a.grad('leaf','#a6ca79','#347453',True));a.line([(125,211),(510,135)],'#d3e3a6',4)
  for j in range(11):
   x=150+j*30;y=205-j*6;a.line([(x,y),(x-12,y-40)],'#80aa72',2)
  for j in range(13):
   x=a.r.randint(185,450);y=a.r.randint(110,225);r=a.r.randint(5,22);a.circle(x,y,r,a.grad('drop'+str(j),'#e0f1db','#508e79',True));a.circle(x-r*.32,y-r*.35,r*.2,'#ffffff')
  if name=='Tiny World Macro':
   for x,y in [(253,211),(385,180),(421,219)]:a.circle(x,y-20,5,'#f1c268');a.line([(x,y-15),(x,y),(x-6,y+13)],'#e28b49',5);a.line([(x,y),(x+7,y+13)],'#3a5462',4);a.line([(x-8,y-10),(x+8,y-12)],'#df9d59',4)
 else:
  p=warm.copy();kind='flat'
  if name in ['Pixel Art Retro']:kind='pixel';p=['#79b5cb','#8b9cc4','#4a9b89','#2d6f65','#f7de86','#c39c78']
  elif name in ['3D Low Poly','Low Poly 3D']:kind='low';p=flat
  elif any(k in name for k in ['Misteri','Horor','Noir']):p=night;kind='film'
  elif name in ['Cyberpunk Neon','Flat Neon','Sci-Fi Retro']:p=neon;kind='film'
  elif name in ['Pensil Sketsa','Classical Engraving']:p=ink;kind='sketch'
  elif name in ['Cat Air Dongeng','Lukisan Minyak','Cat Krayon Anak']:kind={'Cat Air Dongeng':'water','Lukisan Minyak':'paint','Cat Krayon Anak':'crayon'}[name];p=warm
  elif name in ['Realis Sinematik','Gaya Film Dokumenter','Cinematic Hyperrealistic','Cinematic Teal Orange','VHS Nostalgia','Sinema Drone','Timelapse Alam','Sejarah Sinematik']:p=['#7c9fac','#8b9e9d','#4e7776','#2d514b','#f7c888','#c59a72'];kind='film'
  elif name in ['Fantasi Epik','Fantasi Hutan','Cerita Rakyat Nusantara']:p=['#9196bd','#8ba6a4','#477a69','#284d53','#f2ce9b','#ad9271'];kind='paint'
  # distinct palette grading for close variants
  if name=='Noir Hitam Putih':p=['#868a8e','#777d83','#555b63','#30363d','#d5d7d8','#92999d']
  if name=='VHS Nostalgia':p=['#9c819c','#a49aa3','#5e7b77','#495d65','#e6b3a4','#b1a797']
  if name=='Cinematic Teal Orange':p=['#6e9fa7','#527f87','#3f666d','#28515d','#ffb474','#cf9264']
  hills(a,p,kind)
  if name=='VHS Nostalgia':
   for y in range(0,H,5):a.line([(0,y),(W,y)],'#84939a',.7)
  if name=='Timelapse Alam':
   for j in range(4):a.circle(100+j*125,45+abs(j-1.5)*18,14,'#e9cf97')
  if name=='Cyberpunk Neon':
   for j in range(9):
    x=j*75;h=80+(j*37)%120;a.rect(x,360-h,54,h,'#181c38');
    for y in range(365-h,350,17):a.rect(x+8,y,36,4,'#65cce2' if j%2 else '#f559b1')
  if name=='Pensil Sketsa':
   for j in range(90):x=a.r.randint(0,640);y=a.r.randint(200,360);a.line([(x,y),(x+12,y-8)],'#736d60',.7)
  # Style-specific design treatments, avoiding identical artwork for closely related presets.
 if name in ['2D Flat Vector Motion Graphic','Motion Graphic 2D','Flat Motion Graphic','Motion Graphic Edukasi']:
  a.a=[];a.rect(0,0,W,H,{'2D Flat Vector Motion Graphic':'#f5e8d2','Motion Graphic 2D':'#182f4b','Flat Motion Graphic':'#e6ddd1','Motion Graphic Edukasi':'#edf1e6'}[name])
  if name=='2D Flat Vector Motion Graphic':
   for j,c in enumerate(['#3f8d91','#d97b55','#e9b84e']):
    x=112+j*208;a.circle(x,150,62,c);a.rect(x-28,132,56,36,'#f8efe1',3);a.rect(x-14,115,28,18,'#f8efe1',3);a.rect(x-42,238,84,8,'#385b65',4)
    if j<2:a.line([(x+70,150),(x+136,150),(x+125,140)],'#385b65',4)
  elif name=='Motion Graphic 2D':
   for j,c in enumerate(['#e5c56a','#6bd0bf','#eb8669','#8ca8e5']):
    x=95+j*150;y=175+int(35*math.sin(j*2));a.circle(x,y,54,c);a.circle(x,y,26,'#182f4b');a.line([(x,y-80),(x+25,y-100)],c,5)
  elif name=='Flat Motion Graphic':
   a.rect(56,50,235,255,'#2a5861',15);a.poly([(83,249),(151,112),(224,249)],'#f1bf68');a.circle(215,103,42,'#db7b59');a.rect(335,70,248,22,'#2a5861',5);a.rect(335,112,170,10,'#879f97',4);a.rect(335,135,210,10,'#879f97',4);a.rect(335,188,195,80,'#e6b85e',6)
  else:
   for j,(c,hh) in enumerate(zip(['#71a6a0','#e3b766','#d47b5e','#7897bb'],[55,98,145,215])):a.rect(78+j*88,286-hh,58,hh,c,4)
   a.line([(54,290),(466,290)],'#3c5960',3);a.circle(532,118,58,'#d8e3d9');a.poly([(532,118),(532,60),(585,140)],'#d47b5e');a.rect(479,207,106,9,'#80958d',4)
 if name=='Infografis 3D':
  a.a=[];a.rect(0,0,W,H,'#25394c');
  for j,hh in enumerate([70,110,165,228]):
   x=95+j*140;y=300-hh;c=['#61b5a7','#e3b66b','#d87966','#7898cb'][j];a.poly([(x,y),(x+26,y-17),(x+100,y-17),(x+74,y)],shade(c,1.2));a.rect(x,y,74,hh,c);a.poly([(x+74,y),(x+100,y-17),(x+100,283),(x+74,300)],shade(c,.7))
 if name=='Isometric 3D Diorama':
  a.a=[];a.defs=[];iso(a,'box',['#7a9b6e','#9ab36e','#ddd1b7','#607f91','#d9c7a8','#34566a'])
 if name=='Isometric Geo City':
  a.a=[];a.defs=[];iso(a,'full',['#789f84','#90b292','#c5d2c8','#7c8fa1','#d9dfd5','#407785']);a.line([(10,178),(160,107),(305,181),(455,107),(620,186)],'#f1c96e',3,'7 5')
 if name in ['Cat Air Dongeng','Lukisan Minyak','Cat Krayon Anak']:
  if name=='Cat Air Dongeng':
   a.add('<g opacity=".16">');
   for j in range(65):a.ell(a.r.randint(0,640),a.r.randint(70,340),a.r.randint(8,34),a.r.randint(4,18),'#f6e1ad')
   a.add('</g>')
  elif name=='Lukisan Minyak':a.noise('#f1c999',2300,.28)
  else:
   a.noise('#be8a55',1800,.38);a.circle(489,78,43,'#f0bf53','#d5a84f',4)
 if name in ['Fantasi Epik','Sejarah Sinematik','Cerita Rakyat Nusantara']:
  c='#c0a582' if name=='Sejarah Sinematik' else '#c4ac82' if name=='Cerita Rakyat Nusantara' else '#9d9cba';x=350;y=185
  if name=='Cerita Rakyat Nusantara':
   a.rect(x-70,y-12,140,65,c);a.poly([(x-100,y-13),(x-78,y-31),(x-58,y-72),(x,y-48),(x+58,y-72),(x+78,y-31),(x+100,y-13)],'#704d4b');a.rect(x-12,y+12,24,40,'#594d41')
  else:
   a.rect(x-66,y-60,132,112,c);a.rect(x-88,y-88,36,140,shade(c,.85));a.rect(x+52,y-88,36,140,shade(c,.85));a.poly([(x-93,y-88),(x-70,y-132),(x-47,y-88)],shade(c,.7));a.poly([(x+47,y-88),(x+70,y-132),(x+93,y-88)],shade(c,.7));a.rect(x-16,y+6,32,46,'#414b50',12)
 if name=='Fantasi Hutan':
  for j in range(12):a.circle(40+j*48,140+int(65*math.sin(j*2)),2+(j%3),'#f4d987')
 if name=='Sci-Fi Retro':
  a.ell(335,115,76,17,'#d2b3e5');a.ell(335,104,35,22,'#80c8e1');a.ell(335,119,65,8,'#d891c6');a.poly([(300,127),(370,127),(428,315),(244,315)],'#7c68a1')
 if name=='Misteri Gelap':
  a.rect(318,178,45,64,'#172630');a.poly([(300,178),(340,143),(380,178)],'#131d29');a.rect(331,194,14,16,'#e3b77b')
 if name=='Horor Atmosferik':
  a.add('<g opacity=".25">');
  for j in range(6):a.ell(100+j*110,249+(j%2)*17,110,24,'#ccd7d4')
  a.add('</g>')
 if name in ['Anime Petualangan','Cinematic Anime','Anime Slice of Life','Anime']:
  if name=='Anime Petualangan':a.line([(444,165),(490,80)],'#f1dfb8',8);a.line([(430,153),(457,168)],'#806c52',6)
  if name=='Anime Slice of Life':a.rect(470,210,70,40,'#d9ad87',5);a.ell(505,207,35,6,'#faf0d6')
  if name=='Cinematic Anime':a.add('<g opacity=".19">');a.poly([(0,0),(250,0),(640,360),(400,360)],'#fbe8a9');a.add('</g>')
 if name=='3D Low Poly':a.poly([(0,220),(100,98),(190,220)],'#80a2a4');a.poly([(100,98),(100,220),(190,220)],'#608d92')
 if name=='Low Poly 3D':a.poly([(420,195),(510,76),(624,195)],'#90aeb0');a.poly([(510,76),(510,195),(624,195)],'#628e90')
 if name=='Kolase Kertas':
  a.poly([(10,280),(145,235),(205,290),(55,350)],'#e4c59c');a.poly([(430,300),(550,235),(640,310),(510,350)],'#a6b5a0');a.noise('#e7d9b8',400,.19)
 if name=='Claymation 3D':a.ell(435,280,38,20,'#e6c07e');a.circle(435,255,25,'#e6c07e');a.noise('#ffffff',500,.13)
 if name=='Cinematic 3D Cartoon':a.add('<g opacity=".15">');a.poly([(0,0),(180,0),(460,360),(220,360)],'#fff0c9');a.add('</g>')
 if name=='3D Edukasi Pastel':a.rect(450,105,125,92,'#f2e4cd',8);a.circle(478,145,14,'#6eb8b1');a.rect(503,132,50,10,'#9faca8',3);a.rect(503,153,38,10,'#9faca8',3)
 if name=='Edu Sains Minimalis':a.line([(90,280),(550,280)],'#c0d7db',2);a.text(320,315,'A → B → C → D',20,'#d7e4df')
 if name=='Classical Engraving':
  for j in range(0,640,12):a.line([(j,360),(j+80,270)],'#817261',.8)
 if name=='Sinema Drone':a.add('<g opacity=".8">');a.line([(270,360),(393,360),(357,245),(315,220)],'#e1c9a0',6);a.add('</g>')
 if name=='Cinematic Hyperrealistic':a.noise('#d7d4bb',1800,.13)
 if name=='Gaya Film Dokumenter':a.noise('#ede4cb',450,.09)
 if name=='Realis Sinematik':a.noise('#c1dccb',800,.1)
 a.save(folder/f'{i+1:02d}.webp')
(root/'style-preview.js').write_text('/* Offline reference artwork, not output from a generation provider. */\n(function(root){const names='+json.dumps(names,ensure_ascii=False)+';const files=Object.freeze(Object.fromEntries(names.map((name,i)=>[name,"style-previews/"+String(i+1).padStart(2,"0")+".webp"])));const api=Object.freeze({get(name){return Object.prototype.hasOwnProperty.call(files,name)?files[name]:null},names:Object.freeze(names)});if(typeof module==="object"&&module.exports)module.exports=api;else root.KFStylePreview=api;})(typeof globalThis!=="undefined"?globalThis:this);\n')
print('Generated',len(names),'images')
